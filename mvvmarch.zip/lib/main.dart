import 'package:flutter/material.dart';
import 'package:mvvmarch/utils/routes/routes.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/view/home_view.dart';
import 'package:mvvmarch/view_model/auth_view_model.dart';
import 'package:mvvmarch/view_model/home_view_model.dart';
import 'package:mvvmarch/view_model/second_view_model.dart';
import 'package:mvvmarch/view_model/user_view_model.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

double screenWidth = 0.0;
double screenHeight = 0.0;
SharedPreferences? sharedPreferences;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sharedPreferences = await SharedPreferences.getInstance();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<HomeViewModel>(
        create: (context) => HomeViewModel()),
        ChangeNotifierProvider<SecondViewModel>(
        create: (context) => SecondViewModel()),
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        ChangeNotifierProvider(create: (_) => UserViewModel()),
        // ChangeNotifierProvider(create: (_) => SecondViewModel()),
        // ChangeNotifierProvider(create: (_) => HomeViewModel()),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: RoutesName.splash,
        onGenerateRoute: Routes.generateRoute,
        home: HomeView(),
      ),
    );
  }
}
