import 'package:flutter/material.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/view_model/home_view_model.dart';
import 'package:mvvmarch/view_model/second_view_model.dart';
import 'package:mvvmarch/view_model/user_view_model.dart';
import 'package:provider/provider.dart';

class SecondView extends StatefulWidget {
  const SecondView({Key? key}) : super(key: key);

  @override
  State<SecondView> createState() => _SecondViewState();
}

class _SecondViewState extends State<SecondView> {
  @override
  Widget build(BuildContext context) {
    final secondViewModel=Provider.of<SecondViewModel>(context,listen: false);
    final homeVieMoel=Provider.of<HomeViewModel>(context,listen: false);
    return Scaffold(
        appBar: AppBar(),           
        body: Consumer<SecondViewModel>(builder: (context, value, child) {
          return InkWell(
              onTap: () => value.setString(context),
              child: Column(
                children: [
                  Text('Home : ' + homeVieMoel.name.toString()),
                  Text('Name: ' + value.name.toString()),
                ],
              ));
        }));
  }
}
