import 'package:flutter/material.dart';
import 'package:mvvmarch/res/components/round_button.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/utils/utils.dart';
import 'package:mvvmarch/view_model/auth_view_model.dart';
import 'package:provider/provider.dart';

class LoginView extends StatefulWidget {
  const LoginView({Key? key}) : super(key: key);

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passworController = TextEditingController();
  FocusNode _emailFocusNode = FocusNode();
  FocusNode _passwordFocusNode = FocusNode();
  ValueNotifier<bool> _obsecurePassword = ValueNotifier<bool>(true);
  @override
  void initState() {
    _emailController.text='eve.holt@reqres.in';
    _passworController.text='cityslicka';
    super.initState();
  }
  @override
  void dispose() {
    super.dispose();
    _emailController.dispose();
    _passworController.dispose();

    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();

    _obsecurePassword.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final height = MediaQuery.of(context).size.height * 1;
    return Scaffold(
        body: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextFormField(
          controller: _emailController,
          focusNode: _emailFocusNode,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
              hintText: 'Email',
              labelText: 'Email',
              prefixIcon: Icon(Icons.alternate_email)),
          onFieldSubmitted: (value) {
            Utils.fieldFocusChange(
                context, _emailFocusNode, _passwordFocusNode);
          },
        ),
        ValueListenableBuilder(
            valueListenable: _obsecurePassword,
            builder: (context, bool value, child) {
              return TextFormField(
                controller: _passworController,
                focusNode: _passwordFocusNode,
                obscureText: value,
                obscuringCharacter: "*",
                decoration: InputDecoration(
                  hintText: 'Password',
                  labelText: 'Password',
                  prefixIcon: Icon(Icons.lock_outline_rounded),
                  suffixIcon: InkWell(
                      onTap: () {
                        _obsecurePassword.value = !_obsecurePassword.value;
                      },
                      child: Icon(
                          !value ? Icons.visibility_off : Icons.visibility)),
                ),
              );
            }),
        SizedBox(
          height: height * .1,
        ),
        RoundButton(
            title: 'Login',
            loading: authViewModel.loading,
            onPress: () {
              if (_emailController.text.isEmpty) {
                Utils.flusshBarErrorMsage('Please enter email', context);
              } else if (_passworController.text.isEmpty) {
                Utils.flusshBarErrorMsage('Please enter password', context);
              } else if (_passworController.text.length < 6) {
                Utils.flusshBarErrorMsage(
                    'Please enter 6 digit password', context);
              } else {
                print('Hitted');
                Map data = {
                  "email": _emailController.text,
                  "password": _passworController.text
                };
                authViewModel.loginApi(data, context);
              }
            }),
        SizedBox(
          height: height * .1,
        ),
        InkWell(
            onTap: () {
              Navigator.pushNamed(context, RoutesName.signup);
            },
            child: Text("Don't have an accoount? SignUp"))
      ],
    ));
  }
}
