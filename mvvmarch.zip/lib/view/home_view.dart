import 'package:flutter/material.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/view_model/home_view_model.dart';
import 'package:mvvmarch/view_model/second_view_model.dart';
import 'package:mvvmarch/view_model/user_view_model.dart';
import 'package:provider/provider.dart';

class HomeView extends StatefulWidget {
  const HomeView({Key? key}) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  void initState() {
    // homeViewModel.fetchMoviesListApi();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final userPreferance = Provider.of<UserViewModel>(context);
    final homeViewModel = Provider.of<SecondViewModel>(context, listen: false);

    return Scaffold(
        appBar: AppBar(
          actions: [
            InkWell(
              onTap: () {
                userPreferance.remove().then((value) {
                  Navigator.pushNamed(context, RoutesName.login);
                });
              },
              child: Text('Logout'),
            )
          ],
        ),
        body: Consumer<HomeViewModel>(builder: (context, value, child) {
          // switch (value.loading) {
          //   case true:

          //     return CircularProgressIndicator();
          //   case false:
          //     return ListView.builder(
          //       itemCount: value.movieList!.movies!.length,
          //       itemBuilder: (context, index) => ListTile(
          //          onTap:()=> value.navigateSeconScreen(context, value.movieList!.movies![index].title!),
          //         // leading: Image.network(
          //         //   value.movieList.data!.movies![index].posterurl!,
          //         //   loadingBuilder: (context, _, __) {
          //         //     return CircularProgressIndicator();
          //         //   },
          //         //   errorBuilder: (context, error, stack) {
          //         //     return Icon(Icons.error);
          //         //   },
          //         // ),
          //         title: Text(value.movieList!.movies![index].title!),
          //       ),
          //     );
          // }
          return ListTile(
            onTap: () => value.navigateSeconScreen(
              context,
            ),
            // leading: Image.network(
            //   value.movieList.data!.movies![index].posterurl!,
            //   loadingBuilder: (context, _, __) {
            //     return CircularProgressIndicator();
            //   },
            //   errorBuilder: (context, error, stack) {
            //     return Icon(Icons.error);
            //   },
            // ),
            title: Text(value.name),
          );
          // return Container();
        }));
  }
}
