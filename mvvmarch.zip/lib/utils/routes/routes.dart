import 'package:flutter/material.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/view/home_view.dart';
import 'package:mvvmarch/view/login_view.dart';
import 'package:mvvmarch/view/second_view.dart';
import 'package:mvvmarch/view/signup_view.dart';
import 'package:mvvmarch/view/splash_view.dart';

class Routes {
  static MaterialPageRoute generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RoutesName.login:
        return MaterialPageRoute(
            builder: (BuildContext context) => LoginView());
      case RoutesName.home:
        return MaterialPageRoute(
            builder: (BuildContext context) => HomeView());
      case RoutesName.signup:
        return MaterialPageRoute(
            builder: (BuildContext context) => SignUpView());
      case RoutesName.splash:
        return MaterialPageRoute(
            builder: (BuildContext context) => SplashView());
      case RoutesName.second:
        return MaterialPageRoute(
            builder: (BuildContext context) => SecondView());
      default:
        return MaterialPageRoute(
            builder: (_) => const Scaffold(
                  body: Center(
                    child: Text("No route define"),
                  ),
                ));
    }
  }
}
