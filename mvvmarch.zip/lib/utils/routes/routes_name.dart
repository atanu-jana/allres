class RoutesName{
  // account route name
  static const String  login='login_screen';
  // home route name
  static const String  home='home_screen';
  // second route name
  static const String  second='second_screen';
  // sign up route name
  static const String  signup='signup_screen';
  // splash route name
  static const String  splash='splash_screen';
}