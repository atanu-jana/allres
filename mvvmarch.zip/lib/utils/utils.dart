import 'package:another_flushbar/flushbar.dart';
import 'package:another_flushbar/flushbar_route.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mvvmarch/res/app_colors.dart';
import 'package:mvvmarch/utils/appTexts.dart';
import 'dart:developer' as developer;

class Utils {
  static Future<bool> internetCheck() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      return true;
    } else if (connectivityResult == ConnectivityResult.wifi) {
      return true;
    }
    return false;
  }
//   static showOfflineSnakbar(BuildContext context) {
//     ScaffoldMessenger.of(context).clearSnackBars();

//     return ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: AppColors.greenColor,
//         shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.only(
//           topLeft: Radius.circular(5),
//           topRight: Radius.circular(5),
//         )),
//         content: AppTexts.normalText("No Internet"),
//         duration: Duration(seconds: 1),
//       ),
//     );
//   }
  static showOfflineToastMesage() {
    developer.log('message');
    Fluttertoast.showToast(
        msg: 'No Internet',
        backgroundColor: AppColors.redColor,
        textColor: Colors.white);
  }

  static consoleLog({required String key, required dynamic value}) {
    if (kDebugMode) {
      developer.log('LOG KEY: $key\nLOG VALUE: $value');
    }
  }

  static showOnlineSnakbar(BuildContext context) {
    ScaffoldMessenger.of(context).clearSnackBars();

    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.redColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
          topLeft: Radius.circular(5),
          topRight: Radius.circular(5),
        )),
        content: AppTexts.normalText("Back To Internet"),
        duration: Duration(seconds: 1),
      ),
    );
  }

  static toastMessage(String message) {
    Fluttertoast.showToast(
        msg: message, backgroundColor: Colors.black, textColor: Colors.white);
  }

  static void flusshBarErrorMsage(String message, BuildContext context) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          forwardAnimationCurve: Curves.decelerate,
          margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: EdgeInsets.all(15),
          message: message,
          borderRadius: BorderRadius.circular(20),
          duration: Duration(seconds: 3),
          flushbarPosition: FlushbarPosition.TOP,
          backgroundColor: Colors.red,
          reverseAnimationCurve: Curves.easeInOut,
          icon: Icon(Icons.error, size: 20, color: Colors.white),
        )..show(context));
  }

  static snackBar(String message, BuildContext context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(message)));
  }

  static void fieldFocusChange(BuildContext context, FocusNode currentFocusNode,
      FocusNode nextFocusNode) {
    currentFocusNode.unfocus();
    FocusScope.of(context).requestFocus(nextFocusNode);
  }
}
