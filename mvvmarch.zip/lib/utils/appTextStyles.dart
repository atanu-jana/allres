import 'package:flutter/material.dart';
import 'package:mvvmarch/main.dart';

class AppTextStyles {
  static headingTextStyle(
      {Color color = Colors.white,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.051,
        color: color,
        fontFamily: fontFamily,
        fontWeight: fontWeight);
  }

static  smallHeadingTextStyle(
      {Color color = Colors.white,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.048,
        color: color,
        fontFamily: fontFamily,
        fontWeight: fontWeight);
  }

 static heading2TextStyle(
      {Color color = Colors.white,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.057,
        color: color,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

 static heading3TextStyle(
      {Color color = Colors.white,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.065,
        color: color,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

 static normal2TextStyle(
      {Color color = Colors.white,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      bool lineThrough = false,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.042,
        color: color,
        fontWeight: fontWeight,
        decorationThickness: 3,
        decorationStyle: TextDecorationStyle.solid,
        decoration:
            lineThrough ? TextDecoration.lineThrough : TextDecoration.none,
        fontFamily: fontFamily);
  }

 static normalTextStyle(
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      FontStyle fontStyle = FontStyle.normal,
      double letterSpacing = 0,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.039,
        color: color,
        letterSpacing: letterSpacing,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

static  midNormalTextStyle(
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.037,
        color: color,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

static  smallTextStyle(
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      double letterSpacing = 0,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.034,
        color: color,
        fontWeight: fontWeight,
        letterSpacing: letterSpacing,
        fontFamily: fontFamily);
  }

 static extraSmallTextStyle(
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.031,
        color: color,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

  static lightSmallTextStyle(
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.025,
        color: color,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

 static extraSmallSmallTextStyle(
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.02,
        color: color,
        fontWeight: fontWeight,
        fontFamily: fontFamily);
  }

 static subTitleStyle(
      {Color color = Colors.white, String fontFamily = "NunitoSans-Regular"}) {
    return TextStyle(
        fontSize: screenWidth * 0.032, color: color, fontFamily: fontFamily);
  }
}
