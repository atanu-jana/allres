import 'package:flutter/material.dart';
import 'package:mvvmarch/utils/appTextStyles.dart';

class AppTexts {
  static headingText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.headingTextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

  static smallHeadingText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.smallHeadingTextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

  static heading2Text(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.heading2TextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

 static heading3Text(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.heading3TextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

  static normal2Text(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.normal2TextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

  static normalText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      double letterSpacing = 0,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.normalTextStyle(
          color: color,
          fontWeight: fontWeight,
          letterSpacing: letterSpacing,
          fontFamily: fontFamily),
    );
  }

 static midNormalText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.midNormalTextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

 static smallText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      double letterSpacing = 0,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.smallTextStyle(
          color: color,
          fontWeight: fontWeight,
          letterSpacing: letterSpacing,
          fontFamily: fontFamily),
    );
  }

 static extraSmallText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.extraSmallTextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }

 static lightSmallText(String text,
      {Color color = Colors.white,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.lightSmallTextStyle(
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
 
}
