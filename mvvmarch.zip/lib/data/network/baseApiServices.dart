abstract class BaseApiServices {
  Future<dynamic> getGetApiResponse({required String url});
  Future<dynamic> getPostApiResponse({required String url,required Map body});
  Future<dynamic> postRequestWithToken({required String url,required Map body,required String token});
  Future<dynamic> postRequestWithTokenAndFile({required String url,required Map body,required String token,required String imageKey,required String imagePath});
}
