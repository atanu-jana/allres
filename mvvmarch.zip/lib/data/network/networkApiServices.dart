import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:mvvmarch/data/network/baseApiServices.dart';
import 'package:mvvmarch/utils/utils.dart';

class NetworkApiService extends BaseApiServices {
  @override
  Future getGetApiResponse({required String url}) async {
    if (await Utils.internetCheck()) {
      Utils.consoleLog(key: 'Url: ', value: url.toString());

      try {
        var headers = {'Accept': '*/*', 'Content-Type': 'application/json'};
        var request = http.Request(
          'GET',
          Uri.parse(url),
        );
        request.headers.addAll(headers);

        http.StreamedResponse response =
            await request.send().timeout(const Duration(seconds: 10));

        var jsonData = await response.stream.bytesToString();

        Utils.consoleLog(key: 'Response: ', value: jsonData.toString());

        return jsonData;
      } catch (e) {
        Utils.consoleLog(key: 'Error: ', value: e.toString());
      }
    } else {
      Utils.showOfflineToastMesage();
    }
  }

  @override
  Future getPostApiResponse({required String url, required Map body}) async {
    if (await Utils.internetCheck()) {
      Utils.consoleLog(key: 'Url: ', value: url.toString());
      Utils.consoleLog(key: 'body: ', value: body.toString());

      try {
        var headers = {'Accept': '*/*', 'Content-Type': 'application/json'};
        var request = http.Request(
          'POST',
          Uri.parse(url),
        );
        request.body = json.encode(body);
        request.headers.addAll(headers);

        http.StreamedResponse response =
            await request.send().timeout(const Duration(seconds: 10));

        var jsonData = await response.stream.bytesToString();

        Utils.consoleLog(key: 'Response: ', value: jsonData.toString());

        return jsonData;
      } catch (e) {
        Utils.consoleLog(key: 'Error: ', value: e.toString());
      }
    } else {
      Utils.showOfflineToastMesage();
    }
  }

  @override
  Future postRequestWithToken(
      {required String url, required Map body, required String token}) async {
    if (await Utils.internetCheck()) {
      Utils.consoleLog(key: 'Url: ', value: url.toString());
      Utils.consoleLog(key: 'body: ', value: body.toString());
      Utils.consoleLog(key: 'token: ', value: token.toString());

      try {
        var headers = {
          'Accept': '*/*',
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json'
        };
        var request = http.Request(
          'POST',
          Uri.parse(url),
        );
        request.body = json.encode(body);
        request.headers.addAll(headers);

        http.StreamedResponse response =
            await request.send().timeout(const Duration(seconds: 10));

        var jsonData = await response.stream.bytesToString();

        Utils.consoleLog(key: 'Response: ', value: jsonData.toString());

        return jsonData;
      } catch (e) {
        Utils.consoleLog(key: 'Error: ', value: e.toString());
      }
    } else {
      Utils.showOfflineToastMesage();
    }
  }

  @override
  Future postRequestWithTokenAndFile(
      {required String url,
      required Map body,
      required String token,
      required String imageKey,
      required String imagePath}) async {
    if (await Utils.internetCheck()) {
      Utils.consoleLog(key: 'Url: ', value: url.toString());
      Utils.consoleLog(key: 'body: ', value: body.toString());
      Utils.consoleLog(key: 'token: ', value: token.toString());

      try {
        var headers = {
          'Accept': '*/*',
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json'
        };
        var request = http.MultipartRequest(
          'POST',
          Uri.parse(url),
        );
        request.fields.addAll({
          "individualId": '',
        });
        request.files
            .add(await http.MultipartFile.fromPath('nameParam', 'path'));

        request.headers.addAll(headers);
        http.StreamedResponse response =
            await request.send().timeout(const Duration(seconds: 10));

        var jsonData = await response.stream.bytesToString();

        Utils.consoleLog(key: 'Response: ', value: jsonData.toString());

        return jsonData;
      } catch (e) {
        Utils.consoleLog(key: 'Error: ', value: e.toString());
      }
    } else {
      Utils.showOfflineToastMesage();
    }
  }

  // @override
  // Future getPostApiResponse(String url, dynamic data) async {
  //   dynamic responseJson;
  //   try {
  //     final response = await http
  //         .post(Uri.parse(url), body: data)
  //         .timeout(Duration(seconds: 10));
  //     // responseJson = returnResponse(response);
  //     responseJson = response;
  //   } on SocketException {
  //     throw FetchDataException("No Internet");
  //   }
  //   return responseJson;
  // }

  // dynamic returnResponse(http.Response response) {
  //   switch (response.statusCode) {
  //     case 200:
  //       dynamic responseJson = jsonDecode(response.body);
  //       return responseJson;
  //     case 400:
  //       return BadRequestException(response.body.toString());
  //     case 404:
  //       return UnauthorisedException(response.body.toString());
  //     case 500:
  //     default:
  //       throw FetchDataException(
  //           "Error accured while communicating with server" +
  //               "with statu code" +
  //               response.statusCode.toString());
  //   }
  // }
}
