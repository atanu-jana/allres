import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:mvvmarch/model/movie_model.dart';
import 'package:mvvmarch/repository/home_repository.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/utils/utils.dart';
import 'package:mvvmarch/view_model/second_view_model.dart';
import 'package:provider/provider.dart';
import 'dart:math' as random;
class HomeViewModel with ChangeNotifier {
  final _myRepo = HomeRepository();

  MovieModel? movieList;
  bool _loading = false;
  bool get loading => _loading;
   String _name = '';

  String get name => _name;

  setString(String? val) {

    _name = val!;
    notifyListeners();
  }
  // String get name => _name;

  setLoading(bool value) {
    _loading = value;
    notifyListeners();
  }

  navigateSeconScreen(BuildContext context, ) {
   random. Random randomm = random. Random();
    setString( randomm.nextInt(100).toString());
    notifyListeners();

    Navigator.pushNamed(context, RoutesName.second);
  }

  Future<void> fetchMoviesListApi() async {
    // setLoading(true);
    // _myRepo.fetchMovieApi().then((value) {
    //   movieList = MovieModel.fromJson(jsonDecode(value));
    //   Utils.consoleLog(key: 'homeVal', value: movieList);
    //   notifyListeners();
    //   setLoading(false);
    // }).onError((error, stackTrace) {
    //   setLoading(false);
    // });
  }
}
