import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:mvvmarch/model/user_model.dart';
import 'package:mvvmarch/repository/auth_repository.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/utils/utils.dart';
import 'package:mvvmarch/view_model/user_view_model.dart';
import 'package:provider/provider.dart';

class AuthViewModel with ChangeNotifier {
  final _myRepo = AuthRepository();
  bool _loading = false;
  bool get loading => _loading;

  setLoading(bool value) {
    _loading = value;
    notifyListeners();
  }

  Future<void> loginApi(dynamic data, BuildContext context) async {
    setLoading(true);

    _myRepo.loginApi(data).then((value) {
      Utils.consoleLog(key: 'loginLog', value: value.toString());
      Map jsonData = jsonDecode(value);
      setLoading(false);
      if(jsonData['error']==null){
        Utils.flusshBarErrorMsage("Login Successful", context);
        final uerPreference =
            Provider.of<UserViewModel>(context, listen: false);
        uerPreference.saveUser(UserModel(token: jsonData['token'].toString()));
        Navigator.pushNamed(context, RoutesName.home);
      }else{

      if (jsonData['error'].isNotEmpty) {
        Utils.flusshBarErrorMsage(jsonData['error'].toString(), context);
      }
      }
        

     
    }).onError((error, stackTrace) {
      setLoading(false);

      Utils.consoleLog(key: 'loginLog', value: error.toString());
     
    });
  }

  Future<void> signUpApi(Map body, BuildContext context) async {
    _myRepo.signUpApi(body).then((value) {
      // if (kDebugMode) {
      log(value.toString());
      // }
      Utils.flusshBarErrorMsage("SignUp Successful", context);
      Navigator.pushNamed(context, RoutesName.home);
    }).onError((error, stackTrace) {
      if (kDebugMode) {
        print(error.toString());
      }
    });
  }
}
