import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:mvvmarch/model/movie_model.dart';
import 'package:mvvmarch/repository/home_repository.dart';
import 'package:mvvmarch/utils/routes/routes_name.dart';
import 'package:mvvmarch/utils/utils.dart';
import 'package:mvvmarch/view_model/home_view_model.dart';
import 'package:provider/provider.dart';
import 'dart:math' as random;

class SecondViewModel with ChangeNotifier {
  String _name = '';

  String get name => _name;
  setString(BuildContext context) {
    final homProvider = Provider.of<HomeViewModel>(
      context,
      listen: false,
    );

    // HomeViewModel homeViewModel = HomeViewModel();

    _name = homProvider.name;
    random.Random randomm = random.Random();
    homProvider.setString(randomm.nextInt(100).toString());
    notifyListeners();
  }
}
