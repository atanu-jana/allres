// import 'package:dropdown_button2/dropdown_button2.dart';
// import 'package:flutter/material.dart'; 

// class RoundedDropDownButton extends StatefulWidget {
//   final dynamic selectedValue;
//   final List dropdownList;
//   final String hintText;
//   final double textWidth;
//   final IconData icon;
//   final Function(dynamic value) onChange;
//   final TextEditingController searchTextEditingController;
//   final bool objectType;

//   const RoundedDropDownButton({
//     Key? key,
//     required this.selectedValue,
//     required this.hintText,
//     required this.textWidth,
//     required this.onChange,
//     required this.icon,
//     required this.dropdownList,
//     required this.searchTextEditingController,
//      this.objectType=true,
//   }) : super(key: key);

//   @override
//   _RoundedDropDownButtonState createState() => _RoundedDropDownButtonState();
// }

// class _RoundedDropDownButtonState extends State<RoundedDropDownButton> {
//   @override
//   void initState() {
//     super.initState();
//     setState(() {});
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       child: DropdownButtonHideUnderline(
//         child: DropdownButton2(
//           buttonDecoration: BoxDecoration(
//               color: teleWhite, borderRadius: BorderRadius.circular(100)),
//           isExpanded: true,
//           buttonPadding: MarginPadding.customHorizontal(),
//           itemPadding: MarginPadding.customHorizontal(),
//           hint: smallText(widget.hintText,
//               color: teleGray, fontFamily: "NunitoSans-Regular"),
//           dropdownDecoration: BoxDecoration(
//               color: teleWhite, borderRadius: BorderRadius.circular(10)),
//           items: widget.dropdownList.map((value) {
//             return DropdownMenuItem<dynamic>(
//               value: value,
//               child: Container(
//                 width: widget.textWidth,
//                 child: Text(
//               widget.objectType?    value.name:value,
//                   overflow: TextOverflow.ellipsis,
//                   style: smallTextStyle(color: teleBlack),
//                 ),
//               ),
//             );
//           }).toList(),
//           value: widget.selectedValue,
//           onChanged: widget.onChange,
//           searchController: widget.searchTextEditingController,
//           searchInnerWidget: Padding(
//             padding: const EdgeInsets.only(
//               top: 8,
//               bottom: 4,
//               right: 8,
//               left: 8,
//             ),
//             child: TextFormField(
//               controller: widget.searchTextEditingController,
//               decoration: InputDecoration(
//                   contentPadding: MarginPadding.customMarginSame(),
//                   hintText: 'Search for an item...',
//                   hintStyle: smallTextStyle(color: teleGray),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   suffix: Container(
//                     width: Get.width * 0.1,
//                     alignment: Alignment.center,
//                     child: InkWell(
//                         onTap: () {
//                           widget.searchTextEditingController.clear();
//                           Get.back();
//                         },
//                         child: smallIcon(Icons.close, color: teleGray)),
//                   )),
//             ),
//           ),
//           searchMatchFn: (item, searchValue) {
//             return widget.objectType? (item.value.name.toString().toLowerCase().contains(searchValue.toLowerCase())):(item.value.toString().toLowerCase().contains(searchValue.toLowerCase()));
//           },
//           onMenuStateChange: (isOpen) {
//             if (!isOpen) {
//               widget.searchTextEditingController.clear();
//             }
//           },
//         ),
//       ),
//     );
//     DropdownButtonFormField(
//       items: widget.dropdownList.map((value) {
//         return DropdownMenuItem<dynamic>(
//           value: value,
//           child: Container(
//             width: widget.textWidth,
//             child: Text(
//               value.name,
//               overflow: TextOverflow.ellipsis,
//               style: smallTextStyle(color: teleBlack),
//             ),
//           ),
//         );
//       }).toList(),
//       onChanged: widget.onChange,
//       value: widget.selectedValue,
//       decoration: InputDecoration(
//         errorText: "",
//         counterText: "",
//         filled: true,
//         fillColor: Colors.white,
//         prefixIcon: Icon(widget.icon, color: "".isEmpty ? teleBlue : teleRed),
//         focusedErrorBorder: OutlineInputBorder(
//             borderSide: BorderSide(color: Colors.transparent),
//             borderRadius: BorderRadius.all(Radius.circular(32))),
//         errorBorder: OutlineInputBorder(
//             borderSide: BorderSide(color: Colors.transparent),
//             borderRadius: BorderRadius.all(Radius.circular(32))),
//         focusedBorder: OutlineInputBorder(
//             borderSide: BorderSide(color: Colors.black),
//             borderRadius: BorderRadius.all(Radius.circular(32))),
//         enabledBorder: OutlineInputBorder(
//             borderSide: BorderSide(color: Colors.transparent),
//             borderRadius: BorderRadius.all(Radius.circular(32))),
//         hintText: widget.hintText,
//         hintStyle: TextStyle(
//             fontSize: 13, color: teleGray, fontFamily: "NunitoSans-Regular"),
//         labelStyle: TextStyle(
//             fontSize: 13, color: teleGray, fontFamily: "NunitoSans-Regular"),
//       ),
//     );
//   }
// }
