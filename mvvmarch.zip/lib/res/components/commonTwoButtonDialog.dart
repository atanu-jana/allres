// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:teleradiology/Constants/colors_customer.dart';
// import 'package:teleradiology/Constants/dimensions.dart';
// import 'package:teleradiology/utils/marginPadding.dart';

// commonTwoButtonDialog(String title, String message,
//     {String button1 = "No",
//     String button2 = "Yes",
//     Function()? function1,
//     Function()? function2}) {
//   return Get.defaultDialog(
//       title: title,
//       titleStyle: TextStyle(
//           fontSize: 15, fontFamily: 'NunitoSans-Bold', color: teleBlack),
//       content: Column(
//         children: [
//           Container(
//             padding: MarginPadding.customHorizontal(),
//             child: Text(
//               message,
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                   fontSize: 13,
//                   fontFamily: 'NunitoSans-Bold',
//                   color: teleBlack),
//             ),
//           ),
//           SizedBox(
//             height: ScaleController.H * 0.02,
//           ),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               InkWell(
//                 onTap: function1 ??
//                     () {
//                       Get.back();
//                     },
//                 child: Container(
//                     height: ScaleController.H * 0.05,
//                     width: ScaleController.W * 0.2,
//                     decoration: BoxDecoration(
//                         color: telePurple,
//                         borderRadius: BorderRadius.all(Radius.circular(8))),
//                     child: Center(
//                         child: Text(
//                       button1,
//                       style: TextStyle(
//                           fontSize: 13,
//                           fontFamily: 'OpenSans-Bold',
//                           color: Colors.white),
//                     ))),
//               ),
//               SizedBox(
//                 width: ScaleController.W * 0.05,
//               ),
//               InkWell(
//                 onTap: function2 ??
//                     () {
//                       Get.back();
//                     },
//                 child: Container(
//                     height: ScaleController.H * 0.05,
//                     width: ScaleController.W * 0.2,
//                     decoration: BoxDecoration(
//                         color: telePurple,
//                         borderRadius: BorderRadius.all(Radius.circular(8))),
//                     child: Center(
//                         child: Text(
//                       button2,
//                       style: TextStyle(
//                           fontSize: 13,
//                           fontFamily: 'OpenSans-Bold',
//                           color: Colors.white),
//                     ))),
//               ),
//             ],
//           )
//         ],
//       ));
// }
