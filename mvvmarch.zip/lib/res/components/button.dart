// import 'package:flutter/material.dart';
// import 'package:teleradiology/Constants/dimensions.dart';
// import 'package:teleradiology/utils/allTextStyle.dart';

// Widget button(
//     {required String title,
//     required Color color,
//     required Color textColor,
//     required Function() onTap}) {
//   return InkWell(
//     onTap: onTap,
//     borderRadius: BorderRadius.all(Radius.circular(32)),
//     child: Ink(
//       height: ScaleController.H * 0.08,
//       decoration: BoxDecoration(
//           borderRadius: BorderRadius.all(Radius.circular(32)), color: color),
//       child: Center(
//           child: Text(
//         title,
//         style: normalTextStyle(
//           fontFamily: "NunitoSans",
//           color: textColor,
//           fontWeight: FontWeight.bold,
//         ),
//       )),
//     ),
//   );
// }
