// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:teleradiology/Constants/colors_customer.dart';
// import 'package:teleradiology/Constants/dimensions.dart';
// import 'package:teleradiology/utils/marginPadding.dart';

// commonAlertDialog(String title, message, {Function()? function}) {
//   return Get.defaultDialog(
//       title: title,
//       titleStyle: TextStyle(
//           fontSize: 15, fontFamily: 'NunitoSans-Bold', color: teleBlack),
//       content: Column(
//         children: [
//           Container(
//             padding: MarginPadding.customHorizontal(),
//             child: Text(
//               message,
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                   fontSize: 13,
//                   fontFamily: 'NunitoSans-Bold',
//                   color: teleBlack),
//             ),
//           ),
//           SizedBox(
//             height: ScaleController.H * 0.02,
//           ),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               InkWell(
//                 onTap: function ??
//                     () {
//                       Get.back();
//                     },
//                 child: Container(
//                     height: ScaleController.H * 0.05,
//                     width: ScaleController.W * 0.2,
//                     decoration: BoxDecoration(
//                         color: telePurple,
//                         borderRadius: BorderRadius.all(Radius.circular(8))),
//                     child: Center(
//                         child: Text(
//                       "Ok",
//                       style: TextStyle(
//                           fontSize: 13,
//                           fontFamily: 'OpenSans-Bold',
//                           color: Colors.white),
//                     ))),
//               ),
//               // SizedBox(

//               //   width: ScaleController.W * 0.05,
//               // ),
//               // InkWell(
//               //   onTap: () {
//               //     Get.back();
//               //   },
//               //   child: Container(
//               //       height: ScaleController.H * 0.05,
//               //       width: ScaleController.W * 0.2,
//               //       decoration: BoxDecoration(
//               //           color: teleGray,
//               //           borderRadius:
//               //           BorderRadius.all(
//               //               Radius.circular(
//               //                   8))),
//               //       child: Center(
//               //           child: Text(
//               //             "cancel",
//               //             style: TextStyle(
//               //                 fontSize: 13,
//               //                 fontFamily:
//               //                 'OpenSans-Bold',
//               //                 color: Colors.white),
//               //           ))),
//               // ),
//             ],
//           )
//         ],
//       ));
// }
