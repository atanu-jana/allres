// import 'package:flutter/material.dart';
// import 'package:teleradiology/Constants/colors_customer.dart';

// class RoundedInputField extends StatelessWidget {
//   final String? hintText;
//   final int? maxLength;
//   final IconData? icon;
//   final TextEditingController? controller;
//   final TextInputType? textInputType;
//   final TextInputAction? textInputAction;
//   final bool? enable;
//   final Widget? suffixWidget;
//   final Widget? prefixWidget;
//   final Function(String val)? onchangeFunction;
//   final String? Function(String? val)? validate;
//   RoundedInputField({
//     Key? key,
//     required this.hintText,
//     required this.controller,
//     this.enable = true,
//     this.maxLength = 100,
//     this.icon = Icons.person,
//     this.suffixWidget,
//     this.prefixWidget,
//     required this.textInputType,
//     required this.textInputAction,
//     required this.onchangeFunction,
//     required this.validate,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return TextFormField(
//       enabled: enable,
//       textAlign: TextAlign.start,
//       maxLength: maxLength,
//       keyboardType: textInputType,
//       textInputAction: textInputAction,
//       cursorColor: teleGray,
//       controller: controller,
//       onChanged: onchangeFunction,
//       textAlignVertical: TextAlignVertical.center,
//       validator: validate,
//       autovalidateMode: AutovalidateMode.onUserInteraction,
//       decoration: InputDecoration(
//           counterText: "",
//           prefixIcon: Icon(
//             icon,
//             color: teleGray,
//           ),
//           suffix: suffixWidget,
// prefix: prefixWidget,
//           hintText: hintText,
//           hintStyle: TextStyle(
//               fontSize: 13, color: teleGray, fontFamily: "NunitoSans-Regular"),
//           filled: true,
//           fillColor: Colors.white,
//           focusedErrorBorder: OutlineInputBorder(
//               borderSide: BorderSide(color: Colors.red),
//               borderRadius: BorderRadius.all(Radius.circular(32))),
//           errorBorder: OutlineInputBorder(
//               borderSide: BorderSide(color: Colors.red),
//               borderRadius: BorderRadius.all(Radius.circular(32))),
//           focusedBorder: OutlineInputBorder(
//               borderSide: BorderSide(color: Colors.black),
//               borderRadius: BorderRadius.all(Radius.circular(32))),
//           disabledBorder: OutlineInputBorder(
//               borderSide: BorderSide(color: Colors.transparent),
//               borderRadius: BorderRadius.all(Radius.circular(32))),
//           enabledBorder: OutlineInputBorder(
//               borderSide: BorderSide(color: Colors.transparent),
//               borderRadius: BorderRadius.all(Radius.circular(32)))),
//     );
//   }
// }
