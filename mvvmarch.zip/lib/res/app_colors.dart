import 'package:flutter/material.dart';

class AppColors {
  static const Color blackColor = Color(0xFF000000);
  static const Color whitColor = Color(0xFFFFFFFF);
  static const Color greenColor = Colors.green;
  static const Color redColor = Colors.red;
}
