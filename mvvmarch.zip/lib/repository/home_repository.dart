import 'dart:convert';
import 'dart:developer';

import 'package:mvvmarch/data/network/baseApiServices.dart';
import 'package:mvvmarch/data/network/networkApiServices.dart';
import 'package:mvvmarch/model/movie_model.dart';
import 'package:mvvmarch/res/app_urls.dart';

class HomeRepository {
  BaseApiServices _apiServices = NetworkApiService();

  Future fetchMovieApi() async {
    try {
      dynamic response = await _apiServices.getGetApiResponse(url:AppUrl.moviesUrl);
      return response;
    } catch (e) {
      log(e.toString());
      throw e;
    }
  }
}
