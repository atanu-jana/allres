import 'package:mvvmarch/data/network/baseApiServices.dart';
import 'package:mvvmarch/data/network/networkApiServices.dart';
import 'package:mvvmarch/res/app_urls.dart';

class AuthRepository {
  BaseApiServices _apiServices = NetworkApiService();

  Future<dynamic> loginApi(Map body) async {
    try {
      dynamic response =
          await _apiServices.getPostApiResponse(url: AppUrl.loginUrl,body: body);
      return response;
    } catch (e) {
      return null;
    }
  }

  Future<dynamic> signUpApi(Map body) async {
    try {
      dynamic response =
          await _apiServices.getPostApiResponse(url: AppUrl.registerUrl,body: body);
      return response;
    } catch (e) {
      throw e;
    }
  }
}
