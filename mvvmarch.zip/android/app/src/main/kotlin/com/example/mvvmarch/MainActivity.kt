package com.example.mvvmarch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
