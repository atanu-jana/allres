import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/screens/Splash%20Screen/splashscreen.dart'; 

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBuilder(builder: (context) {
      return GetMaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: SplashScreen());
        });

  }
}
class AppBuilder extends StatefulWidget {
  final Function(BuildContext)? builder;

  const AppBuilder({Key? key, this.builder}) : super(key: key);

  @override
  AppBuilderState createState() => new AppBuilderState();

  static AppBuilderState? of(BuildContext context) {
    // return context.ancestorStateOfType(const TypeMatcher<AppBuilderState>());

    return context.findAncestorStateOfType<AppBuilderState>();
  }
}

class AppBuilderState extends State<AppBuilder> {
  @override
  Widget build(BuildContext context) {
    return widget.builder!(context);
  }

  void rebuild() {
    setState(() {});
  }
}