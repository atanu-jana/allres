import 'package:shared_preferences/shared_preferences.dart';
import 'package:teleradiology/utils/printValidString.dart';

Future<void> setUserType(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('userType', printValidStringWithEmpty(value));
}

Future<String?> getUserType() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("userType")??"";
}

Future<void> setUserId(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('userId', printValidStringWithEmpty(value));
}

Future<String?> getUserId() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("userId")??"";
}

Future<void> setFirstName(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('firstName', printValidStringWithEmpty(value));
}

Future<String?> getFirstName() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("firstName")??"";
}

Future<void> setLastName(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('lastName', printValidStringWithEmpty(value));
}

Future<String?> getLastName() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("lastName")??"";
}

Future<void> setEmail(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('email', printValidStringWithEmpty(value));
}

Future<String?> getEmail() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("email")??"";
}

Future<void> setPhone(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('phone', printValidStringWithEmpty(value));
}

Future<String?> getPhone() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("phone")??"";
}

Future<void> setAuthToken(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('authToken', printValidStringWithEmpty(value));
}

Future<String?> getAuthToken() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("authToken")??"";
}

Future<void> setAddress(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('address', printValidStringWithEmpty(value));
}

Future<String?> getAddress() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("address")??"";
}
Future<void> setImage(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('image', printValidStringWithEmpty(value));
}

Future<String?> getImage() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("image")??"";
}
Future<void> setCity(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('city', printValidStringWithEmpty(value));
}

Future<String?> getCity() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("city")??"";
}
Future<void> setStatee(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('state', printValidStringWithEmpty(value));
}

Future<String?> getState() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("state")??"";
}
Future<void> setZipcode(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('zipcode', printValidStringWithEmpty(value));
}

Future<String?> getZipcode() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("zipcode")??"";
}
Future<void> setCountry(dynamic value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('country', printValidStringWithEmpty(value));
}

Future<String?> getCountry() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  return prefs.getString("country")??"";
}
