import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

commonLoader(BuildContext context, Color color) {
  return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) => WillPopScope(
            onWillPop: () async => false,
            child: Center(child: CircularProgressIndicator(color: color,)),
          ));
}