import 'package:teleradiology/res/strings.dart';

String printValidString(dynamic value) {
  if (value == null ||
      value.toString().toLowerCase() == "null" ||
      value.toString().toLowerCase() == "") {
    return Strings.na;
  } else {
    return value.toString();
  }
}
String printValidStringWithEmpty(dynamic value) {
  if (value == null ||
      value.toString().toLowerCase() == "null" ||
      value.toString().toLowerCase() == "") {
    return "";
  } else {
    return value.toString();
  }
}
