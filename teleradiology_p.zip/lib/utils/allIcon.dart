
import 'package:flutter/material.dart'; 
import 'package:teleradiology/Constants/dimensions.dart';

normalIcon(IconData icon, {Color color = Colors.white}) {
  return Icon(
    icon,
    color: color,
    size: ScaleController.W * 0.045,
  );
}

smallIcon(IconData icon, {Color color = Colors.white}) {
  return Icon(
    icon,
    color: color,
    size: ScaleController.W * 0.035,
  );
}

largeIcon(IconData icon, {Color color = Colors.white}) {
  return Icon(
    icon,
    color: color,
    size: ScaleController.W * 0.1,
  );
}

mediumIcon(IconData icon, {Color color = Colors.white}) {
  return Icon(
    icon,
    color: color,
    size: ScaleController.W * 0.06,
  );
}
