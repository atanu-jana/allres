
import 'package:flutter/material.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/utils/allText.dart';

showOnlineSnakbar(BuildContext context) {
  ScaffoldMessenger.of(context).clearSnackBars();

  return ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      backgroundColor: teleGreen,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
        topLeft: Radius.circular(5),
        topRight: Radius.circular(5),
      )),
      content: normalText("Back To Internet"),
      duration: Duration(seconds: 1),
    ),
  );
}