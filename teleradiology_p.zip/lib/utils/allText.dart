import 'package:flutter/material.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/utils/allTextStyle.dart';
headingText(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: headingTextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}
smallHeadingText(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: smallHeadingTextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}
heading2Text(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: heading2TextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}
heading3Text(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: heading3TextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}

normal2Text(String text,
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,
    maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: normal2TextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}

normalText(String text,
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    double letterSpacing = 0, bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,
        maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: normalTextStyle(
        color: color, fontWeight: fontWeight, letterSpacing: letterSpacing,fontFamily:fontFamily),
  );
}

midNormalText(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: midNormalTextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}

smallText(String text,
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    double letterSpacing = 0,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"
    }) {
  return Text(
    text,
      maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: smallTextStyle(
        color: color, fontWeight: fontWeight, letterSpacing: letterSpacing,fontFamily:fontFamily),
  );
}
// smallTextForAll(BuildContext context, String text,
//     {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal}) {
//   return Text(
//     text,
//     style: TextStyle(
//       fontSize: getValueForScreenType<double>(
//                           context: context,
//                           mobile:screenWidth * 0.025,
//                           tablet: screenWidth * 0.02,
//                           desktop: screenWidth * 0.02,
//                         ), color: color, fontWeight: fontWeight),
//   );
// }

extraSmallText(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: extraSmallTextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}
lightSmallText(String text,
    {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal,
     bool center = false,
    bool overflow = false,
    int? maxLines,String fontFamily="NunitoSans-Regular"}) {
  return Text(
    text,  maxLines: maxLines,
    overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
    textAlign: !center ? TextAlign.left : TextAlign.center,
    style: lightSmallTextStyle(color: color, fontWeight: fontWeight,fontFamily:fontFamily),
  );
}

subTitleText(String text) {
  return Text(
    text,
    style: TextStyle(fontSize: ScaleController.W * 0.028, color: Colors.grey),
  );
}
