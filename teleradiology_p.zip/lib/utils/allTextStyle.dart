import 'package:flutter/material.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';

headingTextStyle(
    {Color color = Colors.white,
    FontStyle fontStyle = FontStyle.normal,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.042 : ScaleController.W * 0.051,
      color: color,
      fontFamily: fontFamily,
      fontWeight: fontWeight);
}
smallHeadingTextStyle(
    {Color color = Colors.white,
    FontStyle fontStyle = FontStyle.normal,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.039 : ScaleController.W * 0.048,
      color: color,
      fontFamily: fontFamily,
      fontWeight: fontWeight);
}

heading2TextStyle(
    {Color color = Colors.white,
    FontStyle fontStyle = FontStyle.normal,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.047 : ScaleController.W * 0.057,
      color: color,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}

heading3TextStyle(
    {Color color = Colors.white,
    FontStyle fontStyle = FontStyle.normal,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.06 : ScaleController.W * 0.065,
      color: color,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}

normal2TextStyle(
    {Color color = Colors.white,
    FontStyle fontStyle = FontStyle.normal,
    FontWeight fontWeight = FontWeight.normal,
    bool lineThrough = false,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W * 0.042,
      color: color,
      fontWeight: fontWeight,
      decorationThickness: 3,
      decorationStyle: TextDecorationStyle.solid,
      decorationColor: teleGray,
      decoration:
          lineThrough ? TextDecoration.lineThrough : TextDecoration.none,
      fontFamily: fontFamily);
}

normalTextStyle(
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    FontStyle fontStyle = FontStyle.normal,
    double letterSpacing = 0,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.03 : ScaleController.W * 0.039,
      color: color,
      
      letterSpacing: letterSpacing,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}

// normalTextStyleForAll(BuildContext context,
//     {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal}) {
//   return TextStyle(
//       fontSize: getValueForScreenType<double>(
//         context: context,
//         mobile: ScaleController.W * 0.03,
//         tablet: screenHeight * 0.023,
//         desktop: screenHeight * 0.023,
//       ),
//       color: color,
//       fontWeight: fontWeight);
// }

midNormalTextStyle(
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.028 : ScaleController.W * 0.037,
      color: color,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}

smallTextStyle(
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    double letterSpacing = 0,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.025 : ScaleController.W * 0.034,
      color: color,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
      fontFamily: fontFamily);
}

extraSmallTextStyle(
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.022 : ScaleController.W * 0.031,
      color: color,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}
lightSmallTextStyle(
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.018 : ScaleController.W * 0.025,
      color: color,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}

extraSmallSmallTextStyle(
    {Color color = Colors.white,
    FontWeight fontWeight = FontWeight.normal,
    String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W * 0.02,
      color: color,
      fontWeight: fontWeight,
      fontFamily: fontFamily);
}

subTitleStyle({Color color = Colors.white, String fontFamily = "NunitoSans-Regular"}) {
  return TextStyle(
      fontSize: ScaleController.W >= 600 ? ScaleController.W * 0.023 : ScaleController.W * 0.032,
      color: color,
      fontFamily: fontFamily);
}

// lightTextStyle(
//     {Color color = Colors.white, FontWeight fontWeight = FontWeight.normal}) {
//   return TextStyle(
//       fontSize: ScaleController.W * 0.03, color: color, fontWeight: fontWeight);
// }
