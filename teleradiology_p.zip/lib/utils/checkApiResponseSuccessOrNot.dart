
bool checkApiResponseSuccessOrNot(Map<String, dynamic> jsonData) {
  if (jsonData["status"].toString().toLowerCase() == "true"||jsonData["status"].toString().toLowerCase() == "success") {
    return true;
  } else {
    return false;
  }
}