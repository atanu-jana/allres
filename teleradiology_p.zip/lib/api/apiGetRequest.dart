import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';

apiGetRequest(BuildContext context, String url,String token) async {
  if (await internetCheck()) {
    log(url);
    try {
      http.Response response = await http.get(
        Uri.parse(url),
        headers: {
      'Accept': '*/*',
        'Authorization': 'Bearer $token',
          },
      );     log(response.body.toString());
      return response.body;
    } catch (e) {}
  } else {
    showOfflineSnakbar(context);
  }
}
