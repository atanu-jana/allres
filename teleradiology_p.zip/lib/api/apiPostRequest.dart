// ignore_for_file: depend_on_referenced_packages

import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';

apiPostRequest( BuildContext context , String url,String body) async {
  if (await internetCheck()) {
    log(url);
    log(body);
    try {
      http.Response response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: body,
      );
      log(response.body.toString());
      return response.body;
    } catch (e) {
    log("Exception $e");
    }
  } else {
    showOfflineSnakbar(context);
  }
}
