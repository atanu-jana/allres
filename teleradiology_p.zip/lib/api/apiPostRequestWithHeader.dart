import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';

apiPostRequestWithHeader(
    BuildContext context , String url,String body , String token) async {
  if (await internetCheck()) {
 log(url);
    log(body);
    log(token);

    try {
      var headers = {
      'Accept': '*/*',
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json'
      };
      var request = http.Request(
        'POST',
        Uri.parse(url),
      );
      request.body = body;
      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      var jsonData = await response.stream.bytesToString();
    

      log(jsonData.toString());
      return jsonData;
    } catch (e) {
    }
  } else {
    showOfflineSnakbar(context);
  }
}
