// import 'package:flutter/material.dart';

// Color backgroundBlue = const Color(0xffE5E5E5);
// Color background = const Color(0xffc2dfdc);
// Color secondarybg = const Color(0xffe0f4ff);
// Color appbar = const Color(0xffEBF0FF);
// Color textcolor = const Color(0xff303E69);
// Color teleBlue = const Color(0xff303E69);
// Color teleBlack = const Color(0xff000);
// Color teleGray = const Color(0xffBDC5D5);
// Color telestrokeBorder = const Color(0xffBFD6E4);
// Color darkPurple = const Color(0xff303E69);
// Color bg = Color(0xffbfdcd9);

