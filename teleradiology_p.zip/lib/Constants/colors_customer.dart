import 'dart:ui';

import 'package:flutter/material.dart';

const teleBlue = Color(0xFF018BD3);
const teleBlue2 = Color(0xFF0F87FF);
const backgroundBlue = Color(0xFFC2DFDC);
const teleGray = Color(0xFF9AA1AE);
const teleGray2 = Color(0xFFBDC5D5);
const teleBlack = Color(0xFF323334);
const teleTransparent = Colors.transparent;
const teleWhite = Color(0xFFF4FAFF);
const teleButtonBlue= Color(0xFF018BD3);
const telePurple = Color(0xFF415D95);
const darkPurple = Color(0xFF303E69);
const telestrokeBorder = Color(0xFFBFD6E4);
const teleDarkBlue = Color(0xFF184673);
const teleGreen = Color(0xFF2C7971);
const teleRed = Color(0xFFFF0000);
const telePurple2 = Color(0xFF415D95);

Color background = const Color(0xffc2dfdc);
Color secondarybg = const Color(0xffe0f4ff);
Color appbar = const Color(0xffEBF0FF);
Color textcolor = const Color(0xff303E69);
Color bg = Color(0xffbfdcd9);
