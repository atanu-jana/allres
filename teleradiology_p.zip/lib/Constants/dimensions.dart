import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ScaleController extends GetxController{
  static final H = Get.height;
  static final W = Get.width;
}
