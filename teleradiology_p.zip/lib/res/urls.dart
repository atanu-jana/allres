// ignore_for_file: prefer_interpolation_to_compose_strings

class Urls {
  static String productionBaseUrl =
      "https://mydevfactory.com/~saikat8/teleradiology/api/";  
  static String baseUrl = productionBaseUrl;
 
  static String registration = baseUrl + "registration"; 
  static String accountActivation = baseUrl + "accountActivation"; 
  static String login = baseUrl + "login"; 
  static String resendOtp = baseUrl + "resend_otp"; 
  static String forgotPasswordCheck = baseUrl + "forgot_password_check"; 
  static String forgotPasswordSubmit = baseUrl + "forgot_password_submit"; 

  static String sDashboard = baseUrl + "s_dashboard"; 
  static String sMyServiceList = baseUrl + "s_my_service_list"; 
  static String sChangeServiceStatus = baseUrl + "s_change_service_status"; 
  static String cDashboard = baseUrl + "c_dashboard"; 
  static String cMyBidList = baseUrl + "c_my_bid_list"; 
  static String findService = baseUrl + "find_service"; 
  // static String sMyServiceList = sDashboard; 
  static String serviceTypeList = baseUrl + "service_type_list"; 
  static String sDeleteServiceMapImg = baseUrl + "s_delete_service_map_img"; 
  static String sMyServiceAdd = baseUrl + "s_my_service_add"; 
  static String sMyServiceView = baseUrl + "s_my_service_view"; 
  static String profileUpdate = baseUrl + "profile_update"; 
  static String serviceDetails = baseUrl + "service_details"; 
  static String cSubmitBid = baseUrl + "c_submit_bid"; 
  static String imagePreUrl ="https://mydevfactory.com/~saikat8/teleradiology/public/uploads/users/"; 
  // static String imagePreUrl ="https://mydevfactory.com/~saikat8/teleradiology/public/uploads/service_users/"; 
  
}
