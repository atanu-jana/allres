import 'package:flutter/material.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/res/strings.dart';

noDataFound({String text=""}){
  return  Center(
    child: Container(
      child: Text(
       text.isEmpty? Strings.noDataFound:text,
        style: TextStyle(color:teleBlack),
      ),
    ),
  );
}