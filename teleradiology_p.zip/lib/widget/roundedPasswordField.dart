 
import 'package:flutter/material.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/servicecolors.dart';

class RoundedPasswordField extends StatefulWidget {
  final String? hintText;
  final int? maxLength;
  final IconData? icon;
  final TextEditingController? controller;
  final TextInputType? textInputType;
  final TextInputAction? textInputAction;
  final bool? enable;
  final Function(String val)? onchangeFunction;
  final String? Function(String? val)? validate;

  const RoundedPasswordField(
    { Key? key,
    required this.hintText,
    required this.controller,
    this.enable = true,
    this.maxLength = 100,
    this.icon = Icons.person,
    required this.textInputType,
    required this.textInputAction,
    required this.onchangeFunction,
    required this.validate,
  }) : super(key: key);
  @override
  _RoundedPasswordFieldState createState() => _RoundedPasswordFieldState();
}

class _RoundedPasswordFieldState extends State<RoundedPasswordField> {
  bool obscureText = true;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      enabled: widget.enable,
      textAlign: TextAlign.start,
      maxLength: widget.maxLength,
      keyboardType: widget.textInputType,
      textInputAction: widget.textInputAction,
      cursorColor: teleGray,
      controller: widget.controller,
      onChanged: widget.onchangeFunction,
      textAlignVertical: TextAlignVertical.center,
      validator: widget.validate,
          obscureText: obscureText,
      
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
          counterText: "",
          prefixIcon: Icon(
            widget.icon,
            color: teleGray,
          ),
          hintText:widget. hintText,
          hintStyle: TextStyle(
              fontSize: 13, color: teleGray, fontFamily: "NunitoSans-Regular"),
          filled: true,
          suffixIcon: GestureDetector(
                child: Icon(
                  obscureText ? Icons.visibility : Icons.visibility_off,
                  color: teleBlue,
                ),
                onTap: () {
                  obscureText = !obscureText;
                  setState(() {});
                }),
          fillColor: Colors.white,
focusedErrorBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.red),
              borderRadius: BorderRadius.all(Radius.circular(32))),
          errorBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.red),
              borderRadius: BorderRadius.all(Radius.circular(32))),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black),
              borderRadius: BorderRadius.all(Radius.circular(32))),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.transparent),
              borderRadius: BorderRadius.all(Radius.circular(32)))),
    ); 
  }
}
 