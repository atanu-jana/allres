import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/screens/profile/profileUpdate.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/widget/button.dart';

class ServiceProfileScreen extends StatefulWidget {
  final bool onlyBody;
  final bool isCustomer;

  const ServiceProfileScreen({Key? key, required this.onlyBody,required this.isCustomer})
      : super(key: key);

  @override
  State<ServiceProfileScreen> createState() => _ServiceProfileScreenState();
}

class _ServiceProfileScreenState extends State<ServiceProfileScreen> {
  @override
  Widget build(BuildContext context) {
    var H = MediaQuery.of(context).size.height;
    var W = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        backgroundColor: backgroundBlue,
        appBar: widget.onlyBody
            ? null
            : AppBar(
                backgroundColor: backgroundBlue,
                elevation: 0,
                leading: InkWell(
                  child: Container(
                      child: InkWell(
                          onTap: () {
                            Get.back();
                          },
                          child: Icon(
                            Icons.arrow_back_ios,
                            color: teleBlue2,
                            size: 20,
                          ))),
                ),
                centerTitle: true,
                title: Text("Profile"),
                titleTextStyle: TextStyle(
                    fontSize: 20,
                    fontFamily: "NunitoSans-Bold",
                    color: Color(0xFF184673)),
                actions: [
                  InkWell(
                    onTap: () {},
                    child: Padding(
                      padding: EdgeInsets.only(right: ScaleController.W * 0.04),
                      child: Center(
                        child: Stack(
                          children: [
                            Icon(
                              Icons.notifications,
                              color: Colors.white,
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                left: ScaleController.W * 0.03,
                              ),
                              child: CircleAvatar(
                                backgroundColor: teleBlue,
                                radius: 7,
                                child: Text(
                                  "3",
                                  style: TextStyle(
                                      fontSize: 11, color: Colors.white),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: H * 0.02,
                ),
                Container(
                  height: H * 0.55,
                  child: Container(
                      color: backgroundBlue,
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFFECF7FE),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(16)),
                              ),
                              height: H * 0.42,
                              width: W * 0.9,
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: H * 0.1,
                                    ),
                                    Stack(
                                      children: [
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text("Full Name/\nOrganization",
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      fontFamily:
                                                          "Opensans-Regular",
                                                      color:
                                                          Color(0xFF96A3BD))),
                                              SizedBox(
                                                height: H * 0.035,
                                              ),
                                              Text("Email ID",
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      fontFamily:
                                                          "Opensans-Regular",
                                                      color:
                                                          Color(0xFF96A3BD))),
                                              SizedBox(
                                                height: H * 0.035,
                                              ),
                                              Text("Contact Number",
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      fontFamily:
                                                          "Opensans-Regular",
                                                      color:
                                                          Color(0xFF96A3BD))),
                                              SizedBox(
                                                height: H * 0.035,
                                              ),
                                              Text("Address",
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      fontFamily:
                                                          "Opensans-Regular",
                                                      color:
                                                          Color(0xFF96A3BD))),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              // Text(":  Alex Brown",
                                              //     style: TextStyle(
                                              //         fontSize: 15,
                                              //         fontFamily: "Opensans-Regular",
                                              //         color: Color(0xFF303E69)
                                              //     )
                                              // ),
                                              Container(
                                                child: FutureBuilder(
                                                    future: getFirstName(),
                                                    builder: (BuildContext
                                                            context,
                                                        AsyncSnapshot<String?>
                                                            text) {
                                                      return normalText(
                                                          ": " +
                                                              printValidString(
                                                                  text.data),
                                                          color: Color(
                                                              0xFF303E69));
                                                    }),
                                              ),
                                              SizedBox(
                                                height: H * 0.06,
                                              ),
                                              Container(
                                                child: FutureBuilder(
                                                    future: getEmail(),
                                                    builder: (BuildContext
                                                            context,
                                                        AsyncSnapshot<String?>
                                                            text) {
                                                      return normalText(
                                                          ": " +
                                                              printValidString(
                                                                  text.data),
                                                          color: Color(
                                                              0xFF303E69));
                                                    }),
                                              ),
                                              // Text(":  alex@dummy.com",
                                              //     style: TextStyle(
                                              //         fontSize: 15,
                                              //         fontFamily:
                                              //             "Opensans-Regular",
                                              //         color:
                                              //             Color(0xFF303E69))),
                                              SizedBox(
                                                height: H * 0.035,
                                              ),
                                              Container(
                                                child: FutureBuilder(
                                                    future: getPhone(),
                                                    builder: (BuildContext
                                                            context,
                                                        AsyncSnapshot<String?>
                                                            text) {
                                                      return normalText(
                                                          ": " +
                                                              printValidString(
                                                                  text.data),
                                                          color: Color(
                                                              0xFF303E69));
                                                    }),
                                              ),
                                              // Text(":  +258 789 8965",
                                              //     style: TextStyle(
                                              //         fontSize: 15,
                                              //         fontFamily:
                                              //             "Opensans-Regular",
                                              //         color:
                                              //             Color(0xFF303E69))),
                                              SizedBox(
                                                height: H * 0.035,
                                              ),
                                              Container(
                                                child: FutureBuilder(
                                                    future: getAddress(),
                                                    builder: (BuildContext
                                                            context,
                                                        AsyncSnapshot<String?>
                                                            text) {
                                                      return normalText(
                                                          ": " +
                                                              printValidString(
                                                                  text.data),
                                                          color: Color(
                                                              0xFF303E69));
                                                    }),
                                              ),
                                              // Text(
                                              //     ":  31/32 mrfgi doller. \n   Hilton",
                                              //     style: TextStyle(
                                              //         fontSize: 15,
                                              //         fontFamily:
                                              //             "Opensans-Regular",
                                              //         color:
                                              //             Color(0xFF303E69))),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: H * 0.02,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(bottom: H * 0.35),
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: InkWell(
                                onTap: () {},
                                child: Container(
                                  width: Get.width * 0.3,
                                  height: Get.width * 0.3,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: teleWhite, width: 5),
                                      borderRadius: BorderRadius.circular(100)),
                                  child: FutureBuilder(
                                      future: getImage(),
                                      builder: (BuildContext context,
                                          AsyncSnapshot<String?> text) {
                                        return text.data == null ||
                                                text.data!.isEmpty ||
                                                text.data == "null"
                                            ? CircleAvatar(
                                                radius: Get.width * 0.15,
                                                backgroundColor: Colors.white,
                                                backgroundImage:
                                                    const AssetImage(
                                                  "assets/Images/noImage.png",
                                                ),
                                              )
                                            : ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(100),
                                                child: CachedNetworkImage(
                                                  progressIndicatorBuilder:
                                                      (context, url,
                                                              progress) =>
                                                          Center(
                                                    child: CircleAvatar(
                                                      radius: Get.width * 0.3,
                                                      backgroundColor:
                                                          Colors.white,
                                                      child:
                                                          CircularProgressIndicator(
                                                        color: teleBlue,
                                                      ),
                                                    ),
                                                  ),
                                                  imageUrl: text.data!,
                                                  fit: BoxFit.cover,
                                                ),
                                              );
                                      }),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ),
                SizedBox(
                  height: H * 0.05,
                ),
                Padding(
                    padding: EdgeInsets.only(
                        left: ScaleController.W * 0.05,
                        right: ScaleController.W * 0.05),
                    child: button(
                        onTap: () {
                          Get.to(() => ServiceProfileUpdate(isCustomer: widget.isCustomer,));
                        },
                        title: Strings.editProfile,
                        color: teleButtonBlue,
                        textColor: teleWhite))
              ],
            ),
          ),
        ),
      ),
    );
  }

  Row buildTextProfile(double W, String title, String subTitle) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title,
            style: TextStyle(
                fontSize: 15,
                fontFamily: "Opensans-Regular",
                color: Color(0xFF606060))),
        SizedBox(
          width: W * 0.25,
        ),
        Text(":",
            style: TextStyle(fontSize: 15, fontFamily: "Opensans-Regular")),
        Text(subTitle,
            style: TextStyle(fontSize: 15, fontFamily: "Opensans-Regular")),
      ],
    );
  }

  Container buildCardFlyer(double H, double W) {
    return Container(
      height: H * 0.15,
      width: W * 0.9,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(8)),
        color: Colors.white,
      ),
      child: Row(
        children: [
          Image.asset("assets/images/flyer.png"),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "  Flyer Distribution",
                style: TextStyle(
                    fontSize: 15,
                    fontFamily: 'OpenSans-Bold',
                    color: Color(0xFF333333)),
              ),
              Row(
                children: [
                  Text(
                    "  Location :",
                    style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'OpenSans-Regular',
                        color: Color(0xFF808080)),
                  ),
                  Text(
                    " Area 1, New Town, Kolkata ",
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'OpenSans-Regular',
                        color: Color(0xFF333333)),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "  Pincode :",
                    style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'OpenSans-Regular',
                        color: Color(0xFF808080)),
                  ),
                  Text(
                    " 700091 ",
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'OpenSans-Regular',
                        color: Color(0xFF333333)),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "  Date :",
                    style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'OpenSans-Regular',
                        color: Color(0xFF808080)),
                  ),
                  Text(
                    " 17 May 2022 ",
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'OpenSans-Regular',
                        color: Color(0xFF333333)),
                  ),
                ],
              )
            ],
          ),
        ],
      ),
    );
  }
}
// import 'package:flutter/material.dart';
// import 'package:flutter/src/foundation/key.dart';
// import 'package:flutter/src/widgets/framework.dart';
// import 'package:get/get.dart';
// import 'package:teleradiology/service screen/service_provider_profile.dart';

// import '../Constants/servicecolors.dart';

// class ServiceProfileScreen extends StatefulWidget {
//   const ServiceProfileScreen({Key? key}) : super(key: key);

//   @override
//   State<ServiceProfileScreen> createState() => _ServiceProfileScreenState();
// }

// class _ServiceProfileScreenState extends State<ServiceProfileScreen> {
//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//     return Scaffold(
//       backgroundColor: background,
//       appBar: AppBar(
//         automaticallyImplyLeading: false,
//         backgroundColor: background,
//         elevation: 0,
//         title: Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 10),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               InkWell(
//                 onTap: () {
//                   Get.back();
//                 },
//                 child: Icon(
//                   Icons.arrow_back_ios,
//                   color: textcolor,
//                 ),
//               ),
//               Text(
//                 "Profile",
//                 style: TextStyle(
//                     fontFamily: "NunitoSans",
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold,
//                     color: textcolor),
//               ),
//               Stack(
//                 children: [
//                   Icon(
//                     Icons.notifications,
//                     color: Color(0xffBDC5D5),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                       left: size.width * 0.03,
//                     ),
//                     child: CircleAvatar(
//                       backgroundColor: Color(0xffFCB128),
//                       radius: 7,
//                       child: Text(
//                         "2",
//                         style: TextStyle(fontSize: 11, color: Colors.white),
//                       ),
//                     ),
//                   )
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           Stack(
//             children: [
//               SizedBox(
//                 height: size.height * 0.05,
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(20.0),
//                 child: Container(
//                   margin: EdgeInsets.only(top: size.height * 0.1),
//                   height: size.height * 0.45,
//                   width: size.width,
//                   decoration: BoxDecoration(
//                     color: Color(0xffECF7FE),
//                     borderRadius: BorderRadius.circular(15),
//                   ),
//                   child: Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 20.0, vertical: 10),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.stretch,
//                       children: [
//                         SizedBox(
//                           height: size.height * 0.12,
//                         ),
//                         Row(
//                           children: [
//                             Container(
//                               height: size.height * 0.3,
//                               child: Column(
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       "Full Name/\nOrganization",
//                                       style: TextStyle(
//                                           color: Color(0xff96A3BD),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.w500),
//                                     ),
//                                   ),
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       "Email ID",
//                                       style: TextStyle(
//                                           color: Color(0xff96A3BD),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.w500),
//                                     ),
//                                   ),
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       "Contact Number",
//                                       style: TextStyle(
//                                           color: Color(0xff96A3BD),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.w500),
//                                     ),
//                                   ),
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       "Address",
//                                       style: TextStyle(
//                                           color: Color(0xff96A3BD),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.w500),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                             SizedBox(
//                               width: size.width * 0.02,
//                             ),
//                             Container(
//                               height: size.height * 0.29,
//                               child: Column(
//                                 mainAxisAlignment: MainAxisAlignment.start,
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       ":  ABC Company",
//                                       style: TextStyle(
//                                           color: Color(0xff303E69),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.bold),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: size.width * 0.05,
//                                   ),
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       ":  Info@dummy.com",
//                                       style: TextStyle(
//                                           color: Color(0xff303E69),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.bold),
//                                     ),
//                                   ),
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Text(
//                                       ":  +258 789 8965 ",
//                                       style: TextStyle(
//                                           color: Color(0xff303E69),
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.bold),
//                                     ),
//                                   ),
//                                   Padding(
//                                     padding: const EdgeInsets.all(5.0),
//                                     child: Container(
//                                       width: size.width * 0.39,
//                                       child: Row(
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                         children: [
//                                           Text(
//                                             ":  ",
//                                             maxLines: 3,
//                                             overflow: TextOverflow.ellipsis,
//                                             style: TextStyle(
//                                                 color: Color(0xff303E69),
//                                                 fontSize: 13,
//                                                 fontWeight: FontWeight.bold),
//                                           ),
//                                           Container(
//                                             width: size.width * 0.35,
//                                             child: Text(
//                                               "31/32 mrfgi doller.Hilton",
//                                               maxLines: 3,
//                                               overflow: TextOverflow.ellipsis,
//                                               style: TextStyle(
//                                                   color: Color(0xff303E69),
//                                                   fontSize: 13,
//                                                   fontWeight: FontWeight.bold),
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//               Positioned(
//                 top: size.height * 0.05,
//                 left: size.width * 0.35,
//                 child: Container(
//                   decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(60),
//                       border: Border.all(width: 5, color: Colors.white)),
//                   child: CircleAvatar(
//                     radius: 50,
//                     backgroundImage: AssetImage("assets/Images/profile.png"),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           Container(
//             margin: EdgeInsets.symmetric(horizontal: 20),
//             width: size.width,
//             child: ElevatedButton(
//               child: Text(
//                 'Edit Profile',
//               ),
//               onPressed: () {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                       builder: (context) => ServiceProviderProfile()),
//                 );
//               },
//               style: ElevatedButton.styleFrom(
//                   elevation: 5,
//                   shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(50)),
//                   primary: Color(0xff303E69),
//                   padding: EdgeInsets.symmetric(horizontal: 0, vertical: 12),
//                   textStyle: const TextStyle(
//                       fontSize: 16,
//                       fontFamily: "NunitoSans",
//                       color: Color(0xff184673),
//                       fontWeight: FontWeight.bold)),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
