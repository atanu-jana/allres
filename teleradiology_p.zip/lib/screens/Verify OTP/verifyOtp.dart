import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/otp_field_style.dart';
import 'package:otp_text_field/style.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/api/apiPostRequest.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/Sign%20In/signIn.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/utils/validation.dart';
import 'package:teleradiology/widget/button.dart';
import 'package:teleradiology/widget/roundedInputField.dart';
import 'package:teleradiology/widget/roundedPasswordField.dart';

import '../Forgot Password/resetPassword.dart';

class ServiceVerifyOTP extends StatefulWidget {
  final bool isCustomer;
  
  final String emailId;
  const ServiceVerifyOTP({Key? key, required this.emailId,required this.isCustomer}) : super(key: key);

  @override
  State<ServiceVerifyOTP> createState() => _ServiceVerifyOTPState();
}

class _ServiceVerifyOTPState extends State<ServiceVerifyOTP> {
   TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  OtpFieldController otpFieldController = OtpFieldController();
  String otp = "";
  @override
  void initState() {
    super.initState();
    emailController.text = widget.emailId;
    setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    var H = MediaQuery.of(context).size.height;
    var W = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        leading: Container(
            child: InkWell(
                onTap: () {
                  Get.back();
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: textcolor,
                ))),
      ),
      body: SingleChildScrollView(
        child: Center(
            child: Column(
          children: [
            SizedBox(
              height: ScaleController.H * 0.2,
            ),
            Text(
              "Verify OTP",
              style: TextStyle(
                  fontSize: 20,
                  fontFamily: "NunitoSans",
                  fontWeight: FontWeight.bold,
                  color: teleDarkBlue),
            ),
            SizedBox(
              height: ScaleController.H * 0.02,
            ),
            Text(
              "Please enter OTP send to email",
              style: TextStyle(
                  fontSize: 14, fontFamily: "NunitoSans", color: telePurple2),
            ),
            SizedBox(
              height: H * 0.07,
            ),
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //   children: [
            //     buildTextFormOTP(W, H),
            //     buildTextFormOTP(W, H),
            //     buildTextFormOTP(W, H),
            //     buildTextFormOTP(W, H),
            //   ],
            // ),
            Container(
              padding: MarginPadding.customMarginNormal(),
              child: RoundedInputField(
                  controller: emailController,
                  textInputAction: TextInputAction.next,
                  textInputType: TextInputType.emailAddress,
                  hintText: "Email",
                  icon: Icons.mail,
                  onchangeFunction: (String val) {},
                  validate: (String? value) {
                    return null;
                  }),
            ),
             SizedBox(
              height: ScaleController.H * 0.02,
            ),
            Container(
              padding: MarginPadding.customMarginNormal(),
              child: RoundedPasswordField(
                  controller: passwordController,
                  textInputAction: TextInputAction.next,
                  textInputType: TextInputType.visiblePassword,
                  hintText: "Password",
                  icon: Icons.lock,
                  onchangeFunction: (String val) {},
                  validate: (String? value) {
                    return null;
                  }),
            ),
            SizedBox(
              height: ScaleController.H * 0.02,
            ),
            Container(
              padding: MarginPadding.customMarginNormal(),
              child: RoundedPasswordField(
                  controller: confirmPasswordController,
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  hintText: "Confirm Password",
                  icon: Icons.lock,
                  onchangeFunction: (String val) {},
                  validate: (String? value) {
                    return null;
                  }),
            ),
            SizedBox(
              height: ScaleController.H * 0.02,
            ),

              Container(
              padding: MarginPadding.customMarginNormal(),

                child: OTPTextField(
                                controller: otpFieldController,
                                length: 4,
                                width: MediaQuery.of(context).size.width,
                                textFieldAlignment: MainAxisAlignment.spaceAround,
                                fieldWidth: Get.width * 0.14,
                                fieldStyle: FieldStyle.underline,
                                outlineBorderRadius: 10,
                                style: TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold),
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: Get.width * 0.04,
                                    vertical: Get.width * 0.04),
                                otpFieldStyle: OtpFieldStyle(
                                  enabledBorderColor: Color(0xff212121),
                                  disabledBorderColor: Colors.black38,
                                ),
                                onChanged: (pin) {
                                  setState(() {
                                    otp = pin;
                                  });
                                },
                                onCompleted: (pin) {
                                  // setState(() {
                                  //   otp = pin;
                                  // });
                                }),
              ),
 
            SizedBox(
              height: ScaleController.H * 0.03,
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: ScaleController.W * 0.05,
                  right: ScaleController.W * 0.05),
              child: button(
                  onTap: () {
                    if (validateAndProceed()) {
                      verifyOTPAndProceed();
                    }
                  },
                  title: "Verify",
                  color: teleButtonBlue,
                  textColor: teleWhite),
            ),
            
            SizedBox(
              height: H * 0.05,
            ),
                                      GestureDetector(
                            onTap: () {
                              resendOTP();
                            },
                            child: Container(
                              width: ScaleController.W * 0.8,
                              color: teleTransparent,
                              padding: MarginPadding.customMarginNormal(),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: ScaleController.W * 0.7,
                                    child: Row(
                                      children: [
                                        Container(
                                          child: normalText(
                                              "Didn't receive the OTP? ",
                                              color: teleGray),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: ScaleController.W * 0.01),
                                          child: normalText("RESEND OTP",
                                              color: teleBlue,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

        
          ]))
      ),
    );
  }

  Future resendOTP() async {

    if (await internetCheck()) {
    
otpFieldController.clear();
otp="";
setState(() {
  
});
      commonLoader(context, telePurple);

      String body = json.encode({
        "email": emailController.text.trim(),
        "user_type": widget.isCustomer?4: 3
      });
      apiPostRequest(context, Urls.resendOtp, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            
            commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
                function: () {
              Get.back();
            });
          } else {
           
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            try {
              
              msg += validValue(jsonData["data"]["email"])
                  ? jsonData["data"]["email"]
                  : "";
            } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }


  Future verifyOTPAndProceed() async {
    if (await internetCheck()) {
      commonLoader(context, telePurple);

      String body = json.encode({
        "email": emailController.text.trim(),
        "user_type": widget.isCustomer?4: 3,
        // "recovery_code": otpController.text,
        "recovery_code": otp.trim(),
        "password": passwordController.text.trim(),
        "confirm_password": confirmPasswordController.text.trim(),
      });
      apiPostRequest(context, Urls.forgotPasswordSubmit, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
                function: () {
              Get.back();
              Get.to(() => ServiceSignInPage(emailId: emailController.text,isCustomer: widget.isCustomer,));
            });
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            // try {
            //   msg = validValue(jsonData["data"]["email"][0])
            //       ? jsonData["data"]["email"][0]
            //       : Strings.na;
            //   msg += "\n";
            //   msg += validValue(jsonData["data"]["phone"][0])
            //       ? jsonData["data"]["phone"][0]
            //       : Strings.na;
            // } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  bool validateAndProceed() {
    if (emailController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your email address");
      return false;
    } else if (!validateEmail(emailController.text)) {
      commonAlertDialog(
        Strings.warning,
        "Email address is not valid",
      );
      return false;
    } else  if (otp.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "Please enter OTP",
      );
      return false;
    } else if (otp.length < 3) {
      commonAlertDialog(Strings.warning, "Please enter valid OTP");
      return false;
    } else if (passwordController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your password");
      return false;
    } else if (passwordController.text.length < 6) {
      commonAlertDialog(
        Strings.warning,
        "Password must be atleast 6 characters",
      );
      return false;
    } else if (confirmPasswordController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your password");
      return false;
    } else if (passwordController.text != confirmPasswordController.text) {
      commonAlertDialog(Strings.warning, "Password does not match!");
      return false;
    } else {
      return true;
    }
  }

}
