import 'package:get/get.dart';

class ServiceDetailsController extends GetxController {
  RxString serviceId = "".obs;
  RxBool loading = true.obs;
  // Rx<ServiceModel?> serviceModel = null.obs;
  // late ServiceModel serviceModel;
}
