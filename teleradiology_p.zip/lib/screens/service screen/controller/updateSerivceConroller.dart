import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceTypeModel.dart';

class UpdateServiceConroller extends GetxController {
  RxList<ServiceTypeModel> serviceTypeList = <ServiceTypeModel>[].obs;
  RxString serviceVieoPath = "".obs;
  RxString serviceImagePath = "".obs;
  RxList<RxString> listImage = <RxString>[].obs;
   late ServiceModel serviceModel ;
  RxString serviceId = "".obs;
}
