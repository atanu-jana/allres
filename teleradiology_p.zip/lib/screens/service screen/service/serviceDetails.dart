import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/service%20screen/controller/serviceDetailsController.dart';
import 'package:teleradiology/screens/service%20screen/controller/updateSerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/service/updateService.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allIcon.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/allTextStyle.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/noDataFound.dart';
import 'package:teleradiology/widget/roundedInputField.dart';

class ServiceDetails extends StatefulWidget {
  const ServiceDetails({Key? key}) : super(key: key);

  @override
  State<ServiceDetails> createState() => _ServiceDetailsState();
}

class _ServiceDetailsState extends State<ServiceDetails> {
  ServiceDetailsController serviceDetailsController =
      Get.put(ServiceDetailsController());
  ServiceModel? serviceModel;
  List<String> imageList = [];
  @override
  void initState() {
    super.initState();
    fetchServiceDetails();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: backgroundBlue,
          elevation: 0,
          leading: InkWell(
            child: Container(
                child: InkWell(
                    onTap: () {
                      Get.back();
                    },
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: teleBlue2,
                      size: 20,
                    ))),
          ),
          centerTitle: true,
          title: Text("Service Details"),
          titleTextStyle: TextStyle(
              fontSize: 20,
              fontFamily: "NunitoSans",
              fontWeight: FontWeight.bold,
              color: Color(0xFF184673)),
        ),
        backgroundColor: backgroundBlue,
        body: serviceDetailsController.loading.value
            ? noDataFound()
            : ListView(
                physics: BouncingScrollPhysics(),
                children: [
                  Stack(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: ScaleController.H * 0.12),
                        child: Container(
                          alignment: AlignmentDirectional.bottomCenter,
                          decoration: BoxDecoration(
                              color: Color(0xFFECF7FE),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(50),
                                  topRight: Radius.circular(50))),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: ScaleController.H * 0.12,
                                ),
                                Text(
                                  printValidString(
                                    serviceModel!.title,
                                  ),
                                  style: heading2TextStyle(
                                    fontFamily: "NunitoSans-Bold",
                                    color: teleBlue2,
                                  ),
                                ),
                                SizedBox(
                                  height: ScaleController.H * 0.02,
                                ),
                                Text(
                                  printValidString(
                                    serviceModel!.description,
                                  ),
                                  textAlign: TextAlign.center,
                                  style: normalTextStyle(
                                    fontFamily: "NunitoSans-Regular",
                                    fontWeight: FontWeight.w300,
                                    color: telePurple2,
                                  ),
                                ),
                                SizedBox(
                                  height: ScaleController.H * 0.02,
                                ),
                                customRowDetails("Coverage Hours",
                                    serviceModel!.coverageHours),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                customRowDetails(
                                    "Modalities", serviceModel!.modalities),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                customRowDetails("Type of facility",
                                    serviceModel!.typeOfFacility),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                customRowDetails(
                                    "Volumes", serviceModel!.volumes),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                Divider(),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                customRowDetails(
                                    "Click Price", serviceModel!.clickPrice),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    customRowDetails("Min",
                                        serviceModel!.clickPriceNightMin),
                                    customRowDetails("Max",
                                        serviceModel!.clickPriceNightMax),
                                  ],
                                ),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                Divider(),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                customRowDetails(
                                    "Hour Price", serviceModel!.hourPrice),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    customRowDetails(
                                        "Min", serviceModel!.hourPriceNightMin),
                                    customRowDetails(
                                        "Max", serviceModel!.hourPriceNightMax),
                                  ],
                                ),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                Divider(),
                                SizedBox(
                                  height: ScaleController.H * 0.01,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      // serviceModel!.numberOfBid == "0"
                                      serviceModel!.serviceBids.length
                                                  .toString() ==
                                              "0"
                                          ? MainAxisAlignment.center
                                          : MainAxisAlignment.spaceBetween,
                                  children: [
                                    // serviceModel!.numberOfBid == "0"
                                    serviceModel!.serviceBids.length
                                                .toString() ==
                                            "0"
                                        ? normalText("No Bid Available",
                                            fontWeight: FontWeight.bold,
                                            fontFamily: "NunitoSans",
                                            color: Color(0xFF303E69))
                                        : Row(
                                            children: [
                                              normalText(
                                                  // serviceModel!.numberOfBid ==
                                                  //         "1"
                                                  serviceModel!.serviceBids
                                                              .length
                                                              .toString() ==
                                                          "1"
                                                      ? "Total Bid: "
                                                      : "Total Bids: ",
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily: "NunitoSans",
                                                  color: Color(0xFF303E69)),
                                              SizedBox(
                                                width: Get.height * 0.01,
                                              ),
                                              smallText(
                                                  serviceModel!
                                                      .serviceBids.length
                                                      .toString(),
                                                  // serviceModel!.numberOfBid,
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily: "NunitoSans",
                                                  color: teleGray),
                                            ],
                                          ),
                                    serviceModel!.serviceBids.isEmpty
                                        ? Container()
                                        : InkWell(
                                            onTap: () {
                                              showModalBottomSheet(
                                                  context: context,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10.0),
                                                  ),
                                                  backgroundColor: teleGray2,
                                                  builder:
                                                      (BuildContext context) {
                                                    return ListView(
                                                      physics:
                                                          BouncingScrollPhysics(),
                                                      children: [
                                                        Container(
                                                          margin: MarginPadding
                                                              .customBottom(),
                                                          decoration:
                                                              BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .only(
                                                                    topLeft: Radius
                                                                        .circular(
                                                                            10),
                                                                    topRight: Radius
                                                                        .circular(
                                                                            10),
                                                                  ),
                                                                  boxShadow: [
                                                                    BoxShadow(
                                                                      color: teleGray2
                                                                          .withOpacity(
                                                                              0.5),
                                                                      spreadRadius:
                                                                          5,
                                                                      blurRadius:
                                                                          7,
                                                                      offset: Offset(
                                                                          0,
                                                                          3), // changes position of shadow
                                                                    ),
                                                                  ],
                                                                  color:
                                                                      teleWhite),
                                                          height:
                                                              Get.width * 0.15,
                                                          child: Stack(
                                                            alignment: Alignment
                                                                .center,
                                                            children: [
                                                              normalText("Bids",
                                                                  color:
                                                                      teleBlue,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                              Positioned(
                                                                  right:
                                                                      Get.width *
                                                                          0.05,
                                                                  child:
                                                                      FloatingActionButton
                                                                          .small(
                                                                    onPressed:
                                                                        () {
                                                                      Get.back();
                                                                    },
                                                                    backgroundColor:
                                                                        teleRed,
                                                                    child: smallIcon(
                                                                        Icons
                                                                            .close,
                                                                        color:
                                                                            teleWhite),
                                                                  ))
                                                            ],
                                                          ),
                                                        ),
                                                        Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          children: List.generate(
                                                              serviceModel!
                                                                  .serviceBids
                                                                  .length,
                                                              (index) => customBidCard(
                                                                  serviceModel!
                                                                          .serviceBids[
                                                                      index])),
                                                        )
                                                      ],
                                                    );
                                                  });
                                            },
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                smallText("See All     ",
                                                    fontFamily: "NunitoSans",
                                                    color: teleGreen),
                                              ],
                                            ),
                                          )
                                  ],
                                ),
                                SizedBox(
                                  height: ScaleController.H * 0.03,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        try {
                                          UpdateServiceConroller
                                              updateServiceConroller =
                                              Get.put(UpdateServiceConroller());
                                          updateServiceConroller
                                                  .serviceId.value =
                                              serviceDetailsController
                                                  .serviceId.value;
                                          updateServiceConroller.serviceModel =
                                              serviceModel!;
                                          Get.to(() => UpdateService());
                                        } catch (e) {
                                          log(e.toString());
                                        }
                                      },
                                      child: Container(
                                        alignment: Alignment.center,
                                        height: ScaleController.H * 0.075,
                                        padding: MarginPadding
                                            .customHorizontalLarge(),
                                        decoration: BoxDecoration(
                                            boxShadow: [
                                              BoxShadow(
                                                  color: Color(0xffBBC9D3),
                                                  blurRadius: 10,
                                                  offset: Offset(0, 7.5))
                                            ],
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(32)),
                                            gradient: LinearGradient(
                                              colors: [
                                                Color(0xff0581D7),
                                                Color(0xff1463D4),
                                              ],
                                            )),
                                        child: Text(
                                          "Edit Service",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontFamily: "Gilroy-Bold",
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18,
                                              decoration: TextDecoration.none,
                                              color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: ScaleController.H * 0.06,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: ScaleController.H * 0.01),
                        child: Center(
                          child: Container(
                            height: ScaleController.H * 0.2,
                            width: ScaleController.W * 0.8,
                            child: CarouselSlider.builder(
                              itemCount: imageList.length,
                              itemBuilder: (BuildContext context, int index,
                                      int pageViewIndex) =>
                                  Container(
                                decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                          offset: Offset(0, 0.5),
                                          color: Color(0xffD7E6F0),
                                          blurRadius: 10)
                                    ],
                                    color: Color(0xff2A8FEA),
                                    border: Border.all(
                                        color: Colors.white, width: 3),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(16))),
                                child: ClipRRect(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)),
                                  child: CachedNetworkImage(
                                    progressIndicatorBuilder:
                                        (context, url, progress) => Center(
                                      child: CircularProgressIndicator(
                                        color: teleBlue,
                                      ),
                                    ),
                                    imageUrl: imageList[index],
                                    height: ScaleController.H * 0.2,
                                    width: ScaleController.W * 0.8,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              options: CarouselOptions(
                                autoPlay: true,
                                enlargeCenterPage: true,
                                viewportFraction: 0.9,
                                aspectRatio: 2.0,
                                initialPage: 0,
                              ),
                            ),
                            // child: ClipRRect(
                            //     borderRadius: BorderRadius.circular(8),
                            //     child: serviceModel! != null &&
                            //                 serviceModel!
                            //                     .serviceImage.isEmpty ||
                            //             serviceModel!.serviceImage == "null"
                            //         ? Image.asset(
                            //             "assets/Images/radiology_list.png",
                            //             height: ScaleController.W * 0.3,
                            //             width: ScaleController.W * 0.31,
                            //             fit: BoxFit.fill,
                            //           )
                            // : CachedNetworkImage(
                            //     progressIndicatorBuilder:
                            //         (context, url, progress) => Center(
                            //       child: CircularProgressIndicator(
                            //         color: teleBlue,
                            //       ),
                            //     ),
                            //     imageUrl: serviceModel!.serviceImage,
                            //     height: ScaleController.W * 0.3,
                            //     width: ScaleController.W * 0.31,
                            //     fit: BoxFit.fill,
                            //   )),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
      ),
    );
  }

  Widget customRowDetails(String title, String value, {bool header = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          title + ": ",
          textAlign: TextAlign.center,
          style: header
              ? heading2TextStyle(
                  fontFamily: "NunitoSans-Regular",
                  fontWeight: FontWeight.bold,
                  color: teleBlue2,
                )
              : normalTextStyle(
                  fontFamily: "NunitoSans-Regular",
                  fontWeight: FontWeight.w300,
                  color: teleBlue,
                ),
        ),
        Text(
          printValidString(
            value,
          ),
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: telePurple2,
          ),
        ),
      ],
    );
  }

  Future fetchServiceDetails() async {
    ServiceDetailsController serviceDetailsControllerTemp =
        Get.put(ServiceDetailsController());
    imageList.clear();

    serviceDetailsControllerTemp.loading.value = true;
    setState(() {});
    // serviceDetailsControllerTemp.serviceModel = null;
    setState(() {});
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
        "service_id": serviceDetailsController.serviceId.value,
      });
      apiPostRequestWithHeader(context, Urls.sMyServiceView, body, token!)
          .then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            try {
              if (jsonData["data"].isNotEmpty) {
                if (jsonData["data"]["serviceData"].isNotEmpty) {
                  serviceModel =
                      ServiceModel.fromJson(jsonData["data"]["serviceData"]);
                  imageList.add(serviceModel!.serviceImage);

                  Future.forEach(serviceModel!.serviceImages, (dynamic ele) {
                    imageList.add(ele["image_path"]);
                  });
                  log(imageList.length.toString());
                  setState(() {});
                } else {
                  serviceModel = null;
                }
              } else {
                serviceModel = null;
              }

              serviceDetailsControllerTemp.loading.value = false;
              setState(() {});
            } catch (e) {
              serviceDetailsControllerTemp.loading.value = false;
              setState(() {});
              log(e.toString());
            }
            setState(() {});
          } else {
            serviceDetailsControllerTemp.loading.value = false;
            setState(() {});
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      serviceDetailsControllerTemp.loading.value = false;
      setState(() {});
      showOfflineSnakbar(context);
    }
  }

  customBidCard(Map<String, dynamic> data) {
    // Get.log(Urls.imagePreUrl + data["bid_user_data"]["image"]);
    return Container(
      margin: MarginPadding.customMarginSame(),
      padding: MarginPadding.customMarginSame(),
      decoration: BoxDecoration(
          color: teleWhite, borderRadius: BorderRadius.circular(15)),
      width: Get.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            children: [
              Container(
                width: Get.width * 0.2,
                height: Get.width * 0.2,
                decoration: BoxDecoration(
                    border: Border.all(color: teleWhite, width: 5),
                    borderRadius: BorderRadius.circular(100)),
                child: data["bid_user_data"]["image"] == null ||
                        data["bid_user_data"]["image"].isEmpty ||
                        data["bid_user_data"]["image"] == "null"
                    ? CircleAvatar(
                        radius: Get.width * 0.15,
                        backgroundColor: Colors.white,
                        backgroundImage: const AssetImage(
                          "assets/Images/noImage.png",
                        ),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: CachedNetworkImage(
                          progressIndicatorBuilder: (context, url, progress) =>
                              Center(
                            child: CircleAvatar(
                              radius: Get.width * 0.3,
                              backgroundColor: Colors.white,
                              child: CircularProgressIndicator(
                                color: teleBlue,
                              ),
                            ),
                          ),
                          imageUrl:
                              Urls.imagePreUrl + data["bid_user_data"]["image"],
                          fit: BoxFit.cover,
                        ),
                      ),
              ),
              SizedBox(
                width: Get.width * 0.05,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      width: ScaleController.W * 0.32,
                      child: normalText(
                          printValidString(data["bid_user_data"]["name"]),
                          color: teleBlue)),
                  Container(
                      width: ScaleController.W * 0.32,
                      child: smallText(
                          printValidString(data["bid_user_data"]["email"]),
                          color: Color(0xFF4A4979))),
                ],
              )
            ],
          ),
          Container(
            color: teleGray,
            height: 0.2,
          ),
          Column(
            children: [
              Container(
                  margin: MarginPadding.customVerticalSmall(),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: Get.width / 2.5,
                        child: customRowDetailsVertical(
                            "Time", data["prefer_time"]),
                      ),
                      Container(
                        width: Get.width / 2.5,
                        child: customRowDetailsVertical(
                            "Prefer Price",
                            "\$" +
                                data["prefer_price"].toString() +
                                " / " +
                                data["prefer_type"].toString()),
                      ),
                    ],
                  )),
              Container(
                  margin: MarginPadding.customVerticalSmall(),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: Get.width / 2.5,
                        child:
                            customRowDetailsVertical("Status", data["status"]),
                      ),
                      Container(
                        width: Get.width / 2.5,
                        child: customRowDetailsVertical(
                            "Bid On",
                            DateFormat.yMMMMd().format(
                                DateTime.parse(data["bid_time"].toString()))),
                      ),
                    ],
                  )),
            ],
          ),
          Container(
            margin: MarginPadding.customTop(),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FloatingActionButton.extended(
                    heroTag: "acceptBTN",
                    backgroundColor: teleGreen,
                    onPressed: () {},
                    icon: normalIcon(Icons.check_outlined, color: teleWhite),
                    label: normalText("Accept", color: teleWhite)),
                FloatingActionButton.extended(
                    heroTag: "rejectBTN",
                    backgroundColor: teleRed,
                    onPressed: () {},
                    icon: normalIcon(Icons.close_outlined, color: teleWhite),
                    label: normalText("Reject", color: teleWhite)),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget customRowDetailsVertical(
    String title,
    String value,
  ) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          title + ": ",
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: teleBlue,
          ),
        ),
        Text(
          printValidString(
            value,
          ),
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: telePurple2,
          ),
        ),
      ],
    );
  }
}
// import 'dart:convert';
// import 'dart:developer';
// import 'dart:io';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:teleradiology/Constants/colors_customer.dart';
// import 'package:get/get.dart';
// import 'package:teleradiology/Constants/dimensions.dart';
// import 'package:teleradiology/Screens%20Customer/Rent%20Details/rentdetails.dart';
// import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
// import 'package:teleradiology/common/commonDialog.dart';
// import 'package:teleradiology/common/commonLoader.dart';
// import 'package:teleradiology/res/strings.dart';
// import 'package:teleradiology/res/urls.dart';
// import 'package:teleradiology/service%20screen/controller/serviceDetailsController.dart';
// import 'package:teleradiology/service%20screen/model/serviceModel.dart';
// import 'package:teleradiology/services/sharedPreferenceServices.dart';
// import 'package:teleradiology/utils/allTextStyle.dart';
// import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
// import 'package:teleradiology/utils/checkApiValueValid.dart';
// import 'package:teleradiology/utils/internetCheck.dart';
// import 'package:teleradiology/utils/marginPadding.dart';
// import 'package:teleradiology/utils/printValidString.dart';
// import 'package:teleradiology/utils/showOfflineSnakbar.dart';
// import 'package:teleradiology/widget/noDataFound.dart';
// import 'package:teleradiology/widget/roundedInputField.dart';

// class ServiceDetails extends StatefulWidget {
//   const ServiceDetails({Key? key}) : super(key: key);

//   @override
//   State<ServiceDetails> createState() => _ServiceDetailsState();
// }

// class _ServiceDetailsState extends State<ServiceDetails> {
//   ServiceDetailsController serviceDetailsController =
//       Get.put(ServiceDetailsController());

//   @override
//   void initState() {
//     super.initState();
//     // fetchServiceDetails();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Obx(
//       () => SafeArea(
//         child: Scaffold(
//             appBar: AppBar(
//               backgroundColor: backgroundBlue,
//               elevation: 0,
//               leading: InkWell(
//                 child: Container(
//                     child: InkWell(
//                         onTap: () {
//                           Get.back();
//                         },
//                         child: Icon(
//                           Icons.arrow_back_ios,
//                           color: teleBlue2,
//                           size: 20,
//                         ))),
//               ),
//               centerTitle: true,
//               title: Text("Service Details"),
//               titleTextStyle: TextStyle(
//                   fontSize: 20,
//                   fontFamily: "NunitoSans",
//                   fontWeight: FontWeight.bold,
//                   color: Color(0xFF184673)),
//             ),
//             backgroundColor: backgroundBlue,
//             body: serviceDetailsController.loading.value
//                 ? noDataFound(text: Strings.loading)
//                 : serviceModel! == null
//                     ? noDataFound()
//                     : ListView(
//                         physics: BouncingScrollPhysics(),
//                         children: [
//                           Stack(
//                             children: [
//                               Padding(
//                                 padding: EdgeInsets.only(
//                                     top: ScaleController.H * 0.1),
//                                 child: Container(
//                                   alignment: AlignmentDirectional.bottomCenter,
//                                   decoration: BoxDecoration(
//                                       color: Color(0xFFECF7FE),
//                                       borderRadius: BorderRadius.only(
//                                           topLeft: Radius.circular(50),
//                                           topRight: Radius.circular(50))),
//                                   child: Padding(
//                                     padding: const EdgeInsets.symmetric(
//                                         horizontal: 30),
//                                     child: Column(
//                                       children: [
//                                         SizedBox(
//                                           height: ScaleController.H * 0.12,
//                                         ),
//                                         Text(
//                                           printValidString(
//                                             serviceDetailsController
//                                                 .serviceModel.title,
//                                           ),
//                                           style: heading2TextStyle(
//                                             fontFamily: "NunitoSans-Bold",
//                                             color: teleBlue2,
//                                           ),
//                                         ),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.02,
//                                         ),
//                                         Text(
//                                           printValidString(
//                                             serviceDetailsController
//                                                 .serviceModel
//                                                 
//                                                 .description,
//                                           ),
//                                           textAlign: TextAlign.center,
//                                           style: normalTextStyle(
//                                             fontFamily: "NunitoSans-Regular",
//                                             fontWeight: FontWeight.w300,
//                                             color: telePurple2,
//                                           ),
//                                         ),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.02,
//                                         ),
//                                         customRowDetails(
//                                             "Coverage Hours",
//                                             serviceDetailsController
//                                                 .serviceModel
//                                                 
//                                                 .coverageHours),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         customRowDetails(
//                                             "Modalities",
//                                             serviceDetailsController
//                                                 .serviceModel
//                                                 
//                                                 .modalities),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         customRowDetails(
//                                             "Type of facility",
//                                             serviceDetailsController
//                                                 .serviceModel
//                                                 
//                                                 .typeOfFacility),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         customRowDetails(
//                                             "Volumes",
//                                             serviceDetailsController
//                                                 .serviceModel.volumes),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         Divider(),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         customRowDetails(
//                                             "Click Price",
//                                             serviceDetailsController
//                                                 .serviceModel
//                                                 
//                                                 .clickPrice),
//                                         Row(
//                                           crossAxisAlignment:
//                                               CrossAxisAlignment.center,
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.spaceEvenly,
//                                           children: [
//                                             customRowDetails(
//                                                 "Min",
//                                                 serviceDetailsController
//                                                     .serviceModel
//                                                     
//                                                     .clickPriceNightMin),
//                                             customRowDetails(
//                                                 "Max",
//                                                 serviceDetailsController
//                                                     .serviceModel
//                                                     
//                                                     .clickPriceNightMax),
//                                           ],
//                                         ),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         Divider(),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         customRowDetails(
//                                             "Hour Price",
//                                             serviceDetailsController
//                                                 .serviceModel.hourPrice),
//                                         Row(
//                                           crossAxisAlignment:
//                                               CrossAxisAlignment.center,
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.spaceEvenly,
//                                           children: [
//                                             customRowDetails(
//                                                 "Min",
//                                                 serviceDetailsController
//                                                     .serviceModel
//                                                     
//                                                     .hourPriceNightMin),
//                                             customRowDetails(
//                                                 "Max",
//                                                 serviceDetailsController
//                                                     .serviceModel
//                                                     
//                                                     .hourPriceNightMax),
//                                           ],
//                                         ),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         Divider(),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.01,
//                                         ),
//                                         Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                           crossAxisAlignment:
//                                               CrossAxisAlignment.center,
//                                           children: [
//                                             Container(
//                                               alignment: Alignment.center,
//                                               height: ScaleController.H * 0.075,
//                                               padding: MarginPadding
//                                                   .customHorizontalLarge(),
//                                               decoration: BoxDecoration(
//                                                   boxShadow: [
//                                                     BoxShadow(
//                                                         color:
//                                                             Color(0xffBBC9D3),
//                                                         blurRadius: 10,
//                                                         offset: Offset(0, 7.5))
//                                                   ],
//                                                   borderRadius:
//                                                       BorderRadius.all(
//                                                           Radius.circular(32)),
//                                                   gradient: LinearGradient(
//                                                     colors: [
//                                                       Color(0xff0581D7),
//                                                       Color(0xff1463D4),
//                                                     ],
//                                                   )),
//                                               child: Text(
//                                                 "Edit Service",
//                                                 textAlign: TextAlign.center,
//                                                 style: TextStyle(
//                                                     fontFamily: "Gilroy-Bold",
//                                                     fontWeight: FontWeight.bold,
//                                                     fontSize: 18,
//                                                     decoration:
//                                                         TextDecoration.none,
//                                                     color: Colors.white),
//                                               ),
//                                             ),
//                                           ],
//                                         ),
//                                         SizedBox(
//                                           height: ScaleController.H * 0.06,
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               Padding(
//                                 padding: EdgeInsets.only(
//                                     top: ScaleController.H * 0.01),
//                                 child: Center(
//                                   child: Container(
//                                     decoration: BoxDecoration(
//                                         boxShadow: [
//                                           BoxShadow(
//                                               offset: Offset(0, 0.5),
//                                               color: Color(0xffD7E6F0),
//                                               blurRadius: 10)
//                                         ],
//                                         color: Color(0xff2A8FEA),
//                                         border: Border.all(
//                                             color: Colors.white, width: 7.5),
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(16))),
//                                     height: ScaleController.H * 0.17,
//                                     width: ScaleController.W * 0.38,
//                                     child: ClipRRect(
//                                         borderRadius: BorderRadius.circular(16),
//                                         child: serviceDetailsController
//                                                             .serviceModel !=
//                                                         null &&
//                                                     serviceDetailsController
//                                                         .serviceModel
//                                                         
//                                                         .serviceImage
//                                                         .isEmpty ||
//                                                 serviceDetailsController
//                                                         .serviceModel
//                                                         
//                                                         .serviceImage ==
//                                                     "null"
//                                             ? Image.asset(
//                                                 "assets/Images/radiology_list.png",
//                                                 height: ScaleController.W * 0.3,
//                                                 width: ScaleController.W * 0.31,
//                                                 fit: BoxFit.fill,
//                                               )
//                                             : CachedNetworkImage(
//                                                 progressIndicatorBuilder:
//                                                     (context, url, progress) =>
//                                                         Center(
//                                                   child:
//                                                       CircularProgressIndicator(
//                                                     color: teleBlue,
//                                                   ),
//                                                 ),
//                                                 imageUrl: Urls.imagePreUrl +
//                                                     serviceDetailsController
//                                                         .serviceModel
//                                                         
//                                                         .serviceImage,
//                                                 height: ScaleController.W * 0.3,
//                                                 width: ScaleController.W * 0.31,
//                                                 fit: BoxFit.fill,
//                                               )),
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           )
//                         ],
//                       )),
//       ),
//     );
//   }

//   Widget customRowDetails(String title, String value, {bool header = false}) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       crossAxisAlignment: CrossAxisAlignment.center,
//       children: [
//         Text(
//           title + ": ",
//           textAlign: TextAlign.center,
//           style: header
//               ? heading2TextStyle(
//                   fontFamily: "NunitoSans-Regular",
//                   fontWeight: FontWeight.bold,
//                   color: teleBlue2,
//                 )
//               : normalTextStyle(
//                   fontFamily: "NunitoSans-Regular",
//                   fontWeight: FontWeight.w300,
//                   color: teleBlue,
//                 ),
//         ),
//         Text(
//           printValidString(
//             value,
//           ),
//           textAlign: TextAlign.center,
//           style: normalTextStyle(
//             fontFamily: "NunitoSans-Regular",
//             fontWeight: FontWeight.w300,
//             color: telePurple2,
//           ),
//         ),
//       ],
//     );
//   }

//   Future fetchServiceDetails() async {
//     ServiceDetailsController serviceDetailsControllerTemp =
//         Get.put(ServiceDetailsController());
//     // serviceDetailsControllerTemp.serviceModel = null;
//     setState(() {});
//     if (await internetCheck()) {
//       commonLoader(context, teleBlue);
//       var userId = await getUserId();
//       var token = await getAuthToken();
//       String body = json.encode({
//         "user_id": userId,
//         "user_type": 3,
//         "service_id": serviceDetailsController.serviceId.value,
//       });
//       apiPostRequestWithHeader(context, Urls.sMyServiceView, body, token!)
//           .then((response) {
//         if (response == null) {
//           Get.back();

//           commonAlertDialog(Strings.warning, Strings.connectionFailure);
//         } else {
//           Map<String, dynamic> jsonData = json.decode(response);
//           if (checkApiResponseSuccessOrNot(jsonData)) {
//             Get.back();
//             try {
//               if (jsonData["data"].isNotEmpty) {
//                 if (jsonData["data"]["serviceData"].isNotEmpty) {
//                   serviceDetailsControllerTemp.serviceModel = Rx<ServiceModel>(
//                       ServiceModel.fromJson(jsonData["data"]["serviceData"]));
//                   setState(() {});
//                 } else {
//                   serviceDetailsControllerTemp.serviceModel = null;
//                 }
//               } else {
//                 serviceDetailsControllerTemp.serviceModel = null;
//               }

//               serviceDetailsControllerTemp.loading.value = false;
//               setState(() {});
//             } catch (e) {
//               serviceDetailsControllerTemp.loading.value = false;
//               setState(() {});
//               log(e.toString());
//             }
//             setState(() {});
//           } else {
//             serviceDetailsControllerTemp.loading.value = false;
//             setState(() {});
//             Get.back();
//             String msg = showValidValue(jsonData["msg"]);
//             commonAlertDialog(Strings.warning, showValidValue(msg));
//           }
//         }
//       });
//     } else {
//       serviceDetailsControllerTemp.loading.value = false;
//       setState(() {});
//       showOfflineSnakbar(context);
//     }
//   }
// }
