import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/common/commonTwoButtonDialog.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/service%20screen/controller/homeSerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/controller/mySerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/controller/serviceDetailsController.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/service/serviceDetails.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/button.dart';

class ServiceCard extends StatelessWidget {
  final ServiceModel model;
  const ServiceCard({Key? key, required this.model}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return InkWell(
      onTap: () {
        ServiceDetailsController serviceDetailsController =
            Get.put(ServiceDetailsController());
        serviceDetailsController.serviceId.value = model.id;
        try {
          // serviceDetailsController.serviceModel.value = model;
          // serviceDetailsController.serviceModel = model;
        } catch (e) {
          log(e.toString());
        }
        Get.to(() => ServiceDetails());
      },
      child: Container(
        // height: size.height * 0.2,
        padding: MarginPadding.customVerticalLarge(),
        width: size.width * 0.9,
        decoration: BoxDecoration(
            color: Color(0xFFE0F4FF),
            borderRadius: BorderRadius.all(Radius.circular(20)),
            border: Border.all(color: Color(0xFFBFD6E4), width: 5)),
        child: Padding(
          padding: EdgeInsets.only(left: size.width * 0.05),
          child: Row(
            children: [
              Container(
                height: size.width * 0.3,
                width: size.width * 0.31,
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: model.serviceImage.isEmpty ||
                            model.serviceImage == "null"
                        ? Image.asset(
                            "assets/Images/radiology_list.png",
                            height: size.width * 0.3,
                            width: size.width * 0.31,
                            fit: BoxFit.fill,
                          )
                        : CachedNetworkImage(
                            progressIndicatorBuilder:
                                (context, url, progress) => Center(
                              child: CircularProgressIndicator(
                                color: teleBlue,
                              ),
                            ),
                            imageUrl: model.serviceImage,
                            height: size.width * 0.3,
                            width: size.width * 0.31,
                            fit: BoxFit.fill,
                          )),
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.white, width: 5),
                    borderRadius: BorderRadius.all(Radius.circular(16))),
              ),
              SizedBox(
                width: size.width * 0.05,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: Get.width * 0.4,
                    child: Text(
                      printValidString(model.title),
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: "NunitoSans",
                          color: Color(0xFF184673)),
                    ),
                  ),
                  SizedBox(
                    width: size.width * 0.45,
                    child: Text(
                      printValidString(model.description),
                      maxLines: 3,
                      softWrap: true,
                      style: TextStyle(
                          fontSize: 11,
                          fontFamily: "NunitoSans",
                          color: Color(0xFF4A4979)),
                    ),
                  ),
                  SizedBox(
                    height: size.height * 0.01,
                  ),
                  Row(
                    children: [
                      Text(
                        "Price:",
                        style: TextStyle(
                            fontSize: 13,
                            fontFamily: "NunitoSans",
                            color: Color(0xffFCB128)),
                      ),
                      Text(
                        "  \$${model.clickPrice}",
                        style: TextStyle(
                            fontSize: 13,
                            fontFamily: "NunitoSans",
                            color: Color(0xFF4A4979)),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: size.height * 0.01,
                  ),
                  Container(
                    width: Get.width * 0.4,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        smallText("Total Bids: ", color: teleGray),
                        Container(
                          margin: MarginPadding.customLeft(),
                          padding: MarginPadding.customHorizontal(),
                          alignment: Alignment.center,
                          child: normalText(
                            model.numberOfBid,
                            color: teleBlack,
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: size.height * 0.01,
                  ),
                  Container(
                    width: Get.width * 0.4,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        smallText("Status: ", color: teleGray),
                        GestureDetector(
                          onTap: () {
                            commonTwoButtonDialog(Strings.warning,
                                "Are you sure you want to change the status?",
                                function2: () {
                              Get.back();
                              changeStatus(context);
                            });
                          },
                          child: Container(
                            margin: MarginPadding.customLeft(),
                            padding: MarginPadding.customHorizontal(),
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color:
                                        model.status.toLowerCase() == "inactive"
                                            ? teleButtonBlue
                                            : teleGreen),
                                color: teleTransparent,
                                borderRadius: BorderRadius.circular(5)),
                            alignment: Alignment.center,
                            child: normalText(
                              model.status.capitalize!,
                              color: model.status.toLowerCase() == "inactive"
                                  ? teleButtonBlue
                                  : teleGreen,
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Future changeStatus(BuildContext context) async {
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
        "service_id": model.id,
      });
      apiPostRequestWithHeader(context, Urls.sChangeServiceStatus, body, token!)
          .then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            try {
              String msg = showValidValue(jsonData["message"]);
              commonAlertDialog(Strings.alert, showValidValue(msg),
                  function: () {
                Get.back();
                fetchServiceList(context);
              });
            } catch (e) {
              log(e.toString());
            }
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  Future fetchServiceList(BuildContext context) async {
    MySerivceConroller mySerivceConrollerTemp = Get.put(MySerivceConroller());

    HomeSerivceConroller homeSerivceConrollerTemp =
        Get.put(HomeSerivceConroller());
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
      });
      apiPostRequestWithHeader(context, Urls.sMyServiceList, body, token!)
          .then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            List tempList = jsonData["data"]["serviceList"];
            try {
              List<ServiceModel> serviceList =
                  tempList.map((json) => ServiceModel.fromJson(json)).toList();
              mySerivceConrollerTemp.serviceList.value = serviceList;
              List<ServiceModel> serviceList2 =
                  tempList.map((json) => ServiceModel.fromJson(json)).toList();
              homeSerivceConrollerTemp.serviceList.value = serviceList;
            } catch (e) {
              log(e.toString());
            }
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
