import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/Constants/servicecolors.dart';
import 'package:teleradiology/screens/Navigation%20Page/navigationPage.dart';
import 'package:teleradiology/screens/profile/profile.dart';
import 'package:teleradiology/screens/service%20screen/myService.dart';
import 'package:teleradiology/screens/service%20screen/service_homepage.dart'; 
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allIcon.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';

import 'most_visited.dart';
import 'order_history.dart';
import 'services.dart';

int serviceDrawerIndex = 0;

int serviceBottomNavigationIndex = 0;
Widget serviceScreenWidget = Container();
String serviceScreenTitle = "";

class ServiceMainScreen extends StatefulWidget {
  ServiceMainScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<ServiceMainScreen> createState() => _ServiceMainScreenState();
}

class _ServiceMainScreenState extends State<ServiceMainScreen> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  List tileText = [
    // "Service Information",
    "Home",
    "Profile",
    "Change Password",
    "Manage Service",
    "My Service",

    // "Service Details",
    "Manage Subscription",
    "Manage Featured Subscription",
    "Order History",
    "About",
    "Terms & Conditions",
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: scaffoldKey,
        appBar: AppBar(
          backgroundColor: background,
          elevation: 0,
          leading: InkWell(
            onTap: () {
              scaffoldKey.currentState!.openDrawer();
            },
            child: SizedBox(
                height: 10,
                width: 10,
                child: Icon(
                  Icons.menu,
                  color: teleBlue,
                )),
          ),
          centerTitle: true,
          title: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: ScaleController.W * 0.005),
                child: Image.asset(
                  "assets/Images/homeLogo.png",
                  fit: BoxFit.cover,
                  // width: Get.width * 0.08,
                  height: Get.width * 0.065,
                ),
              ),
              smallText(
                "Teleradiology Service",
                fontFamily: "NunitoSans",
                color: Color(0xff303E69),
                fontWeight: FontWeight.w600,
                center: true,
              ),
            ],
          ),
          titleTextStyle: TextStyle(
              fontSize: 20, fontFamily: "NunitoSans-Bold", color: darkPurple),
          flexibleSpace: Container(
            decoration: BoxDecoration(
                color: appbar,
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16))),
          ),
          actions: [
            InkWell(
              onTap: () {},
              child: Padding(
                padding: EdgeInsets.only(right: Get.width * 0.04),
                child: Center(
                  child: Stack(
                    children: [
                      Icon(
                        Icons.notifications,
                        color: Color(0xffBDC5D5),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: Get.width * 0.03,
                        ),
                        child: CircleAvatar(
                          backgroundColor: Color(0xffFCB128),
                          radius: 7,
                          child: Text(
                            "3",
                            style: TextStyle(fontSize: 11, color: Colors.white),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
        drawer: Drawer(
          width: Get.width * 0.9,
          child: Container(
            color: Color(0xffECF7FE),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  InkWell(
                    onTap: () {
                      Get.to(ServiceProfileScreen(onlyBody: false,isCustomer: false,));
                    },
                    child: Padding(
                      padding: EdgeInsets.only(
                          left: Get.width * 0.025, top: Get.height * 0.02),
                      child: Row(
                        children: [
                          Container(
                            width: Get.width * 0.2,
                            height: Get.width * 0.2,
                            decoration: BoxDecoration(
                                border: Border.all(color: teleWhite, width: 5),
                                borderRadius: BorderRadius.circular(100)),
                            child: FutureBuilder(
                                future: getImage(),
                                builder: (BuildContext context,
                                    AsyncSnapshot<String?> text) {
                                  return text.data == null ||
                                          text.data!.isEmpty ||
                                          text.data == "null"
                                      ? CircleAvatar(
                                          radius: Get.width * 0.15,
                                          backgroundColor: Colors.white,
                                          backgroundImage: const AssetImage(
                                            "assets/Images/noImage.png",
                                          ),
                                        )
                                      : ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: CachedNetworkImage(
                                            progressIndicatorBuilder:
                                                (context, url, progress) =>
                                                    Center(
                                              child: CircleAvatar(
                                                radius: Get.width * 0.3,
                                                backgroundColor: Colors.white,
                                                child:
                                                    CircularProgressIndicator(
                                                  color: teleBlue,
                                                ),
                                              ),
                                            ),
                                            imageUrl: text.data!,
                                            fit: BoxFit.cover,
                                          ),
                                        );
                                }),
                          ),
                          SizedBox(
                            width: Get.width * 0.05,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: ScaleController.W * 0.32,
                                child: FutureBuilder(
                                    future: getFirstName(),
                                    builder: (BuildContext context,
                                        AsyncSnapshot<String?> text) {
                                      return normalText(
                                          printValidString(text.data),
                                          color: teleBlue);
                                    }),
                              ),
                              Container(
                                width: ScaleController.W * 0.32,
                                child: FutureBuilder(
                                    future: getEmail(),
                                    builder: (BuildContext context,
                                        AsyncSnapshot<String?> text) {
                                      return smallText(
                                          printValidString(text.data),
                                          color: Color(0xFF4A4979));
                                    }),
                              ),
                            ],
                          )
                          // Column(
                          //   crossAxisAlignment: CrossAxisAlignment.start,
                          //   children: [
                          //     Text(
                          //       "ABC Company pvt",
                          //       style: TextStyle(
                          //           fontFamily: "NunitoSans",
                          //           fontSize: 18,
                          //           color: Color(0xFF303E69)),
                          //     ),
                          //     Text(
                          //       "info@abccompany.com",
                          //       style: TextStyle(
                          //           fontFamily: "NunitoSans",
                          //           fontSize: 13,
                          //           color: Color(0xFF4A4979)),
                          //     ),
                          //   ],
                          // )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * 0.01,
                  ),
                  Container(
                    child: Divider(
                      height: Get.height * 0.08,
                      color: Color(0xFF7978A0),
                    ),
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: ScrollPhysics(),
                    itemCount: tileText.length,
                    itemBuilder: (BuildContext context, int index) {
                      if (index == serviceDrawerIndex) {
                        // scaffoldKey.currentState!.openEndDrawer();
                        return Padding(
                          padding: const EdgeInsets.only(right: 10, left: 15),
                          child: Container(
                            height: Get.height * 0.065,
                            width: Get.width * 0.2,
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 10),
                            decoration: BoxDecoration(
                                color: Color(0xffC2DFDC),
                                borderRadius: BorderRadius.circular(30)),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  "assets/Images/drawer$index.svg",
                                  color: Colors.white,
                                  height: 22,
                                ),
                                SizedBox(
                                  width: 8,
                                ),
                                Text(
                                  "${tileText[index]}",
                                  style: TextStyle(
                                      fontFamily: "NunitoSans",
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: textcolor),
                                ),
                              ],
                            ),
                          ),
                        );
                      }
                      return InkWell(
                        onTap: () {
                          setState(() {
                            serviceDrawerIndex = index;
                          });

                          switch (index) {
                            case 0:
                              // Get.to(ServiceProviderProfile());
                              // Get.to(ServiceMainScreen());
                              serviceScreenWidget = ServiceHomePage();
                              scaffoldKey.currentState!.closeDrawer();

                              break;
                            case 1:
                              // Get.to(ServiceProviderProfile());
                              // Get.to(ServiceProfileScreen(onlyBody: true));
                              serviceScreenWidget =
                                  ServiceProfileScreen(onlyBody: true,isCustomer: false,);
                              scaffoldKey.currentState!.closeDrawer();

                              break;
                            case 3:
                              // Get.to(ServicePage());
                              serviceScreenWidget = ServicePage();
                              scaffoldKey.currentState!.closeDrawer();

                              break;
                            case 4:
                              // Get.to(MyService());
                              serviceScreenWidget = MyService();
                              scaffoldKey.currentState!.closeDrawer();

                              break;
                            case 7:
                              // Get.to(ServiceOrderHistory());
                              serviceScreenWidget = ServiceOrderHistory();
                              scaffoldKey.currentState!.closeDrawer();

                              break;

                            default:
                          }

                          setState(() {});
                        },
                        child: ListTile(
                          title: Row(
                            children: [
                              SvgPicture.asset(
                                "assets/Images/drawer$index.svg",
                                height: 20,
                              ),
                              SizedBox(
                                width: Get.width * 0.03,
                              ),
                              Text(
                                "${tileText[index]}",
                                style: TextStyle(
                                    fontFamily: "NunitoSans",
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: textcolor),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(
                    height: Get.height * 0.03,
                  ),
                  Container(
                    child: Divider(
                      color: Color(0xFF7978A0),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Get.width * 0.05, top: Get.height * 0.02),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        InkWell(
                          onTap: () {
                            setUserType("");
                            Get.to((() => NavigationPage()));
                            // Get.off(ServiceSignInPage(emailId: "",));
                          },
                          child: Container(
                            height: Get.height * 0.06,
                            width: Get.width * 0.3,
                            decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(32)),
                                color: teleBlue),
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: Get.width * 0.05,
                                  right: Get.width * 0.05,
                                  top: Get.height * 0.008,
                                  bottom: Get.height * 0.008),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.logout_outlined,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                  Text(
                                    "  Logout",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontFamily: "NunitoSans",
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: Get.height * 0.03,
                  ),
                ],
              ),
            ),
          ),
        ),
        backgroundColor:
            serviceBottomNavigationIndex == 2 || serviceBottomNavigationIndex == 3
                ? Color(0xffECF7FE)
                : background,
        body: serviceScreenWidget,
        bottomNavigationBar: ClipRRect(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16)),
          child: BottomNavigationBar(
            elevation: 0,
            currentIndex: serviceBottomNavigationIndex,
            selectedItemColor: Color(0xff303E69),
            unselectedItemColor: Color(0xFF7978A0),
            backgroundColor: Color(0xffE0F4FF),
            items: [
              BottomNavigationBarItem(
                icon: SvgPicture.asset(
                  "assets/Images/home.svg",
                  height: 22,
                ),
                label: "Home",
              ),
              // BottomNavigationBarItem(
              //     icon: SvgPicture.asset(
              //       "assets/Images/analytics.svg",
              //       height: 22,
              //     ),
              //     label: "Analytics",
              //     backgroundColor: Color(0xFFE0F4FF)),
              BottomNavigationBarItem(
                  icon: SvgPicture.asset(
                    "assets/Images/profile.svg",
                    height: 22,
                  ),
                  label: "Profile",
                  backgroundColor: Color(0xFFE0F4FF)),
              BottomNavigationBarItem(
                  icon: Icon(
                    Icons.shopping_cart_outlined,
                  ),
                  label: "Cart",
                  backgroundColor: Color(0xFFE0F4FF)),
              BottomNavigationBarItem(
                  icon: Icon(
                    Icons.dashboard,
                  ),
                  label: "DashBoard",
                  backgroundColor: Color(0xFFE0F4FF)),
            ],
            selectedLabelStyle:
                TextStyle(fontFamily: 'NunitoSans', color: Color(0xFF4A4979)),
            onTap: (index) {
              setState(() {
                serviceBottomNavigationIndex = index;
                switch (serviceBottomNavigationIndex) {
                  case 0:
                    serviceScreenWidget = ServiceHomePage();
                    break;
                  case 1:
                    serviceScreenWidget = ServiceProfileScreen(onlyBody: true,isCustomer: false,);
                    break;
                  case 2:
                    serviceScreenWidget = ServiceOrderHistory();
                    break;

                  case 3:
                    serviceScreenWidget = MostVisitedScreen();
                    break;
                  default:
                }
                setState(() {});
              });
            },
          ),
        ),
      ),
    );
  }
}
