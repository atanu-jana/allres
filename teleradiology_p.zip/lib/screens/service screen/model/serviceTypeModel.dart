
class ServiceTypeModel {
  ServiceTypeModel({
    required this.id,
    required this.name 
  });

  final String id; 
  final String name;  

  factory ServiceTypeModel.fromJson(Map<String, dynamic> json) => ServiceTypeModel(
        id: json["id"].toString(),
        name: json["name"].toString(),  
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,  
      };
}
