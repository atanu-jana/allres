
class ServiceModel {
  ServiceModel({
    required this.id,
    required this.serviceUniqueId, 
    required this.serviceTypeId, 
    required this.title, 
    required this.description, 
    required this.userId, 
    required this.serviceImage, 
    required this.serviceVideo, 
    required this.coverageHours, 
    required this.volumes, 
    required this.modalities, 
    required this.state, 
    required this.typeOfFacility, 
    required this.credentialingNeeded, 
    required this.numberOfBid, 
    required this.priceType, 
    required this.clickPrice, 
    required this.clickPriceNightMin, 
    required this.clickPriceNightMax, 
    required this.hourPrice, 
    required this.hourPriceNightMin, 
    required this.hourPriceNightMax, 
    required this.status, 
    required this.serviceBids, 
    required this.serviceImages, 
  });

  final String id; 
  final String serviceUniqueId; 
  final String serviceTypeId; 
  final String title; 
  final String description; 
  final String userId; 
  final String serviceImage; 
  final String serviceVideo; 
  final String coverageHours; 
  final String volumes; 
  final String modalities; 
  final String state; 
  final String typeOfFacility; 
  final String credentialingNeeded; 
  final String numberOfBid; 
  final String priceType; 
  final String clickPrice; 
  final String clickPriceNightMin; 
  final String clickPriceNightMax; 
  final String hourPrice; 
  final String hourPriceNightMin; 
  final String hourPriceNightMax; 
  final String status; 
  final List serviceBids; 
  final List serviceImages; 

  factory ServiceModel.fromJson(Map<String, dynamic> json) => ServiceModel(
        id: json["id"].toString(),
        serviceUniqueId: json["service_unique_id"].toString(), 
        serviceTypeId: json["service_type_id"].toString(), 
        title: json["title"].toString(), 
        description: json["description"].toString(), 
        userId: json["user_id"].toString(), 
        serviceImage: json["service_image_path"].toString(), 
        serviceVideo: json["service_video"].toString(), 
        coverageHours: json["coverage_hours"].toString(), 
        volumes: json["volumes"].toString(), 
        modalities: json["modalities"].toString(), 
        state: json["state"].toString(), 
        typeOfFacility: json["type_of_facility"].toString(), 
        credentialingNeeded: json["credentialing_needed"].toString(), 
        numberOfBid: json["number_of_bid"].toString(), 
        priceType: json["price_type"].toString(), 
        clickPrice: json["click_price"].toString(), 
        clickPriceNightMin: json["click_price_night_min"].toString(), 
        clickPriceNightMax: json["click_price_night_max"].toString(), 
        hourPrice: json["hour_price"].toString(), 
        hourPriceNightMin: json["hour_price_night_min"].toString(), 
        hourPriceNightMax: json["hour_price_night_max"].toString(), 
        status: json["status"].toString(), 
        serviceBids: json["service_bids"]??[] , 
        serviceImages: json["service_images"]??[] , 
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "service_unique_id": serviceUniqueId, 
        "service_type_id": serviceTypeId, 
        "title": title, 
        "description": description, 
        "user_id": userId, 
        "service_image_path": serviceImage, 
        "service_video": serviceVideo, 
        "coverage_hours": coverageHours, 
        "volumes": volumes, 
        "modalities": modalities, 
        "state": state, 
        "type_of_facility": typeOfFacility, 
        "credentialing_needed": credentialingNeeded, 
        "number_of_bid": numberOfBid, 
        "price_type": priceType, 
        "click_price": clickPrice, 
        "click_price_night_min": clickPriceNightMin, 
        "click_price_night_max": clickPriceNightMax, 
        "hour_price": hourPrice, 
        "hour_price_night_min": hourPriceNightMin, 
        "hour_price_night_max": hourPriceNightMax, 
        "status": status, 
        "service_bids": serviceBids, 
        "service_images": serviceImages, 
      };
}
