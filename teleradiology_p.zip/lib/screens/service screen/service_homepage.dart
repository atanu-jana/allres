import 'dart:convert';
import 'dart:developer';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/service%20screen/controller/homeSerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/widgets/serviceCard.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/noDataFound.dart';

class ServiceHomePage extends StatefulWidget {
  const ServiceHomePage({
    Key? key,
  }) : super(key: key);

  @override
  State<ServiceHomePage> createState() => _ServiceHomePageState();
}

class _ServiceHomePageState extends State<ServiceHomePage> {
  HomeSerivceConroller mySerivceConroller = Get.put(HomeSerivceConroller());
  @override
  void initState() {
    super.initState();
    fetchServiceList();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Obx(
      () => SafeArea(
        child: Scaffold(
          backgroundColor: background,
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: Get.height * 0.01,
                ),
                Stack(
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: Get.height * 0.08,
                        padding: EdgeInsets.only(
                            left: Get.width * 0.05, right: Get.width * 0.05),
                        child: TextFormField(
                          cursorColor: teleGray,
                          decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.search_rounded,
                                color: Color(0xFF8771A7),
                              ),
                              hintText: "Search radiology services here......",
                              hintStyle: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF4A4979),
                                  fontFamily: "NunitoSans"),
                              filled: true,
                              contentPadding: EdgeInsets.all(15),
                              fillColor: secondarybg,
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: telestrokeBorder, width: 5),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(32))),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: telestrokeBorder, width: 5),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(32)))),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(
                          right: Get.width * 0.06,
                        ),
                        child: Container(
                          height: Get.height * 0.075,
                          width: Get.width * 0.16,
                          child: Center(
                            child: Text(
                              "Go",
                              style: TextStyle(
                                  fontSize: 20,
                                  fontFamily: "NunitoSans",
                                  color: Colors.white),
                            ),
                          ),
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(16)),
                              gradient: LinearGradient(
                                begin: Alignment.topRight,
                                end: Alignment.bottomLeft,
                                colors: [
                                  Color(0xff303E69),
                                  Color(0xff162657),
                                ],
                              )),
                        ),
                      ),
                    )
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(
                      left: Get.width * 0.03, right: Get.width * 0.03),
                  child: Container(
                    height: Get.height * 0.18,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 6,
                      shrinkWrap: true,
                      itemBuilder: (BuildContext context, int index) {
                        return Row(
                          children: [
                            buildListCardHome(
                                "assets/Images/radiology_list.png",
                                "Radiology"),
                            SizedBox(
                              width: Get.width * 0.02,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
                Container(
                  width: Get.width * 0.1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 6,
                        width: 20,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Color(0xff89A7D8)),
                      ),
                      Container(
                        height: 6,
                        width: 6,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: Color(0xff89A7D8)),
                      ),
                      Container(
                        height: 6,
                        width: 6,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: Color(0xff89A7D8)),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.01,
                ),
                Container(
                  width: Get.width * 0.95,
                  child: Divider(
                    color: Color(0xFF7978A0),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.01,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Text(
                          "   Our Services",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              fontFamily: "NunitoSans",
                              color: Color(0xFF303E69)),
                        ),
                        SizedBox(
                          width: Get.height * 0.01,
                        ),
                        Container(
                          height: 6,
                          width: 20,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Color(0xFF303E69)),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          "See All     ",
                          style: TextStyle(
                              fontSize: 13,
                              fontFamily: "NunitoSans",
                              color: Color(0xffFCB128)),
                        ),
                      ],
                    )
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.03,
                ),
                mySerivceConroller.serviceList.isEmpty
                    ? noDataFound()
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: mySerivceConroller.serviceList.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Column(
                            children: [
                              ServiceCard(
                                  model: mySerivceConroller.serviceList[index]),
                              SizedBox(
                                height: Get.height * 0.01,
                              )
                            ],
                          );
                        },
                      )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Container buildHomeCard(ServiceModel model) {
    Size size = MediaQuery.of(context).size;

    return Container(
      height: Get.height * 0.2,
      width: Get.width * 0.9,
      decoration: BoxDecoration(
          color: Color(0xFFE0F4FF),
          borderRadius: BorderRadius.all(Radius.circular(20)),
          border: Border.all(color: Color(0xFFBFD6E4), width: 5)),
      child: Padding(
        padding: EdgeInsets.only(left: Get.width * 0.05),
        child: Row(
          children: [
            Container(
              height: Get.width * 0.3,
              width: Get.width * 0.31,
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child:
                      model.serviceImage.isEmpty || model.serviceImage == "null"
                          ? Image.asset(
                              "assets/Images/radiology_list.png",
                              height: Get.width * 0.3,
                              width: Get.width * 0.31,
                              fit: BoxFit.fill,
                            )
                          : CachedNetworkImage(
                              progressIndicatorBuilder:
                                  (context, url, progress) => Center(
                                child: CircularProgressIndicator(
                                  color: teleBlue,
                                ),
                              ),
                              imageUrl:
                                  "https://mydevfactory.com/~saikat8/teleradiology/public/uploads/service_users/" +
                                      model.serviceImage,
                              height: Get.width * 0.3,
                              width: Get.width * 0.31,
                              fit: BoxFit.fill,
                            )),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.white, width: 5),
                  borderRadius: BorderRadius.all(Radius.circular(16))),
            ),
            SizedBox(
              width: Get.width * 0.05,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  printValidString(model.title),
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: "NunitoSans",
                      color: Color(0xFF184673)),
                ),
                SizedBox(
                  width: Get.width * 0.45,
                  child: Text(
                    printValidString(model.description),
                    maxLines: 3,
                    softWrap: true,
                    style: TextStyle(
                        fontSize: 11,
                        fontFamily: "NunitoSans",
                        color: Color(0xFF4A4979)),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.01,
                ),
                Row(
                  children: [
                    Text(
                      "Price:",
                      style: TextStyle(
                          fontSize: 13,
                          fontFamily: "NunitoSans",
                          color: Color(0xffFCB128)),
                    ),
                    Text(
                      "  \$${model.clickPrice}",
                      style: TextStyle(
                          fontSize: 13,
                          fontFamily: "NunitoSans",
                          color: Color(0xFF4A4979)),
                    ),
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.01,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget buildListCardHome(String image, String title) {
   

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          height: Get.height * 0.15,
          width: Get.width * 0.3,
          decoration: BoxDecoration(
              color: Color(0xFFE0F4FF),
              borderRadius: BorderRadius.all(Radius.circular(25)),
              border: Border.all(color: telestrokeBorder, width: 5)),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Image.asset(
              image,
              fit: BoxFit.cover,
            ),
          ),
        ),
        SizedBox(
          height: Get.height * 0.01,
        ),
        Text(
          title,
          style: TextStyle(
              fontSize: 13, fontFamily: "NunitoSans", color: Color(0xFF4A4979)),
        ),
      ],
    );
  }

  Future fetchServiceList() async {
    HomeSerivceConroller mySerivceConrollerTemp =
        Get.put(HomeSerivceConroller());
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
      });
      apiPostRequestWithHeader(context, Urls.sMyServiceList, body, token!)
          .then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            List tempList = jsonData["data"]["serviceList"];
            try {
              List<ServiceModel> serviceList =
                  tempList.map((json) => ServiceModel.fromJson(json)).toList();
              mySerivceConrollerTemp.serviceList.value = serviceList;
              setState(() {});
            } catch (e) {
              log(e.toString());
            }
            setState(() {});
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
