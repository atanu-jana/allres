import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/servicecolors.dart';
import 'package:teleradiology/api/apiPostRequest.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/service%20screen/addService.dart';
import 'package:teleradiology/screens/service%20screen/controller/mySerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/widgets/serviceCard.dart'; 
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/noDataFound.dart';
import 'most_visited.dart';
import 'service_mainscreen.dart';

class MyService extends StatefulWidget {
  const MyService({
    Key? key,
  }) : super(key: key);

  @override
  State<MyService> createState() => _MyServiceState();
}

class _MyServiceState extends State<MyService> {
  MySerivceConroller mySerivceConroller = Get.put(MySerivceConroller());

  // List<ServiceModel> serviceList = [];
  @override
  void initState() {
    super.initState();
    fetchServiceList();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Obx(
      () => SafeArea(
        child: Scaffold(
          backgroundColor: background,
          floatingActionButton: FloatingActionButton(
            heroTag: "addServicetag",
            backgroundColor: teleButtonBlue,
            onPressed: () {
              Get.to(() => AddService());
            },
            child: Center(
              child: Icon(
                Icons.add,
                color: teleWhite,
              ),
            ),
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                mySerivceConroller.serviceList.isEmpty
                    ? noDataFound()
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: mySerivceConroller.serviceList.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Column(
                            children: [
                              ServiceCard(
                                  model: mySerivceConroller.serviceList[index]),
                              SizedBox(
                                height: size.height * 0.01,
                              )
                            ],
                          );
                        },
                      )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildListCardHome(String image, String title) {
    Size size = MediaQuery.of(context).size;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          height: size.height * 0.15,
          width: size.width * 0.3,
          decoration: BoxDecoration(
              color: Color(0xFFE0F4FF),
              borderRadius: BorderRadius.all(Radius.circular(25)),
              border: Border.all(color: telestrokeBorder, width: 5)),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Image.asset(
              image,
              fit: BoxFit.cover,
            ),
          ),
        ),
        SizedBox(
          height: size.height * 0.01,
        ),
        Text(
          title,
          style: TextStyle(
              fontSize: 13, fontFamily: "NunitoSans", color: Color(0xFF4A4979)),
        ),
      ],
    );
  }

  Future fetchServiceList() async {
    MySerivceConroller mySerivceConrollerTemp = Get.put(MySerivceConroller());
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
      });
      apiPostRequestWithHeader(context, Urls.sMyServiceList, body, token!)
          .then((response) {
        if (response == null) {
          Get.back();
          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            List tempList = jsonData["data"]["serviceList"];
            try {
              List<ServiceModel> serviceList =
                  tempList.map((json) => ServiceModel.fromJson(json)).toList();
              mySerivceConrollerTemp.serviceList.value = serviceList;
              setState(() {});
            } catch (e) {
              log(e.toString());
            }
            setState(() {});
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
