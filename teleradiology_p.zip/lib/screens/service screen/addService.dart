import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/api/apiGetRequest.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/service%20screen/controller/addSerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/controller/homeSerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/controller/mySerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceTypeModel.dart'; 
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allIcon.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/allTextStyle.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/button.dart';
import 'package:teleradiology/widget/roundedDropdownButton.dart';
import 'package:teleradiology/widget/roundedInputField.dart';
import 'package:video_player/video_player.dart';

class AddService extends StatefulWidget {
  const AddService({Key? key}) : super(key: key);

  @override
  State<AddService> createState() => _AddServiceState();
}

class _AddServiceState extends State<AddService> {
  ServiceTypeModel? serviceTypeController;
  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController coverageHrsController = TextEditingController();
  TextEditingController volumesController = TextEditingController();
  TextEditingController modalitieController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController typeOfFacilitycodeController = TextEditingController();
  TextEditingController credentialingNeededController = TextEditingController();
  TextEditingController clickPriceController = TextEditingController();
  TextEditingController clickPriceMinController = TextEditingController();
  TextEditingController clickPriceMaxController = TextEditingController();
  TextEditingController hourPriceController = TextEditingController();
  TextEditingController hourPriceMinController = TextEditingController();
  TextEditingController hourPriceMaxController = TextEditingController();
  TextEditingController searchTextEditingController = TextEditingController();
  // File? serviceImage;
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  // PickedFile? serviceVieo;
  String videoPickError = "";
  VideoPlayerController? videoController;

  AddSerivceConroller addSerivceConroller = Get.put(AddSerivceConroller());

  @override
  void initState() {
    super.initState();
    AddSerivceConroller addSerivceConrollerTemp =
        Get.put(AddSerivceConroller());
    if (addSerivceConrollerTemp.serviceTypeList.isEmpty) {
      fetchServiceTypeList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => SafeArea(
        child: Scaffold(
            appBar: AppBar(
              backgroundColor: backgroundBlue,
              elevation: 0,
              leading: InkWell(
                child: Container(
                    child: InkWell(
                        onTap: () {
                          Get.back();
                        },
                        child: Icon(
                          Icons.arrow_back_ios,
                          color: teleBlue2,
                          size: 20,
                        ))),
              ),
              centerTitle: true,
              title: Text("Add Service"),
              titleTextStyle: TextStyle(
                  fontSize: 20,
                  fontFamily: "NunitoSans",
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF184673)),
            ),
            backgroundColor: backgroundBlue,
            body: SingleChildScrollView(
              physics: BouncingScrollPhysics(),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: ScaleController.H * 0.01,
                    ),
                    Form(
                      key: formkey,
                      child: Column(
                        children: [
                          Container(
                        width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: RoundedDropDownButton(
                              searchTextEditingController: searchTextEditingController,
                              selectedValue: serviceTypeController,
                              hintText: "Select Service type *",
                              textWidth: ScaleController.W * 0.5,
                              onChange: (dynamic val) {
                                serviceTypeController = val!;
                                setState(() {});
                              },
                              icon: Icons.merge_type,
                              dropdownList:
                                  addSerivceConroller.serviceTypeList.value,
                            ),
                          ),
                            SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: RoundedInputField(
                              controller: titleController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.text,
                              hintText: "Title *",
                              icon: Icons.title,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter Title';
                                }
                                return null;
                              },
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: RoundedInputField(
                              controller: descriptionController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.text,
                              hintText: "Service Description *",
                              icon: Icons.description,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter Service Description';
                                }
                                return null;
                              },
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.05,
                                    right: ScaleController.W * 0.01),
                                child: RoundedInputField(
                                  controller: coverageHrsController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Needed Coverage Hours *",
                                  icon: Icons.hourglass_bottom,
                                  suffixWidget: Container(
                                    width: ScaleController.W * 0.1,
                                    child: normalText("hours",
                                        color: teleBlue, center: true),
                                  ),
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Needed Coverage Hours';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.01,
                                    right: ScaleController.W * 0.05),
                                child: RoundedInputField(
                                  controller: volumesController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Volumes *",
                                  icon: Icons.ring_volume_sharp,
                                  suffixWidget: Container(
                                    width: ScaleController.W * 0.1,
                                    child: normalText("cc",
                                        color: teleBlue, center: true),
                                  ),
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Volumes';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.05,
                                    right: ScaleController.W * 0.01),
                                child: RoundedInputField(
                                  controller: modalitieController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Modalities *",
                                  icon: Icons.circle,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Modalities';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.01,
                                    right: ScaleController.W * 0.05),
                                child: RoundedInputField(
                                    controller: stateController,
                                    textInputAction: TextInputAction.next,
                                    textInputType: TextInputType.streetAddress,
                                    hintText: "State",
                                    icon: Icons.satellite_alt,
                                    onchangeFunction: (String val) {},
                                    validate: (String? value) {
                                      if (value == null || value.isEmpty) {
                                        return 'Please enter state';
                                      }
                                      return null;
                                    }),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.05,
                                    right: ScaleController.W * 0.01),
                                child: RoundedInputField(
                                  controller: typeOfFacilitycodeController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.text,
                                  hintText: "Type Of Facility *",
                                  icon: Icons.type_specimen,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Type Of Facility';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.01,
                                    right: ScaleController.W * 0.05),
                                child: RoundedInputField(
                                    controller: credentialingNeededController,
                                    textInputAction: TextInputAction.next,
                                    textInputType: TextInputType.number,
                                    hintText: "Credentialing Needed *",
                                    icon: Icons.verified,
                                    onchangeFunction: (String val) {},
                                    validate: (String? value) {
                                      if (value == null || value.isEmpty) {
                                        return 'Please enter Credentialing Needed';
                                      }
                                      return null;
                                    }),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: RoundedInputField(
                              controller: clickPriceController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.number,
                              hintText: "Click Price *",
                              icon: Icons.price_change,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter Click Price';
                                }
                                return null;
                              },
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.05,
                                    right: ScaleController.W * 0.01),
                                child: RoundedInputField(
                                  controller: clickPriceMinController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Click Price Night Min *",
                                  icon: Icons.price_change,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Click Price Night Min';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.01,
                                    right: ScaleController.W * 0.05),
                                child: RoundedInputField(
                                  controller: clickPriceMaxController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Click Price Night Max *",
                                  icon: Icons.price_change,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Click Price Night Max';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: RoundedInputField(
                              controller: hourPriceController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.number,
                              hintText: "Hour Price *",
                              icon: Icons.price_change,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter Hour Price';
                                }
                                return null;
                              },
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.05,
                                    right: ScaleController.W * 0.01),
                                child: RoundedInputField(
                                  controller: hourPriceMinController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Hour Price Night Min *",
                                  icon: Icons.price_change,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Hour Price Night Min';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Container(
                                width: ScaleController.W / 2,
                                padding: EdgeInsets.only(
                                    left: ScaleController.W * 0.01,
                                    right: ScaleController.W * 0.05),
                                child: RoundedInputField(
                                  controller: hourPriceMaxController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Hour Price Night Max *",
                                  icon: Icons.price_change,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Hour Price Night Max';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    extraSmallText("Service Image *",
                                        fontWeight: FontWeight.bold,
                                        color: teleBlack),
                                    Container(
                                      margin: EdgeInsets.symmetric(
                                        vertical: ScaleController.W * 0.0,
                                      ),
                                      child: Row(
                                        children: [
                                          Container(
                                            child: GestureDetector(
                                              onTap: () {
                                                pickImageOption(context, true);
                                                setState(() {});
                                              },
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    width:
                                                        ScaleController.W * 0.2,
                                                    height:
                                                        ScaleController.W * 0.2,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  5)),
                                                      color: teleGray
                                                          .withOpacity(0.5),
                                                    ),
                                                    child: Material(
                                                      color: teleGray
                                                          .withOpacity(0.5),
                                                      //display new updated image here
                                                      child: addSerivceConroller
                                                              .serviceImagePath
                                                              .value
                                                              .isEmpty
                                                          ? mediumIcon(
                                                              Icons.attach_file,
                                                              color: teleBlack)
                                                          : Image.file(
                                                              File(addSerivceConroller
                                                                  .serviceImagePath
                                                                  .value),
                                                              fit: BoxFit.cover,
                                                            ),
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  5)),
                                                      clipBehavior:
                                                          Clip.hardEdge,
                                                    ),
                                                  ),
                                                  addSerivceConroller
                                                          .serviceImagePath
                                                          .value
                                                          .isEmpty
                                                      ? Container()
                                                      : Positioned(
                                                          top: ScaleController
                                                                  .W *
                                                              0.01,
                                                          right: ScaleController
                                                                  .W *
                                                              0.01,
                                                          child:
                                                              GestureDetector(
                                                            onTap: () {
                                                              AddSerivceConroller
                                                                  addSerivceConrollerTemp =
                                                                  Get.put(
                                                                      AddSerivceConroller());

                                                              addSerivceConrollerTemp
                                                                  .serviceImagePath
                                                                  .value = "";

                                                              setState(() {});
                                                            },
                                                            child: Container(
                                                              child: normalIcon(
                                                                  Icons.close),
                                                            ),
                                                          ))
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    extraSmallText("Service Video",
                                        fontWeight: FontWeight.bold,
                                        color: teleBlack),
                                    Container(
                                      margin: EdgeInsets.symmetric(
                                        vertical: ScaleController.W * 0.0,
                                      ),
                                      child: Row(
                                        children: [
                                          Container(
                                            child: GestureDetector(
                                              onTap: () {
                                                pickImageOption(context, false);
                                              },
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    width:
                                                        ScaleController.W * 0.2,
                                                    height:
                                                        ScaleController.W * 0.2,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  5)),
                                                      color: teleGray
                                                          .withOpacity(0.5),
                                                    ),
                                                    child: Material(
                                                      color: teleGray
                                                          .withOpacity(0.5),
                                                      //display new updated image here
                                                      child: addSerivceConroller
                                                              .serviceVieoPath
                                                              .value
                                                              .isEmpty
                                                          ? mediumIcon(
                                                              Icons.video_file,
                                                              color: teleBlack)
                                                          // : Image.file(
                                                          //     File(video!.path),
                                                          //     fit: BoxFit.cover,
                                                          //   ),
                                                          : mediumIcon(
                                                              Icons
                                                                  .video_library,
                                                              color: teleBlack),
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  5)),
                                                      clipBehavior:
                                                          Clip.hardEdge,
                                                    ),
                                                  ),
                                                  addSerivceConroller
                                                          .serviceVieoPath
                                                          .value
                                                          .isEmpty
                                                      ? Container()
                                                      : Positioned(
                                                          top: ScaleController
                                                                  .W *
                                                              0.01,
                                                          right: ScaleController
                                                                  .W *
                                                              0.01,
                                                          child:
                                                              GestureDetector(
                                                            onTap: () {
                                                              AddSerivceConroller
                                                                  addSerivceConrollerTemp =
                                                                  Get.put(
                                                                      AddSerivceConroller());

                                                              addSerivceConrollerTemp
                                                                  .serviceVieoPath
                                                                  .value = "";

                                                              setState(() {});
                                                            },
                                                            child: Container(
                                                              child: normalIcon(
                                                                  Icons.close),
                                                            ),
                                                          ))
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            height: addSerivceConroller.listImage.isEmpty
                                ? 0
                                : ScaleController.W * 0.25,
                            alignment: Alignment.centerLeft,
                            width: ScaleController.W,
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: ListView(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              children: List.generate(
                                  addSerivceConroller.listImage.length,
                                  (index) => moreImagesWidget(index)),
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.01,
                          ),
                          FloatingActionButton.extended(
                            heroTag: "addmore",
                            onPressed: () {
                              AddSerivceConroller addSerivceConrollerTemp =
                                  Get.put(AddSerivceConroller());
                              if (addSerivceConrollerTemp.listImage.length <
                                  4) {
                                addSerivceConrollerTemp.listImage
                                    .add(RxString(""));
                                setState(() {});
                              }
                            },
                            label: normalText(
                              "Add More",
                              color: teleWhite,
                            ),
                            icon: normalIcon(Icons.add, color: teleWhite),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.03,
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: button(
                                onTap: () {
                                  if (validateAndProceed()) {
                                    addService();
                                  }
                                },
                                title: Strings.submit,
                                color: teleButtonBlue,
                                textColor: teleWhite),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.03,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )),
      ),
    );
  }

  Widget moreImagesWidget(int index) {
    return Container(
      child: Row(
        children: [
          Container(
            width: ScaleController.W * 0.2,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                extraSmallText(Strings.image + " $index ",
                    fontWeight: FontWeight.bold, color: teleBlack),
                Container(
                  margin: EdgeInsets.symmetric(
                    vertical: ScaleController.W * 0.0,
                  ),
                  child: Container(
                    child: GestureDetector(
                      onTap: () {
                        pickImageOption(context, false,
                            listImage: true, listImageIndex: index);
                      },
                      child: Stack(
                        children: [
                          Container(
                            width: ScaleController.W * 0.2,
                            height: ScaleController.W * 0.2,
                            decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                              color: teleGray.withOpacity(0.5),
                            ),
                            child: Material(
                              color: teleGray.withOpacity(0.5),
                              //display new updated image here
                              child: addSerivceConroller
                                      .listImage[index].value.isEmpty
                                  ? mediumIcon(Icons.attach_file,
                                      color: teleBlack)
                                  // ? normalText(addSerivceConroller
                                  //     .listImage[index]
                                  //     .toString())
                                  : Image.file(
                                      File(addSerivceConroller
                                          .listImage[index].value),
                                      fit: BoxFit.cover,
                                    ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                              clipBehavior: Clip.hardEdge,
                            ),
                          ),
                          addSerivceConroller.listImage[index].value.isEmpty
                              ? Container()
                              : Positioned(
                                  top: ScaleController.W * 0.01,
                                  right: ScaleController.W * 0.01,
                                  child: GestureDetector(
                                    onTap: () {
                                      addSerivceConroller
                                          .listImage[index].value = "";
                                      setState(() {});
                                    },
                                    child: Container(
                                      child: normalIcon(Icons.close),
                                    ),
                                  ))
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: MarginPadding.customHorizontalSmall(),
            child: FloatingActionButton.small(
              heroTag: "removeImage$index",
              backgroundColor: teleRed,
              onPressed: () {
                addSerivceConroller.listImage.removeAt(index);
                setState(() {});
              },
              child: smallIcon(Icons.close, color: teleWhite),
            ),
          )
        ],
      ),
    );
  }

  pickImageOption(BuildContext context, bool image,
      {bool listImage = false, int? listImageIndex}) {
    videoPickError = "";
    return Get.defaultDialog(
        title: Strings.choose,
        titleStyle: normalTextStyle(color: teleBlack),
        content: Column(
          children: [
            SimpleDialogOption(
                padding: EdgeInsets.all(0),
                child: ListTile(
                  contentPadding:
                      EdgeInsets.only(left: ScaleController.W * 0.05),
                  leading: normalIcon(Icons.camera_alt, color: teleBlue),
                  title: normalText(Strings.camera, color: teleBlack),
                ),
                onPressed: () {
                  if (listImage) {
                    _onImageButtonPressedForListImage(
                        context, ImageSource.camera, listImageIndex!);
                  } else {
                    _onImageButtonPressed(context, ImageSource.camera, image);
                  }
                  Navigator.pop(context);
                }),
            SimpleDialogOption(
                padding: EdgeInsets.all(0),
                child: ListTile(
                  contentPadding:
                      EdgeInsets.only(left: ScaleController.W * 0.05),
                  leading: normalIcon(Icons.photo_library, color: teleBlue),
                  title: normalText(Strings.gallery, color: teleBlack),
                ),
                onPressed: () {
                  if (listImage) {
                    _onImageButtonPressedForListImage(
                        context, ImageSource.gallery, listImageIndex!);
                  } else {
                    _onImageButtonPressed(context, ImageSource.gallery, image);
                  }
                  Navigator.pop(context);
                }),
          ],
        ));
  }

  _onImageButtonPressed(
      BuildContext context, ImageSource imageSource, bool imagePick) async {
    AddSerivceConroller addSerivceConrollerTemp =
        Get.put(AddSerivceConroller());

    try {
      if (imagePick) {
        final pickedFile = await ImagePicker.platform
            .pickImage(source: imageSource, imageQuality: 50);
        File tempFile = File(pickedFile!.path);
        addSerivceConrollerTemp.serviceImagePath.value = tempFile.path;
        setState(() {});
      } else {
        log(imagePick.toString());

        final pickedFile = await ImagePicker.platform
            .pickVideo(source: imageSource, maxDuration: Duration(seconds: 30));
        int sizeInBytes = File(pickedFile!.path).lengthSync();
        double sizeInMb = sizeInBytes / (1024 * 1024);
        if (sizeInMb > 30) {
          addSerivceConrollerTemp.serviceVieoPath.value = "";

          videoPickError = "Please select file that is less then 30 mb";
        } else {
          addSerivceConrollerTemp.serviceVieoPath.value = pickedFile.path;
          setState(() {});

          late VideoPlayerController controller;
          controller = VideoPlayerController.file(
              File(addSerivceConrollerTemp.serviceVieoPath.value));
          videoController = controller;
          setState(() {});
        }
      }
      setState(() {});
    } catch (e) {}
    setState(() {});
  }

  _onImageButtonPressedForListImage(
      BuildContext context, ImageSource imageSource, int index) async {
    AddSerivceConroller addSerivceConrollerTemp =
        Get.put(AddSerivceConroller());
    try {
      final pickedFile = await ImagePicker.platform
          .pickImage(source: imageSource, imageQuality: 50);
      File tempFile = File(pickedFile!.path);

      addSerivceConrollerTemp.listImage[index].value = tempFile.path;

      setState(() {});
    } catch (e) {
      log(e.toString());
    }
  }

  bool validateAndProceed() {
    if (serviceTypeController == null) {
      commonAlertDialog(Strings.warning, "Please select service type");
      return false;
    } else if (titleController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Title",
      );
      return false;
    } else if (descriptionController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Service Description",
      );
      return false;
    } else if (coverageHrsController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Needed Coverage Hours",
      );
      return false;
    } else if (volumesController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Volumes",
      );
      return false;
    } else if (modalitieController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Modalities",
      );
      return false;
    } else if (stateController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter State",
      );
      return false;
    } else if (typeOfFacilitycodeController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Type Of Facility",
      );
      return false;
    } else if (credentialingNeededController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Credentialing Needed",
      );
      return false;
    } else if (clickPriceController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Click Price",
      );
      return false;
    } else if (clickPriceMinController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Click Price Night Min",
      );
      return false;
    } else if (clickPriceMaxController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Click Price Night Max",
      );
      return false;
    } else if (hourPriceController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Hour Price",
      );
      return false;
    } else if (hourPriceMinController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Hour Price Min",
      );
      return false;
    } else if (hourPriceMaxController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Hour Price Max",
      );
      return false;
    } else if (addSerivceConroller.serviceImagePath.value.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "please enter Service Image",
      );
      return false;
    } else if (addSerivceConroller.listImage.isNotEmpty) {
      Future.forEach(addSerivceConroller.listImage, (RxString fileImage) {
        if (fileImage.value == "") {
          commonAlertDialog(
            Strings.warning,
            "please enter Service Image",
          );
          return false;
        }
      });
      return true;
    } else {
      return true;
    }
  }

  Future fetchServiceTypeList() async {
    AddSerivceConroller addSerivceConrollerTemp =
        Get.put(AddSerivceConroller());
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
      });
      apiGetRequest(context, Urls.serviceTypeList, token!).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            List tempList = jsonData["data"];
            try {
              addSerivceConroller.serviceTypeList.clear();
              List<ServiceTypeModel> serviceTypeList = tempList
                  .map((json) => ServiceTypeModel.fromJson(json))
                  .toList();
              addSerivceConroller.serviceTypeList.value = serviceTypeList;
              addSerivceConroller.serviceTypeList.value = serviceTypeList;
              serviceTypeController =
                  addSerivceConroller.serviceTypeList.value.first;
              setState(() {});
            } catch (e) {
              log(e.toString());
            }
            setState(() {});
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  Future addService() async {
    if (await internetCheck()) {
      FocusManager.instance.primaryFocus?.unfocus();

      var userId = await getUserId();
      var token = await getAuthToken();
      commonLoader(context, telePurple);

      var request = http.MultipartRequest(
        'POST',
        Uri.parse(Urls.sMyServiceAdd),
      );
      request.fields.addAll({
        "user_id": userId!,
        "user_type": "3",
        "service_type_id": serviceTypeController!.id,
        "title": titleController.text,
        "coverage_hours": coverageHrsController.text.trim() + " hours",
        "volumes": volumesController.text.trim() + " cc",
        "modalities": modalitieController.text,
        "state": stateController.text,
        "type_of_facility": typeOfFacilitycodeController.text,
        "credentialing_needed": credentialingNeededController.text,
        "description": descriptionController.text,
        "click_price": clickPriceController.text,
        "click_price_night_min": clickPriceMinController.text,
        "click_price_night_max": clickPriceMaxController.text,
        "hour_price": hourPriceController.text,
        "hour_price_night_min": hourPriceMinController.text,
        "hour_price_night_max": hourPriceMaxController.text,
      });
      // request.files.add(await http.MultipartFile.fromPath(
      //     "service_image", addSerivceConroller.serviceImagePath.value));
      // if (addSerivceConroller.serviceVieoPath.value.isNotEmpty) {
      //   request.files.add(await http.MultipartFile.fromPath(
      //       "service_video", addSerivceConroller.serviceVieoPath.value));
      // }
      List<http.MultipartFile> newList = [];
      newList.add(await http.MultipartFile.fromPath(
          "service_image", addSerivceConroller.serviceImagePath.value));
      if (addSerivceConroller.serviceVieoPath.value.isNotEmpty) {
        newList.add(await http.MultipartFile.fromPath(
            "service_video", addSerivceConroller.serviceVieoPath.value));
      }
// log(addSerivceConroller.listImage.value.toString());
      for (RxString fileImage in addSerivceConroller.listImage.value) {
        if (fileImage.value.isNotEmpty) {
          // log(fileImage.value);
          var multipartFile = await http.MultipartFile.fromPath(
            'serviceImages[]',
            fileImage.value,
          );
          newList.add(multipartFile);
        }
      }
      request.files.addAll(newList);

      log(request.fields.toString());
      log(request.files.toString());

      request.headers.addAll({
        'Accept': '*/*',
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json'
      });

      http.StreamedResponse response = await request.send();
      if (response.statusCode == 200) {
        var jsonDataString = await response.stream.bytesToString();
        Map<String, dynamic> jsonData = json.decode(jsonDataString);
        log(jsonData.toString());
        if (checkApiResponseSuccessOrNot(jsonData)) {
          Get.back();

          commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
              function: () {
            Get.back();
            fetchServiceList();
          });
        } else {
          Get.back();
          String msg = showValidValue(jsonData["msg"]);
          // try {
          //   msg = validValue(jsonData["data"]["password"])
          //       ? jsonData["data"]["password"]
          //       : "";
          //   msg += "\n";
          //   msg += validValue(jsonData["data"]["email"])
          //       ? jsonData["data"]["email"]
          //       : "";
          // } catch (e) {}
          commonAlertDialog(Strings.warning, showValidValue(msg));
        }
      }
    } else {
      showOfflineSnakbar(context);
    }
  }

  Future fetchServiceList() async {
    MySerivceConroller mySerivceConrollerTemp = Get.put(MySerivceConroller());

    HomeSerivceConroller homeSerivceConrollerTemp =
        Get.put(HomeSerivceConroller());
    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 3,
      });
      apiPostRequestWithHeader(context, Urls.sMyServiceList, body, token!)
          .then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            List tempList = jsonData["data"]["serviceList"];
            try {
              List<ServiceModel> serviceList =
                  tempList.map((json) => ServiceModel.fromJson(json)).toList();
              mySerivceConrollerTemp.serviceList.value = serviceList;
              homeSerivceConrollerTemp.serviceList.value = serviceList;
              setState(() {});
              Get.back();
            } catch (e) {
              log(e.toString());
            }
            setState(() {});
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  clearController() {
    AddSerivceConroller addSerivceConrollerTemp =
        Get.put(AddSerivceConroller());
    addSerivceConrollerTemp.serviceImagePath.value = "";
    addSerivceConrollerTemp.serviceVieoPath.value = "";
    setState(() {});
  }
}

class DialogOver2 extends StatefulWidget {
  final File file;

  const DialogOver2({Key? key, required this.file}) : super(key: key);
  @override
  State<StatefulWidget> createState() => DialogOver2State();
}

class DialogOver2State extends State<DialogOver2>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;
  Animation<double>? scaleAnimation;
  late VideoPlayerController _controller;
  bool isClicked = true;
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    scaleAnimation = CurvedAnimation(parent: controller!, curve: Curves.linear);

    controller!.addListener(() {
      setState(() {});
    });

    _controller = VideoPlayerController.file(
      widget.file,
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    _controller.addListener(() {
      setState(() {});
    });
    _controller.setLooping(true);
    _controller.initialize();
    controller!.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: scaleAnimation!,
      child: Container(
        width: ScaleController.W,
        height: ScaleController.H,
        margin: EdgeInsets.only(left: 0.0, right: 0.0),
        child: Stack(
          children: <Widget>[
            Container(
              width: ScaleController.W,
              height: ScaleController.H,
              child: Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  Container(
                    child: AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: <Widget>[
                          VideoPlayer(_controller),
                          VideoProgressIndicator(_controller,
                              allowScrubbing: true),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isClicked = true;
                        Future.delayed(Duration(seconds: 1), () {
                          isClicked = false;
                        });
                        if (_controller.value.isPlaying) {
                          _controller.pause();
                        } else {
                          _controller.play();
                        }
                      });
                    },
                    child: Container(
                        width: ScaleController.W * 0.15,
                        height: ScaleController.W * 0.15,
                        color: teleTransparent,
                        child: !isClicked
                            ? Container()
                            : largeIcon(
                                _controller.value.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: teleWhite)),
                  )
                ],
              ),
            ),
            Positioned(
              right: 15.0,
              top: 10.0,
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Align(
                  alignment: Alignment.topRight,
                  child: Container(
                      width: ScaleController.W * 0.1,
                      height: ScaleController.W * 0.1,
                      decoration: BoxDecoration(
                          color: teleRed,
                          borderRadius: BorderRadius.circular(10000)),
                      child: largeIcon(Icons.close, color: teleWhite)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class VideoPlayWidget extends StatefulWidget {
  final File file;

  const VideoPlayWidget({Key? key, required this.file}) : super(key: key);
  @override
  State<StatefulWidget> createState() => VideoPlayWidgetState();
}

class VideoPlayWidgetState extends State<VideoPlayWidget>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;
  Animation<double>? scaleAnimation;
  late VideoPlayerController _controller;
  bool isClicked = true;
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    scaleAnimation = CurvedAnimation(parent: controller!, curve: Curves.linear);

    controller!.addListener(() {
      setState(() {});
    });

    _controller = VideoPlayerController.file(
      widget.file,
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    _controller.addListener(() {
      setState(() {});
    });
    _controller.setLooping(true);
    _controller.initialize();
    controller!.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          width: ScaleController.W,
          height: ScaleController.W * 0.7,
          child: Stack(
            // fit: StackFit.expand,
            alignment: Alignment.center,
            children: <Widget>[
              Container(
                child: AspectRatio(
                  aspectRatio: _controller.value.aspectRatio,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: <Widget>[
                      VideoPlayer(_controller),
                      VideoProgressIndicator(_controller, allowScrubbing: true),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    isClicked = true;
                    Future.delayed(Duration(seconds: 1), () {
                      isClicked = false;
                    });
                    if (_controller.value.isPlaying) {
                      _controller.pause();
                    } else {
                      _controller.play();
                    }
                  });
                },
                child: Container(
                    width: ScaleController.W * 0.15,
                    height: ScaleController.W * 0.15,
                    color: teleTransparent,
                    child: !isClicked
                        ? Container()
                        : largeIcon(
                            _controller.value.isPlaying
                                ? Icons.pause
                                : Icons.play_arrow,
                            color: teleWhite)),
              )
            ],
          ),
        ),
        // Positioned(
        //   right: 15.0,
        //   top: 10.0,
        //   child: GestureDetector(
        //     onTap: () {
        //       Navigator.pop(context);
        //     },
        //     child: Align(
        //       alignment: Alignment.topRight,
        //       child: Container(
        //           width: ScaleController.W * 0.1,
        //           height: ScaleController.W * 0.1,
        //           decoration: BoxDecoration(
        //               color: teleRed,
        //               borderRadius: BorderRadius.circular(10000)),
        //           child: largeIcon(Icons.close, color: teleWhite)),
        //     ),
        //   ),
        // ),
      ],
    );
  }
}
