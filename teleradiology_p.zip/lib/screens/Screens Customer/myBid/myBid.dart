import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/Constants/servicecolors.dart';
import 'package:teleradiology/api/apiPostRequest.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/Screens%20Customer/HomePage%20Customer/bidServiceDetails.dart';
import 'package:teleradiology/screens/Screens%20Customer/widget/serviceReqCard.dart';
import 'package:teleradiology/screens/service%20screen/addService.dart';
import 'package:teleradiology/screens/service%20screen/controller/mySerivceConroller.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceModel.dart';
import 'package:teleradiology/screens/service%20screen/widgets/serviceCard.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allIcon.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/allTextStyle.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/noDataFound.dart';

class MyBid extends StatefulWidget {
  const MyBid({
    Key? key,
  }) : super(key: key);

  @override
  State<MyBid> createState() => _MyBidState();
}

class _MyBidState extends State<MyBid> {
  bool loading = false;
  List bidList = [];
  @override
  void initState() {
    super.initState();
    fetchBidList();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        backgroundColor: background,
        body: SingleChildScrollView(
          child: Column(
            children: [
              bidList.isEmpty
                  ? noDataFound()
                  : ListView.builder(
                      physics: BouncingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: bidList.length,
                      itemBuilder: (BuildContext context, int index) {
                        return ServiceReqCard(singleData: bidList[index]);
                      },
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildListCardHome(String image, String title) {
    Size size = MediaQuery.of(context).size;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          height: size.height * 0.15,
          width: size.width * 0.3,
          decoration: BoxDecoration(
              color: Color(0xFFE0F4FF),
              borderRadius: BorderRadius.all(Radius.circular(25)),
              border: Border.all(color: telestrokeBorder, width: 5)),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Image.asset(
              image,
              fit: BoxFit.cover,
            ),
          ),
        ),
        SizedBox(
          height: size.height * 0.01,
        ),
        Text(
          title,
          style: TextStyle(
              fontSize: 13, fontFamily: "NunitoSans", color: Color(0xFF4A4979)),
        ),
      ],
    );
  }

  Future fetchBidList() async {
    setState(() {
      loading = true;
    });

    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 4,
      });
      apiPostRequestWithHeader(context, Urls.cMyBidList, body, token!)
          .then((response) {
        if (response == null) {
          setState(() {
            loading = false;
          });

          Get.back();
          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            setState(() {
              loading = false;
            });
            try {
              bidList = jsonData["data"]["bidServiceList"];
              setState(() {});
            } catch (e) {
              bidList = [];

              Get.log(e.toString());
            }
            setState(() {});
          } else {
            setState(() {
              loading = false;
            });

            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      setState(() {
        loading = false;
      });

      setState(() {
        loading = true;
      });
      showOfflineSnakbar(context);
    }
  }
}
