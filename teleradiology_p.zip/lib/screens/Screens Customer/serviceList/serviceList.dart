import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:get/get.dart';
import 'package:teleradiology/api/apiGetRequest.dart';
import 'package:teleradiology/api/apiPostRequestWithHeader.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/main.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/Screens%20Customer/HomePage%20Customer/bidServiceDetails.dart';
import 'package:teleradiology/screens/Screens%20Customer/Rent%20Now%20Customer/rent_now_customer.dart';
import 'package:teleradiology/screens/service%20screen/model/serviceTypeModel.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/allIcon.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/allTextStyle.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/widget/button.dart';
import 'package:teleradiology/widget/noDataFound.dart';
import 'package:teleradiology/widget/roundedDropdownButton.dart';

class ServiceList extends StatefulWidget {
  const ServiceList({Key? key}) : super(key: key);

  @override
  State<ServiceList> createState() => _ServiceListState();
}

class _ServiceListState extends State<ServiceList> {
  bool loading = false;
  ServiceTypeModel? serviceTypeController;
  TextEditingController searchTextEditingController = TextEditingController();
  List<RxString> listImage = [];
  List<ServiceTypeModel> serviceTypeList = [];
  List serviceList = [];
  List _searchResult = [];

  String priceValue = "";
  TextEditingController onSearchTextEditingController = TextEditingController();
  FocusNode onSearchFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    fetchServiceTypeList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: backgroundBlue,
        body: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.only(right: ScaleController.W * 0.15),
                    child: Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: ScaleController.H * 0.08,
                        width: ScaleController.W * 0.8,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: ScaleController.W * 0.7,
                              child: TextFormField(
                                focusNode: onSearchFocusNode,
                                controller: onSearchTextEditingController,
                                onChanged: onSearchTextChanged,

                                cursorColor: teleGray,
                                decoration: InputDecoration(
                                    prefixIcon: Icon(
                                      Icons.search_rounded,
                                      color: Color(0xFF8771A7),
                                    ),
                                    hintText:
                                        "Search radiology services here....",
                                    hintStyle: TextStyle(
                                        fontSize: 12,
                                        color: Color(0xFF4A4979),
                                        fontFamily: "NunitoSans-Regular"),
                                    filled: true,
                                    fillColor: Colors.white,
                                    focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: telestrokeBorder, width: 5),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(32))),
                                    enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: telestrokeBorder, width: 5),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(32)))),
                              ),
                            ),
                            onSearchTextEditingController.text.isEmpty
                                ? Container()
                                : GestureDetector(
                                    onTap: () {
                                      onSearchTextEditingController.clear();
                                      onSearchFocusNode.unfocus();
                                      onSearchTextChanged('');
                                    },
                                    child: Container(
                                        height: ScaleController.H * 0.08,
                        width: ScaleController.W * 0.1,
                                      child: Center(
                                        child: Container(
                                          width: Get.width * 0.05,
                                          height: Get.width * 0.05,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(1000),
                                              color: teleGray),
                                          child: normalIcon(Icons.close,
                                              color: teleWhite),
                                        ),
                                      ),
                                    ),
                                  ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Padding(
                  //   padding: EdgeInsets.only(right: ScaleController.W * 0.08),
                  //   child: Align(
                  //     alignment: Alignment.centerRight,
                  //     child: Padding(
                  //       padding: EdgeInsets.only(
                  //         right: ScaleController.W * 0.09,
                  //       ),
                  //       child: Container(
                  //         height: ScaleController.H * 0.075,
                  //         width: ScaleController.W * 0.16,
                  //         child: Center(
                  //           child: Text(
                  //             "Go",
                  //             style: TextStyle(
                  //                 fontSize: 20,
                  //                 fontFamily: "NunitoSans-Bold",
                  //                 color: Colors.white),
                  //           ),
                  //         ),
                  //         decoration: BoxDecoration(
                  //           borderRadius: BorderRadius.all(Radius.circular(16)),
                  //           color: teleBlue2,
                  //         ),
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  
                  Padding(
                    padding: EdgeInsets.only(
                        top: ScaleController.H * 0.005,
                        right: ScaleController.W * 0.02),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        height: ScaleController.H * 0.065,
                        width: ScaleController.W * 0.14,
                        child: Center(
                            child: InkWell(
                              onTap: () {
                                  FocusScope.of(context).requestFocus(new FocusNode());
                      showModalBottomSheet(
                          context: context,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          backgroundColor: teleGray2,
                          builder: (BuildContext context) {
                            return ListView(
                              physics: BouncingScrollPhysics(),
                              children: [
                                Container(
                                  margin: MarginPadding.customBottom(),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(10),
                                        topRight: Radius.circular(10),
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: teleGray2.withOpacity(0.5),
                                          spreadRadius: 5,
                                          blurRadius: 7,
                                          offset: Offset(0,
                                              3), // changes position of shadow
                                        ),
                                      ],
                                      color: teleWhite),
                                  height: Get.width * 0.15,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      normalText("Filter",
                                          color: teleBlue,
                                          fontWeight: FontWeight.bold),
                                      Positioned(
                                          right: Get.width * 0.05,
                                          child: FloatingActionButton.small(
                                            onPressed: () {
                                              Get.back();
                                            },
                                            backgroundColor: teleRed,
                                            child: smallIcon(Icons.close,
                                                color: teleWhite),
                                          ))
                                    ],
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: ScaleController.W,
                                      padding: EdgeInsets.only(
                                          left: ScaleController.W * 0.05,
                                          right: ScaleController.W * 0.05),
                                      child: RoundedDropDownButton(
                                        searchTextEditingController:
                                            searchTextEditingController,
                                        selectedValue: serviceTypeController,
                                        hintText: "Select Service type *",
                                        textWidth: ScaleController.W * 0.5,
                                        onChange: (dynamic val) {
                                          serviceTypeController = val!;
                                          setState(() {});
                                          AppBuilder.of(context)!.rebuild();
                                        },
                                        icon: Icons.merge_type,
                                        dropdownList: serviceTypeList,
                                      ),
                                    ),
                                    SizedBox(
                                      height: ScaleController.H * 0.02,
                                    ),
                                    Container(
                                      margin: MarginPadding.customVertical(),
                                      padding: EdgeInsets.only(
                                          left: ScaleController.W * 0.05,
                                          right: ScaleController.W * 0.05),
                                      child: ListTile(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        onTap: () {
                                          setState(() {
                                            priceValue = "Low To High";
                                          });
                                          AppBuilder.of(context)!.rebuild();
                                        },
                                        tileColor: teleWhite,
                                        title: normalText('Low To High',
                                            color: teleBlack),
                                        leading: Radio(
                                          value: "Low To High",
                                          groupValue: priceValue,
                                          onChanged: (String? value) {
                                            setState(() {
                                              priceValue = value!;
                                            });
                                            AppBuilder.of(context)!.rebuild();
                                          },
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: MarginPadding.customVertical(),
                                      padding: EdgeInsets.only(
                                          left: ScaleController.W * 0.05,
                                          right: ScaleController.W * 0.05),
                                      child: ListTile(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        onTap: () {
                                          setState(() {
                                            priceValue = "High To Low";
                                          });
                                          AppBuilder.of(context)!.rebuild();
                                        },
                                        tileColor: teleWhite,
                                        title: normalText('High To Low',
                                            color: teleBlack),
                                        leading: Radio(
                                          value: "High To Low",
                                          groupValue: priceValue,
                                          onChanged: (String? value) {
                                            setState(() {
                                              priceValue = value!;
                                            });
                                            AppBuilder.of(context)!.rebuild();
                                          },
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: ScaleController.H * 0.02,
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(
                                          left: ScaleController.W * 0.05,
                                          right: ScaleController.W * 0.05),
                                      child: button(
                                          title: Strings.apply,
                                          color: Colors.blue,
                                          textColor: Colors.white,
                                          onTap: () {
                                            Get.back();
                                            fetchServiceList();
                                          }),
                                    )
                                  ],
                                )
                              ],
                            );
                          });
                    },
                    
                              child: Container(
                                  height: ScaleController.H * 0.03,
                                  child: Image.asset(
                                      "assets/Images/filter_icon.png")),
                            )),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(16)),
                          color: Color(0xFFAFAED3),
                        ),
                      ),
                    ),
                  ),
                
                ],
              ),
              SizedBox(
                height: ScaleController.H * 0.005,
              ),
              Container(
                child:_searchResult.length != 0 ||
                                        onSearchTextEditingController
                                            .text.isNotEmpty? ListView.builder(
                            shrinkWrap: true,

                        physics: BouncingScrollPhysics(),
                        itemCount: _searchResult.length,
                        itemBuilder: (context, index) =>
                           customCard(_searchResult[index]))
                    : serviceList.isEmpty
                        ? noDataFound()
                        : ListView.builder(
                            physics: BouncingScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: serviceList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return customCard(serviceList[index]);},
                          ),
              )
            ],
          ),
        )

        // body: SingleChildScrollView(
        //   child: Column(
        //     children: [
        //       SizedBox(height: ScaleController.H * 0.03,),
        //       Stack(
        //         children: [
        //           Align(
        //             alignment: Alignment.center,
        //             child: Container(
        //               height: ScaleController.H * 0.08,
        //               padding: EdgeInsets.only(left: ScaleController.W * 0.05,
        //                   right: ScaleController.W * 0.05),
        //               child: TextFormField(
        //                 cursorColor: teleGray,
        //                 decoration: InputDecoration(
        //                     prefixIcon: Icon(Icons.search_rounded,
        //                       color: Color(0xFF8771A7),),
        //                     hintText: "Search radiology services here......",
        //                     hintStyle: TextStyle(
        //                         fontSize: 13,
        //                         color: Color(0xFF4A4979),
        //                         fontFamily: "NunitoSans-Regular"
        //                     ),
        //                     filled: true,
        //                     fillColor: Colors.white,
        //                     focusedBorder: OutlineInputBorder(
        //                         borderSide: BorderSide(
        //                             color: telestrokeBorder, width: 5),
        //                         borderRadius: BorderRadius.all(
        //                             Radius.circular(32))
        //                     ),
        //                     enabledBorder: OutlineInputBorder(
        //                         borderSide: BorderSide(
        //                             color: telestrokeBorder, width: 5),
        //                         borderRadius: BorderRadius.all(
        //                             Radius.circular(32))
        //                     )
        //                 ),
        //               ),
        //             ),
        //           ),
        //           Align(
        //             alignment: Alignment.centerRight
        //             , child: Padding(
        //             padding: EdgeInsets.only(right: ScaleController.W * 0.06,),
        //             child: Container(
        //               height: ScaleController.H * 0.075,
        //               width: ScaleController.W * 0.16,
        //               child: Center(child:
        //               Text("Go", style: TextStyle(
        //                   fontSize: 20,
        //                   fontFamily: "NunitoSans-Bold",
        //                   color: Colors.white
        //               ),),),
        //               decoration: BoxDecoration(
        //                 borderRadius: BorderRadius.all(Radius.circular(16)),
        //                 color: teleBlue2,

        //               ),
        //             ),
        //           ),
        //           )
        //         ],
        //       ),

        //       Padding(
        //         padding: EdgeInsets.only(left: ScaleController.W * 0.03,
        //             right: ScaleController.W * 0.03),
        //         child: Container(
        //           height: ScaleController.H * 0.24,
        //           child: InkWell(
        //             onTap: (){
        //               Get.to(RentNow());
        //             },
        //             child: ListView.builder(
        //               scrollDirection: Axis.horizontal,
        //               shrinkWrap: true,
        //               itemCount: 6,
        //               itemBuilder: (BuildContext context, int index) {
        //                 return Row(
        //                   children: [
        //                     buildListCardHome("assets/Images/radiology.png", "Radiology"),
        //                     SizedBox(width: ScaleController.W*0.02,)
        //                   ],
        //                 );
        //               },

        //             ),
        //           )
        //         ),
        //       ),
        //       SizedBox(height: ScaleController.H * 0.02,),
        //       Container(
        //         width: ScaleController.W * 0.95,
        //         child: Divider(
        //           color: Color(0xFF7978A0),
        //         ),
        //       ),
        //       SizedBox(height: ScaleController.H * 0.01,),
        //       Row(
        //         children: [
        //           Text("     Newest First ", style: TextStyle(
        //               fontSize: 12,
        //               fontFamily: "NunitoSans-Bold",
        //               color: Color(0xFF184673)
        //           ),),
        //           Container(
        //               height: ScaleController.H * 0.02,
        //               child: VerticalDivider(color: Color(0xFF7978A0))),
        //           Text("  Price: High to Low ", style: TextStyle(
        //               fontSize: 12,
        //               fontFamily: "NunitoSans-Bold",
        //               color: Color(0xFF184673)
        //           ),),
        //           Container(
        //               height: ScaleController.H * 0.02,
        //               child: VerticalDivider(color: Color(0xFF7978A0))),
        //           Text("  Price: Low to High", style: TextStyle(
        //               fontSize: 12,
        //               fontFamily: "NunitoSans-Bold",
        //               color: Color(0xFF184673)
        //           ),),
        //         ],
        //       ),
        //       SizedBox(height: ScaleController.H * 0.01,),
        //       Container(
        //         width: ScaleController.W * 0.95,
        //         child: Divider(
        //           color: Color(0xFF7978A0),
        //         ),
        //       ),
        //       SizedBox(height: ScaleController.H * 0.02,),
        //       Row(
        //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //         children: [
        //           Row(
        //             children: [
        //               Text("    Services",
        //                 style: TextStyle(
        //                     fontSize: 20,
        //                     fontFamily: "NunitoSans-Bold",
        //                     color: Color(0xFF184673)
        //                 ),),
        //               SizedBox(width: ScaleController.H * 0.01,),
        //               Padding(
        //                 padding: EdgeInsets.only(
        //                     top: ScaleController.H * 0.005),
        //                 child: Container(
        //                     width: ScaleController.W * 0.05,
        //                     child: Image.asset("assets/Images/divider.png")),
        //               ),
        //             ],
        //           ),
        //           Row(
        //             mainAxisAlignment: MainAxisAlignment.end,
        //             children: [
        //               Text("See All     ",
        //                 style: TextStyle(
        //                     fontSize: 13,
        //                     fontFamily: "NunitoSans-SemiBold",
        //                     color: teleBlue2
        //                 ),),
        //             ],
        //           )
        //         ],
        //       ),
        //       SizedBox(height: ScaleController.H * 0.03,),
        //       ListView.builder(
        //         shrinkWrap: true,
        //         physics: NeverScrollableScrollPhysics(),
        //         itemCount: 3,
        //         itemBuilder: (BuildContext context,
        //             int index) {
        //           return Column(
        //             children: [
        //               buildHomeCard(),
        //               SizedBox(height: ScaleController.H * 0.01,)
        //             ],
        //           );
        //         },)
        //     ],
        //   ),
        // ),

        );
  }
Widget customCard(Map data){
  return Column(
                                children: [
                                  InkWell(
                                    onTap: () {
                                      Get.to(() => BidServiceDetails(
                                            data: data,
                                            serviceId:data["id"].toString() ,
                                          ));
                                    },
                                    child: Container(
                                      // height:Get.height * 0.2,
                                      padding:
                                          MarginPadding.customVerticalLarge(),
                                      width: Get.width * 0.9,
                                      decoration: BoxDecoration(
                                          color: Color(0xFFE0F4FF),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20)),
                                          border: Border.all(
                                              color: Color(0xFFBFD6E4),
                                              width: 5)),
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                            left: Get.width * 0.05),
                                        child: Row(
                                          children: [
                                            Container(
                                              height: Get.width * 0.3,
                                              width: Get.width * 0.31,
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(16),
                                                  child: data[
                                                                  "service_image_path"]
                                                              .toString()
                                                              .isEmpty ||
                                                          data[
                                                                  "service_image_path"] ==
                                                              "null"
                                                      ? Image.asset(
                                                          "assets/Images/radiology_list.png",
                                                          height:
                                                              Get.width * 0.3,
                                                          width:
                                                              Get.width * 0.31,
                                                          fit: BoxFit.fill,
                                                        )
                                                      : CachedNetworkImage(
                                                          progressIndicatorBuilder:
                                                              (context, url,
                                                                      progress) =>
                                                                  Center(
                                                            child:
                                                                CircularProgressIndicator(
                                                              color: teleBlue,
                                                            ),
                                                          ),
                                                          imageUrl: data[
                                                              "service_image_path"],
                                                          height:
                                                              Get.width * 0.3,
                                                          width:
                                                              Get.width * 0.31,
                                                          fit: BoxFit.fill,
                                                        )),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.white,
                                                      width: 5),
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(16))),
                                            ),
                                            SizedBox(
                                              width: Get.width * 0.05,
                                            ),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  width: Get.width * 0.4,
                                                  child: Text(
                                                    printValidString(
                                                        data
                                                            ["title"]),
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontFamily:
                                                            "NunitoSans",
                                                        color:
                                                            Color(0xFF184673)),
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: Get.width * 0.45,
                                                  child: Text(
                                                    printValidString(
                                                        data
                                                            ["description"]),
                                                    maxLines: 3,
                                                    softWrap: true,
                                                    style: TextStyle(
                                                        fontSize: 11,
                                                        fontFamily:
                                                            "NunitoSans",
                                                        color:
                                                            Color(0xFF4A4979)),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: Get.height * 0.01,
                                                ),
                                                Row(
                                                  children: [
                                                    Text(
                                                      "Price:",
                                                      style: TextStyle(
                                                          fontSize: 13,
                                                          fontFamily:
                                                              "NunitoSans",
                                                          color: Color(
                                                              0xffFCB128)),
                                                    ),
                                                    Text(
                                                      "  \$${data["click_price"]}",
                                                      style: TextStyle(
                                                          fontSize: 13,
                                                          fontFamily:
                                                              "NunitoSans",
                                                          color: Color(
                                                              0xFF4A4979)),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: Get.height * 0.01,
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: ScaleController.H * 0.02,
                                  )
                                ],
                              );
                            
}
  Widget customRowDetailsVertical(
    String title,
    String value,
  ) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          title + ": ",
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: teleBlue,
          ),
        ),
        Text(
          printValidString(
            value,
          ),
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: telePurple2,
          ),
        ),
      ],
    );
  }

  Container buildHomeCard() {
    return Container(
      height: ScaleController.H * 0.2,
      width: ScaleController.W * 0.9,
      decoration: BoxDecoration(
          color: Color(0xFFE0F4FF),
          borderRadius: BorderRadius.all(Radius.circular(16)),
          border: Border.all(color: Color(0xFFBFD6E4), width: 5)),
      child: Padding(
        padding: EdgeInsets.only(left: ScaleController.W * 0.05),
        child: Row(
          children: [
            Container(
              height: ScaleController.H * 0.15,
              width: ScaleController.W * 0.31,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/Images/imagine_list.png"),
                      fit: BoxFit.fill),
                  border: Border.all(color: Colors.white, width: 5),
                  borderRadius: BorderRadius.all(Radius.circular(16))),
            ),
            SizedBox(
              width: ScaleController.W * 0.05,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Radiology",
                  style: TextStyle(
                      fontSize: 18,
                      fontFamily: "NunitoSans-Bold",
                      color: Color(0xFF184673)),
                ),
                Text(
                  "Dicta sunt explicabo ratione ",
                  style: TextStyle(
                      fontSize: 11,
                      fontFamily: "NunitoSans-Regular",
                      color: Color(0xFF4A4979)),
                ),
                SizedBox(
                  height: ScaleController.H * 0.01,
                ),
                Row(
                  children: [
                    Text(
                      "Price:",
                      style: TextStyle(
                          fontSize: 13,
                          fontFamily: "NunitoSans-SemiBold",
                          color: teleBlue2),
                    ),
                    Text(
                      "  \$80.00",
                      style: TextStyle(
                          fontSize: 13,
                          fontFamily: "NunitoSans-SemiBold",
                          color: Color(0xFF4A4979)),
                    ),
                  ],
                ),
                SizedBox(
                  height: ScaleController.H * 0.01,
                ),
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(16)),
                      color: teleBlue2),
                  child: Padding(
                    padding: EdgeInsets.only(
                        left: ScaleController.W * 0.05,
                        right: ScaleController.W * 0.05,
                        top: ScaleController.H * 0.008,
                        bottom: ScaleController.H * 0.008),
                    child: Row(
                      children: [
                        Icon(
                          Icons.shopping_cart_outlined,
                          color: Colors.white,
                          size: 15,
                        ),
                        Text(
                          "  Add to cart",
                          style: TextStyle(
                              fontSize: 12,
                              fontFamily: "NunitoSans-Bold",
                              color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  Center buildListCardHome(String image, String title) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: ScaleController.H * 0.15,
            width: ScaleController.W * 0.32,
            decoration: BoxDecoration(
                color: Color(0xFFE0F4FF),
                borderRadius: BorderRadius.all(Radius.circular(16)),
                border: Border.all(color: telestrokeBorder, width: 5)),
            child: Center(
              child: Image.asset(image),
            ),
          ),
          SizedBox(
            height: ScaleController.H * 0.01,
          ),
          Text(
            title,
            style: TextStyle(
                fontSize: 13,
                fontFamily: "NunitoSans-SemiBold",
                color: Color(0xFF4A4979)),
          ),
        ],
      ),
    );
  }

  Future fetchServiceTypeList() async {
    setState(() {
      loading = true;
    });

    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 4,
      });
      apiGetRequest(context, Urls.serviceTypeList, token!).then((response) {
        if (response == null) {
          Get.back();
          setState(() {
            loading = false;
          });

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            setState(() {
              loading = false;
            });

            List tempList = jsonData["data"];
            try {
              serviceTypeList.clear();
              serviceTypeList = tempList
                  .map((json) => ServiceTypeModel.fromJson(json))
                  .toList();
              fetchServiceList();

              setState(() {});
            } catch (e) {
              Get.log(e.toString());
            }
            setState(() {});
          } else {
            setState(() {
              loading = false;
            });

            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      setState(() {
        loading = false;
      });

      showOfflineSnakbar(context);
    }
  }

  Future fetchServiceList() async {
    setState(() {
      loading = true;
    });

    if (await internetCheck()) {
      commonLoader(context, teleBlue);
      var userId = await getUserId();
      var token = await getAuthToken();
      String body = json.encode({
        "user_id": userId,
        "user_type": 4,
        "service_type_id":
            serviceTypeController == null ? "" : serviceTypeController!.id,
        "price": priceValue == "Low To High"
            ? 0
            : priceValue == "High To Low"
                ? 1
                : "",
      });
      apiPostRequestWithHeader(context, Urls.findService, body, token!)
          .then((response) {
        if (response == null) {
          setState(() {
            loading = false;
          });

          Get.back();
          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            setState(() {
              loading = false;
            });
            try {
              serviceList = jsonData["data"]["serviceList"]["data"];
            } catch (e) {
              serviceList = [];
              setState(() {});
              Get.log(e.toString());
            }
            setState(() {});
          } else {
            setState(() {
              loading = false;
            });

            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      setState(() {
        loading = false;
      });

      setState(() {
        loading = true;
      });
      showOfflineSnakbar(context);
    }
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    serviceList.forEach((searchDetails) {
      if (searchDetails["title"]
              .toString()
              .toLowerCase()
              .contains(text) ||
          searchDetails["description"].toString().toLowerCase().contains(text))
        _searchResult.add(searchDetails);
      setState(() {});
    });

    setState(() {});
  }
}
