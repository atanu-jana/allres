import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/screens/Screens%20Customer/HomePage%20Customer/bidServiceDetails.dart';
import 'package:teleradiology/utils/allIcon.dart';
import 'package:teleradiology/utils/allTextStyle.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/printValidString.dart';

class ServiceReqCard extends StatelessWidget {
  final Map singleData;
  const ServiceReqCard({Key? key, required this.singleData}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: () {
            Get.to(() => BidServiceDetails(
                  data: singleData,
                  serviceId: singleData["service_data"]["id"].toString(),
                ));
          },
          child: Container(
            // height: Get.height * 0.2,
            padding: MarginPadding.customVerticalLarge(),
            width: Get.width * 0.9,
            decoration: BoxDecoration(
                color: Color(0xFFE0F4FF),
                borderRadius: BorderRadius.all(Radius.circular(20)),
                border: Border.all(color: Color(0xFFBFD6E4), width: 5)),
            child: Padding(
              padding: EdgeInsets.only(left: Get.width * 0.05),
              child: Row(
                children: [
                  Container(
                    height: Get.width * 0.2,
                    width: Get.width * 0.2,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: singleData["service_data"]["service_image_path"]
                                    .toString()
                                    .isEmpty ||
                                singleData["service_data"]
                                        ["service_image_path"] ==
                                    "null"
                            ? Image.asset(
                                "assets/Images/radiology_list.png",
                                height: Get.width * 0.2,
                                width: Get.width * 0.2,
                                fit: BoxFit.fill,
                              )
                            : CachedNetworkImage(
                                progressIndicatorBuilder:
                                    (context, url, progress) => Center(
                                  child: CircularProgressIndicator(
                                    color: teleBlue,
                                  ),
                                ),
                                imageUrl: singleData["service_data"]
                                    ["service_image_path"],
                                height: Get.width * 0.2,
                                width: Get.width * 0.2,
                                fit: BoxFit.fill,
                              )),
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.white, width: 5),
                        borderRadius: BorderRadius.all(Radius.circular(16))),
                  ),
                  SizedBox(
                    width: Get.width * 0.05,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: Get.width * 0.53,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Container(
                              width: Get.width * 0.4,
                              child: Text(
                                printValidString(
                                    singleData["service_data"]["title"]),
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: "NunitoSans",
                                    color: Color(0xFF184673)),
                              ),
                            ),
                            Container(
                              width: Get.width * 0.05,
                              child: smallIcon(Icons.arrow_forward_ios_outlined,
                                  color: teleGray),
                            )
                          ],
                        ),
                      ),
                      // SizedBox(
                      //   width: Get.width * 0.53,
                      //   child: Text(
                      //     printValidString(
                      //         singleData
                      //                 ["service_data"]
                      //             ["description"]),
                      //     maxLines: 3,
                      //     softWrap: true,
                      //     style: TextStyle(
                      //         fontSize: 11,
                      //         fontFamily: "NunitoSans",
                      //         color: Color(0xFF4A4979)),
                      //   ),
                      // ),

                      SizedBox(
                        height: Get.height * 0.01,
                      ),
                      Column(
                        children: [
                          Container(
                              width: Get.width * 0.53,
                              margin: MarginPadding.customVerticalSmall(),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: Get.width * 0.15,
                                    child: customRowDetailsVertical(
                                        "Time", singleData["prefer_time"]),
                                  ),
                                  Container(
                                    width: Get.width * 0.25,
                                    child: customRowDetailsVertical(
                                        "Prefer Price",
                                        "\$" +
                                            singleData["prefer_price"]
                                                .toString() +
                                            " / " +
                                            singleData["prefer_type"]
                                                .toString()),
                                  ),
                                ],
                              )),
                          Container(
                              width: Get.width * 0.53,
                              margin: MarginPadding.customVerticalSmall(),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: Get.width * 0.15,
                                    child: customRowDetailsVertical(
                                        "Status", singleData["status"]),
                                  ),
                                  Container(
                                    width: Get.width * 0.25,
                                    child: customRowDetailsVertical(
                                        "Bid On",
                                        DateFormat.yMMMMd().format(
                                            DateTime.parse(
                                                singleData["bid_time"]
                                                    .toString()))),
                                  ),
                                ],
                              )),
                        ],
                      ),
                      SizedBox(
                        height: Get.height * 0.01,
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
        SizedBox(
          height: Get.height * 0.02,
        )
      ],
    );
  }

  Widget customRowDetailsVertical(
    String title,
    String value,
  ) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          title + ": ",
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: teleBlue,
          ),
        ),
        Text(
          printValidString(
            value,
          ),
          textAlign: TextAlign.center,
          style: normalTextStyle(
            fontFamily: "NunitoSans-Regular",
            fontWeight: FontWeight.w300,
            color: telePurple2,
          ),
        ),
      ],
    );
  }
}
