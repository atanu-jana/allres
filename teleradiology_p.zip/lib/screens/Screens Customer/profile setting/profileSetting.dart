import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';

class ProfileSetting extends StatefulWidget {
  const ProfileSetting({
    Key? key,
  }) : super(key: key);

  @override
  State<ProfileSetting> createState() => _ProfileSettingState();
}

class _ProfileSettingState extends State<ProfileSetting> {
  int _currentIndex = 0;
  String selectedItem = "";

  @override
  Widget build(BuildContext context) {
    var H = MediaQuery.of(context).size.height;
    var W = MediaQuery.of(context).size.width;
    return SafeArea(
      child: Scaffold(
        backgroundColor: backgroundBlue,

        body: SingleChildScrollView(
          child: Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: H * 0.02,
                ),
                Container(
                  height: H * 0.65,
                  child: Container(
                      color: backgroundBlue,
                      child: Stack(
                        children: [
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFFECF7FE),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(16)),
                              ),
                              height: H * 0.55,
                              width: W * 0.9,
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: H * 0.1,
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        customButton("Account Information",Icons.account_circle_outlined, () {
                                          setState(() {
                                            selectedItem =
                                                "Account Information";
                                          });
                                        }),
                                        SizedBox(
                                          height: ScaleController.H * 0.02,
                                        ),
                                        customButton("Email Address",Icons.email_outlined, () {
                                          setState(() {
                                            selectedItem = "Email Address";
                                          });
                                        }),
                                        SizedBox(
                                          height: ScaleController.H * 0.02,
                                        ),
                                        customButton("Password",Icons.password_outlined, () {
                                          setState(() {
                                            selectedItem = "Password";
                                          });
                                        }),
                                        SizedBox(
                                          height: ScaleController.H * 0.02,
                                        ),
                                        customButton("Shipping Details", Icons.local_shipping_outlined,() {
                                          setState(() {
                                            selectedItem = "Shipping Details";
                                          });
                                        }),
                                        SizedBox(
                                          height: ScaleController.H * 0.02,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: H * 0.02,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(bottom: H * 0.48),
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: Stack(
                                children: [
                                  CircleAvatar(
                                    radius: 50,
                                    backgroundColor: Colors.white,
                                    child: CircleAvatar(
                                      radius: 43,
                                      child: Container(
                                        height: H * 0.12,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    "assets/Images/profile_pic.png"),
                                                fit: BoxFit.fill)),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: ScaleController.W * 0.01,
                                    right: -Get.width * 0.01,
                                    // right: 0,
                                    child: GestureDetector(
                                      onTap: () {},
                                      child: Container(
                                        height: Get.height * 0.05,
                                        width: Get.height * 0.05,
                                        padding: EdgeInsets.all(3),
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(50)),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: teleBlue,
                                              borderRadius:
                                                  BorderRadius.circular(50)),
                                          child: Icon(
                                            Icons.edit_outlined,
                                            color: Colors.white,
                                            size: Get.height * 0.02,
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      )),
                ),
                SizedBox(
                  height: H * 0.05,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget customButton(String title, IconData icon, Function() onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: EdgeInsets.only(
            left: ScaleController.W * 0.05, right: ScaleController.W * 0.05),
        child: Container(
          height: ScaleController.H * 0.07,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(32)),
              color: title == selectedItem ? teleBlue : teleWhite),
          child: Center(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
             title == selectedItem ? Container(
                padding:EdgeInsets.only(right: ScaleController.W*0.02),
                child: Icon(icon,color:teleWhite),
              ):Container(),
              Text(
                title,
                style: TextStyle(
                    fontFamily: "NunitoSans-Bold",
                    color: title == selectedItem ? teleWhite : teleBlack,
                    fontWeight: FontWeight.bold,
                    fontSize: ScaleController.W * 0.045),
              ),
            ],
          )),
        ),
      ),
    );
  }
}
