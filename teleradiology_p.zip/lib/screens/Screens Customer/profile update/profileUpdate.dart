import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/widget/roundedInputField.dart';

class ProfileUpdate extends StatefulWidget {
  const ProfileUpdate({Key? key}) : super(key: key);

  @override
  State<ProfileUpdate> createState() => _ProfileUpdateState();
}

class _ProfileUpdateState extends State<ProfileUpdate> {
  TextEditingController fNameController = TextEditingController();
  TextEditingController lNameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController zipcodeController = TextEditingController();
  TextEditingController countryController = TextEditingController();
  File? image;
  GlobalKey<FormState> formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            backgroundColor: backgroundBlue,
            elevation: 0,
            leading: InkWell(
              child: Container(
                  child: InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Icon(
                        Icons.arrow_back_ios,
                        color: teleBlue2,
                        size: 20,
                      ))),
            ),
            centerTitle: true,
            title: Text("Profile Update"),
            titleTextStyle: TextStyle(
                fontSize: 20,
                fontFamily: "NunitoSans",
                fontWeight: FontWeight.bold,
                color: Color(0xFF184673)),
          ),
          backgroundColor: backgroundBlue,
          body: SingleChildScrollView(
            child: Center(
              child: Column(
                children: [
                  SizedBox(
                    height: ScaleController.H * 0.05,
                  ),
                  Container(
                    height: Get.height * 0.2,
                    child: Stack(
                      children: [
                        Container(
                          height: Get.width * 0.32,
                          width: Get.width * 0.32,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              border: Border.all(color: teleBlue, width: 3)),
                          child: image != null
                              ? CircleAvatar(
                                  radius: Get.width * 0.15,
                                  backgroundColor: Colors.white,
                                  backgroundImage: FileImage(image!),
                                )
                              :
                              //profileController.image.value != ""
                              //     ? ClipRRect(
                              //         borderRadius:
                              //             BorderRadius.circular(100),
                              //         child: CachedNetworkImage(
                              //           progressIndicatorBuilder:
                              //               (context, url, progress) =>
                              //                   Center(
                              //             child: Container(
                              //               color: Colors.white,
                              //               child:
                              //                   CircularProgressIndicator(
                              //                 color: kPrimaryColor,
                              //               ),
                              //             ),
                              //           ),
                              //           imageUrl:
                              //               profileController.image.value,
                              //           height: Get.width * 0.25,
                              //           width: Get.width * 0.25,
                              //           fit: BoxFit.fill,
                              //         ),
                              //       )
                              //     :
                              CircleAvatar(
                                  radius: Get.width * 0.15,
                                  backgroundColor: Colors.white,
                                  backgroundImage: const AssetImage(
                                    "assets/Images/noImage.png",
                                  ),
                                ),
                        ),
                        Positioned(
                          bottom: 10,
                          left: Get.width * 0.1,
                          // right: 0,
                          child: GestureDetector(
                            onTap: () {
                              pickImage();
                            },
                            child: Container(
                              height: Get.height * 0.06,
                              width: Get.height * 0.06,
                              padding: EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        blurRadius: 4.0,
                                        spreadRadius: 2),
                                  ],
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(50)),
                              child: CircleAvatar(
                                backgroundColor: Color(0xff3E61B9),
                                child: Icon(
                                  Icons.camera_alt_rounded,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: ScaleController.H * 0.01,
                  ),
                  Form(
                    key: formkey,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: ScaleController.W / 2,
                              padding: EdgeInsets.only(
                                  left: ScaleController.W * 0.05,
                                  right: ScaleController.W * 0.01),
                              child: RoundedInputField(
                                  controller: fNameController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.text,
                                  hintText: "First Name",
                                  icon: Icons.person,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter first name';
                                    }
                                    return null;
                                  }),
                            ),
                            Container(
                              width: ScaleController.W / 2,
                              padding: EdgeInsets.only(
                                  left: ScaleController.W * 0.01,
                                  right: ScaleController.W * 0.05),
                              child: RoundedInputField(
                                  controller: lNameController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.text,
                                  hintText: "Last Name",
                                  icon: Icons.person,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter last name';
                                    }
                                    return null;
                                  }),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: ScaleController.H * 0.02,
                        ),
                        Container(
                          width: ScaleController.W,
                          padding: EdgeInsets.only(
                              left: ScaleController.W * 0.05,
                              right: ScaleController.W * 0.05),
                          child: RoundedInputField(
                              controller: emailController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.emailAddress,
                              hintText: "Email Id",
                              icon: Icons.email,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter email id';
                                }
                                return null;
                              }),
                        ),
                        SizedBox(
                          height: ScaleController.H * 0.02,
                        ),
                        Container(
                          width: ScaleController.W,
                          padding: EdgeInsets.only(
                              left: ScaleController.W * 0.05,
                              right: ScaleController.W * 0.05),
                          child: RoundedInputField(
                              prefixWidget: Container(
                                  width: ScaleController.W * 0.07,
                                  child: normalText("+1",
                                      color: teleBlue, center: true),
                                ),
                              controller: phoneController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.phone,
                              hintText: "Contact Number",
                              icon: Icons.call,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter contact number';
                                }
                                return null;
                              }),
                        ),
                        SizedBox(
                          height: ScaleController.H * 0.02,
                        ),
                        Container(
                          width: ScaleController.W,
                          padding: EdgeInsets.only(
                              left: ScaleController.W * 0.05,
                              right: ScaleController.W * 0.05),
                          child: RoundedInputField(
                              controller: addressController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.streetAddress,
                              hintText: "Address",
                              icon: Icons.location_city,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter addres';
                                }
                                return null;
                              }),
                        ),
                        SizedBox(
                          height: ScaleController.H * 0.02,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: ScaleController.W / 2,
                              padding: EdgeInsets.only(
                                  left: ScaleController.W * 0.05,
                                  right: ScaleController.W * 0.01),
                              child: RoundedInputField(
                                  controller: stateController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.streetAddress,
                                  hintText: "State",
                                  icon: Icons.satellite_alt,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter state';
                                    }
                                    return null;
                                  }),
                            ),
                            Container(
                              width: ScaleController.W / 2,
                              padding: EdgeInsets.only(
                                  left: ScaleController.W * 0.01,
                                  right: ScaleController.W * 0.05),
                              child: RoundedInputField(
                                  controller: zipcodeController,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.number,
                                  hintText: "Zip Code",
                                  maxLength: 6,
                                  icon: Icons.pin_drop_sharp,
                                  onchangeFunction: (String val) {},
                                  validate: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter zipcode';
                                    }
                                    return null;
                                  }),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: ScaleController.H * 0.02,
                        ),
                        Container(
                          width: ScaleController.W,
                          padding: EdgeInsets.only(
                              left: ScaleController.W * 0.05,
                              right: ScaleController.W * 0.05),
                          child: RoundedInputField(
                              controller: countryController,
                              textInputAction: TextInputAction.next,
                              textInputType: TextInputType.streetAddress,
                              hintText: "Country",
                              icon: Icons.flag,
                              onchangeFunction: (String val) {},
                              validate: (String? value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter country';
                                }
                                return null;
                              }),
                        ),
                        SizedBox(
                          height: ScaleController.H * 0.03,
                        ),
                        InkWell(
                          onTap: () {
                            print(formkey.currentState!.validate());
                          },
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: Container(
                              height: ScaleController.H * 0.08,
                              decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(32)),
                                  color: teleButtonBlue),
                              child: Center(
                                  child: Text(
                                "Submit",
                                style: TextStyle(
                                    fontFamily: "NunitoSans-Bold",
                                    color: teleWhite,
                                    fontSize: 14),
                              )),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )),
    );
  }

  Future pickImage() async {
    try {
      final pickimage =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickimage == null) return;
      print(pickimage.path);
      final imageTemp = File(pickimage.path);
      setState(() => image = imageTemp);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }
}
