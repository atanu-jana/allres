import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/screens/Screens%20Customer/customerMainScreen.dart';
import 'package:teleradiology/screens/Sign%20In/signIn.dart';
import 'package:teleradiology/screens/service%20screen/service_mainscreen.dart';

class NavigationPage extends StatefulWidget {
  const NavigationPage({Key? key}) : super(key: key);

  @override
  State<NavigationPage> createState() => _NavigationPageState();
}

class _NavigationPageState extends State<NavigationPage> {
  @override
  void initState() {
    super.initState();
    serviceDrawerIndex = 0;
    customerDrawerIndex = 0;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundBlue,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            SizedBox(),
            Container(
              child: const Text(
                "Are you customer or service provider?",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: "NunitoSans",
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black),
              ),
            ),
            InkWell(
                onTap: () {
                  Get.to(ServiceSignInPage(
                    isCustomer:true ,
                    emailId: "",
                  ));
                },
                child: Column(
                  children: [
                    Text(
                      "Customer",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontFamily: "NunitoSans",
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color(0xff303E69)),
                    ),
                    SizedBox(
                      height: Get.height * 0.02,
                    ),
                    Container(
                      height: Get.height * 0.3,
                      width: Get.width,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                "assets/Images/customer.jpg",
                              )),
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          SizedBox(
                            height: Get.height * 0.03,
                          ), //image
                        ],
                      ),
                    ),
                  ],
                )),
            InkWell(
                onTap: () {
                  Get.to(ServiceSignInPage(
                    isCustomer: false,
                    emailId: "",
                  ));
                },
                child: Column(
                  children: [
                    Text(
                      "Service Provider",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontFamily: "NunitoSans",
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color(0xff303E69)),
                    ),
                    SizedBox(
                      height: Get.height * 0.02,
                    ),
                    Container(
                      height: Get.height * 0.3,
                      width: Get.width,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                "assets/Images/service provider.jpg",
                              )),
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          SizedBox(
                            height: Get.height * 0.03,
                          ), //image
                        ],
                      ),
                    ),
                  ],
                )),
            SizedBox(),
          ],
        ),
      ),
    );
  }
}
