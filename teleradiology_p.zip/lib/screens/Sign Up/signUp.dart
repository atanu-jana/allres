import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:otp_text_field/otp_text_field.dart';
import 'package:otp_text_field/style.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:get/get.dart';
import 'package:teleradiology/api/apiPostRequest.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/utils/allText.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/utils/validation.dart';
import 'package:teleradiology/widget/button.dart';
import 'package:teleradiology/widget/roundedInputField.dart';
import 'package:teleradiology/widget/roundedPasswordField.dart';
import '../Sign In/signIn.dart';

class ServiceSignUpPage extends StatefulWidget {
  final bool isCustomer;

  const ServiceSignUpPage({Key? key, required this.isCustomer})
      : super(key: key);

  @override
  State<ServiceSignUpPage> createState() => _ServiceSignUpPageState();
}

class _ServiceSignUpPageState extends State<ServiceSignUpPage> {
  bool verifyOTP = false;
  TextEditingController userController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  OtpFieldController otpFieldController = OtpFieldController();
  String otp = "";
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          Get.back();
          return true;
        },
        child: Scaffold(
            backgroundColor: backgroundBlue,
            body: SingleChildScrollView(
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: ScaleController.H * 0.1,
                    ),
                    Container(
                        height: ScaleController.H * 0.08,
                        width: ScaleController.W * 0.4,
                        child: Image.asset(
                          "assets/Images/essential.png",
                          fit: BoxFit.fill,
                        )),
                    SizedBox(
                      height: ScaleController.H * 0.02,
                    ),
                    SizedBox(
                      height: ScaleController.H * 0.05,
                    ),
                    if (verifyOTP)
                      Column(
                        children: [
                          Container(
                            padding: MarginPadding.customMarginNormal(),
                            child: OTPTextField(
                                controller: otpFieldController,
                                length: 4,
                                width: MediaQuery.of(context).size.width,
                                textFieldAlignment:
                                    MainAxisAlignment.spaceAround,
                                fieldWidth: Get.width * 0.14,
                                fieldStyle: FieldStyle.underline,
                                outlineBorderRadius: 10,
                                style: TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold),
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: Get.width * 0.04,
                                    vertical: Get.width * 0.04),
                                otpFieldStyle: OtpFieldStyle(
                                  enabledBorderColor: Color(0xff212121),
                                  disabledBorderColor: Colors.black38,
                                ),
                                onChanged: (pin) {
                                  setState(() {
                                    otp = pin;
                                  });
                                },
                                onCompleted: (pin) {
                                  // setState(() {
                                  //   otp = pin;
                                  // });
                                }),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          GestureDetector(
                            onTap: () {
                              resendOTP();
                            },
                            child: Container(
                              width: ScaleController.W * 0.8,
                              color: teleTransparent,
                              padding: MarginPadding.customMarginNormal(),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: ScaleController.W * 0.7,
                                    child: Row(
                                      children: [
                                        Container(
                                          child: normalText(
                                              "Didn't receive the OTP? ",
                                              color: teleGray),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: ScaleController.W * 0.01),
                                          child: normalText("RESEND OTP",
                                              color: teleBlue,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.03,
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: button(
                                onTap: () {
                                  if (validateAndProceedForPasword()) {
                                    verifyOTPAndProceed();
                                  }
                                },
                                title: "Verify OTP",
                                color: teleButtonBlue,
                                textColor: teleWhite),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.04,
                          ),
                        ],
                      )
                    else
                      Column(
                        children: [
                          Container(
                            padding: MarginPadding.customMarginNormal(),
                            child: RoundedInputField(
                                controller: userController,
                                textInputAction: TextInputAction.next,
                                textInputType: TextInputType.name,
                                hintText: "Customer",
                                icon: Icons.person,
                                onchangeFunction: (String val) {},
                                validate: (String? value) {
                                  return null;
                                }),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            padding: MarginPadding.customMarginNormal(),
                            child: RoundedInputField(
                              
                                controller: phoneController,
                                prefixWidget: Container(
                                  width: ScaleController.W * 0.07,
                                  child: normalText("+1",
                                      color: teleBlue, center: true),
                                ),
                                textInputAction: TextInputAction.next,
                                textInputType: TextInputType.number,
                                maxLength: 15,
                                hintText: "Contact No",
                                icon: Icons.phone,
                                onchangeFunction: (String val) {},
                                validate: (String? value) {
                                  return null;
                                }),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            padding: MarginPadding.customMarginNormal(),
                            child: RoundedInputField(
                                controller: emailController,
                                textInputAction: TextInputAction.next,
                                textInputType: TextInputType.emailAddress,
                                hintText: "Email",
                                icon: Icons.mail,
                                onchangeFunction: (String val) {},
                                validate: (String? value) {
                                  return null;
                                }),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            padding: MarginPadding.customMarginNormal(),
                            child: RoundedPasswordField(
                                controller: passwordController,
                                textInputAction: TextInputAction.next,
                                textInputType: TextInputType.visiblePassword,
                                hintText: "Password",
                                icon: Icons.lock,
                                onchangeFunction: (String val) {},
                                validate: (String? value) {
                                  return null;
                                }),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.02,
                          ),
                          Container(
                            padding: MarginPadding.customMarginNormal(),
                            child: RoundedPasswordField(
                                controller: confirmPasswordController,
                                textInputAction: TextInputAction.done,
                                textInputType: TextInputType.visiblePassword,
                                hintText: "Confirm Password",
                                icon: Icons.lock,
                                onchangeFunction: (String val) {},
                                validate: (String? value) {
                                  return null;
                                }),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.03,
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                left: ScaleController.W * 0.05,
                                right: ScaleController.W * 0.05),
                            child: button(
                                onTap: () {
                                  verifyOTP = true;
                                  setState(() {});
                                  // if (validateAndProceed()) {
                                  //   registration();
                                  // }
                                },
                                title: "Sign Up",
                                color: teleButtonBlue,
                                textColor: teleWhite),
                          ),
                          SizedBox(
                            height: ScaleController.H * 0.04,
                          ),
                        ],
                      ),
                    SizedBox(
                      height: ScaleController.H * 0.04,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Already Have An Account?",
                          style: TextStyle(
                              fontSize: 14,
                              color: teleGreen,
                              fontFamily: "NunitoSans"),
                        ),
                        InkWell(
                          onTap: () {
                            Get.to(ServiceSignInPage(
                              emailId: "",
                              isCustomer: widget.isCustomer,
                            ));
                          },
                          child: Text(
                            "  Sign In",
                            style: TextStyle(
                                fontSize: 14,
                                color: telePurple,
                                fontFamily: "NunitoSans"),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: ScaleController.H * 0.04,
                    ),
                  ],
                ),
              ),
            )),
      ),
    );
  }

  Future resendOTP() async {
    if (await internetCheck()) {
      otpFieldController.clear();
      otp = "";
      setState(() {});
      commonLoader(context, telePurple);

      String body = json.encode({
        "email": emailController.text.trim(),
        "user_type": widget.isCustomer ? 4 : 3
      });
      apiPostRequest(context, Urls.resendOtp, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
                function: () {
              Get.back();
            });
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            try {
              msg += validValue(jsonData["data"]["email"])
                  ? jsonData["data"]["email"]
                  : "";
            } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  Future registration() async {
    if (await internetCheck()) {
      otp = "";
      setState(() {
        verifyOTP = false;
      });
      commonLoader(context, telePurple);
      // commonAlertDialog(Strings.success, showValidValue("OTP"), function: () {
      //   setState(() {
      //     verifyOTP = true;
      //   });
      //   // Get.to(() => SignInPageCustomer());
      //   Get.back();
      //   Get.back();
      // });
      String body = json.encode({
        "name": userController.text.trim(),
        "email": emailController.text.trim(),
        "user_type": widget.isCustomer ? 4 : 3,
        "phone": phoneController.text.trim(),
        "password": passwordController.text.trim(),
        "confirm_password": confirmPasswordController.text.trim(),
      });
      apiPostRequest(context, Urls.registration, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
                function: () {
              setState(() {
                verifyOTP = true;
              });
              // Get.to(() => SignInPageCustomer());
              Get.back();
            });
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            try {
              msg = validValue(jsonData["data"]["email"][0])
                  ? jsonData["data"]["email"][0]
                  : "";
              msg += "\n";
              msg += validValue(jsonData["data"]["phone"][0])
                  ? jsonData["data"]["phone"][0]
                  : "";
            } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  Future verifyOTPAndProceed() async {
    if (await internetCheck()) {
      commonLoader(context, telePurple);

      String body = json.encode({
        "email": emailController.text.trim(),
        "user_type": widget.isCustomer ? 4 : 3,
        "otp": otp.trim(),
      });
      apiPostRequest(context, Urls.accountActivation, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
                function: () {
              Get.back();
              Get.to(() => ServiceSignInPage(
                    emailId: emailController.text,
                    isCustomer: widget.isCustomer,
                  ));
            });
          } else {
            setState(() {
              verifyOTP = false;
            });
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            try {
              msg = validValue(jsonData["data"]["email"][0])
                  ? jsonData["data"]["email"][0]
                  : "";
              msg += "\n";
              msg += validValue(jsonData["data"]["phone"][0])
                  ? jsonData["data"]["phone"][0]
                  : "";
            } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  bool validateAndProceed() {
    if (userController.text.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "Please enter your name",
      );
      return false;
    } else if (userController.text.length < 3) {
      commonAlertDialog(Strings.warning, "Name must be atleast 3 characters");
      return false;
    } else if (phoneController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your mobile number");
      return false;
    } else if (phoneController.text.length != 11) {
      commonAlertDialog(Strings.warning, "Check your mobile number!");
      return false;
    } else if (emailController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your email address");
      return false;
    } else if (!validateEmail(emailController.text)) {
      commonAlertDialog(
        Strings.warning,
        "Email address is not valid",
      );
      return false;
    } else if (passwordController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your password");
      return false;
    } else if (passwordController.text.length < 6) {
      commonAlertDialog(
        Strings.warning,
        "Password must be atleast 6 characters",
      );
      return false;
    } else if (confirmPasswordController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your password");
      return false;
    } else if (passwordController.text != confirmPasswordController.text) {
      commonAlertDialog(Strings.warning, "Password does not match!");
      return false;
    } else {
      return true;
    }
  }

  bool validateAndProceedForPasword() {
    if (otp.isEmpty) {
      commonAlertDialog(
        Strings.warning,
        "Please enter OTP",
      );
      return false;
    } else if (otp.length < 3) {
      commonAlertDialog(Strings.warning, "Please enter valid OTP");
      return false;
    } else {
      return true;
    }
  }
}
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
// import 'package:otp_text_field/otp_text_field.dart';
// import 'package:teleradiology/Constants/colors_customer.dart';
// import 'package:teleradiology/Constants/dimensions.dart';
// import 'package:get/get.dart';
// import 'package:teleradiology/service%20screen/Forgot%20Password/service_forgot_password.dart';
// import '../Sign In/service_sign_in_page.dart';

// class ServiceSignUpPage extends StatefulWidget {
//   const ServiceSignUpPage({Key? key}) : super(key: key);

//   @override
//   State<ServiceSignUpPage> createState() => _ServiceSignUpPageState();
// }

// class _ServiceSignUpPageState extends State<ServiceSignUpPage> {
//   bool verifyOTP = false;
//   TextEditingController userController = TextEditingController();
//   TextEditingController phoneController = TextEditingController();
//   TextEditingController emailController = TextEditingController();
//   TextEditingController passwordController = TextEditingController();
//   TextEditingController confirmPasswordController = TextEditingController();
//   OtpFieldController otpFieldController = OtpFieldController();
//   String otp = "";
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: WillPopScope(
//         onWillPop: ()async{
//           Get.back();
//           return true;
//         },
//         child: Scaffold(
//             backgroundColor: backgroundBlue,
//             body: SingleChildScrollView(
//               child: Center(
//                 child: Column(
//                   children: [
//                     SizedBox(
//                       height: ScaleController.H * 0.1,
//                     ),
//                     Container(
//                         height: ScaleController.H * 0.08,
//                         width: ScaleController.W * 0.4,
//                         child: Image.asset(
//                           "assets/Images/essential.png",
//                           fit: BoxFit.fill,
//                         )),
//                     SizedBox(
//                       height: ScaleController.H * 0.02,
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.05,
//                     ),
//                     Container(
//                       padding: EdgeInsets.only(
//                           left: ScaleController.W * 0.05,
//                           right: ScaleController.W * 0.05),
//                       child: TextFormField(
//                         keyboardType: TextInputType.name,
//                         cursorColor: teleGray,
//                         controller: userController,
//                         decoration: InputDecoration(
//                             prefixIcon: selectedItem
//                                 ? Icon(
//                                     Icons.person,
//                                     color: teleGray,
//                                   )
//                                 : Icon(
//                                     Icons.person,
//                                     color: teleBlack,
//                                   ),
//                             hintText:
//                                 "Service Provider/Hospital/Health System/OP Facility",
//                             hintStyle: TextStyle(
//                                 fontSize: 13,
//                                 color: teleGray,
//                                 fontFamily: "NunitoSans"),
//                             filled: true,
//                             fillColor: Colors.white,
//                             focusedBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Color(0xff184673)),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32))),
//                             enabledBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Colors.transparent),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32)))),
//                       ),
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.02,
//                     ),
//                     Container(
//                       padding: EdgeInsets.only(
//                           left: ScaleController.W * 0.05,
//                           right: ScaleController.W * 0.05),
//                       child: TextFormField(
//                         cursorColor: teleGray,
//                         controller: phoneController,
//                         keyboardType: TextInputType.phone,
//                         decoration: InputDecoration(
//                             prefixIcon: selectedItem
//                                 ? Icon(
//                                     Icons.phone,
//                                     color: teleGray,
//                                   )
//                                 : Icon(
//                                     Icons.phone,
//                                     color: teleBlack,
//                                   ),
//                             hintText: "Contact No",
//                             hintStyle: TextStyle(
//                                 fontSize: 13,
//                                 color: teleGray,
//                                 fontFamily: "NunitoSans"),
//                             filled: true,
//                             fillColor: Colors.white,
//                             focusedBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Color(0xff184673)),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32))),
//                             enabledBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Colors.transparent),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32)))),
//                       ),
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.02,
//                     ),
//                     Container(
//                       padding: EdgeInsets.only(
//                           left: ScaleController.W * 0.05,
//                           right: ScaleController.W * 0.05),
//                       child: TextFormField(
//                         cursorColor: teleGray,
//                         controller: emailController,
//                         keyboardType: TextInputType.emailAddress,
//                         decoration: InputDecoration(
//                             prefixIcon: selectedItem
//                                 ? Icon(
//                                     Icons.mail,
//                                     color: teleGray,
//                                   )
//                                 : Icon(
//                                     Icons.mail,
//                                     color: teleBlack,
//                                   ),
//                             hintText: "Email",
//                             hintStyle: TextStyle(
//                                 fontSize: 13,
//                                 color: teleGray,
//                                 fontFamily: "NunitoSans"),
//                             filled: true,
//                             fillColor: Colors.white,
//                             focusedBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Color(0xff184673)),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32))),
//                             enabledBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Colors.transparent),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32)))),
//                       ),
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.02,
//                     ),
//                     Container(
//                       padding: EdgeInsets.only(
//                           left: ScaleController.W * 0.05,
//                           right: ScaleController.W * 0.05),
//                       child: TextFormField(
//                         cursorColor: teleGray,
//                         obscureText: hidePassword1,
//                         controller: passwordController,
//                         decoration: InputDecoration(
//                             hintText: "Password",
//                             hintStyle: TextStyle(
//                                 fontSize: 14,
//                                 color: teleGray,
//                                 fontFamily: "NunitoSans"),
//                             prefixIcon: Icon(
//                               Icons.lock,
//                               color: teleGray,
//                             ),
//                             suffixIcon: InkWell(
//                                 onTap: () {
//                                   setState(() {
//                                     hidePassword1 = !hidePassword1;
//                                   });
//                                 },
//                                 child: hidePassword1
//                                     ? Icon(
//                                         Icons.visibility_outlined,
//                                         color: teleGray,
//                                       )
//                                     : Icon(
//                                         Icons.visibility_off,
//                                         color: teleGray,
//                                       )),
//                             filled: true,
//                             fillColor: Colors.white,
//                             focusedBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Color(0xff184673)),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32))),
//                             enabledBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Colors.transparent),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32)))),
//                       ),
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.02,
//                     ),
//                     Container(
//                       padding: EdgeInsets.only(
//                           left: ScaleController.W * 0.05,
//                           right: ScaleController.W * 0.05),
//                       child: TextFormField(
//                         cursorColor: teleGray,
//                         obscureText: hidePassword2,
//                         controller: confirmPasswordController,
//                         decoration: InputDecoration(
//                             hintText: "Confirm Password",
//                             hintStyle: TextStyle(
//                                 fontSize: 14,
//                                 color: teleGray,
//                                 fontFamily: "NunitoSans"),
//                             prefixIcon: Icon(
//                               Icons.lock,
//                               color: teleGray,
//                             ),
//                             suffixIcon: InkWell(
//                                 onTap: () {
//                                   setState(() {
//                                     hidePassword2 = !hidePassword2;
//                                   });
//                                 },
//                                 child: hidePassword2
//                                     ? Icon(
//                                         Icons.visibility_outlined,
//                                         color: teleGray,
//                                       )
//                                     : Icon(
//                                         Icons.visibility_off,
//                                         color: teleGray,
//                                       )),
//                             filled: true,
//                             fillColor: Colors.white,
//                             focusedBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Color(0xff184673)),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32))),
//                             enabledBorder: OutlineInputBorder(
//                                 borderSide: BorderSide(color: Colors.transparent),
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(32)))),
//                       ),
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.03,
//                     ),
//                     Padding(
//                       padding: EdgeInsets.only(
//                           left: ScaleController.W * 0.05,
//                           right: ScaleController.W * 0.05),
//                       child: InkWell(
//                         onTap: () {
//                           if(userController.text.isEmpty){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Please enter your name",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }
//                           else if(userController.text.length < 3){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Name must be atleast 3 characters",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }else if(phoneController.text.isEmpty){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Please enter your mobile number",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }
//                           else if(phoneController.text.length != 11){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Check your mobile number!",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }else if(emailController.text.isEmpty){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Please enter your email address",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }
//                           else if(!emailController.text.contains(RegExp(
//                               r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+"))){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Email address is not valid",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }else if(passwordController.text.isEmpty){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Please enter your password",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }
//                           else if(passwordController.text.length < 6){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Password must be atleast 6 characters",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }else if(confirmPasswordController.text.isEmpty){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Please enter your password",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }else if (passwordController.text !=
//                               confirmPasswordController.text){
//                             Get.defaultDialog(
//                                 title: "",
//                                 titleStyle: TextStyle(
//                                     fontSize: 15,
//                                     fontFamily: 'NunitoSans-Bold',
//                                     color: teleBlack),
//                                 content: Column(
//                                   children: [
//                                     Text(
//                                       "Password does not match!",
//                                       style: TextStyle(
//                                           fontSize: 13,
//                                           fontFamily: 'NunitoSans-Bold',
//                                           color: teleBlack),
//                                     ),
//                                     SizedBox(
//                                       height: ScaleController.H * 0.02,
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       children: [
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: telePurple,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "Ok",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                         SizedBox(
//                                           width: ScaleController.W * 0.05,
//                                         ),
//                                         InkWell(
//                                           onTap: () {
//                                             Get.back();
//                                           },
//                                           child: Container(
//                                               height: ScaleController.H * 0.05,
//                                               width: ScaleController.W * 0.2,
//                                               decoration: BoxDecoration(
//                                                   color: teleGray,
//                                                   borderRadius:
//                                                   BorderRadius.all(
//                                                       Radius.circular(
//                                                           8))),
//                                               child: Center(
//                                                   child: Text(
//                                                     "cancel",
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         fontFamily:
//                                                         'OpenSans-Bold',
//                                                         color: Colors.white),
//                                                   ))),
//                                         ),
//                                       ],
//                                     )
//                                   ],
//                                 ));
//                           }
//                           else{
//                             registration();
//                           }
//                         },
//                         child: Container(
//                           height: ScaleController.H * 0.08,
//                           decoration: BoxDecoration(
//                               borderRadius: BorderRadius.all(Radius.circular(32)),
//                               color: teleButtonBlue),
//                           child: Center(
//                               child:  Text(
//                             "Sign Up",
//                             style: TextStyle(
//                                 fontFamily: "NunitoSans",
//                                 color: teleWhite,
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 14),
//                           )),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.04,
//                     ),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text(
//                           "Already Have An Account?",
//                           style: TextStyle(
//                               fontSize: 14,
//                               color: teleGreen,
//                               fontFamily: "NunitoSans"),
//                         ),
//                         InkWell(
//                           onTap: () {
//                             Get.to(ServiceSignInPage());
//                           },
//                           child: Text(
//                             "  Sign In",
//                             style: TextStyle(
//                                 fontSize: 14,
//                                 color: telePurple,
//                                 fontFamily: "NunitoSans"),
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(
//                       height: ScaleController.H * 0.04,
//                     ),
//                   ],
//                 ),
//               ),
//             )),
//       ),
//     );
//   }
//   Future registration() async {
//     showDialog(context: context, builder: (context){
//       return Center(child: CircularProgressIndicator(color: telePurple,));
//     });
//     print('Clicked');
//     var apiURL = "https://mydevfactory.com/~saikat8/teleradiology/api/registration";

//     var mapData = json.encode({
//       "name": userController.text.trim(),
//       "email": emailController.text.trim(),
//       "user_type": widget.isCustomer?4: 3
//       "phone": phoneController.text.trim(),
//       "password": passwordController.text.trim(),
//       "confirm_password": confirmPasswordController.text.trim(),
//     });

//     http.Response response = await http.post(Uri.parse(apiURL),
//         headers: {
//           "Content-Type": "application/json",
//           'Accept': 'application/json',
//         },
//         body: mapData);


//     try {
//     if(response.statusCode == 200){
//       var result  =  jsonDecode(response.body);
//      if(result["status"] == false){
//        email = result["data"]["email"];
//        print(email);
//        phone = result["data"]["phone"];
//        print(phone);
//         if(email != null && phone == null){
//          Navigator.of(context).pop();
//          Get.defaultDialog(
//              title: "",
//              titleStyle: TextStyle(
//                  fontSize: 15,
//                  fontFamily: 'NunitoSans-Bold',
//                  color: teleBlack),
//              content: Column(
//                children: [
//                  Text(
//                    "The email has already been taken!",
//                    style: TextStyle(
//                        fontSize: 13,
//                        fontFamily: 'NunitoSans-Bold',
//                        color: teleBlack),
//                  ),
//                  SizedBox(
//                    height: ScaleController.H * 0.02,
//                  ),
//                  Row(
//                    mainAxisAlignment:
//                    MainAxisAlignment.center,
//                    children: [
//                      InkWell(
//                        onTap: () {
//                          Get.back();
//                        },
//                        child: Container(
//                            height: ScaleController.H * 0.05,
//                            width: ScaleController.W * 0.2,
//                            decoration: BoxDecoration(
//                                color: telePurple,
//                                borderRadius:
//                                BorderRadius.all(
//                                    Radius.circular(
//                                        8))),
//                            child: Center(
//                                child: Text(
//                                  "Ok",
//                                  style: TextStyle(
//                                      fontSize: 13,
//                                      fontFamily:
//                                      'OpenSans-Bold',
//                                      color: Colors.white),
//                                ))),
//                      ),
//                      SizedBox(
//                        width: ScaleController.W * 0.05,
//                      ),
//                      InkWell(
//                        onTap: () {
//                          Get.back();
//                        },
//                        child: Container(
//                            height: ScaleController.H * 0.05,
//                            width: ScaleController.W * 0.2,
//                            decoration: BoxDecoration(
//                                color: teleGray,
//                                borderRadius:
//                                BorderRadius.all(
//                                    Radius.circular(
//                                        8))),
//                            child: Center(
//                                child: Text(
//                                  "cancel",
//                                  style: TextStyle(
//                                      fontSize: 13,
//                                      fontFamily:
//                                      'OpenSans-Bold',
//                                      color: Colors.white),
//                                ))),
//                      ),
//                    ],
//                  )
//                ],
//              ));
//        }else if(email == null && phone != null){
//           Navigator.of(context).pop();
//           Get.defaultDialog(
//               title: "",
//               titleStyle: TextStyle(
//                   fontSize: 15,
//                   fontFamily: 'NunitoSans-Bold',
//                   color: teleBlack),
//               content: Column(
//                 children: [
//                   Text(
//                     "The phone has already been taken!",
//                     style: TextStyle(
//                         fontSize: 13,
//                         fontFamily: 'NunitoSans-Bold',
//                         color: teleBlack),
//                   ),
//                   SizedBox(
//                     height: ScaleController.H * 0.02,
//                   ),
//                   Row(
//                     mainAxisAlignment:
//                     MainAxisAlignment.center,
//                     children: [
//                       InkWell(
//                         onTap: () {
//                           Get.back();
//                         },
//                         child: Container(
//                             height: ScaleController.H * 0.05,
//                             width: ScaleController.W * 0.2,
//                             decoration: BoxDecoration(
//                                 color: telePurple,
//                                 borderRadius:
//                                 BorderRadius.all(
//                                     Radius.circular(
//                                         8))),
//                             child: Center(
//                                 child: Text(
//                                   "Ok",
//                                   style: TextStyle(
//                                       fontSize: 13,
//                                       fontFamily:
//                                       'OpenSans-Bold',
//                                       color: Colors.white),
//                                 ))),
//                       ),
//                       SizedBox(
//                         width: ScaleController.W * 0.05,
//                       ),
//                       InkWell(
//                         onTap: () {
//                           Get.back();
//                         },
//                         child: Container(
//                             height: ScaleController.H * 0.05,
//                             width: ScaleController.W * 0.2,
//                             decoration: BoxDecoration(
//                                 color: teleGray,
//                                 borderRadius:
//                                 BorderRadius.all(
//                                     Radius.circular(
//                                         8))),
//                             child: Center(
//                                 child: Text(
//                                   "cancel",
//                                   style: TextStyle(
//                                       fontSize: 13,
//                                       fontFamily:
//                                       'OpenSans-Bold',
//                                       color: Colors.white),
//                                 ))),
//                       ),
//                     ],
//                   )
//                 ],
//               ));
//         }else if(email != null && phone != null){
//           Navigator.of(context).pop();
//           Get.defaultDialog(
//               title: "",
//               titleStyle: TextStyle(
//                   fontSize: 15,
//                   fontFamily: 'NunitoSans-Bold',
//                   color: teleBlack),
//               content: Column(
//                 children: [
//                   Text(
//                     "Phone and email address already exist!",
//                     style: TextStyle(
//                         fontSize: 13,
//                         fontFamily: 'NunitoSans-Bold',
//                         color: teleBlack),
//                   ),
//                   SizedBox(
//                     height: ScaleController.H * 0.02,
//                   ),
//                   Row(
//                     mainAxisAlignment:
//                     MainAxisAlignment.center,
//                     children: [
//                       InkWell(
//                         onTap: () {
//                           Get.back();
//                         },
//                         child: Container(
//                             height: ScaleController.H * 0.05,
//                             width: ScaleController.W * 0.2,
//                             decoration: BoxDecoration(
//                                 color: telePurple,
//                                 borderRadius:
//                                 BorderRadius.all(
//                                     Radius.circular(
//                                         8))),
//                             child: Center(
//                                 child: Text(
//                                   "Ok",
//                                   style: TextStyle(
//                                       fontSize: 13,
//                                       fontFamily:
//                                       'OpenSans-Bold',
//                                       color: Colors.white),
//                                 ))),
//                       ),
//                       SizedBox(
//                         width: ScaleController.W * 0.05,
//                       ),
//                       InkWell(
//                         onTap: () {
//                           Get.back();
//                         },
//                         child: Container(
//                             height: ScaleController.H * 0.05,
//                             width: ScaleController.W * 0.2,
//                             decoration: BoxDecoration(
//                                 color: teleGray,
//                                 borderRadius:
//                                 BorderRadius.all(
//                                     Radius.circular(
//                                         8))),
//                             child: Center(
//                                 child: Text(
//                                   "cancel",
//                                   style: TextStyle(
//                                       fontSize: 13,
//                                       fontFamily:
//                                       'OpenSans-Bold',
//                                       color: Colors.white),
//                                 ))),
//                       ),
//                     ],
//                   )
//                 ],
//               ));
//         }
//        print("This is my bad response : ${response.body}");
//      } else{
//        print("This is my response : ${response.body}");
//        Navigator.of(context).pop();
//        Get.offAll(ServiceSignInPage());
//        Get.defaultDialog(
//            title: "Congratulations!",
//            titleStyle: TextStyle(
//                fontSize: 15,
//                fontFamily: 'NunitoSans-Bold',
//                color: teleBlack),
//            content: Column(
//              children: [
//                Text(
//                  "Your account has been successfully created",
//                  style: TextStyle(
//                      fontSize: 13,
//                      fontFamily: 'NunitoSans-Bold',
//                      color: teleBlack),
//                ),
//                SizedBox(
//                  height: ScaleController.H * 0.02,
//                ),
//                Row(
//                  mainAxisAlignment:
//                  MainAxisAlignment.center,
//                  children: [
//                    InkWell(
//                      onTap: () {
//                        Get.back();
//                      },
//                      child: Container(
//                          height: ScaleController.H * 0.05,
//                          width: ScaleController.W * 0.2,
//                          decoration: BoxDecoration(
//                              color: telePurple,
//                              borderRadius:
//                              BorderRadius.all(
//                                  Radius.circular(
//                                      8))),
//                          child: Center(
//                              child: Text(
//                                "Ok",
//                                style: TextStyle(
//                                    fontSize: 13,
//                                    fontFamily:
//                                    'OpenSans-Bold',
//                                    color: Colors.white),
//                              ))),
//                    ),
//                    SizedBox(
//                      width: ScaleController.W * 0.05,
//                    ),
//                    InkWell(
//                      onTap: () {
//                        Get.back();
//                      },
//                      child: Container(
//                          height: ScaleController.H * 0.05,
//                          width: ScaleController.W * 0.2,
//                          decoration: BoxDecoration(
//                              color: teleGray,
//                              borderRadius:
//                              BorderRadius.all(
//                                  Radius.circular(
//                                      8))),
//                          child: Center(
//                              child: Text(
//                                "cancel",
//                                style: TextStyle(
//                                    fontSize: 13,
//                                    fontFamily:
//                                    'OpenSans-Bold',
//                                    color: Colors.white),
//                              ))),
//                    ),
//                  ],
//                )
//              ],
//            ));
//      }
//       // }
//     }
//     } catch (e) {
//       print(e.toString());
//     }
//   }
// }