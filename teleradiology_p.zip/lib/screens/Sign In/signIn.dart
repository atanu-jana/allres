import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/api/apiPostRequest.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/Screens%20Customer/HomePage%20Customer/homepage_customer.dart';
import 'package:teleradiology/screens/Screens%20Customer/customerMainScreen.dart';
import 'package:teleradiology/screens/service%20screen/service_homepage.dart';
import 'package:teleradiology/screens/service%20screen/service_mainscreen.dart';
import 'package:teleradiology/services/sharedPreferenceServices.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/utils/validation.dart';
import 'package:teleradiology/widget/button.dart';
import 'package:teleradiology/widget/roundedInputField.dart';
import 'package:teleradiology/widget/roundedPasswordField.dart';
import '../Forgot Password/forgotPassword.dart';
import '../Sign Up/signUp.dart';

class ServiceSignInPage extends StatefulWidget {
  final String emailId;
  final bool isCustomer;

  const ServiceSignInPage(
      {Key? key, required this.emailId, required this.isCustomer})
      : super(key: key);

  @override
  State<ServiceSignInPage> createState() => _ServiceSignInPageState();
}

class _ServiceSignInPageState extends State<ServiceSignInPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  @override
  void initState() {
    super.initState();
    setState(() {
      emailController.text = widget.emailId;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: backgroundBlue,
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: ScaleController.H * 0.1,
                ),
                Container(
                    height: ScaleController.H * 0.08,
                    width: ScaleController.W * 0.4,
                    child: Image.asset(
                      "assets/Images/essential.png",
                      fit: BoxFit.fill,
                    )),
                SizedBox(
                  height: ScaleController.H * 0.02,
                ),
                SizedBox(
                  height: ScaleController.H * 0.05,
                ),
                Container(
                  padding: MarginPadding.customMarginNormal(),
                  child: RoundedInputField(
                      controller: emailController,
                      textInputAction: TextInputAction.next,
                      textInputType: TextInputType.emailAddress,
                      hintText: "Email",
                      icon: Icons.mail,
                      onchangeFunction: (String val) {},
                      validate: (String? value) {
                        return null;
                      }),
                ),
                SizedBox(
                  height: ScaleController.H * 0.02,
                ),
                Container(
                  padding: MarginPadding.customMarginNormal(),
                  child: RoundedPasswordField(
                      controller: passwordController,
                      textInputAction: TextInputAction.done,
                      textInputType: TextInputType.visiblePassword,
                      hintText: "Password",
                      icon: Icons.lock,
                      onchangeFunction: (String val) {},
                      validate: (String? value) {
                        return null;
                      }),
                ),
                SizedBox(
                  height: ScaleController.H * 0.03,
                ),
                Padding(
                  padding: EdgeInsets.only(
                      left: ScaleController.W * 0.05,
                      right: ScaleController.W * 0.05),
                  child: button(
                      onTap: () {
                        if (validateAndProceed()) {
                          signIn();
                        }
                      },
                      title: "Sign In",
                      color: teleButtonBlue,
                      textColor: teleWhite),
                ),
                SizedBox(
                  height: ScaleController.H * 0.03,
                ),
                InkWell(
                  onTap: () {
                    Get.to(ForgotPassword(
                      isCustomer: widget.isCustomer,
                      emailId: emailController.text,
                    ));
                  },
                  child: Text(
                    "Forgot Password?",
                    style: TextStyle(
                        fontSize: 14,
                        color: telePurple,
                        fontFamily: "NunitoSans"),
                  ),
                ),
                SizedBox(
                  height: ScaleController.H * 0.28,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Don't Have An Account?",
                      style: TextStyle(
                          fontSize: 14,
                          color: teleGreen,
                          fontFamily: "NunitoSans"),
                    ),
                    InkWell(
                      onTap: () {
                        Get.to(ServiceSignUpPage(
                          isCustomer: widget.isCustomer,
                        ));
                      },
                      child: Text(
                        "  Sign Up",
                        style: TextStyle(
                            fontSize: 14,
                            color: telePurple,
                            fontFamily: "NunitoSans"),
                      ),
                    ),
                  ],
                )
              ],
            ),
          )),
    );
  }

  bool validateAndProceed() {
    if (!validateEmail(emailController.text)) {
      commonAlertDialog(
        Strings.warning,
        "Email address is not valid",
      );
      return false;
    } else if (passwordController.text.isEmpty) {
      commonAlertDialog(Strings.warning, "Please enter your password");
      return false;
    } else if (passwordController.text.length < 6) {
      commonAlertDialog(
        Strings.warning,
        "Password must be atleast 6 characters",
      );
      return false;
    } else {
      return true;
    }
  }

  Future signIn() async {
    if (await internetCheck()) {
      commonLoader(context, telePurple);

      String body = json.encode({
        "email": emailController.text.trim(),
        "user_type": widget.isCustomer ? 4 : 3,
        "password": passwordController.text.trim(),
      });
      apiPostRequest(context, Urls.login, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            try {
              setUserType(jsonData["data"]["user_type"]);
              setUserId(jsonData["data"]["id"]);
              setFirstName(jsonData["data"]["name"]);

              setLastName(jsonData["data"]["last_name"]);
              setEmail(jsonData["data"]["email"]);
              setPhone(jsonData["data"]["phone"]);
              setImage(jsonData["data"]["image_path"]);
              setAddress(jsonData["data"]["address"]);
              setCity(jsonData["data"]["city"]);
              setStatee(jsonData["data"]["state"]);
              setZipcode(jsonData["data"]["zip_code"]);
              setCountry(jsonData["data"]["country"]);
              setAuthToken(jsonData["data"]["auth_token"]);
              Get.back();
              if (widget.isCustomer) {
                customerScreenWidget = HomePageCustomer();
                Get.to(() => CustomerMainScreen());
              } else {
                serviceScreenWidget = ServiceHomePage();

                Get.to(() => ServiceMainScreen());
              }
            } catch (e) {
              log(e.toString());
            }

            // commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
            //     function: () {
            //   Get.back();
            //   Get.to(HomePageCustomer());
            // });
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            try {
              msg = validValue(jsonData["data"]["password"])
                  ? jsonData["data"]["password"]
                  : "";
              msg += "\n";
              msg += validValue(jsonData["data"]["email"])
                  ? jsonData["data"]["email"]
                  : "";
            } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:teleradiology/Constants/colors_customer.dart';
// import 'package:teleradiology/Constants/dimensions.dart';
// import 'package:teleradiology/service%20screen/service_mainscreen.dart';
// import '../Forgot Password/service_forgot_password.dart';
// import '../Sign Up/service_sign_up_page.dart';

// class ServiceSignInPage extends StatefulWidget {
//   const ServiceSignInPage({Key? key}) : super(key: key);

//   @override
//   State<ServiceSignInPage> createState() => _ServiceSignInPageState();
// }

// class _ServiceSignInPageState extends State<ServiceSignInPage> {
//   TextEditingController userController = TextEditingController();
//   TextEditingController passwordController = TextEditingController();
//   bool hidePassword = true;
//   bool selectedItem = true;
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//           backgroundColor: backgroundBlue,
//           body: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: ScaleController.H * 0.1,
//                 ),
//                 Container(
//                     height: ScaleController.H * 0.08,
//                     width: ScaleController.W * 0.4,
//                     child: Image.asset(
//                       "assets/Images/essential.png",
//                       fit: BoxFit.fill,
//                     )),
//                 SizedBox(
//                   height: ScaleController.H * 0.02,
//                 ),
//                 SizedBox(
//                   height: ScaleController.H * 0.05,
//                 ),
//                 Container(
//                   padding: EdgeInsets.only(
//                       left: ScaleController.W * 0.05,
//                       right: ScaleController.W * 0.05),
//                   child: TextFormField(
//                     cursorColor: teleGray,
//                     enabled: selectedItem,
//                     controller: userController,
//                     decoration: InputDecoration(
//                         prefixIcon: selectedItem
//                             ? Icon(
//                                 Icons.person,
//                                 color: teleGray,
//                               )
//                             : Icon(
//                                 Icons.person,
//                                 color: teleBlack,
//                               ),
//                         hintText:
//                             "Service Provider/Hospital/Health System/OP Facility",
//                         hintStyle: TextStyle(
//                             fontSize: 13,
//                             color: teleGray,
//                             fontFamily: "NunitoSans"),
//                         filled: true,
//                         fillColor: Colors.white,
//                         focusedBorder: OutlineInputBorder(
//                             borderSide: BorderSide(color: telePurple2),
//                             borderRadius:
//                                 BorderRadius.all(Radius.circular(32))),
//                         enabledBorder: OutlineInputBorder(
//                             borderSide: BorderSide(color: Colors.transparent),
//                             borderRadius:
//                                 BorderRadius.all(Radius.circular(32)))),
//                   ),
//                 ),
//                 SizedBox(
//                   height: ScaleController.H * 0.02,
//                 ),
//                 Container(
//                   padding: EdgeInsets.only(
//                       left: ScaleController.W * 0.05,
//                       right: ScaleController.W * 0.05),
//                   child: TextFormField(
//                     cursorColor: teleGray,
//                     obscureText: hidePassword,
//                     controller: passwordController,
//                     decoration: InputDecoration(
//                         hintText: "Password",
//                         hintStyle: TextStyle(
//                             fontSize: 14,
//                             color: teleGray,
//                             fontFamily: "NunitoSans"),
//                         prefixIcon: Icon(
//                           Icons.lock,
//                           color: teleGray,
//                         ),
//                         suffixIcon: InkWell(
//                             onTap: () {
//                               setState(() {
//                                 hidePassword = !hidePassword;
//                               });
//                             },
//                             child: hidePassword
//                                 ? Icon(
//                                     Icons.visibility_outlined,
//                                     color: teleGray,
//                                   )
//                                 : Icon(
//                                     Icons.visibility_off,
//                                     color: teleGray,
//                                   )),
//                         filled: true,
//                         fillColor: Colors.white,
//                         focusedBorder: OutlineInputBorder(
//                             borderSide: BorderSide(color: telePurple2),
//                             borderRadius:
//                                 BorderRadius.all(Radius.circular(32))),
//                         enabledBorder: OutlineInputBorder(
//                             borderSide: BorderSide(color: Colors.transparent),
//                             borderRadius:
//                                 BorderRadius.all(Radius.circular(32)))),
//                   ),
//                 ),
//                 SizedBox(
//                   height: ScaleController.H * 0.03,
//                 ),
//                 InkWell(
//                   onTap: () {
//                     Get.to(ServiceMainScreen());

//                     // Get.to(ServiceSignUpPage());
//                   },
//                   child: Padding(
//                     padding: EdgeInsets.only(
//                         left: ScaleController.W * 0.05,
//                         right: ScaleController.W * 0.05),
//                     child: Container(
//                       height: ScaleController.H * 0.08,
//                       decoration: BoxDecoration(
//                           borderRadius: BorderRadius.all(Radius.circular(32)),
//                           color: teleButtonBlue),
//                       child: Center(
//                           child: Text(
//                         "Sign in",
//                         style: TextStyle(
//                             fontFamily: "NunitoSans",
//                             color: teleWhite,
//                             fontWeight: FontWeight.bold,
//                             fontSize: 14),
//                       )),
//                     ),
//                   ),
//                 ),
//                 SizedBox(
//                   height: ScaleController.H * 0.03,
//                 ),
//                 InkWell(
//                   onTap: () {
//                     Get.to(ServiceForgotPassword());
//                   },
//                   child: Text(
//                     "Forgot Password?",
//                     style: TextStyle(
//                         fontSize: 14,
//                         color: telePurple,
//                         fontFamily: "NunitoSans"),
//                   ),
//                 ),
//                 SizedBox(
//                   height: ScaleController.H * 0.28,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text(
//                       "Don't Have An Account?",
//                       style: TextStyle(
//                           fontSize: 14,
//                           color: teleGreen,
//                           fontFamily: "NunitoSans"),
//                     ),
//                     InkWell(
//                       onTap: () {
//                         Get.to(ServiceSignUpPage());
//                       },
//                       child: Text(
//                         "  Sign Up",
//                         style: TextStyle(
//                             fontSize: 14,
//                             color: telePurple,
//                             fontFamily: "NunitoSans"),
//                       ),
//                     ),
//                   ],
//                 )
//               ],
//             ),
//           )),
//     );
//   }
// }
