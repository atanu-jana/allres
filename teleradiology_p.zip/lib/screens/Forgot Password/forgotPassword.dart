import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:teleradiology/api/apiPostRequest.dart';
import 'package:teleradiology/common/commonDialog.dart';
import 'package:teleradiology/common/commonLoader.dart';
import 'package:teleradiology/res/strings.dart';
import 'package:teleradiology/res/urls.dart';
import 'package:teleradiology/screens/Verify%20OTP/verifyOtp.dart';
import 'package:teleradiology/utils/checkApiResponseSuccessOrNot.dart';
import 'package:teleradiology/utils/checkApiValueValid.dart';
import 'package:teleradiology/utils/internetCheck.dart';
import 'package:teleradiology/utils/marginPadding.dart';
import 'package:teleradiology/utils/showOfflineSnakbar.dart';
import 'package:teleradiology/utils/validation.dart';
import 'package:teleradiology/widget/roundedInputField.dart';

class ForgotPassword extends StatefulWidget {

  final bool isCustomer;
  final String emailId;

  const ForgotPassword({Key? key,required this.emailId,required this.isCustomer}) : super(key: key);

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  TextEditingController emailController = TextEditingController();

  bool selectedItem = true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: backgroundBlue,
          appBar: AppBar(
            leading: InkWell(
                onTap: () {
                  Get.back();
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: teleBlue2,
                )),
            elevation: 0,
            backgroundColor: backgroundBlue,
          ),
          body: SingleChildScrollView(
            child: Center(
              child: Column(
                children: [
                  SizedBox(
                    height: ScaleController.H * 0.15,
                  ),
                  Text(
                    "Password Recovery",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: "NunitoSans",
                        color: teleDarkBlue),
                  ),
                  Text(
                    "Enter your registered email address",
                    style: TextStyle(
                        fontSize: 14,
                        fontFamily: "NunitoSans",
                        color: telePurple2),
                  ),
                  SizedBox(
                    height: ScaleController.H * 0.05,
                  ),
                   Container(
                  padding: MarginPadding.customMarginNormal(),
                  child: RoundedInputField(
                      controller: emailController,
                      textInputAction: TextInputAction.next,
                      textInputType: TextInputType.emailAddress,
                      hintText: "Email",
                      icon: Icons.mail,
                      onchangeFunction: (String val) {},
                      validate: (String? value) {
                        return null;
                      }),
                ),
                  SizedBox(
                    height: ScaleController.H * 0.03,
                  ),
                  InkWell(
                    onTap: () {
                      if (validateAndProceed()) {
                        sendCodeToEmail();

                        // Get.to(() => VerifyOTPCustomer(
                        //       emailId: emailController.text,
                        //     ));
                      }
                    },
                    child: Padding(
                      padding: EdgeInsets.only(
                          left: ScaleController.W * 0.05,
                          right: ScaleController.W * 0.05),
                      child: Container(
                        height: ScaleController.H * 0.08,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(32)),
                            color: teleButtonBlue),
                        child: Center(
                            child: Text(
                          "Send OTP",
                          style: TextStyle(
                              fontFamily: "NunitoSans-Bold",
                              color: teleWhite,
                              fontSize: 14),
                        )),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: ScaleController.H * 0.04,
                  ), 
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Cancel",
                        style: TextStyle(
                            fontSize: 14,
                            color: telePurple2,
                            fontFamily: "NunitoSans"),
                      ),
                    ],
                  )
                ],
              ),
            ),
          )),
    );
  }

  bool validateAndProceed() {
    if (!validateEmail(emailController.text)) {
      commonAlertDialog(
        Strings.warning,
        "Email address is not valid",
      );
      return false;
    } else {
      return true;
    }
  }

  Future sendCodeToEmail() async {
    if (await internetCheck()) {
      commonLoader(context, telePurple);

      String body = json.encode({
        "email": emailController.text.trim(),
        "user_type":  widget.isCustomer?4: 3
      });
      apiPostRequest(context, Urls.forgotPasswordCheck, body).then((response) {
        if (response == null) {
          Get.back();

          commonAlertDialog(Strings.warning, Strings.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            Get.back();
            commonAlertDialog(Strings.success, showValidValue(jsonData["msg"]),
                function: () {
              Get.back();
              Get.to(() => ServiceVerifyOTP(
                    emailId: emailController.text,
                    isCustomer: widget.isCustomer,
                  ));
            });
          } else {
            Get.back();
            String msg = showValidValue(jsonData["msg"]);
            // try {
            //   msg = validValue(jsonData["data"]["email"][0])
            //       ? jsonData["data"]["email"][0]
            //       : Strings.na;
            //   msg += "\n";
            //   msg += validValue(jsonData["data"]["phone"][0])
            //       ? jsonData["data"]["phone"][0]
            //       : Strings.na;
            // } catch (e) {}
            commonAlertDialog(Strings.warning, showValidValue(msg));
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

}
