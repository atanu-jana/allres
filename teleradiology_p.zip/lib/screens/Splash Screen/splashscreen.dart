import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:teleradiology/Constants/colors_customer.dart';
import 'package:teleradiology/Constants/dimensions.dart';
import 'package:get/get.dart';
import 'package:teleradiology/screens/Navigation%20Page/navigationPage.dart';
import 'package:teleradiology/screens/Screens%20Customer/customerMainScreen.dart';
import 'package:teleradiology/screens/service%20screen/service_homepage.dart';
import 'package:teleradiology/screens/service%20screen/service_mainscreen.dart'; 
import 'package:teleradiology/services/sharedPreferenceServices.dart';

import '../Screens Customer/HomePage Customer/homepage_customer.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    serviceDrawerIndex = 0;
    customerDrawerIndex = 0;
    Future.delayed(Duration(seconds: 3), () {
      getUserType().then((userType) {
        if (userType == "4") {
         customerScreenWidget= HomePageCustomer();
          Get.to(() => CustomerMainScreen());
        } else if (userType == "3") {
          serviceScreenWidget = ServiceHomePage();

          Get.to(() => ServiceMainScreen());
        } else {
          Get.to((() => NavigationPage()));
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Image.asset(
              "assets/Images/background.png",
              fit: BoxFit.fill,
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                      height: MediaQuery.of(context).size.height * 0.046,
                      child: Image.asset("assets/Images/logo1.png")),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.02,
                  ),
                  Container(
                      height: MediaQuery.of(context).size.height * 0.046,
                      child: Image.asset("assets/Images/logo2.png")),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.02,
                  ),
                  Container(
                      height: MediaQuery.of(context).size.height * 0.046,
                      child: Image.asset("assets/Images/logo3.png")),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.02,
                  ),
                  Container(
                      height: MediaQuery.of(context).size.height * 0.046,
                      child: Image.asset("assets/Images/logo4.png")),
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.01,
              ),
              Container(
                  height: MediaQuery.of(context).size.height * 0.04,
                  child: Image.asset("assets/Images/essential.png")),
            ],
          ),
        ],
      )),
    );
  }
}
