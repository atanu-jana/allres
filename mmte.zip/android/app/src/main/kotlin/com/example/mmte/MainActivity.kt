package com.example.mmte

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
