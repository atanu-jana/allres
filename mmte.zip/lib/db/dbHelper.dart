 
import 'dart:developer';
import 'dart:io';
import 'package:mmte/res/app_strings.dart';
import 'package:mmte/utils/all_formatter.dart';
import 'package:mmte/utils/utils.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';

// the database helper class
class Databasehelper {
  // a database
  static Database? _mmteDb;

  // privateconstructor
  Databasehelper._privateConstructor();
  static final Databasehelper instance = Databasehelper._privateConstructor();

  // asking for a database
  Future<Database> get databse async {
    if (_mmteDb != null) return _mmteDb!;

    // create a database if one doesn't exist
    _mmteDb = await _initDatabase();
    return _mmteDb!;
  }

  // database name
  static const _mmteDbName = "mmte.db";
  static const _mmteDbVersion =
      3; // need to increase when update database field etc

  // the table name
  String logDbTable = "log_table";
  String logSuggetionTable = "log_suggetion_table";
  String todoDbTable = "todo_table";
  String noteDbTable = "note_table";
  String noteCategoryDbTable = "note_category_table";
  String expenseTypeDbTable = "expense_type";
  String notificationDbTable = "notification_table";
  String notificationSendUserDbTable = "notification_send_user_table";
  String notificationSendUserUserDbTable = "notification_send_user_user_table";
  String countdownDbTable = "countdown_table";
  String logMonthlyExpenseDbTable = "log_monthly_expense";
  String monthlyExpenseDbTable = "monthly_expense";
  String rememberWordDbTable = "remember_word";
  String passwordDbTable = "password";
  String dayNoteDbTable = "day_note";
  String investingDbTable = "investing";

//** CountDown column names
//id
// dateForSearch
  //timestamp
  static const color = 'color';
  static const label = 'label';
  static const description = 'description';
  static const hours = 'hours';
  static const minutes = 'minutes';
  static const seconds = 'seconds';

//** Password column names
//id
  static const name = 'name';
  static const userName = 'userName';
  static const password = 'password';
// dateForSearch
  //timestamp
  //description

//** Remember Word column names
//id
  static const word = 'word';
  static const wordHeader = 'wordHeader';
  static const wordStartDate = 'wordStartDate';
  static const wordForDays = 'wordForDays';
  static const dateEnable = 'dateEnable';
// dateForSearch
  //timestamp
//** Investing column names
//id
//type
  static const where = 'wheree';
  static const monthlyDate = 'monthlyDate';
  static const monthly = 'monthly';
// comment
// amount
// dateForSearch
  //timestamp
//** Day Note column names
//id
  static const note = 'note';
// dateForSearch
  //timestamp
//** Notification Send To User column names
//id
//package
// dateForSearch
  //timestamp
//** Notification  Send To User on app selecteduser column names
//id
//package
  static const contactNumber = 'contactNumber';
// dateForSearch
  //timestamp
//** Notification column names
  static const id = 'id';
  static const package = 'package';
// dateForSearch
  //title
  static const message = "message";
  //timestamp

//** Log Table Column */
  static const lId = 'id';
  static const amount = 'amount';
  static const type = "type";
  static const highLight = "highLight";
  static const comment = "comment";
  static const timeStamp = "timeStamp";
// dateForSearch

//** Monthly Expense Table Column */
//id
  // amount
  // timeStamp
  // message
  // title
//** Log Monthly Expense Table Column */
//id
  // amount
  // timeStamp
// dateForSearch
  static const idMonthlyExpense = "idMonthlyExpense";
  static const statusMonthlyExpense = "statusMonthlyExpense";

//** Suggetion Table Column */

  static const sId = 'id';
  static const sAmount = 'amount';
  static const sType = "type";
  static const sHighLight = "highLight";
  static const sComment = "comment";
  static const sTimeStamp = "timeStamp";
  static const sHowMany = "howMany";
// dateForSearch

//** Todo Table Column */
  static const tId = 'id';
  static const title = "title";
  static const desc = "desc";
  static const todoDate = "todoDate";
  static const todoTime = "todoTime";
  static const priority = "priority";
  static const dateForSearch = "dateForSearch";
  static const beforeAlert = "beforeAlert";
  static const todoStatus = "todoStatus";
  static const beforeAlertTimeTitle = "beforeAlertTimeTitle";
//** Note Table Column */
  static const nId = 'id';
  static const nTitle = 'title';
  static const nDateForSearch = "dateForSearch";
  static const nNote = "note";
  static const nTimeStamp = "timeStamp";
  static const noteCategoryId = "noteCategoryId";
//** Note Category Table Column */
// id
  static const categoryName = 'categoryName';
  static const categoryDescription = "categoryDescription";
  // dateForSearch
  //timestamp
//** Expense Type Table Column */
// id
  static const typeName = 'typeName';
  static const typeDescription = "typeDescription";
  // dateForSearch
  //timestamp

  // function to return a database for rate chart
  _initDatabase() async {
    try {
      if (Platform.isAndroid) {
        try {
          if (await Utils.requestPermission2(Permission.storage)) {
            if (await Utils.requestPermission2(Permission.manageExternalStorage)) {
              try {
                Directory directory;

                directory = (await getExternalStorageDirectory())!;
                String newPath = "";
                List<String> folders = directory.path.split("/");
                for (int x = 1; x < folders.length; x++) {
                  String folder = folders[x];
                  if (folder != "Android") {
                    newPath += "/" + folder;
                  } else {
                    break;
                  }
                }

                newPath = newPath + "/${AppStrings.appName}/.db";
                directory = Directory(newPath);
                if (!await directory.exists()) {
                  await directory.create(recursive: true);
                }
                if (await directory.exists()) {
                  String path = join(directory.path, _mmteDbName);
                  return await openDatabase(path,
                      version: _mmteDbVersion,
                      onCreate: _onCreate,
                      onUpgrade: _onUpgrade);
                }
              } catch (e) {}
            } else {}
          } else {}
        } catch (e) {}
      } else {
        // Not IOS
      }
    } catch (e) {}
  }

  // create a database since it doesn't exist
  Future _onCreate(Database db, int version) async {
    Batch batch = db.batch();
    // sql code

    batch.execute('''
      CREATE TABLE $dayNoteDbTable (
        $id INTEGER PRIMARY KEY,
        $note TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
      CREATE TABLE $rememberWordDbTable (
        $lId INTEGER PRIMARY KEY,
        $word TEXT NOT NULL,
        $wordHeader TEXT NOT NULL,
        $wordForDays TEXT NOT NULL,
        $wordStartDate TEXT NOT NULL,
        $dateEnable TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
      CREATE TABLE $investingDbTable (
        $id INTEGER PRIMARY KEY,
        $type TEXT NOT NULL,
        $where TEXT NOT NULL,
        $monthlyDate TEXT NOT NULL,
        $amount TEXT NOT NULL,
        $monthly TEXT NOT NULL,
        $comment TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');

    batch.execute('''
      CREATE TABLE $passwordDbTable (
        $lId INTEGER PRIMARY KEY,
        $name TEXT NOT NULL,
        $userName TEXT NOT NULL,
        $password TEXT NOT NULL,
        $description TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
      CREATE TABLE $logDbTable (
        $lId INTEGER PRIMARY KEY,
        $amount TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $type TEXT NOT NULL,
        $comment TEXT NOT NULL,
        $highLight TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
      CREATE TABLE $logSuggetionTable (
        $sId INTEGER PRIMARY KEY,
        $sAmount TEXT NOT NULL,
        $sType TEXT NOT NULL,
        $sHighLight TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $sComment TEXT NOT NULL,
        $sHowMany INTEGER NOT NULL,
        $sTimeStamp TEXT NOT NULL
      );
      ''');

    batch.execute('''
      CREATE TABLE $todoDbTable (
        $tId INTEGER PRIMARY KEY,
        $priority INTEGER NOT NULL,
        $title TEXT NOT NULL,
        $desc TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $beforeAlertTimeTitle TEXT NOT NULL,
        $beforeAlert TEXT NOT NULL,
        $todoDate TEXT NOT NULL,
        $todoStatus TEXT NOT NULL,
        $todoTime TEXT NOT NULL
      );
      ''');
    batch.execute('''
      CREATE TABLE $noteDbTable (
        $nId INTEGER PRIMARY KEY,
        $noteCategoryId TEXT NOT NULL,
        $nTitle TEXT NOT NULL,
        $nDateForSearch TEXT NOT NULL,
        $nNote TEXT NOT NULL,
        $nTimeStamp TEXT NOT NULL
      );
      ''');
    // test TEXT ,
    batch.execute('''
     CREATE TABLE $notificationDbTable (
        $id INTEGER PRIMARY KEY,
        $package TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $title TEXT NOT NULL,
        $message TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
     CREATE TABLE $notificationSendUserDbTable (
        $id INTEGER PRIMARY KEY,
        $package TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
     CREATE TABLE $notificationSendUserUserDbTable (
        $id INTEGER PRIMARY KEY,
        $package TEXT NOT NULL,
        $contactNumber TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
     CREATE TABLE $noteCategoryDbTable  (
        $id INTEGER PRIMARY KEY,
        $categoryName TEXT NOT NULL,
        $categoryDescription TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
   
    batch.execute('''
     CREATE TABLE $countdownDbTable (
        $id INTEGER PRIMARY KEY,
        $color INTEGER,
        $description TEXT,
        $hours INTEGER,
        $minutes INTEGER,
        $seconds INTEGER,
        $dateForSearch TEXT NOT NULL,
        $label TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
     CREATE TABLE $logMonthlyExpenseDbTable (
        $id INTEGER PRIMARY KEY,
        $idMonthlyExpense INTEGER NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $statusMonthlyExpense TEXT NOT NULL,
        $amount TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    batch.execute('''
     CREATE TABLE $monthlyExpenseDbTable (
        $id INTEGER PRIMARY KEY,
        $title TEXT NOT NULL,
        $comment TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $amount TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');
    List<dynamic> res = await batch.commit();
  }

  void _onUpgrade(Database db, int oldVersion, int newVersion) async {
    log("OnUpgrade");
    var val = await db.getVersion();
    log(val.toString());
    log("oldVersion " + oldVersion.toString());
    log("newVersion " + newVersion.toString());
    if (oldVersion < newVersion) {
      // db.execute("ALTER TABLE $monthlyExpenseDbTable ADD COLUMN $comment TEXT ;");// Note: not add like TEXT NOT NULL,
      // db.execute('''
      // CREATE TABLE IF NOT EXISTS $investingDbTable (
      //   $id INTEGER PRIMARY KEY,
      //   $type TEXT NOT NULL,
      //   $where TEXT NOT NULL,
      //   $monthlyDate TEXT NOT NULL,
      //   $amount TEXT NOT NULL,
      //   $monthly TEXT NOT NULL,
      //   $comment TEXT NOT NULL,
      //   $dateForSearch TEXT NOT NULL,
      //   $timeStamp TEXT NOT NULL
      // );
      // '''); // Note: not add like TEXT NOT NULL,
      db.execute('''
      CREATE TABLE IF NOT EXISTS $expenseTypeDbTable (
        $id INTEGER PRIMARY KEY,
        $typeName TEXT NOT NULL, 
        $typeDescription TEXT NOT NULL,
        $dateForSearch TEXT NOT NULL,
        $timeStamp TEXT NOT NULL
      );
      ''');  
    }
    //id
    // amount
    // timeStamp
// dateForSearch
  }

//! ----------------   Day Note Start -------------------------
//!**
//!**
//!**
  Future<void> updateDayNote(int id, String noteee) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $dayNoteDbTable SET $note = ?  WHERE id = ? ",
      [noteee, id],
    );
  }

  insertDayNote(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(dayNoteDbTable, row);
  }

  Future<int> deleteDayNote(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(dayNoteDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<List<Map<String, dynamic>>> fetchAllDayNoteByDate(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      dayNoteDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllDayNotes() async {
    Database db = await instance.databse;

    return await db.query(
      dayNoteDbTable,
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllDayNotesForExport() async {
    Database db = await instance.databse;

    return await db.query(
      dayNoteDbTable,
    );
  }

//!**
//!**
//!**
//! ----------------   Day Note  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Note Category Start -------------------------
//!**
//!**
//!**
  Future<void> updateNoteCategory(
      int id, String categoryName, String categoryDescription) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $noteCategoryDbTable SET $categoryName = ?, $categoryDescription = ? WHERE id = ? ",
      [categoryName, categoryDescription, id],
    );
  }

  insertNoteCategory(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(noteCategoryDbTable, row);
  }

  Future<List<Map<String, dynamic>>> queryAllNoteCategory() async {
    Database db = await instance.databse;
    return await db.query(
      noteCategoryDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllNoteCategoryForExport() async {
    Database db = await instance.databse;
    return await db.query(
      noteCategoryDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<int> deleteNoteCategory(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(noteCategoryDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<List<Map<String, dynamic>>> fetchAllNoteCategoryByDate(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      noteCategoryDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllNotes() async {
    Database db = await instance.databse;

    return await db.query(
      noteCategoryDbTable,
      orderBy: "$nTimeStamp DESC",
    );
  }

//!**
//!**
//!**
//! ----------------   Note Category  End -------------------------
//******************************************************************************************************************************** */
//! ----------------   Note Category Start -------------------------
//!**
//!**
//!**
  Future<void> updateExpenseType(
      int id, String categoryName, String categoryDescription) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $expenseTypeDbTable SET $typeName = ?, $typeDescription = ? WHERE id = ? ",
      [categoryName, categoryDescription, id],
    );
  }

  insertExpenseType(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(expenseTypeDbTable ,row);
  }

  Future<List<Map<String, dynamic>>> queryAllExpenseType() async {
    Database db = await instance.databse;
    return await db.query(
      expenseTypeDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllExpenseTypeForExport() async {
    Database db = await instance.databse;
    return await db.query(
      expenseTypeDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<int> deleteExpenseType(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(expenseTypeDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<List<Map<String, dynamic>>> fetchAllExpenseTypeByDate(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      expenseTypeDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllExpenseType() async {
    Database db = await instance.databse;

    return await db.query(
      expenseTypeDbTable,
      orderBy: "$nTimeStamp DESC",
    );
  }

//!**
//!**
//!**
//! ----------------   Note Category  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Log Monthly Expense Start -------------------------
//!**
//!**
//!**

  insertLogMonthlyExpense(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(logMonthlyExpenseDbTable, row);
  }

  Future<void> updateLogMonthlyExpense(int id, String amountt,
      String statusMonthlyExpensee, int expenseId) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $logMonthlyExpenseDbTable SET  $amount = ?,$statusMonthlyExpense = ?   WHERE id = ? AND $idMonthlyExpense = ? ",
      [amountt, statusMonthlyExpensee, id, expenseId],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllLogMonthlyExpense() async {
    Database db = await instance.databse;
    return await db.query(
      logMonthlyExpenseDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>>
      queryAllLogMonthlyExpenseForExport() async {
    Database db = await instance.databse;
    return await db.query(
      logMonthlyExpenseDbTable,
    );
  }

  Future<int> deleteLogMonthlyExpense(int id) async {
    Database db = await instance.databse;
    var res = await db
        .delete(logMonthlyExpenseDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Log Monthly Expense  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Password Start -------------------------
//!**
//!**
//!**

  insertPassword(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(passwordDbTable, row);
  }

  Future<void> updatePassword(int id, String namee, String userNamee,
      String passwordd, String descriptionn) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $passwordDbTable SET  $name = ?,$userName = ?,$password = ?,$description = ?   WHERE id = ?   ",
      [namee, userNamee, passwordd, descriptionn, id],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllPassword() async {
    Database db = await instance.databse;
    return await db.query(
      passwordDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllPasswordForExport() async {
    Database db = await instance.databse;
    return await db.query(
      passwordDbTable,
    );
  }

  Future<int> deletePassword(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(passwordDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Log Monthly Expense  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Monthly Expense Start -------------------------
//!**
//!**
//!**

  insertMonthlyExpense(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(monthlyExpenseDbTable, row);
  }

  Future<void> updateMonthlyExpense(
      int id, String amount, String title, String message) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $monthlyExpenseDbTable SET  $amount = ?, $title = ?,$message = ? WHERE id = ? ",
      [amount, title, message, id],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllMonthlyExpense() async {
    Database db = await instance.databse;
    return await db.query(
      monthlyExpenseDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllMonthlyExpenseForExport() async {
    Database db = await instance.databse;
    return await db.query(
      monthlyExpenseDbTable,
    );
  }

  Future<int> deleteMonthlyExpense(int id) async {
    Database db = await instance.databse;
    var res = await db
        .delete(monthlyExpenseDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Log Monthly Expense  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Remember Word Start -------------------------
//!**
//!**
//!**

  insertRememberWord(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(rememberWordDbTable, row);
  }

  Future<void> updateRememberWord(int id, String wordd) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $rememberWordDbTable SET  $word = ? WHERE id = ? ",
      [wordd, id],
    );
  }

  Future<void> updateRememberWordHeader(int id, String wordHeaderr) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $rememberWordDbTable SET   $wordHeader = ? WHERE id = ? ",
      [wordHeaderr, id],
    );
  }

  Future<void> updateRememberWordStartDate(
      int id, String wordStartDateee, String wordForDaysassss) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $rememberWordDbTable SET  $wordStartDate = ?,$wordForDays = ? WHERE id = ? ",
      [wordStartDateee, wordForDaysassss, id],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllRememberWord() async {
    Database db = await instance.databse;
    return await db.query(
      rememberWordDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllRememberWordForExport() async {
    Database db = await instance.databse;
    return await db.query(
      rememberWordDbTable,
    );
  }

  Future<int> deleteRememberWord(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(rememberWordDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Remember Word  End -------------------------
//******************************************************************************************************************************** */
//! ----------------   Investing Word Start -------------------------
//!**
//!**
//!**

  insertInvesting(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(investingDbTable, row);
  }

  // Future<void> updateRememberWord(int id, String wordd) async {
  //   Database db = await instance.databse;
  //   await db.rawUpdate(
  //     "UPDATE $investingDbTable SET  $word = ? WHERE id = ? ",
  //     [wordd, id],
  //   );
  // }

  // Future<void> updateRememberWordHeader(int id, String wordHeaderr) async {
  //   Database db = await instance.databse;
  //   await db.rawUpdate(
  //     "UPDATE $investingDbTable SET   $wordHeader = ? WHERE id = ? ",
  //     [wordHeaderr, id],
  //   );
  // }

  Future<void> updateInvestingDate(int id, String monthlyDateee) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $investingDbTable SET  $monthlyDate = ? WHERE id = ? ",
      [monthlyDateee, id],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllInvesting() async {
    Database db = await instance.databse;
    return await db.query(
      investingDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllInvestingForExport() async {
    Database db = await instance.databse;
    return await db.query(
      investingDbTable,
    );
  }

  Future<int> deleteInvesting(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(investingDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Investing Word  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   CountDown Start -------------------------
//!**
//!**
//!**

  insertCountDown(Map<String, dynamic> row) async {
    // var table = await db.rawQuery('SELECT MAX(id)+1 as id FROM CountDown');
    // var id = table.first['id'];
    Database db = await instance.databse;
    return await db.insert(countdownDbTable, row);
  }

  Future<List<Map<String, dynamic>>> queryAllCountDown() async {
    Database db = await instance.databse;
    return await db.query(
      countdownDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllCountDownForExport() async {
    Database db = await instance.databse;
    return await db.query(
      countdownDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<int> deleteCountDown(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(countdownDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<List<Map<String, dynamic>>> fetchAllCountDownByDate(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      countdownDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

//!**
//!**
//!**
//! ----------------   CountDown  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Notification For Send User Start -------------------------
//!**
//!**
//!**

  Future<int> insertNotificationSendForUser(Map<String, dynamic> row) async {
    Database db = await instance.databse;

    return await db.insert(notificationSendUserDbTable, row);
  }

  Future<List<Map<String, dynamic>>> fetchAllSendForUserByDate(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      notificationSendUserDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllSendForUserForExport() async {
    Database db = await instance.databse;

    return await db.query(
      notificationSendUserDbTable,
    );
  }

  Future<List<Map<String, dynamic>>> queryAllNotificationSendForUser() async {
    Database db = await instance.databse;
    return await db.query(
      notificationSendUserDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<int> deleteNotificationSendForUser(int id) async {
    Database db = await instance.databse;
    var res = await db
        .delete(notificationSendUserDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Notification For Send User  End -------------------------

//******************************************************************************************************************************** */
//******************************************************************************************************************************** */
//! ----------------   Notification For Send User Start -------------------------
//!**
//!**
//!**

  Future<int> insertNotificationSendForUserUser(
      Map<String, dynamic> row) async {
    Database db = await instance.databse;

    return await db.insert(notificationSendUserUserDbTable, row);
  }

  Future<List<Map<String, dynamic>>> fetchAllSendForUserUserByDate(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      notificationSendUserUserDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>>
      fetchAllSendForUserUserUserForExport() async {
    Database db = await instance.databse;

    return await db.query(
      notificationSendUserUserDbTable,
    );
  }

  Future<List<Map<String, dynamic>>>
      queryAllNotificationSendForUserUser() async {
    Database db = await instance.databse;
    return await db.query(
      notificationSendUserUserDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<int> deleteNotificationSendForUserUser(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(notificationSendUserUserDbTable,
        where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Notification For Send User  End -------------------------

//******************************************************************************************************************************** */
//! ----------------   Notification Start -------------------------
//!**
//!**
//!**

  Future<int> insertNotification(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(notificationDbTable, row);
  }

  Future<List<Map<String, dynamic>>> fetchAllTodaysNotification(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      notificationDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllNotificationForExport() async {
    Database db = await instance.databse;

    return await db.query(
      notificationDbTable,
    );
  }

  Future<List<Map<String, dynamic>>> queryAllNotification() async {
    Database db = await instance.databse;
    return await db.query(
      notificationDbTable,
      orderBy: "$id DESC",
    );
  }

  Future<int> deleteNotification(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(notificationDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

//!**
//!**
//!**
//! ----------------   Notification End -------------------------

//******************************************************************************************************************************** */

//! ----------------   Note Start -------------------------
//!**
//!**
//!**

  Future<int> insertNote(Map<String, dynamic> row) async {
    Database db = await instance.databse;

    return await db.insert(noteDbTable, row);
  }

  Future<List<Map<String, dynamic>>> fetchAllTodaysNode(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      noteDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllNoteForExport() async {
    Database db = await instance.databse;

    return await db.query(
      noteDbTable,
    );
  }

  // Future<List<Map<String, dynamic>>> queryAllNote() async {
  //   Database db = await instance.databse;
  //   return await db.query(
  //     noteDbTable,
  //     orderBy: "$nId DESC",
  //   );
  // }
  Future<List<Map<String, dynamic>>> queryAllNoteWithCategoryId(
      String noteCategoryId) async {
    Database db = await instance.databse;
    return await db.query(
      noteDbTable,
      where: "noteCategoryId  = ?",
      whereArgs: [noteCategoryId],
      orderBy: "$nTimeStamp DESC",
    );
  }

  Future<int> deleteNote(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(noteDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<void> updateNote(int id, String title, String note) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $noteDbTable SET title = ?, note = ?,$nDateForSearch = ?,$nTimeStamp = ? WHERE id = ? ",
      [
        title,
        note,
        formatterForSearchTodo.format(DateTime.now()),
        DateTime.now().toString(),
        id
      ],
    );
  }

  Future<void> updateNoteCategoryId(int id, String categoryId) async {
    Database db = await instance.databse;
    await db.rawUpdate(
        "UPDATE $noteDbTable SET $noteCategoryId = ? WHERE id = ? ",
        [categoryId, id]);
    // await db.update(
    //   todoDbTable,
    //   mapData,
    //      where: "id = ? and dateForSearch  = ?",
    //   whereArgs: [id,dateForSearch],
    //   // Pass the Dog's id as a whereArg to prevent SQL injection.
    // );
  }

//!**
//!**
//!**
//! ----------------   Note End -------------------------

//******************************************************************************************************************************** */

//! ----------------   Todo Start -------------------------
//!**
//!**
//!**
  // function to query all the rows
  Future<List<Map<String, dynamic>>> queryAllTodo(String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      todoDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
      orderBy: "$priority ASC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllTodoForExport() async {
    Database db = await instance.databse;

    return await db.query(
      todoDbTable,
    );
  }

  Future<List<Map<String, dynamic>>> fetchAllTodaysTodo(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      todoDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  Future<int> insertTodo(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(todoDbTable, row);
  }

  Future<void> updateTodoStatus(int id, String status) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $todoDbTable SET  $todoStatus = ? WHERE id = ? ",
      [status, id],
    );
  }

  Future<int> deleteTodo(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(todoDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  Future<void> updatePriority(
      int id, Map<String, dynamic> mapData, String dateForSearch) async {
    Database db = await instance.databse;

    await db.update(
      todoDbTable,
      mapData,
      where: "id = ? and dateForSearch  = ?",
      whereArgs: [id, dateForSearch],
      // Pass the Dog's id as a whereArg to prevent SQL injection.
    );
  }
//!**
//!**
//!**
//! ----------------   Todo End -------------------------

//******************************************************************************************************************************** */

//! ----------------   Log Start -------------------------
//!**
//!**
//!**

  Future<List<Map<String, dynamic>>> fetchAllTodaysLog(
      String dateForSearch) async {
    Database db = await instance.databse;

    return await db.query(
      logDbTable,
      where: "dateForSearch  = ?",
      whereArgs: [dateForSearch],
    );
  }

  // functions to insert data
  Future<int> insertLog(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(logDbTable, row);
  }

  // function to query all the rows
  Future<List<Map<String, dynamic>>> queryAllLog() async {
    Database db = await instance.databse;
    return await db.query(
      logDbTable,
      orderBy: "$lId DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllLogForExport() async {
    Database db = await instance.databse;
    return await db.query(
      logDbTable,
    );
  }

  // function to delete some data
  Future<int> deleteLog(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(logDbTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
//!**
//!**
//!**
//! ----------------   Log End -------------------------

//******************************************************************************************************************************** */

//! ----------------   Suggetion Start -------------------------
//!**
//!**
//!**
  // functions to insert data
  Future<int> insertSuggetion(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(logSuggetionTable, row);
  }

  // function to query all the rows
  Future<List<Map<String, dynamic>>> queryAllSuggetion() async {
    Database db = await instance.databse;

    return await db.query(
      logSuggetionTable,
      orderBy: "$sHowMany DESC",
    );
  }

  Future<List<Map<String, dynamic>>> queryAllSuggetionForExport() async {
    Database db = await instance.databse;

    return await db.query(
      logSuggetionTable,
    );
  }

  // function to query all the rows
  Future<List<Map<String, dynamic>>> querySuggetion(
      String type, String highLight, String amount) async {
    Database db = await instance.databse;

    return await db.query(
      logSuggetionTable,
      where: "type LIKE ? and highLight = ? and amount = ?",
      whereArgs: [type, highLight, amount],
      orderBy: "$sId DESC",
    );
  }

  Future<void> updateForSuggetion(int id, Map<String, dynamic> mapData) async {
    Database db = await instance.databse;

    await db.update(
      logSuggetionTable,
      mapData,
      // Ensure that the Dog has a matching id.
      where: "id = ?",
      // Pass the Dog's id as a whereArg to prevent SQL injection.
      whereArgs: [id],
    );
  }

  Future<int> deleteLogSuggetion(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(logSuggetionTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
//!**
//!**
//!**
//! ----------------   Suggetion End -------------------------

//******************************************************************************************************************************** */

  Future<void> truncateTables() async {
    Database db = await instance.databse;

    await db.delete(
      logDbTable,
    );
    await db.delete(
      logSuggetionTable,
    );

    await db.delete(
      todoDbTable,
    );
    await db.delete(
      noteDbTable,
    );
    await db.delete(
      noteCategoryDbTable,
    );
    await db.delete(
      notificationDbTable,
    );
    await db.delete(
      notificationSendUserDbTable,
    );
    await db.delete(
      notificationSendUserUserDbTable,
    );
    await db.delete(
      countdownDbTable,
    );
    await db.delete(
      logMonthlyExpenseDbTable,
    );
    await db.delete(
      monthlyExpenseDbTable,
    );
    await db.delete(
      rememberWordDbTable,
    );
    await db.delete(
      passwordDbTable,
    );
    await db.delete(
      dayNoteDbTable,
    );
  }

  Future<int> insertAllExportedData(
      Map<String, dynamic> rowForImport, String tableForInsert) async {
    Database db = await instance.databse;
    return await db.insert(tableForInsert, rowForImport);
  }

  Future<List<Map<String, dynamic>>> fetchAllForImportedData(
      String tableForFetch) async {
    Database db = await instance.databse;

    return await db.query(
      tableForFetch,
    );
  }
}

// import 'dart:io';
// import 'package:path/path.dart';
// // should install these
// // refer description for more
// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';

// // the database helper class
// class Databasehelper {
//   // a database
//   static Database? _logDb;
//   static Database? _logDbForSuggetion;

//   // privateconstructor
//   Databasehelper._privateConstructor();
//   static final Databasehelper instance = Databasehelper._privateConstructor();

//   // asking for a database
//   Future<Database> get databse async {
//     if (_logDb != null) return _logDb!;

//     // create a database if one doesn't exist
//     _logDb = await _initDatabase();
//     return _logDb!;
//   }

//   Future<Database> get databseForSuggetion async {
//     if (_logDbForSuggetion != null) return _logDbForSuggetion!;

//     // create a database if one doesn't exist
//     _logDbForSuggetion = await _initDatabaseForSuggetion();

//     return _logDbForSuggetion!;
//   }

//   // database name
//   static const _logDbName = "log.db";
//   static const _logSuggetionDbName = "logSuggetion.db";
//   static const _logDbVersion = 1;

//   // the table name
//   static const logDbTable = "log_table";
//   static const logSuggetionTable = "log_suggetion_table";

//   // log column names
//   static const id = 'id';
//   static const amount = 'amount';
//   static const type = "type";
//   static const highLight = "highLight";
//   static const timeStamp = "timeStamp";
//   // log suggetion column names
//   static const sId = 'id';
//   static const sAmount = 'amount';
//   static const sType = "type";
//   static const sHighLight = "highLight";
//   static const sTimeStamp = "timeStamp";
//   static const sHowMany = "howMany";

//   // function to return a database for rate chart
//   _initDatabase() async {
//     Directory documentdirecoty = await getApplicationDocumentsDirectory();
//     String path = join(documentdirecoty.path, _logDbName);
//     return await openDatabase(path,
//         version: _logDbVersion, onCreate: _onCreate);
//   }

//   // function to return a database for rate chart
//   _initDatabaseForSuggetion() async {
//     Directory documentdirecoty = await getApplicationDocumentsDirectory();
//     String path = join(documentdirecoty.path, _logSuggetionDbName);
//     return await openDatabase(path,
//         version: _logDbVersion, onCreate: _onCreateSuggetion);
//   }

//   // create a database since it doesn't exist
//   Future _onCreate(Database db, int version) async {
//     // sql code
//     await db.execute('''
//       CREATE TABLE $logDbTable (
//         $id INTEGER PRIMARY KEY,
//         $amount TEXT NOT NULL,
//         $type TEXT NOT NULL,
//         $highLight TEXT NOT NULL,
//         $timeStamp TEXT NOT NULL
//       );
//       ''');
//   }

//   Future _onCreateSuggetion(Database db, int version) async {
//     // sql code
//     await db.execute('''
//       CREATE TABLE $logSuggetionTable (
//         $sId INTEGER PRIMARY KEY,
//         $sAmount TEXT NOT NULL,
//         $sType TEXT NOT NULL,
//         $sHighLight TEXT NOT NULL,
//         $sHowMany INTEGER NOT NULL,
//         $sTimeStamp TEXT NOT NULL
//       );
//       ''');
//   }

//   // functions to insert data
//   Future<int> insert(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(logDbTable, row);
//   }

//   // functions to insert data
//   Future<int> insertSuggetion(Map<String, dynamic> row) async {
//     Database db = await instance.databseForSuggetion;
//     return await db.insert(logSuggetionTable, row);
//   }

//   // function to query all the rows
//   Future<List<Map<String, dynamic>>> queryall() async {
//     Database db = await instance.databse;
//     return await db.query(
//       logDbTable,
//       orderBy: "$id DESC",
//     );
//   }

//   // function to query all the rows
//   Future<List<Map<String, dynamic>>> queryallSuggetion() async {
//     Database db = await instance.databseForSuggetion;
//     return await db.query(
//       logSuggetionTable,
//       orderBy: "$sHowMany DESC",
//     );
//   }

//   // function to query all the rows
//   Future<List<Map<String, dynamic>>> querySuggetion(
//       String type, String highLight, String amount) async {
//     Database db = await instance.databseForSuggetion;
//     return await db.query(
//       logSuggetionTable,
//       where: "type LIKE ? and highLight = ? and amount = ?",
//       whereArgs: [type, highLight, amount],
//       orderBy: "$id DESC",
//     );
//   }

//   Future<void> updateForSuggetion(int id, Map<String, dynamic> mapData) async {
//     Database db = await instance.databseForSuggetion;

//     await db.update(
//       logSuggetionTable,
//       mapData,
//       // Ensure that the Dog has a matching id.
//       where: "id = ?",
//       // Pass the Dog's id as a whereArg to prevent SQL injection.
//       whereArgs: [id],
//     );
//   }

//   // function to delete some data
//   Future<int> deletedata(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(logDbTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// }
