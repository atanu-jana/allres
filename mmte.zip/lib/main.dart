import 'package:flutter/material.dart';
import 'package:mmte/db/dbHelper.dart';
import 'package:mmte/res/app_colors.dart';
import 'package:mmte/res/app_sharedPreferences_keys.dart';
import 'package:mmte/res/app_strings.dart';
import 'package:mmte/utils/routes/routes.dart';
import 'package:mmte/utils/routes/routes_name.dart';
import 'package:mmte/view/splash_view/splash_view.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

double screenWidth = 0.0;
double screenHeight = 0.0;
bool darkTheme = false;
SharedPreferences? sharedPreferences;
final dbhelper = Databasehelper.instance;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sharedPreferences = await SharedPreferences.getInstance();
  loadAllPreferencesValue();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      darkTheme: ThemeData(
        //   textTheme: TextTheme(
        // headlineMedium: TextStyle(),
        // bodyText1: TextStyle(),
        // subtitle1: TextStyle(),
        // bodySmall: TextStyle(),
        // titleMedium: TextStyle(),
        // titleLarge: TextStyle(),
      // )
      ),
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: RoutesName.splash,
      onGenerateRoute: Routes.generateRoute,
      home: SplashView(),
    );
  }
}

void loadAllPreferencesValue() {
  if (sharedPreferences!.getBool(
        AppSharedPreferencesKeys.darkTheme,
      ) ==
      null) {
    sharedPreferences!.setBool(
      AppSharedPreferencesKeys.darkTheme,
      false,
    );
  }
  if (sharedPreferences!.getString(
        AppSharedPreferencesKeys.salary,
      ) ==
      null) {
    sharedPreferences!.setString(
      AppSharedPreferencesKeys.salary,
      "0",
    );
  }
  if (sharedPreferences!.getString(
        AppSharedPreferencesKeys.fingerprintUnlockTime,
      ) ==
      null) {
    sharedPreferences!.setString(
      AppSharedPreferencesKeys.fingerprintUnlockTime,
      "",
    );
  }
  if (sharedPreferences!.getString(
        AppSharedPreferencesKeys.automaticallyLockTime,
      ) ==
      null) {
    sharedPreferences!.setString(
      AppSharedPreferencesKeys.automaticallyLockTime,
      AppStrings.select,
    );
  }
  if (sharedPreferences!.getString(
        AppSharedPreferencesKeys.fontFamily,
      ) ==
      null) {
    sharedPreferences!.setString(
      AppSharedPreferencesKeys.fontFamily,
      AppStrings.defaultFontFamily,
    );
  }
 

  if (sharedPreferences!.getInt(
        AppSharedPreferencesKeys.dayStartHr,
      ) ==
      null) {
    sharedPreferences!.setInt(
      AppSharedPreferencesKeys.dayStartHr,
      -1,
    );
  }
  if (sharedPreferences!.getInt(
        AppSharedPreferencesKeys.dayEndHr,
      ) ==
      null) {
    sharedPreferences!.setInt(
      AppSharedPreferencesKeys.dayEndHr,
      -1,
    );
  }
  if (sharedPreferences!.getInt(
        AppSharedPreferencesKeys.dayStartMin,
      ) ==
      null) {
    sharedPreferences!.setInt(
      AppSharedPreferencesKeys.dayStartMin,
      -1,
    );
  }
  if (sharedPreferences!.getInt(
        AppSharedPreferencesKeys.dayEndMin,
      ) ==
      null) {
    sharedPreferences!.setInt(
      AppSharedPreferencesKeys.dayEndMin,
      -1,
    );
  }
  darkTheme = sharedPreferences!.getBool(
    AppSharedPreferencesKeys.darkTheme,
  )!;
  if (sharedPreferences!.getString(
        AppSharedPreferencesKeys.primaryColor,
      ) ==
      null) {
    sharedPreferences!.setString(
        AppSharedPreferencesKeys.primaryColor, darkTheme ? "0073D1" : "2196f3");
  }
  AppColors.primaryColor = Color(int.parse(
      'FF${sharedPreferences!.getString(
        AppSharedPreferencesKeys.primaryColor,
      )!}',
      radix: 16)); 
  if (sharedPreferences!.getString(
        AppSharedPreferencesKeys.gradint1,
      ) ==
      null) {
    sharedPreferences!.setString(AppSharedPreferencesKeys.gradint1, "59C173");
  } 
}
