import 'package:flutter/material.dart';
import 'package:mmte/main.dart';
import 'package:mmte/res/app_colors.dart';
import 'package:mmte/utils/appIcons.dart';
import 'package:mmte/utils/appMarginPadding.dart';
import 'package:mmte/utils/appTexts.dart'; 

class SplashScreenPermissionTile extends StatelessWidget {
  final Function() onTap;
  final IconData icon;
  final String name;
  final bool forHome;
  const SplashScreenPermissionTile(
      {Key? key,
      required this.icon,
      required this.name,
      required this.onTap,
      this.forHome = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTap();
      },
      child: Container(
        padding: EdgeInsets.all(2),
        child: Container(
          padding: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.02, vertical: screenWidth * 0.02),
          decoration: BoxDecoration(
            color: darkTheme ? AppColors.blackColor : AppColors.whiteColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                children: [
                  Container(
                      margin: AppMarginPadding.customHorizontal(),
                      child: AppIcons.normalIcon(icon, color: AppColors.primaryColor)),
                  Container(
                    child: AppTexts.bodyText(
                      context,
                      name,
                        color: darkTheme ? AppColors.whiteColor : AppColors.blackColor),
                  )
                ],
              ),
              Container(
                  width: screenWidth * 0.06,
                  height: screenWidth * 0.06,
                  color: AppColors.transparentColor,
                  margin: AppMarginPadding.customHorizontal(),
                  child: AppIcons.mediumIcon(
                      forHome
                          ? Icons.check_rounded
                          : Icons.warning_amber_rounded,
                      color: forHome ? AppColors.deepGreenColor : AppColors.yellowColor)),
            ],
          ),
        ),
      ),
    );
  }
}
