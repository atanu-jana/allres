 

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mmte/main.dart';
import 'package:mmte/res/app_colors.dart';
import 'package:mmte/res/app_images.dart';
import 'package:mmte/res/app_strings.dart';
import 'package:mmte/utils/appMarginPadding.dart';
import 'package:mmte/utils/appTexts.dart';
import 'package:mmte/view/splash_view/widget/splash_permission_tile.dart';
import 'package:mmte/view_model/splash_model.dart';

class SplashView extends StatefulWidget {
  const SplashView({Key? key}) : super(key: key);

  @override
  _SplashViewState createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView>
    with TickerProviderStateMixin {
      SplashModel _splashModel=SplashModel();
  @override
  void initState() {
    _splashModel.getAppInfo(context);

    _splashModel.animationController1 = AnimationController(
        duration: const Duration(milliseconds: 700), vsync: this)
      ..repeat(reverse: true);
    _splashModel.animation1 =
        IntTween(begin: 100, end: 0).animate(_splashModel.animationController1!);
    _splashModel.animationController1!.addListener(() {
      setState(() {});
    });
    _splashModel.animationController2 = AnimationController(
        duration: const Duration(milliseconds: 700), vsync: this)
      ..repeat(reverse: true);
    _splashModel.animationController2!.addListener(() {
      setState(() {});
    });
    _splashModel.animation2 =
        IntTween(begin: 0, end: 100).animate(_splashModel.animationController2!);
    _splashModel.splashScreenController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    )..repeat(reverse: true);
    _splashModel.animation = CurvedAnimation(
        parent: _splashModel.splashScreenController!, curve: Curves.easeIn);

    _splashModel.splashScreenController!.forward().then((_) {
      _splashModel.checkAllPermissionThenVisiblePermissionGrant().then((value) {
        if (value) {
          _splashModel.checkPageChange(context);
        } else {
          _splashModel.visiblePermissionScreen = true;
        }
      });
    });

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
 
  }

  @override
  Widget build(BuildContext context) {
    screenHeight = MediaQuery.of(context).size.height;
    screenWidth = MediaQuery.of(context).size.width;

    return   Scaffold(
          backgroundColor: darkTheme ? AppColors.blackColor : AppColors.whiteColor,
          body: SafeArea(
              child: _splashModel.showFingerPrintScreen
                  ? Container(
                      width: screenWidth,
                      height: screenHeight,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          GestureDetector(
                            onTap: () {
                              _splashModel.checkPageChange(context);
                            },
                            child: Column(
                              children: [
                                Container(
                                  margin: AppMarginPadding.customVertical(),
                                  height: screenWidth * 0.4,
                                  width: screenWidth * 0.4,
                                  decoration: BoxDecoration(
                                      color: AppColors.pinkColor,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                            offset: Offset(10, 10),
                                            color: Colors.black38,
                                            blurRadius: 15),
                                        BoxShadow(
                                            offset: Offset(-10, -10),
                                            color: darkTheme
                                                ? Colors.grey.withOpacity(0.85)
                                                : Colors.white
                                                    .withOpacity(0.85),
                                            blurRadius: 15)
                                      ]),
                                  child: Icon(
                                    FontAwesomeIcons.fingerprint,
                                    color: darkTheme
                                        ? Colors.grey.shade700
                                        : Colors.grey.shade200,
                                    // color: AppColors.primaryColorColor,
                                    size: screenWidth * 0.3,
                                  ),
                                ),
                                Container(
                                  margin: AppMarginPadding.customVertical(),
                                ),
                                Container(
                                  margin: AppMarginPadding.customVertical(),
                                  height: screenWidth * 0.1,
                                  width: screenWidth * 0.5,
                                  decoration: BoxDecoration(
                                      color: darkTheme
                                          ? Colors.grey.shade700
                                          : Colors.grey.shade200,
                                      borderRadius: BorderRadius.circular(7),
                                      boxShadow: [
                                        BoxShadow(
                                            offset: Offset(10, 10),
                                            color: Colors.black38,
                                            blurRadius: 15),
                                        BoxShadow(
                                            offset: Offset(-10, -10),
                                            color: darkTheme
                                                ? Colors.grey.withOpacity(0.85)
                                                : Colors.white
                                                    .withOpacity(0.85),
                                            blurRadius: 15)
                                      ]),
                                  alignment: Alignment.center,
                                  child: AppTexts.headlineMediumText(
                                    context,
                                      "${AppStrings.unlock} ${AppStrings.appName}",
                                      color: darkTheme
                                          ? AppColors.whiteColor.withOpacity(0.5)
                                          : AppColors.blackColor.withOpacity(0.5),
                                      center: true),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    )
                  : _splashModel.visiblePermissionScreen
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            if (!_splashModel.storagePermissionGranted)
                              SplashScreenPermissionTile(
                                icon: Icons.storage_rounded,
                                name: "Grant Storage Permission",
                                onTap: () {
                                  _splashModel
                                      .checkAllPermissionThenVisiblePermissionGrant();
                                },
                              ),
                            
                            if (!_splashModel.managePermissionGranted)
                              SplashScreenPermissionTile(
                                icon: Icons.filter_vintage_outlined,
                                name:
                                    "Grant Manage External Storage Permission",
                                onTap: () {
                                  _splashModel
                                      .checkAllPermissionThenVisiblePermissionGrant();
                                },
                              ),
                            
                            if (_splashModel.storagePermissionGranted &&
                                _splashModel.managePermissionGranted)
                              SplashScreenPermissionTile(
                                icon: Icons.home_rounded,
                                name: "Home",
                                forHome: true,
                                onTap: () {
                                  _splashModel.checkPageChange(context);
                                },
                              ),
                          ],
                        )
                      : Column(
                          children: [
                            Container(
                              height: screenHeight - 50,
                              width: screenWidth,
                              color:
                                  darkTheme ? AppColors.blackColor : AppColors.whiteColor,
                              child: Stack(
                                children: [
                                  Center(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        FadeTransition(
                                          opacity: _splashModel.animation!,
                                          child: Container(
                                            width: screenWidth,
                                            color: darkTheme
                                                ? AppColors.blackColor
                                                : AppColors.whiteColor,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Image.asset(
                                                  AppImages.logo,
                                                  height: screenWidth * 0.4,
                                                  width: screenWidth * 0.4,
                                                  fit: BoxFit.cover,
                                                ),
                                                SizedBox(
                                                  height: screenWidth * 0.1,
                                                ),
                                                // largeText(AllString.appName,
                                                //     center: true,
                                                //     fontWeight: FontWeight.bold,
                                                //     color: AppColors.primaryColorColor),
                                              ],
                                            ),
                                          ),
                                        ),
                                        
                                        SizedBox(
                                          height: screenWidth * 0.15,
                                        ),
                                        Container(
                                          width: screenWidth / 2,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(15),
                                           
                                          ),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(15),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                Expanded(
                                                  flex: int.parse(_splashModel
                                                      .animation1!.value
                                                      .toString()),
                                                  child: SizedBox(
                                                    width: 0.0,
                                                    // color: AppColors.redColor,
                                                    height: screenWidth * 0.02,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 100,
                                                  child: SizedBox(
                                                    width: 0.0,
                                                    height: screenWidth * 0.02,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        color: AppColors
                                                            .primaryColor,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: int.parse(_splashModel
                                                      .animation2!.value
                                                      .toString()),
                                                  child: SizedBox(
                                                    width: 0.0,
                                                    height: screenWidth * 0.02,
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 10,
                                    child: Container(
                                      width: screenWidth,
                                      child: AppTexts. bodySmallText(
                                        context,
                                        AppStrings.versionNameWithVersion,
                                        center:true,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        )),
        );
  }
}
