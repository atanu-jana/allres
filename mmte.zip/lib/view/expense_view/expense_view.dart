import 'package:flutter/material.dart';
import 'package:mmte/utils/appTexts.dart';
import 'package:mmte/view_model/expense_view_model.dart';
import 'package:provider/provider.dart';

class ExpenseView extends StatefulWidget {
  const ExpenseView({super.key});

  @override
  State<ExpenseView> createState() => _ExpenseViewState();
}

class _ExpenseViewState extends State<ExpenseView> {
  ExpenseViewModel _expenseModel = ExpenseViewModel();
  @override
  void initState() {
    _expenseModel.fetchExpenseList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(),
      body: 
      ChangeNotifierProvider<ExpenseViewModel>(
        create: (context)=>_expenseModel,
        child:  Consumer<ExpenseViewModel>(builder:(context,model,widget){
        return _expenseModel.loading
          ? CircularProgressIndicator()
          : ListView.builder(
            itemCount: model.expenseList.length,
              itemBuilder: (context, index) => ListTile(
                    title: AppTexts.bodyText(
                        context, model.expenseList[index].highLight!),
                  ));
      }),
      )
     
    );
  }
}
