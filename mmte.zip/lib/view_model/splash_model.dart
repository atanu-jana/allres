import 'dart:io';

import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:mmte/main.dart';
import 'package:mmte/res/app_sharedPreferences_keys.dart';
import 'package:mmte/res/app_strings.dart';
import 'package:mmte/utils/capitalize.dart';
import 'package:mmte/utils/routes/routes_name.dart';
import 'package:mmte/utils/utils.dart';
import 'package:package_info/package_info.dart';
import 'package:permission_handler/permission_handler.dart';

class SplashModel with ChangeNotifier {
  AnimationController? splashScreenController;
  Animation<double>? animation;
  AnimationController? animationController1;
  AnimationController? animationController2;
  Animation? animation1;
  Animation? animation2;
  int duration = 2;
  bool visiblePermissionScreen = false;
  bool notificationPermissionGranted = false;
  bool storagePermissionGranted = false;
  bool contactPermissionGranted = false;
  bool managePermissionGranted = false;

  bool showFingerPrintScreen = false;
  bool isAuthenticate = false;

  Future<bool> checkAllPermissionThenVisiblePermissionGrant() async {
    try {
      if (Platform.isAndroid) {
        try {
          if (await Utils.requestPermission2(Permission.storage)) {
            storagePermissionGranted = true;

            if (await Utils.requestPermission2(
                Permission.manageExternalStorage)) {
              managePermissionGranted = true;

              if (await Utils.requestPermission2(Permission.notification)) {
                notificationPermissionGranted = true;
                return true;
              
              } else {
                notificationPermissionGranted = false;

                return false;
              }
            } else {
              managePermissionGranted = false;

              return false;
            }
          } else {
            storagePermissionGranted = false;

            return false;
          }
        } catch (e) {
          return false;
        }
      } else {
        return false;
      }
      
    } catch (e) {
      return false;
    }
  }

  Future<bool> authenticateWithBiometrics() async {
    final LocalAuthentication auth = LocalAuthentication();
    try {
      bool authenticated = await auth.authenticate(
          localizedReason: " ",
          // authMessages:[ AndroidAuthMessages(
          //     biometricNotRecognized: "Not Recognised",
          //     signInTitle:
          //         'Enter phone screen lock pattern, PIN, password or fingerprint',
          //     biometricHint: AppStrings.unlock + " " + AppStrings.appName)],
);
      return authenticated;
    } catch (e) {
      return false;
    }
  }

  callAuthticateProcess(BuildContext context) {
    authenticateWithBiometrics().then((authhh) {
      isAuthenticate = authhh;

      if (isAuthenticate) {
        sharedPreferences!.setString(
            AppSharedPreferencesKeys.fingerprintUnlockTime,
            DateTime.now().toString());
        splashScreenController!.dispose();
        // Navigator.of(context).pushReplacement(
        //     CupertinoPageRoute(builder: (BuildContext context) => Home()));
      } else {
        isAuthenticate = false;

        showFingerPrintScreen = true;
      }
    }).catchError((onError) {
      isAuthenticate = false;
      showFingerPrintScreen = true;
    });
  }

  checkPageChange(BuildContext context) async {
    try {
      animationController1!.dispose();
      animationController2!.dispose();
    } catch (e) {
    }
        Navigator.pushNamed(context, RoutesName.expense);

    if (sharedPreferences!
            .getString(
              AppSharedPreferencesKeys. automaticallyLockTime,
            )!
            .isEmpty ||
        sharedPreferences!.getString(
              AppSharedPreferencesKeys. automaticallyLockTime,
            )! ==
            AppStrings.select ||
        sharedPreferences!.getString(
              AppSharedPreferencesKeys. automaticallyLockTime,
            )! ==
            AppStrings.immediately) {
      callAuthticateProcess(context);
    } else {
      if (sharedPreferences!.getString(
                AppSharedPreferencesKeys. automaticallyLockTime,
              ) ==
              AppStrings.after1minute &&
          DateTime.now()
                  .difference(DateTime.parse(sharedPreferences!.getString(
                    AppSharedPreferencesKeys. fingerprintUnlockTime,
                  )!))
                  .inMinutes >
              1) {
        callAuthticateProcess(context);
      } else if (sharedPreferences!.getString(
                AppSharedPreferencesKeys. automaticallyLockTime,
              ) ==
              AppStrings.after10minute &&
          DateTime.now()
                  .difference(DateTime.parse(sharedPreferences!.getString(
                    AppSharedPreferencesKeys. fingerprintUnlockTime,
                  )!))
                  .inMinutes >
              10) {
        callAuthticateProcess(context);
      } else if (sharedPreferences!.getString(
                AppSharedPreferencesKeys. automaticallyLockTime,
              ) ==
              AppStrings.after30minute &&
          DateTime.now()
                  .difference(DateTime.parse(sharedPreferences!.getString(
                    AppSharedPreferencesKeys. fingerprintUnlockTime,
                  )!))
                  .inMinutes >
              30) {
        callAuthticateProcess(context);
      } else {
        splashScreenController!.dispose();
        // Navigator.of(context).pushReplacement(
        //     CupertinoPageRoute(builder: (BuildContext context) => H ome()));
      }
    }
  }

  getAppInfo(BuildContext context) async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String appName = packageInfo.appName;
    String packageName = packageInfo.packageName;
    String buildNumber = packageInfo.buildNumber;
    AppStrings.appName = appName.capitalize();
    AppStrings.appVersion = packageInfo.version;
    AppStrings.versionNameWithVersion =
        AppStrings.versionName + ": ${AppStrings.appVersion}";
    print(appName);
    print(packageName);
    print(buildNumber);
    print(AppStrings.versionNameWithVersion);
  }
}
