import 'package:flutter/material.dart';
import 'package:mmte/main.dart';
import 'package:mmte/model/expense_model.dart';
import 'package:mmte/utils/utils.dart'; 

class ExpenseViewModel with ChangeNotifier {

  bool _loading = false;
  bool get loading => _loading;

  setLoading(bool value) {
    _loading = value;
    notifyListeners();
  }

  List<ExpenseModel> expenseList = [];
  fetchExpenseList() async {
    setLoading(true);
    await dbhelper.queryAllLog().then((data) {
      expenseList =
          data.map((postJson) => ExpenseModel.fromJson(postJson)).toList();
    setLoading(false);

      notifyListeners();
      // Utils.consoleLog(key: 'Expense List', value: expenseLit);
    }).catchError((e){
    setLoading(false);
      notifyListeners();

      Utils.consoleLog(key: 'Expense Error', value:e);

    });
  }
}
