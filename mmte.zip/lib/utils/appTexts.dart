import 'package:flutter/material.dart';
import 'package:mmte/utils/appTextStyles.dart';

class AppTexts {
  static headlineMediumText(BuildContext context, String text,
      {Color? color,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.headlineMediumTextStyle(context,
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
  static bodyText(BuildContext context, String text,
      {Color? color,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.bodyTextStyle(context,
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
  static bodySmallText(BuildContext context, String text,
      {Color? color,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.bodySmallTextStyle(context,
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
  static subTitleText(BuildContext context, String text,
      {Color? color,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.subTitleTextStyle(context,
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
  static titleMediumText(BuildContext context, String text,
      {Color? color,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.titleMediumTextStyle(context,
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
  static titleLargeText(BuildContext context, String text,
      {Color? color,
      FontWeight fontWeight = FontWeight.normal,
      bool center = false,
      bool overflow = false,
      int? maxLines,
      String fontFamily = "NunitoSans-Regular"}) {
    return Text(
      text,
      maxLines: maxLines,
      overflow: overflow ? TextOverflow.ellipsis : TextOverflow.visible,
      textAlign: !center ? TextAlign.left : TextAlign.center,
      style: AppTextStyles.titleLargeText(context,
          color: color, fontWeight: fontWeight, fontFamily: fontFamily),
    );
  }
}
