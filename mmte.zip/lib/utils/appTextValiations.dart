import 'package:mmte/res/app_strings.dart';

class AppTextValiations {
  static String printValidString(dynamic value) {
    if (value == null ||
        value.toString().toLowerCase() == "null" ||
        value.toString().toLowerCase() == "") {
      return AppStrings.na;
    } else {
      return value.toString();
    }
  }

  static String printValidStringWithEmpty(dynamic value) {
    if (value == null ||
        value.toString().toLowerCase() == "null" ||
        value.toString().toLowerCase() == "") {
      return "";
    } else {
      return value.toString();
    }
  }

  static bool checkApiValueValid(dynamic value) {
    if (value == null ||
        value.toString().toLowerCase() == "null" ||
        value.toString().toLowerCase() == "") {
      return true;
    } else {
      return false;
    }
  }

  static bool validValue(dynamic value) {
    if (value == null ||
        value.toString().toLowerCase() == "null" ||
        value.toString().toLowerCase() == "") {
      return false;
    } else {
      return true;
    }
  }

  static String showValidValue(dynamic value) {
    return validValue(value) ? value.toString() : "NA";
  }
}
