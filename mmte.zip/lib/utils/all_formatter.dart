import 'package:intl/intl.dart';

List<String> specialNumberFormat =
    //    0     1     2     3     4     5     6     7     8     9
    [
  "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th",
  //    10    11    12    13    14    15    16    17    18    19
  "th", "th", "th", "th", "th", "th", "th", "th", "th", "th",
  //    20    21    22    23    24    25    26    27    28    29
  "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th",
  //    30    31
  "th", "st"
];

List<int> totalDayInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

dateFormatForMonthAndDay(DateTime dateTime) {
  return dateTime.day.toString() +
      "" +
      specialNumberFormat[dateTime.day].toString() +
      " " +
      month[dateTime.month - 1].toString() +
      ", " +
      dateTime.year.toString();
}

final currencyFormat = NumberFormat.currency(locale: 'HI');
NumberFormat amountFormatter = NumberFormat.currency(locale: 'HI');
String convertAmountFormat(String amount) {
  try {
    return amountFormatter
        .format(double.parse(amount))
        .toString()
        .replaceAll("INR", "");
  } catch (e) {
    return amount.toString();
    //  return amountFormatter.format( 100000 ).toString();
  }
}

List<int> twentyFourFormat = [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 0];
NumberFormat numberFormatter = NumberFormat("00");
String splitText = "==+RB+==";
String rBAuthKey = "RBDWAh!Q1s74e";
String apiDefaultUserId = "PRB0329869";
final DateFormat formatter = DateFormat('dd-MM-yyyy');
final DateFormat formatter2 = DateFormat('yyyy-MM-dd');
final DateFormat formatterForSearchTodo = DateFormat('dd-MM-yyyy');
final DateFormat onlyTimeFormatter = DateFormat('kk:mm a');
final DateFormat fullTimeFormatter = DateFormat('h:mm:ss a');
final DateFormat onlyTimeFormatter12HRS =
    DateFormat('h:mm a'); //DateFormat.jm().format(DateTime.now())

String formatCurrency(dynamic amount) {
  return currencyFormat.format(amount).toString().split("INR").last.toString()
      // .split(".")
      // .first
      // .toString()
      ;
}

String timestamp() => DateTime.now().millisecondsSinceEpoch.toString();

List month = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
List weekDay = [
  " ",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];
String convertStringToDate({DateTime? datetime, String? dateString}) {
  DateTime date;
  if (dateString != null) {
    date = DateTime.parse(dateString);
  } else {
    date = datetime!;
  }
  return date.day.toString() +
      specialNumberFormat[date.day] +
      " " +
      month[date.month - 1].toString().substring(0, 3) +
      ", " +
      weekDay[date.weekday].toString().substring(0, 3) +
      " " +
      date.year.toString();
}
