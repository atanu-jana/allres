import 'package:flutter/material.dart';
import 'package:mmte/utils/routes/routes_name.dart';
import 'package:mmte/view/expense_view/expense_view.dart';
import 'package:mmte/view/splash_view/splash_view.dart';

class Routes {
  static MaterialPageRoute generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RoutesName.splash:
        return MaterialPageRoute(
            builder: (BuildContext context) => SplashView());
      case RoutesName.expense:
        return MaterialPageRoute(
            builder: (BuildContext context) => ExpenseView());

      default:
        return MaterialPageRoute(
            builder: (_) => const Scaffold(
                  body: Center(
                    child: Text("No route define"),
                  ),
                ));
    }
  }
}
