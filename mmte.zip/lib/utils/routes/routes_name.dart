class RoutesName{ 
  // splash route name
  static const String  splash='splash_screen';
  // expense route name
  static const String  expense='expense_screen';
}