import 'package:flutter/material.dart';
import 'package:mmte/main.dart';

class AppIcons {
  static normalIcon(IconData icon, {Color color = Colors.white}) {
    return Icon(
      icon,
      color: color,
      size: screenWidth * 0.045,
    );
  }

 static smallIcon(IconData icon, {Color color = Colors.white}) {
    return Icon(
      icon,
      color: color,
      size: screenWidth * 0.035,
    );
  }

 static largeIcon(IconData icon, {Color color = Colors.white}) {
    return Icon(
      icon,
      color: color,
      size: screenWidth * 0.1,
    );
  }

 static mediumIcon(IconData icon, {Color color = Colors.white}) {
    return Icon(
      icon,
      color: color,
      size: screenWidth * 0.06,
    );
  }
}
