import 'package:flutter/material.dart';
import 'package:mmte/main.dart';

class AppMarginPadding {
  static EdgeInsets customMarginNormal() {
    return EdgeInsets.only(left: screenWidth * 0.05, right: screenWidth * 0.05);
  }

  static EdgeInsets customMarginSame() {
    return EdgeInsets.symmetric(
        horizontal: screenWidth * 0.03, vertical: screenWidth * 0.03);
  }

  static EdgeInsets customMarginSameLarge() {
    return EdgeInsets.symmetric(
        horizontal: screenWidth * 0.05, vertical: screenWidth * 0.05);
  }

  static EdgeInsets customMarginSameCustomForTAC() {
    return EdgeInsets.symmetric(
        horizontal: screenWidth * 0.04, vertical: screenWidth * 0.04);
  }

  static EdgeInsets customMarginLarge() {
    return EdgeInsets.symmetric(
        horizontal: screenWidth * 0.05, vertical: screenWidth * 0.03);
  }

  static EdgeInsets customMarginSameSmall() {
    return EdgeInsets.symmetric(
        horizontal: screenWidth * 0.015, vertical: screenWidth * 0.015);
  }

  static EdgeInsets customHorizontal() {
    return EdgeInsets.symmetric(horizontal: screenWidth * 0.03);
  }

  static EdgeInsets customHorizontalLarge() {
    return EdgeInsets.symmetric(horizontal: screenWidth * 0.04);
  }

  static EdgeInsets customRight() {
    return EdgeInsets.only(right: screenWidth * 0.03);
  }

  static EdgeInsets customRightSmall() {
    return EdgeInsets.only(right: screenWidth * 0.015);
  }

  static EdgeInsets customHorizontalSmall() {
    return EdgeInsets.symmetric(horizontal: screenWidth * 0.01);
  }

  static EdgeInsets customLeft() {
    return EdgeInsets.symmetric(horizontal: screenWidth * 0.015);
  }

  static EdgeInsets customLeftLarge() {
    return EdgeInsets.symmetric(horizontal: screenWidth * 0.03);
  }

  static EdgeInsets customVertical() {
    return EdgeInsets.symmetric(vertical: screenWidth * 0.015);
  }

  static EdgeInsets customVerticalLarge() {
    return EdgeInsets.symmetric(vertical: screenWidth * 0.03);
  }

  static EdgeInsets customVerticalSmallLarge() {
    return EdgeInsets.symmetric(vertical: screenWidth * 0.02);
  }

  static EdgeInsets customVerticalSmall() {
    return EdgeInsets.symmetric(vertical: screenWidth * 0.01);
  }

  static EdgeInsets customVerticalExtraSmall() {
    return EdgeInsets.symmetric(vertical: screenWidth * 0.005);
  }

  static EdgeInsets customBottom() {
    return EdgeInsets.only(bottom: screenWidth * 0.03);
  }

  static EdgeInsets customBottomSmall() {
    return EdgeInsets.only(bottom: screenWidth * 0.015);
  }

  static EdgeInsets customTop() {
    return EdgeInsets.only(top: screenWidth * 0.03);
  }

  static EdgeInsets customTopSmall() {
    return EdgeInsets.only(top: screenWidth * 0.015);
  }

  static EdgeInsets customSmallBottom() {
    return EdgeInsets.only(bottom: screenWidth * 0.015);
  }
}
