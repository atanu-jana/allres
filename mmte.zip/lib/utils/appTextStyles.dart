import 'package:flutter/material.dart';
import 'package:mmte/main.dart';

class AppTextStyles {
  static headlineMediumTextStyle(BuildContext context,
      {Color? color,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return Theme.of(context).textTheme.headlineMedium?.copyWith(
        color: color, fontFamily: fontFamily, fontWeight: fontWeight);
  }
  static bodyTextStyle(BuildContext context,
      {Color? color,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return Theme.of(context).textTheme.headlineMedium?.copyWith(
        color: color, fontFamily: fontFamily, fontWeight: fontWeight);
  }
  static bodySmallTextStyle(BuildContext context,
      {Color? color,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return Theme.of(context).textTheme.headlineMedium?.copyWith(
        color: color, fontFamily: fontFamily, fontWeight: fontWeight);
  }
  static subTitleTextStyle(BuildContext context,
      {Color? color,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return Theme.of(context).textTheme.headlineMedium?.copyWith(
        color: color, fontFamily: fontFamily, fontWeight: fontWeight);
  }
  static titleMediumTextStyle(BuildContext context,
      {Color? color,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return Theme.of(context).textTheme.headlineMedium?.copyWith(
        color: color, fontFamily: fontFamily, fontWeight: fontWeight);
  }
  static titleLargeText(BuildContext context,
      {Color? color,
      FontStyle fontStyle = FontStyle.normal,
      FontWeight fontWeight = FontWeight.normal,
      String fontFamily = "NunitoSans-Regular"}) {
    return Theme.of(context).textTheme.headlineMedium?.copyWith(
        color: color, fontFamily: fontFamily, fontWeight: fontWeight);
  }
}
