import 'package:another_flushbar/flushbar.dart';
import 'package:another_flushbar/flushbar_route.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mmte/res/app_colors.dart';
import 'package:mmte/utils/appTexts.dart';
import 'dart:developer' as developer;
import 'package:permission_handler/permission_handler.dart';
class Utils {  

static Future<bool> requestPermission2(
    Permission permission) async {
  if (await permission.status.isGranted) {
    return true;
  } else {
    // if (await permissionAlert(context, permission)) {
    if (await permission.isGranted) {
      return true;
    } else {
      var result = await permission.request();
      if (result == PermissionStatus.granted) {
        return true;
      }
    }
    return false;
    // }
    // return false;
  }
}
  static consoleLog({required String key, required dynamic value}) {
    if (kDebugMode) {
      developer.log('LOG KEY: $key\nLOG VALUE: $value');
    }
  }

  static showOnlineSnakbar(BuildContext context) {
    ScaffoldMessenger.of(context).clearSnackBars();

    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.redColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
          topLeft: Radius.circular(5),
          topRight: Radius.circular(5),
        )),
        content: AppTexts.bodySmallText(context,"Back To Internet"),
        duration: Duration(seconds: 1),
      ),
    );
  }

  static toastMessage(String message) {
    Fluttertoast.showToast(
        msg: message, backgroundColor: Colors.black, textColor: Colors.white);
  }

  static void flusshBarErrorMsage(String message, BuildContext context) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          forwardAnimationCurve: Curves.decelerate,
          margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: EdgeInsets.all(15),
          message: message,
          borderRadius: BorderRadius.circular(20),
          duration: Duration(seconds: 3),
          flushbarPosition: FlushbarPosition.TOP,
          backgroundColor: Colors.red,
          reverseAnimationCurve: Curves.easeInOut,
          icon: Icon(Icons.error, size: 20, color: Colors.white),
        )..show(context));
  }

  static snackBar(String message, BuildContext context) {
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: Colors.red, content: Text(message)));
  }

  static void fieldFocusChange(BuildContext context, FocusNode currentFocusNode,
      FocusNode nextFocusNode) {
    currentFocusNode.unfocus();
    FocusScope.of(context).requestFocus(nextFocusNode);
  }
}
