import 'dart:convert';
import 'dart:io';
import 'package:mmte/data/network/baseApiServices.dart';
import 'package:mmte/utils/utils.dart';

class NetworkApiService extends BaseApiServices {
  @override
  Future getGetApiResponse({required String url}) async {
  }

  @override
  Future getPostApiResponse({required String url, required Map body}) async {
    
  }
 
}
