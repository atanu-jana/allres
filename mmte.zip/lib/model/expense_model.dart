class ExpenseModel {
  int? id;
  String? amount;
  String? dateForSearch;
  String? type;
  String? comment;
  String? highLight;
  String? timeStamp;

  ExpenseModel(
      {this.id,
      this.amount,
      this.dateForSearch,
      this.type,
      this.comment,
      this.highLight,
      this.timeStamp});

  ExpenseModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    amount = json['amount'];
    dateForSearch = json['dateForSearch'];
    type = json['type'];
    comment = json['comment'];
    highLight = json['highLight'];
    timeStamp = json['timeStamp'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['amount'] = this.amount;
    data['dateForSearch'] = this.dateForSearch;
    data['type'] = this.type;
    data['comment'] = this.comment;
    data['highLight'] = this.highLight;
    data['timeStamp'] = this.timeStamp;
    return data;
  }
}