class AppSharedPreferencesKeys {
  static String darkTheme="darkTheme";
  static String salary="salary";
  static String salaryDate="salaryDate";
  static String dayStartHr="dayStartHr";
  static String dayEndHr="dayEndHr";
  static String dayStartMin="dayStartMin";
  static String dayEndMin="dayEndMin";
  static String primaryColor="primaryColor";
  static String gradint1="gradint1";
  static String gradint2="gradint2";
  static String gradint3="gradint3";
  static String fontFamily="fontFamily";
  static String dayStartNotificationId="dayStartNotificationId";
  static String dayEndNotificationId="dayEndNotificationId";
  static String automaticallyLockTime="automaticallyLockTime";
  static String fingerprintUnlockTime="fingerprintUnlockTime";
}
