class AppImages {
  static String logo = "assets/images/icon.png"; 
  static String noDataFound = "assets/images/noDataFound.png"; 
  static String log = "assets/icons/log.png"; 
  static String todo = "assets/icons/todo.png"; 
  static String note = "assets/icons/note.png"; 

}
