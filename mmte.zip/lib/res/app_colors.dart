import 'package:flutter/material.dart';

class AppColors {
  static Color whiteColor = Color(0xffffffff);
  static Color lightYellowColor = Color(0xFFFFEE50);
  static Color yellowColor = Color(0xFFD3BE06);
  static Color lightBlackColor = Color(0xfff2f2f4);
  static Color lightWhiteColor = Color(0xFF5C5C5C);
  static Color greenColor = Color(0xFF1faa00);
  static Color indigoColor = Colors.indigo;
  static Color blueGreyColor = Colors.blueGrey;
  static Color blueColor = Color(0xff0288d1);
  static Color lightBlueGreyColor = Color(0xffeceff1);
  static Color redColor = Color(0xFFFF0000);
  static Color orangeColor = Color(0xFFff5722);
  static Color pinkColor = Color(0xFFa00037);
  static Color amberColor = Color(0xFFac1900);
  static Color purpleColor = Color(0xFF38006b);
  static Color blackColor = Color(0xFF000000);
  static Color deepGreenColor = Color(0xFF009624);
  static Color lightGreyColor = Color(0xFFe0e0e0);
  static Color transparentColor = Colors.transparent;
  static Color greyColor = Colors.grey;
  static Color primaryColor = Color(0xff2196f3);
}
