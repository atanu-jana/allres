package com.example.hr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
