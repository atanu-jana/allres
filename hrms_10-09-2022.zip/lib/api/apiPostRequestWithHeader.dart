import 'dart:convert';
import 'dart:developer';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:http/http.dart' as http;

apiPostRequestWithHeader(
    Map data, String url, BuildContext context, String token) async {
  // if (await internetCheck()) {
    String body = json.encode(data);

    log(url);
    log(body);
    log(token);

    try {
      var headers = {
        '': '',
        'Authorization': 'Bearer ${sharedPreferences!.getString(AllSharedPreferencesKey.token)!}',
        // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhYmFzZU5hbWUiOiJocm1zX3NtYXJ0Y2FyZSIsImhvc3ROYW1lIjoiZWFzZXVyYml6LmM4c3E3dzJiMTZ3Zy5hcC1zb3V0aC0xLnJkcy5hbWF6b25hd3MuY29tIiwiZGF0YWJhc2VVc2VyTmFtZSI6ImFkbWluIiwiZGF0YWJhc2VQYXNzd29yZCI6IiFuZnlNYXgyMDIxIiwiaWF0IjoxNjM5OTgyOTM0LCJleHAiOjE2Mzk5ODI5NjR9.QCS3C5x9Ej98Y6HKARUUsGLhAAmLT7TaNSwYOTXp7Cs',
        'Content-Type': 'application/json'
      };
      var request = http.Request(
        'POST',
        Uri.parse(url),
      );
      request.body = json.encode(data);
      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      var jsonData = await response.stream.bytesToString();
    log(url);
    log(body);

      log(jsonData.toString());
      return jsonData;
    } catch (e) {
      // commonAlertDialog(
      //     context, AllString.warning, AllString.somethingWentWrong);
    }
  // } else {
  //   showOfflineSnakbar(context);
  // }
}
