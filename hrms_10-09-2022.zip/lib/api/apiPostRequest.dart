import 'dart:convert';
import 'dart:developer';
import 'package:hr/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:http/http.dart' as http;

apiPostRequest(Map data, String url, BuildContext context) async {
  // if (await internetCheck()) {
    String body = json.encode(data);
    log(url);
    log(body);
    try {
      http.Response response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: body,
      );
      log(response.body.toString());
      return response.body;
    } catch (e) {
      AppBuilder.of(context)!.rebuild();
      // commonAlertDialog(context, AllString.warning, AllString.somethingWentWrong);
    }
  // } else {
  //   showOfflineSnakbar(context);
  // }
}
