import 'package:flutter/material.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:http/http.dart' as http;

apiGetRequest(BuildContext context, String url) async {
  // if (await internetCheck()) {
    try {
      http.Response response = await http.get(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
      );
      return response;
    } catch (e) {}
  // } else {
  //   showOfflineSnakbar(context);
  // }
}
