import 'dart:convert';
import 'package:path/path.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:http/http.dart' as http;

// commonApiPostRequestWithHeaderForFile(
//     String path, String url, BuildContext context, String token) async {
//   // if (await internetCheck()) {
//   log(path);
//   log(url);
//   log(token);

//   try {
//     var headers = {
//         'Authorization': 'Bearer ${sharedPreferences!.getString(AllSharedPreferencesKey.token)!}',

//       // 'Authorization':
//       //     'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhYmFzZU5hbWUiOiJocm1zX3NtYXJ0Y2FyZSIsImhvc3ROYW1lIjoiZWFzZXVyYml6LmM4c3E3dzJiMTZ3Zy5hcC1zb3V0aC0xLnJkcy5hbWF6b25hd3MuY29tIiwiZGF0YWJhc2VVc2VyTmFtZSI6ImFkbWluIiwiZGF0YWJhc2VQYXNzd29yZCI6IiFuZnlNYXgyMDIxIiwiaWF0IjoxNjM5OTgyOTM0LCJleHAiOjE2Mzk5ODI5NjR9.QCS3C5x9Ej98Y6HKARUUsGLhAAmLT7TaNSwYOTXp7Cs',

//       // 'Authorization': 'Bearer $token',
//       'Content-Type': 'application/json'
//     };
//     var request = http.MultipartRequest(
//       'POST',
//       Uri.parse(url),
//     );
//     request.fields.addAll({
//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!
//     });
//     request.files
//         .add(await http.MultipartFile.fromPath('imageParameter', path));

//     request.headers.addAll(headers);

//     http.StreamedResponse response = await request.send();

//     log(url + "\n" + response.toString());
//     if (response.statusCode == 200) {
//       var jsonData = await response.stream.bytesToString();
//       log(jsonData.toString());
//       return jsonData;
//     } else {
//       commonAlertDialog(context, AllString.warning, response.reasonPhrase);
//     }
//   } catch (e) {
//     // commonAlertDialog(
//     //     context, AllString.warning, AllString.somethingWentWrong);
//   }
//   // } else {
//   //   showOfflineSnakbar(context);
//   // }
// }
commonApiPostRequestWithHeaderForFile(
    String path,
    String url,
    BuildContext context,
    String token,
    String nameParam,
    String fileName) async {
  // if (await internetCheck()) {
  log(path);
  log(url);
  log(token);

  try {
    var headers = {
      'Authorization':
          'Bearer ${sharedPreferences!.getString(AllSharedPreferencesKey.token)!}',

      // 'Authorization':
      //     'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhYmFzZU5hbWUiOiJocm1zX3NtYXJ0Y2FyZSIsImhvc3ROYW1lIjoiZWFzZXVyYml6LmM4c3E3dzJiMTZ3Zy5hcC1zb3V0aC0xLnJkcy5hbWF6b25hd3MuY29tIiwiZGF0YWJhc2VVc2VyTmFtZSI6ImFkbWluIiwiZGF0YWJhc2VQYXNzd29yZCI6IiFuZnlNYXgyMDIxIiwiaWF0IjoxNjM5OTgyOTM0LCJleHAiOjE2Mzk5ODI5NjR9.QCS3C5x9Ej98Y6HKARUUsGLhAAmLT7TaNSwYOTXp7Cs',

      // 'Authorization': 'Bearer $token',
      'Content-Type': 'application/json'
    };
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(url),
    );
    request.fields.addAll({
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId)!,
      "imageName": fileName
    });
    request.files.add(await http.MultipartFile.fromPath(nameParam, path));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
log(request.fields.toString());
    log(url + "\n" + response.toString());
    if (response.statusCode == 200) {
      var jsonData = await response.stream.bytesToString();
      log(jsonData.toString());
      return jsonData;
    } else {
      commonAlertDialog(context, AllString.warning, response.reasonPhrase);
    }
  } catch (e) {
    // commonAlertDialog(
    //     context, AllString.warning, AllString.somethingWentWrong);
  }
  // } else {
  //   showOfflineSnakbar(context);
  // }
}

Future<String> imageToUrlApi(String path, BuildContext context) async =>
    await commonApiPostRequestWithHeaderForFile(path, AllUrls.uploadVideo,
            context, loginToken, 'videoFile', basename(path))
        .then((response) {
      if (response == null) {
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure,
            function: () {
          Navigator.pop(context);
        });
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          return jsonData["imageData"]["videoName"];
        } else {
          commonAlertDialog(context, jsonData["status"], jsonData["message"],
              function: () {
            Navigator.pop(context);
          });
        }
      }
    });
Future<String> imageToUrlApiImage(String path, BuildContext context) async =>
    await commonApiPostRequestWithHeaderForFile(
            path,
            AllUrls.uploadEmployeeVisitImage,
            context,
            loginToken,
            "imageParameter",
            basename(path))
        .then((response) {
      if (response == null) {
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure,
            function: () {
          Navigator.pop(context);
        });
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          return jsonData["imageUrl"]["imageName"];
        } else {
          commonAlertDialog(context, jsonData["status"], jsonData["message"],
              function: () {
            Navigator.pop(context);
          });
        }
      }
    });
