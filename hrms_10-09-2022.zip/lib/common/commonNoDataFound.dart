import 'package:flutter/material.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/customMarginCardItem.dart';

commonNoDataFound({Color? color}) {
  return Center(
    child: Container(
      margin: customMarginCardItem(),
      child: Text(
        AllString.noDataFound,
        style: TextStyle(color:color?? AllColor.black),
      ),
    ),
  );
}
