
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/widget/alertButton.dart';
import 'package:hr/widget/button.dart';

commonAlertDialogForBackPressToClose(BuildContext context) {
  return showDialog(
      barrierDismissible: true,
      context: context,
      builder: (context) => WillPopScope(
            onWillPop: () async => true,
            child: SimpleDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0)),
                elevation: 0.0,
                backgroundColor: AllColor.white,
                // title: Container(
                //     width: screenWidth,
                //     alignment: Alignment.center,
                //     child: Container(
                //       child: normalText("HRMS",
                //           color: AllColor.greyColor),
                //     )),
                children: [
                  SizedBox(
                    height: screenWidth * 0.02,
                  ),
                  Container(
                      width: screenWidth * 0.1,
                      height: screenWidth * 0.1,
                      alignment: Alignment.center,
                      // child: largeIcon(Icons.exit_to_app, color: AllColor.red)),
                      child: Image.asset("assets/images/appLogo.png")),
                  SizedBox(
                    height: screenWidth * 0.02,
                  ),
                  Container(
                      width: screenWidth,
                      alignment: Alignment.center,
                      child: Text("Are you sure you want to close this App?",
                          textAlign: TextAlign.center,
                          style: headingTextStyle(color: AllColor.black))),
                  SizedBox(
                    height: screenWidth * 0.02,
                  ),
                    Container(
                    alignment: Alignment.center,
                    width: screenWidth,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Center(
                          child: Container(
                            child: alertButton(context,
                                color: AllColor.primaryColor,
                                text: AllString.no, function: () {
                              Navigator.pop(context);
                            }),
                          ),
                        ),
                        Center(
                          child: Container(

                            child: alertButton(context,
                                color: AllColor.primaryColor,
                                text: AllString.yes, function: () {
                              SystemNavigator.pop();
                            }),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: screenWidth * 0.03,
                  ),
                ]),
          ));
}
