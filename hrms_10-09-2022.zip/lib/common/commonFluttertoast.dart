//*****************
//
// custom toast message for whole application
//
//*****************
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';

commonFluttertoast({required String msg}) {
  return Fluttertoast.showToast(
      msg: msg,
      backgroundColor: AllColor.primaryColor,
      textColor: AllColor.white,
      fontSize: screenWidth * 0.025);
}
