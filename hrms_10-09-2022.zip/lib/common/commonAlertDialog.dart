import 'package:hr/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/widget/alertButton.dart';

commonAlertDialog(BuildContext context, String title, message,
    {Function()? function, String? alertMsg}) {
  return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) => WillPopScope(
            onWillPop: () async => false,
            child: SimpleDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0)),
                elevation: 0.0,
                backgroundColor: AllColor.white,
                title: Container(
                  color: AllColor.white,
                  margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.02,
                    horizontal: screenWidth * 0.02,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    title,
                    textAlign: TextAlign.center,
                    style: headingTextStyle(
                        fontWeight: FontWeight.bold,
                        color: title.toLowerCase() == "error" ||
                                title.toLowerCase() == "failure"
                            ? AllColor.red
                            : title == AllString.warning
                                ? AllColor.yellow
                                : AllColor.green),
                  ),
                ),
                children: [
                  Container(
                    width: screenWidth,
                    alignment: Alignment.center,
                    padding:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
                    child: Text(
                      message,
                      textAlign: TextAlign.center,
                      style: headingTextStyle(
                          color: AllColor.black.withOpacity(0.7)),
                    ),
                  ),
                  SizedBox(
                    height: screenWidth * 0.03,
                  ),
                  alertMsg == null
                      ? Container()
                      : Container(
                          width: screenWidth,
                          alignment: Alignment.center,
                          padding: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.02),
                          child: Text(
                            "* Note: " + alertMsg,
                            textAlign: TextAlign.center,
                            style: headingTextStyle(
                                fontWeight: FontWeight.bold,
                                color: AllColor.deepYellow),
                          ),
                        ),
                  alertMsg == null
                      ? Container()
                      : SizedBox(
                          height: screenWidth * 0.03,
                        ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: alertButton(context,
                            color: AllColor.primaryColor,
                            text: AllString.ok,
                            textColor: AllColor.white,
                            function: function == null
                                ? () {
                                    Navigator.pop(context);
                                  }
                                : function),
                      ),
                    ],
                  )
                ]),
          ));
}
