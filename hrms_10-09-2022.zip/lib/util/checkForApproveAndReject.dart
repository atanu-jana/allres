import 'dart:developer';

import 'package:hr/main.dart';
import 'package:hr/res/allSharePreferencesKey.dart';

// 16 == HR
// 17 == TM

///////////////////////////////////////////

// "0"=="Pending By Team Manager"
// "1"== "Rejected By Team Manager"
// "2"=="Approved By Team Manager"
// "3"=="Rejected By HR"
// "4"=="Approved By HR"

///////////////////////////////////////////

// 0==Tm->Only
// 0>Hm->Only HR
// 1->No One

bool checkForApproveAndReject(String status) {
  
  if ((sharedPreferences!
              .getString(AllSharedPreferencesKey.individualTypeId)
              .toString() ==
          "17") ||
      (sharedPreferences!
              .getString(AllSharedPreferencesKey.individualTypeId)
              .toString() ==
          "16")) {
    if (status == "1") {
      return false;
    } else if (status == "3" ||status == "4") {
      return false;
    } else if (status == "0" &&
        (sharedPreferences!
                .getString(AllSharedPreferencesKey.individualTypeId)
                .toString() ==
            "17")) {
      return true;
    } else if (int.parse(status) > 0 &&
        (sharedPreferences!
                .getString(AllSharedPreferencesKey.individualTypeId)
                .toString() ==
            "16")) {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}


bool checkForApproveAndReject2(String status) {
  // log(sharedPreferences!
  //     .getString(AllSharedPreferencesKey.individualTypeId)
  //     .toString());
  // log(status);
  if(status=="null"|| status.isEmpty){
      return false;

  }else{

  if (
      (sharedPreferences!
              .getString(AllSharedPreferencesKey.individualTypeId)
              .toString() ==
          "16")) {
    if (status == "1" ||status == "2") {
      return false;
    }else if (status == "0" &&
        (sharedPreferences!
                .getString(AllSharedPreferencesKey.individualTypeId)
                .toString() ==
            "16")) {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
  }
}
