import 'dart:developer';

bool checkApiResponseSuccessOrNot(Map<String, dynamic> jsonData) {
  if (jsonData["status"].toString().toLowerCase() == "success") {
    return true;
  } else {
    return false;
  }
}

bool checkApiResponseForArray(Map<String, dynamic> jsonData, String dataName) {
  if (jsonData[dataName].toString().toLowerCase() == "[]" ||
      jsonData[dataName].isEmpty ||
      jsonData[dataName].toString()  == "") {
    return false;
  } else {
    return true;
  }
}
