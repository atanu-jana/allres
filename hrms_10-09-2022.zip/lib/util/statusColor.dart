import 'package:flutter/material.dart';
import 'package:hr/res/allColors.dart';

Color statusColor(dynamic value) {
  if (value == null ||
      value.toString().toLowerCase() == "null" ||
      value.toString().toLowerCase() == "") {
    return AllColor.greyColor;
  } else if (value.toString().toLowerCase() == "success") {
    return AllColor.green;
  } else if (value.toString().toLowerCase() == "failure") {
    return AllColor.red;
  } else if (value.toString().toLowerCase() == "continue") {
    return AllColor.blue;
  } else if (value.toString().toLowerCase() == "pending") {
    return AllColor.yellow;
  }else{
    return AllColor.black;
  }
}
