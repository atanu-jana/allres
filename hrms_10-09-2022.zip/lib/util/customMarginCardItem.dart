import 'package:flutter/material.dart';
import 'package:hr/main.dart';

customMarginCardItem() {
  return EdgeInsets.symmetric(
      horizontal: screenWidth * 0.03, vertical: screenWidth * 0.015);
}

customHorizontal() {
  return EdgeInsets.symmetric(
      horizontal: screenWidth * 0.03);
}
customVertical() {
  return EdgeInsets.symmetric(
      vertical: screenWidth * 0.015);
}
