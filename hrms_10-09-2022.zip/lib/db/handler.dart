// import 'dart:io';
// import 'package:path/path.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';

// class Databasehelper {
//   static Database? _database;
//   Databasehelper._privateConstructor();
//   static final Databasehelper instance = Databasehelper._privateConstructor();
//   Future<Database> get databse async {
//     if (_database != null) return _database!;
//     _database = await _initDatabase();
//     return _database!;
//   }

//   static final _databasename = "HRMS.db";
//   static final _databaseversion = 1;

// // *** Tables
//   static final checkInTable = "CheckIn";
//   static final trackingLocationTable = "trackingLocation";
//   static final dayStartDayEndTable = "dayStartDayEnd";
//   static final breakStartBreakEndTable = "breakStartBreakEnd";
//   static final checkOutTable = "CheckOut";
//   static final orderProductTable = "CheckOutOrders";
//   static final paymentTable = "payment";
//   static final orderListTable = "orderList";
//   static final orderTable = "orderTable";
//   static final expenseTable = "expense";
//   static final checkOutImageTable = "checkOutImage";
//   static final expenseImageTable = "expenseImage";
//   static final paymentImageTable = "paymentImage";
// // *** Day Start Tables
//   static final id = "id";
//   static final attendanceId = "attendanceId";
//   static final checkInLocation = "checkInLocation";
//   static final checkInLatitude = "checkInLatitude";
//   static final inTime = "inTime";
//   static final checkInLongitude = "checkInLongitude";
//   static final checkOutLocation = "checkOutLocation";
//   static final outTime = "outTime";
//   static final checkOutLongitude = "checkOutLongitude";
//   static final checkOutLatitude = "checkOutLatitude";
// // *** Break Start Tables
//   static final breakPunchId = "breakPunchId";
//   static final breakStartTime = "breakStartTime";
//   static final breakEndTime = "breakEndTime";
// //attendanceId
// // *** Tracking Location Tables
//   static final distance = "distance";
//   // *** Check In Table column names
//   static final checkInId = 'id';
//   static final officeName = 'officeName';
//   static final officeType = "officeType";
//   static final dealerId = "dealerId";
//   static final companyId = "companyId";
//   static final individualId = "individualId";
//   static final userId = "userId";
//   static final visitType = "visitType";
//   static final location = "location";
//   static final checkInTime = "checkInTime";
//   static final latitude = "latitude";
//   static final longitude = "longitude";

//   // *** Check Out Orders Table column names
//   static final orderProductId = 'id';
//   static final checkOutIdId = 'checkOutId';
//   static final productCategoryId = 'productCategoryId';
//   static final productId = 'productId';
//   static final brandId = 'brandId';
//   static final quantity = "quantity";

//   // *** Check OUT Table column names
//   static final checkOutId = 'id';
//   static final checkOutDealerId = 'dealerId';
//   static final checkOutCheckInId = "checkInId";
//   static final ordersId = "ordersId";
//   static final visitTypeName = "visitTypeName";
//   static final checkOutTime = "checkOutTime";
//   static final paymentAmount = "paymentAmount";
//   static final paymentRemark = "paymentRemark";
//   static final conveyanceAmount = "conveyanceAmount";
//   static final conveyanceRemark = "conveyanceRemark";

// // *** Checkout images
// //id
// //checkOutId
//   static final checkOutAttatchmentImageFile1 = "checkOutAttatchmentImageFile1";
//   static final checkOutAttatchmentImageFile2 = "checkOutAttatchmentImageFile2";
//   static final checkOutPaymentImage = "checkOutPaymentImage";

// // *** payment images
// //id
// //paymentId
//   static final paymentPaymentImage = "paymentPaymentImage";
// // *** expense images
// //id
// //expenseId
//   static final expenseAttchment1 = "expenseAttchment1";
//   static final expenseAttchment2 = "expenseAttchment2";

//   // *** payment Table column names
//   static final paymentId = 'id';
//   static final paymentUserLoginId = 'userLoginId';
//   static final paymentDealerId = "dealerId";
//   static final paymentPayAmount = "amount";
//   static final paymentComment = "comment";
//   static final paymentVisitTypeName = "visitTypeName";
//   static final paymentIndividualId = "individualId";
//   static final paymentCompanyId = "companyId";

//   // *** orderList Table column names
//   static final orderListId = 'id';
//   static final orderTableId = 'orderTableId';
//   static final orderListProductCategoryId = 'productCategoryId';
//   static final orderListProductId = 'productId';
//   static final orderListBrandId = "brandId";
//   static final orderListQuantity = "quantity";

//   // *** order Table column names
//   static final orderId = 'id';
//   static final orderOrderListId = 'orderListid';
//   static final orderUserId = 'userId';
//   static final orderDealerId = 'dealerId';
//   static final orderRemarks = "remarks";
//   static final orderVisitTypeName = "visitTypeName";
//   static final orderIndividualId = "individualId";
//   static final orderCompanyId = "companyId";
//   static final orderVisitType = "visitType";
//   static final orderUserLoginId = "userLoginId";

// // *** expense Table column names
//   static final expenseId = 'id';
//   static final expenseUserLoginId = 'userLoginId';
//   static final expenseIndividualId = 'individualId';
//   static final expenseCompanyId = "companyId";
//   static final expenseExpenceTypeId = "expenceTypeId";
//   static final expenseVisitId = "visitId";
//   static final expenseAmount = "amount";
//   static final expenseComment = "comment";
//   static final expenseUserId = "userId";

//   // *** function to return a database for rate chart
//   _initDatabase() async {
//     Directory documentdirecoty = await getApplicationDocumentsDirectory();
//     String path = join(documentdirecoty.path, _databasename);
//     return await openDatabase(path,
//         version: _databaseversion, onCreate: _onCreate);
//   }

//   // *** create a database since it doesn't exist
//   Future _onCreate(Database db, int version) async {
//     await db.execute('''
//       CREATE TABLE $orderProductTable (
//         $orderProductId INTEGER PRIMARY KEY,
//         $productCategoryId TEXT NOT NULL,
//         $checkOutIdId TEXT NOT NULL,
//         $productId TEXT NOT NULL,
//         $brandId TEXT NOT NULL,
//         $quantity TEXT NOT NULL
//       );
//       ''');

//     await db.execute('''
//       CREATE TABLE $breakStartBreakEndTable (
//         $id INTEGER PRIMARY KEY,
//         $breakPunchId TEXT NOT NULL,
//         $attendanceId TEXT NOT NULL
//       );
//       ''');
//     await db.execute('''
//       CREATE TABLE $checkOutImageTable (
//         $id INTEGER PRIMARY KEY,
//         $checkOutId INTEGER NOT NULL,
//         $checkOutAttatchmentImageFile1 TEXT NOT NULL,
//         $checkOutAttatchmentImageFile2 TEXT NOT NULL,
//         $checkOutPaymentImage TEXT NOT NULL
//       );
//       ''');
//     await db.execute('''
//       CREATE TABLE $paymentImageTable (
//         $id INTEGER PRIMARY KEY,
//         $paymentId INTEGER NOT NULL,
//         $paymentPaymentImage TEXT NOT NULL
//       );
//       ''');
//     await db.execute('''
//       CREATE TABLE $expenseImageTable (
//         $id INTEGER PRIMARY KEY,
//         $expenseId INTEGER NOT NULL,
//         $expenseAttchment1 TEXT NOT NULL,
//         $expenseAttchment2 TEXT NOT NULL
//       );
//       ''');
//     await db.execute('''
//       CREATE TABLE $trackingLocationTable (
//         $id INTEGER PRIMARY KEY,
//         $location TEXT NOT NULL,
//         $latitude TEXT NOT NULL,
//         $distance TEXT NOT NULL,
//         $longitude TEXT NOT NULL
//       );
//       ''');

//     await db.execute('''
//       CREATE TABLE $dayStartDayEndTable (
//         $id INTEGER PRIMARY KEY,
//         $attendanceId TEXT NOT NULL,
//         $checkInLocation TEXT NOT NULL,
//         $checkInLatitude TEXT NOT NULL,
//         $checkInLongitude TEXT NOT NULL,
//         $inTime TEXT NOT NULL,
//         $checkOutLocation TEXT NOT NULL,
//         $outTime TEXT NOT NULL,
//         $checkOutLongitude TEXT NOT NULL,
//         $checkOutLatitude TEXT NOT NULL
//       );
//       ''');
//     await db.execute(''' 
//       CREATE TABLE $checkInTable (
//         $checkInId INTEGER PRIMARY KEY,
//         $officeName TEXT NOT NULL,
//         $officeType TEXT NOT NULL,
//         $dealerId TEXT NOT NULL,
//         $companyId TEXT NOT NULL,
//         $visitTypeName TEXT NOT NULL,
//         $individualId TEXT NOT NULL,
//         $userId TEXT NOT NULL,
//         $visitType TEXT NOT NULL,
//         $checkInTime TEXT NOT NULL,
//         $location TEXT NOT NULL,
//         $latitude TEXT NOT NULL,
//         $longitude TEXT NOT NULL
//       );
//       ''');
//     await db.execute('''
//       CREATE TABLE $checkOutTable (
//         $checkOutId INTEGER PRIMARY KEY,
//         $checkOutDealerId TEXT NOT NULL,
//         $checkOutCheckInId TEXT NOT NULL, 
//         $ordersId TEXT NOT NULL,
//         $latitude TEXT NOT NULL,
//         $longitude TEXT NOT NULL,
//         $location TEXT NOT NULL,
//         $officeName TEXT NOT NULL,
//         $companyId TEXT NOT NULL,
//         $conveyanceAmount TEXT NOT NULL,
//         $conveyanceRemark TEXT NOT NULL, 
//         $paymentRemark TEXT NOT NULL,
//         $paymentAmount TEXT NOT NULL,
//         $visitType TEXT NOT NULL,
//         $visitTypeName TEXT NOT NULL,
//         $individualId TEXT NOT NULL,
//         $checkOutTime TEXT NOT NULL 
//       );
//       ''');

//     await db.execute('''
//       CREATE TABLE $expenseTable (
//         $expenseId INTEGER PRIMARY KEY,
//         $expenseUserLoginId TEXT NOT NULL,
//         $expenseIndividualId TEXT NOT NULL,
//         $expenseCompanyId TEXT NOT NULL,
//         $expenseExpenceTypeId TEXT NOT NULL,
//         $expenseVisitId TEXT NOT NULL,
//         $expenseAmount TEXT NOT NULL,
//         $expenseComment TEXT NOT NULL,
//         $expenseUserId TEXT NOT NULL,
//         $expenseAttchment1 TEXT NOT NULL,
//         $expenseAttchment2 TEXT NOT NULL
//       );
//       ''');

//     await db.execute('''
//       CREATE TABLE $orderListTable (
//         $orderListId INTEGER PRIMARY KEY,
//         $orderListProductCategoryId TEXT NOT NULL,
//         $orderListProductId TEXT NOT NULL,
//         $orderListBrandId TEXT NOT NULL,
//         $orderListQuantity TEXT NOT NULL
//       );
//       ''');

//     await db.execute('''
//       CREATE TABLE $orderTable (
//         $orderId INTEGER PRIMARY KEY,
//         $orderDealerId TEXT NOT NULL,
//         $orderRemarks TEXT NOT NULL,
//         $orderVisitTypeName TEXT NOT NULL,
//         $orderIndividualId TEXT NOT NULL,
//         $orderCompanyId TEXT NOT NULL,
//         $orderVisitType TEXT NOT NULL,
//         $orderUserLoginId TEXT NOT NULL
//      );
//       ''');

//     await db.execute('''
//       CREATE TABLE $paymentTable (
//         $paymentId INTEGER PRIMARY KEY, 
//         $paymentUserLoginId TEXT NOT NULL,
//         $paymentDealerId TEXT NOT NULL,
//         $paymentPayAmount TEXT NOT NULL,
//         $paymentComment TEXT NOT NULL,
//         $paymentVisitTypeName TEXT NOT NULL,
//         $paymentIndividualId TEXT NOT NULL,
//         $paymentCompanyId TEXT NOT NULL
//       );
//       ''');
//   }

 
// // ! *** Add Expense Image ------------------------

//   // *** functions to insert data in orderList Table
//   Future<int> insertExpenseImage(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(expenseImageTable, row);
//   }

//   // *** function to query all the rows in orderList Table
//   Future<List<Map<String, dynamic>>> fetchAllExpenseImage() async {
//     Database db = await instance.databse;
//     return await db.query(expenseImageTable);
//   }

//   // *** function to delete some data in paymorderListent Table
//   Future<int> deleteExpenseImage(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(expenseImageTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// // ! *** Add PaymentImage Image ------------------------

//   // *** functions to insert data in orderList Table
//   Future<int> insertPaymentImage(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(paymentImageTable, row);
//   }

//   // *** function to query all the rows in orderList Table
//   Future<List<Map<String, dynamic>>> fetchAllPaymentImage() async {
//     Database db = await instance.databse;
//     return await db.query(paymentImageTable);
//   }

//   // *** function to delete some data in paymorderListent Table
//   Future<int> deletePaymentImage(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(paymentImageTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// // ! *** Add Checkout Image ------------------------

//   // *** functions to insert data in orderList Table
//   Future<int> insertCheckOutImage(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(checkOutImageTable, row);
//   }

//   // *** function to query all the rows in orderList Table
//   Future<List<Map<String, dynamic>>> fetchAllCheckOutImage() async {
//     Database db = await instance.databse;
//     return await db.query(checkOutImageTable);
//   }

//   // *** function to delete some data in paymorderListent Table
//   Future<int> deleteCheckOutImage(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(checkOutImageTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// // ! *** Add Expense ------------------------

//   // *** functions to insert data in orderList Table
//   Future<int> insertExpense(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(expenseTable, row);
//   }

//   // *** function to query all the rows in orderList Table
//   Future<List<Map<String, dynamic>>> fetchAllExpense() async {
//     Database db = await instance.databse;
//     return await db.query(expenseTable);
//   }

//   // *** function to delete some data in paymorderListent Table
//   Future<int> deleteExpense(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(expenseTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }

//   // ! *** Add Order ------------------------

//   // *** functions to insert data in orderList Table
//   Future<int> insertOrder(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(orderTable, row);
//   }

//   // *** function to query all the rows in orderList Table
//   Future<List<Map<String, dynamic>>> fetchAllOrder() async {
//     Database db = await instance.databse;
//     return await db.query(orderTable);
//   }

//   // *** function to delete some data in paymorderListent Table
//   Future<int> deleteOrder(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(orderTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }

//   // ! *** Add OrderList ------------------------

//   // *** functions to insert data in orderList Table
//   Future<int> insertOrderList(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(orderListTable, row);
//   }

//   // *** function to query all the rows in orderList Table
//   Future<List<Map<String, dynamic>>> fetchAllOrderList() async {
//     Database db = await instance.databse;
//     return await db.query(orderListTable);
//   }

//   // *** function to delete some data in paymorderListent Table
//   Future<int> deleteOrderList(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(orderListTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }

//   // ! *** Apply Payment ------------------------

//   // *** functions to insert data in payment Table
//   Future<int> insertApplyPayment(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(paymentTable, row);
//   }

//   // *** function to query all the rows in payment Table
//   Future<List<Map<String, dynamic>>> fetchAllApplyPayment() async {
//     Database db = await instance.databse;
//     return await db.query(paymentTable);
//   }

//   // *** function to delete some data in payment Table
//   Future<int> deleteApplyPayment(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(paymentTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }

// // ! *** Tracking Location In ------------------------

//   // *** functions to insert data in Check In Table
//   Future<int> insertTrackingLocation(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(trackingLocationTable, row);
//   }

//   // *** function to query all the rows in Check In Table
//   Future<List<Map<String, dynamic>>> fetchAllTrackingLocation() async {
//     Database db = await instance.databse;
//     return await db.query(trackingLocationTable);
//   }

//   // *** function to delete some data in Check In Table
//   Future<int> deleteTrackingLocation(int id) async {
//     Database db = await instance.databse;
//     var res = await db
//         .delete(trackingLocationTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// // ! *** Break Start Break End and day end In ------------------------

//   // *** functions to insert data in Check In Table
//   Future<int> insertBreakStartBreakEnd(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(breakStartBreakEndTable, row);
//   }

//   // *** function to query all the rows in Check In Table
//   Future<List<Map<String, dynamic>>> fetchAllBreakStartAndBreakEnd() async {
//     Database db = await instance.databse;
//     return await db.query(breakStartBreakEndTable);
//   }

//   // *** function to delete some data in Check In Table
//   Future<int> deleteBreakStartBreakEnd(int id) async {
//     Database db = await instance.databse;
//     var res = await db
//         .delete(breakStartBreakEndTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// // ! *** DayStart and day end In ------------------------

//   // *** functions to insert data in Check In Table
//   Future<int> insertDayStartDayEnd(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(dayStartDayEndTable, row);
//   }

//   // *** function to query all the rows in Check In Table
//   Future<List<Map<String, dynamic>>> fetchAllDayStartDayEnd() async {
//     Database db = await instance.databse;
//     return await db.query(dayStartDayEndTable);
//   }

//   // *** function to delete some data in Check In Table
//   Future<int> deleteDayStartDayEnd(int id) async {
//     Database db = await instance.databse;
//     var res =
//         await db.delete(dayStartDayEndTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// // ! *** Check In ------------------------

//   // *** functions to insert data in Check In Table
//   Future<int> insertCheckIn(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(checkInTable, row);
//   }

//   // *** function to query all the rows in Check In Table
//   Future<List<Map<String, dynamic>>> fetchAllCheckIn() async {
//     Database db = await instance.databse;
//     return await db.query(checkInTable);
//   }

//   // *** function to delete some data in Check In Table
//   Future<int> deleteCheckIn(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(checkInTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }

// // ! *** Check Out ------------------------

//   // *** functions to insert data in Check Out Table
//   Future<int> insertCheckOut(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(checkOutTable, row);
//   }

//   // *** function to query all the rows in Check Out Table
//   Future<List<Map<String, dynamic>>> fetchAllCheckOut() async {
//     Database db = await instance.databse;
//     return await db.query(checkOutTable);
//   }

//   // *** function to delete some data in Check Out Table
//   Future<int> deleteCheckOut(int id) async {
//     Database db = await instance.databse;
//     var res = await db.delete(checkOutTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }

// // ! *** Check Out Orders ------------------------

//   // *** functions to insert data in Check Out Table
//   Future<int> insertCheckOutOrder(Map<String, dynamic> row) async {
//     Database db = await instance.databse;
//     return await db.insert(orderProductTable, row);
//   }

//   // *** function to query all the rows in Check Out Table
//   Future<List<Map<String, dynamic>>> fetchAllCheckOutOrder(
//       int checkOutId) async {
//     Database db = await instance.databse;
//     return await db.query(orderProductTable,
//         where: "checkOutId = ?", whereArgs: [checkOutId]);
//   }

//   Future<List<Map<String, dynamic>>> fetchAllCheckOutOrders() async {
//     Database db = await instance.databse;
//     return await db.query(orderProductTable);
//   }

//   // *** function to delete some data in Check Out Table
//   Future<int> deleteCheckOutOrder(int id) async {
//     Database db = await instance.databse;
//     var res =
//         await db.delete(orderProductTable, where: "id = ?", whereArgs: [id]);
//     return res;
//   }
// }
import 'dart:io';
import 'package:hr/res/allString.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class Databasehelper {
  static Database? _database;
  
  Databasehelper._privateConstructor();
  static final Databasehelper instance = Databasehelper._privateConstructor();
  Future<Database> get databse async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  static final _databasename = "SmartOfficeZone.db";
  static final _databaseversion = 5;

// *** Tables
  static final checkInCheckOutTable = "CheckInCheckOut";
  static final trackingLocationTable = "trackingLocation";
  static final dayStartDayEndTable = "dayStartDayEnd";
  static final breakStartBreakEndTable = "breakStartBreakEnd";
  static final orderProductTable = "CheckOutOrders";
  static final paymentTable = "payment";
  static final orderTable = "orderTable";
  static final expenseTable = "expense";
  static final checkOutImageTable = "checkOutImage";
  static final expenseImageTable = "expenseImage";
  static final paymentImageTable = "paymentImage";
  static final location = "location";
  static final latitude = "latitude";
  static final distance = "distance";
  static final longitude = "longitude";
  static final orderListTable = "orderListTable";
  // *** Day Start Tables
  static final id = "id";
  static final attendanceId = "attendanceId";
  static final punchInTime = "punchInTime";
  static final punchOutTime = "punchOutTime";
  static final checkInLocation = "checkInLocation";
  static final checkInLatitude = "checkInLatitude";
  static final inTime = "inTime";
  static final checkInLongitude = "checkInLongitude";
  static final checkOutLocation = "checkOutLocation";
  static final outTime = "outTime";
  static final checkOutLongitude = "checkOutLongitude";
  static final checkOutLatitude = "checkOutLatitude";
// *** Break Start Tables
  static final breakPunchId = "breakPunchId";
  static final breakStartTime = "breakStartTime";
  static final breakEndTime = "breakEndTime";
//attendanceId
// *** Tracking Location Tables
  // *** Check In Check Out Table column names
  static final orderListId = "id";
  static final checkInofficeName = "checkInofficeName";
  static final checkInofficeType = "checkInofficeType";
  static final checkIndealerId = "checkIndealerId";
  static final checkInvisitTypeName = "checkInvisitTypeName";
  static final checkInvisitType = "checkInvisitType";
  static final checkInTime = "checkInTime";
  static final checkInlocation = "checkInlocation";
  static final checkInlatitude = "checkInlatitude";
  static final checkInlongitude = "checkInlongitude";
  static final checkInCheckOutStatus = "forWhat";
  static final checkOutDealerId = "checkOutDealerId";
  static final checkInIdForCheckOut = "checkInIdForCheckOut";
  static final checkOutordersId = "checkOutordersId";
  static final checkOutlatitude = "checkOutlatitude";
  static final checkOutlongitude = "checkOutlongitude";
  static final checkOutlocation = "checkOutlocation";
  static final checkOutofficeName = "checkOutofficeName";
  static final checkOutconveyanceAmount = "checkOutconveyanceAmount";
  static final checkOutconveyanceRemark = "checkOutconveyanceRemark";
  static final checkOutpaymentRemark = "checkOutpaymentRemark";
  static final checkOutpaymentAmount = "checkOutpaymentAmount";
  static final checkOutvisitType = "checkOutvisitType";
  static final checkOutvisitTypeName = "checkOutvisitTypeName";
  static final checkOutindividualId = "checkOutindividualId";
  static final checkOutcheckOutTime = "checkOutcheckOutTime";

  // *** Check Out and  Orders Table column names
  static final orderProductId = 'id';
  static final checkOutIdOrOrderId = 'checkOutIdOrOrderId';
  static final productCategoryId = 'productCategoryId';
  static final productId = 'productId';
  static final brandId = 'brandId';
  static final quantity = "quantity";

// *** Checkout images
//id
//checkOutId
  static final checkOutAttatchmentImageFile1 = "checkOutAttatchmentImageFile1";
  static final checkOutAttatchmentImageFile2 = "checkOutAttatchmentImageFile2";
  static final checkOutPaymentImage = "checkOutPaymentImage";

// *** payment images
//id
//paymentId
  static final paymentPaymentImage = "paymentPaymentImage";
// *** expense images
//id
//expenseId
  static final expenseAttchment1 = "expenseAttchment1";
  static final expenseAttchment2 = "expenseAttchment2";

  // *** payment Table column names
  static final paymentId = 'paymentId';
  static final paymentDealerId = "dealerId";
  static final paymentPayAmount = "amount";
  static final paymentComment = "comment";
  static final paymentVisitTypeName = "visitTypeName";
  static final paymentVisitTypeId = "visitTypeId";
  static final paymentUniqueId = "paymentUniqueId";

 

  // *** order Table column names
  static final orderId = 'orderId';
  static final orderOrderListId = 'orderListid';
  static final orderDealerId = 'dealerId';
  static final orderRemarks = "remarks";
  static final orderVisitTypeName = "visitTypeName";
  static final orderIndividualId = "individualId";
  static final orderVisitType = "visitType";

// *** expense Table column names
  static final expenseId = 'expenseId';
  static final expenseIndividualId = 'individualId';
  static final expenseExpenceTypeId = "expenceTypeId";
  static final expenseVisitId = "visitId";
  static final expenseAmount = "amount";
  static final expenseComment = "comment";

  // *** function to return a database for rate chart
  _initDatabase() async {
    Directory documentdirecoty = await getApplicationDocumentsDirectory();
    String path = join(documentdirecoty.path, _databasename);
    return await openDatabase(path,
        version: _databaseversion, onCreate: _onCreate);
  }

  // *** create a database since it doesn't exist
  Future _onCreate(Database db, int version) async {
        //Payment
      await db.execute('''
      CREATE TABLE $paymentTable (
        $id INTEGER PRIMARY KEY, 
        $paymentDealerId TEXT NOT NULL,
        $paymentPayAmount TEXT NOT NULL,
        $paymentComment TEXT NOT NULL,
        $paymentVisitTypeId TEXT NOT NULL,
        $paymentUniqueId TEXT NOT NULL,
        $paymentVisitTypeName TEXT NOT NULL
      );
      ''');
      //Payment Image
    await db.execute('''
      CREATE TABLE $paymentImageTable (
        $id INTEGER PRIMARY KEY,
        $paymentId INTEGER NOT NULL,
        $paymentPaymentImage TEXT NOT NULL
      );
      ''');
    //Expense
  await db.execute('''
      CREATE TABLE $expenseTable (
        $id INTEGER PRIMARY KEY,
        $expenseExpenceTypeId TEXT NOT NULL,
        $expenseVisitId TEXT NOT NULL,
        $expenseAmount TEXT NOT NULL,
        $expenseComment TEXT NOT NULL 
      );
      ''');

      //Expense Image
    await db.execute('''
      CREATE TABLE $expenseImageTable (
        $id INTEGER PRIMARY KEY,
        $expenseId INTEGER NOT NULL,
        $expenseAttchment1 TEXT NOT NULL,
        $expenseAttchment2 TEXT NOT NULL
      );
      ''');

      //Distance Calculation
    await db.execute('''
      CREATE TABLE $trackingLocationTable (
        $id INTEGER PRIMARY KEY,
        $location TEXT NOT NULL,
        $latitude TEXT NOT NULL,
        $distance TEXT NOT NULL,
        $longitude TEXT NOT NULL
      );
      ''');
//For Attendance
    await db.execute('''
      CREATE TABLE $dayStartDayEndTable (
        $id INTEGER PRIMARY KEY,
        $attendanceId TEXT NOT NULL,
        $checkInLocation TEXT NOT NULL,
        $checkInLatitude TEXT NOT NULL,
        $checkInLongitude TEXT NOT NULL,
        $punchInTime TEXT NOT NULL,
        $checkOutLocation TEXT NOT NULL,
        $punchOutTime TEXT NOT NULL,
        $checkOutLongitude TEXT NOT NULL,
        $checkOutLatitude TEXT NOT NULL
      );
      ''');
 //BreakStart BreakEnd
    await db.execute('''
      CREATE TABLE $breakStartBreakEndTable (
        $id INTEGER PRIMARY KEY,
        $breakPunchId TEXT NOT NULL,
        $breakEndTime TEXT NOT NULL,
        $breakStartTime TEXT NOT NULL,
        $attendanceId TEXT NOT NULL
      );
      ''');



//CheckInCheckOut Process

    await db.execute(''' 
      CREATE TABLE $checkInCheckOutTable (
        $id INTEGER PRIMARY KEY,
        $checkInofficeName TEXT NOT NULL,
        $checkInofficeType TEXT NOT NULL,
        $checkIndealerId TEXT NOT NULL,
        $checkInvisitTypeName TEXT NOT NULL,
        $checkInvisitType TEXT NOT NULL,
        $checkInTime TEXT NOT NULL,
        $checkInlocation TEXT NOT NULL,
        $checkInlatitude TEXT NOT NULL,
        $checkInCheckOutStatus TEXT NOT NULL,
        $checkInlongitude TEXT NOT NULL,
        $checkOutDealerId TEXT NOT NULL,
        $checkInIdForCheckOut TEXT NOT NULL, 
        $checkOutordersId TEXT NOT NULL,
        $checkOutlatitude TEXT NOT NULL,
        $checkOutlongitude TEXT NOT NULL,
        $checkOutlocation TEXT NOT NULL,
        $checkOutofficeName TEXT NOT NULL,
        $checkOutconveyanceAmount TEXT NOT NULL,
        $checkOutconveyanceRemark TEXT NOT NULL, 
        $checkOutpaymentRemark TEXT NOT NULL,
        $checkOutpaymentAmount TEXT NOT NULL,
        $checkOutvisitType TEXT NOT NULL,
        $checkOutvisitTypeName TEXT NOT NULL,
        $checkOutindividualId TEXT NOT NULL,
        $checkOutcheckOutTime TEXT NOT NULL 
      );
      ''');
//For Multiple Order Entry
   await db.execute('''
      CREATE TABLE $orderProductTable (
        $id INTEGER PRIMARY KEY,
        $orderId TEXT NOT NULL,
        $productCategoryId TEXT NOT NULL,
        $productId TEXT NOT NULL,
        $brandId TEXT NOT NULL,
        $quantity TEXT NOT NULL
      );
      ''');

   

      //CheckOut Image
    await db.execute('''
      CREATE TABLE $checkOutImageTable (
        $id INTEGER PRIMARY KEY,
        $orderId INTEGER NOT NULL,
        $checkOutAttatchmentImageFile1 TEXT NOT NULL,
        $checkOutAttatchmentImageFile2 TEXT NOT NULL,
        $checkOutPaymentImage TEXT NOT NULL
      );
      ''');
// Order Table
    await db.execute('''
      CREATE TABLE $orderTable (
        $id INTEGER PRIMARY KEY,
        $orderDealerId TEXT NOT NULL,
        $orderRemarks TEXT NOT NULL,
        $orderVisitTypeName TEXT NOT NULL,
        $orderIndividualId TEXT NOT NULL,
        $orderVisitType TEXT NOT NULL 
     );
      '''); 
// Order List Table
    await db.execute('''
      CREATE TABLE $orderListTable (
        $id INTEGER PRIMARY KEY,
        $checkOutIdOrOrderId TEXT NOT NULL,
        $productCategoryId TEXT NOT NULL,
        $productId TEXT NOT NULL,
        $brandId TEXT NOT NULL,
        $quantity TEXT NOT NULL 
     );
      ''');

    
  }

// ! *** Add Expense Image ------------------------

  // *** functions to insert data in orderList Table
  Future<int> insertExpenseImage(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(expenseImageTable, row);
  }

  // *** function to query all the rows in orderList Table
  Future<List<Map<String, dynamic>>> fetchAllExpenseImage() async {
    Database db = await instance.databse;
    return await db.query(expenseImageTable);
  }

  // *** function to delete some data in paymorderListent Table
  Future<int> deleteExpenseImage(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(expenseImageTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
// ! *** Add PaymentImage Image ------------------------

  // *** functions to insert data in orderList Table
  Future<int> insertPaymentImage(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(paymentImageTable, row);
  }

  // *** function to query all the rows in orderList Table
  Future<List<Map<String, dynamic>>> fetchAllPaymentImage() async {
    Database db = await instance.databse;
    return await db.query(paymentImageTable);
  }

  // *** function to delete some data in paymorderListent Table
  Future<int> deletePaymentImage(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(paymentImageTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
// ! *** Add Checkout Image ------------------------

  // *** functions to insert data in orderList Table
  Future<int> insertCheckOutImage(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(checkOutImageTable, row);
  }

  // *** function to query all the rows in orderList Table
  Future<List<Map<String, dynamic>>> fetchAllCheckOutImage() async {
    Database db = await instance.databse;
    return await db.query(checkOutImageTable);
  }

  // *** function to delete some data in paymorderListent Table
  Future<int> deleteCheckOutImage(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(checkOutImageTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
// ! *** Add Expense ------------------------

  // *** functions to insert data in orderList Table
  Future<int> insertExpense(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(expenseTable, row);
  }

  // *** function to query all the rows in orderList Table
  Future<List<Map<String, dynamic>>> fetchAllExpense() async {
    Database db = await instance.databse;
    return await db.query(expenseTable);
  }

  // *** function to delete some data in paymorderListent Table
  Future<int> deleteExpense(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(expenseTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  // ! *** Add Order ------------------------

  // *** functions to insert data in orderList Table
  Future<int> insertOrder(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(orderTable, row);
  }

  // *** function to query all the rows in orderList Table
  Future<List<Map<String, dynamic>>> fetchAllOrder() async {
    Database db = await instance.databse;
    return await db.query(orderTable);
  }

  // *** function to delete some data in paymorderListent Table
  Future<int> deleteOrder(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(orderTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

  // ! *** Add OrderList ------------------------

   
  // ! *** Apply Payment ------------------------

  // *** functions to insert data in payment Table
  Future<int> insertApplyPayment(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(paymentTable, row);
  }

  // *** function to query all the rows in payment Table
  Future<List<Map<String, dynamic>>> fetchAllApplyPayment() async {
    Database db = await instance.databse;
    return await db.query(paymentTable);
  }

  // *** function to delete some data in payment Table
  Future<int> deleteApplyPayment(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(paymentTable, where: "id = ?", whereArgs: [id]);
    return res;
  }

// ! *** Tracking Location In ------------------------

  // *** functions to insert data in Check In Table
  Future<int> insertTrackingLocation(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(trackingLocationTable, row);
  }

  // *** function to query all the rows in Check In Table
  Future<List<Map<String, dynamic>>> fetchAllTrackingLocation() async {
    Database db = await instance.databse;
    return await db.query(trackingLocationTable);
  }

  // *** function to delete some data in Check In Table
  Future<int> deleteTrackingLocation(int id) async {
    Database db = await instance.databse;
    var res = await db
        .delete(trackingLocationTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
// ! *** Break Start Break End and day end In ------------------------

  // *** functions to insert data in Check In Table
  Future<int> insertBreakStartBreakEnd(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(breakStartBreakEndTable, row);
  }
  Future<void> updateBreakStartBreakEnd(int iddd, String timeeee) async {
    Database db = await instance.databse;
    await db.rawUpdate(
      "UPDATE $breakStartBreakEndTable SET $breakEndTime = ?  WHERE id = ? ",
      [timeeee, iddd],
    );
  }
  // *** function to query all the rows in Check In Table
  Future<List<Map<String, dynamic>>> fetchAllBreakStartAndBreakEnd() async {
    Database db = await instance.databse;
    return await db.query(breakStartBreakEndTable);
  }

  // *** function to delete some data in Check In Table
  Future<int> deleteBreakStartBreakEnd(int id) async {
    Database db = await instance.databse;
    var res = await db
        .delete(breakStartBreakEndTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
// ! *** DayStart and day end In ------------------------

  // *** functions to insert data in Check In Table
  Future<int> insertDayStartDayEnd(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(dayStartDayEndTable, row);
  }

  // *** function to query all the rows in Check In Table
  Future<List<Map<String, dynamic>>> fetchAllDayStartDayEnd() async {
    Database db = await instance.databse;
    return await db.query(dayStartDayEndTable);
  }

  // *** function to delete some data in Check In Table
  Future<int> deleteDayStartDayEnd(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(dayStartDayEndTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
// ! *** Check In ------------------------

  // *** functions to insert data in Check In Table
  Future<int> insertCheckIn(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(checkInCheckOutTable, row);
  }

  // *** function to query all the rows in Check In Table
  Future<List<Map<String, dynamic>>> fetchAllCheckIn() async {
    Database db = await instance.databse;
    return await db.query(checkInCheckOutTable, where: "$checkInCheckOutStatus = ?", whereArgs: [AllString.checkIn]);
  }

  // *** function to delete some data in Check In Table
  Future<int> deleteCheckIn(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(checkInCheckOutTable, where: "id = ?  And $checkInCheckOutStatus = ?", whereArgs: [id,AllString.checkIn]);
    return res;
  }

// ! *** Check Out ------------------------

  // *** functions to insert data in Check Out Table
  Future<int> insertCheckOut(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(checkInCheckOutTable, row);
  }

  // *** function to query all the rows in Check Out Table
  Future<List<Map<String, dynamic>>> fetchAllCheckOut() async {
    Database db = await instance.databse;
    return await db.query(checkInCheckOutTable, where: "$checkInCheckOutStatus = ?", whereArgs: [AllString.checkOut]);
  }

  // *** function to delete some data in Check Out Table
  Future<int> deleteCheckOut(int id) async {
    Database db = await instance.databse;
    var res = await db.delete(checkInCheckOutTable, where: "id = ? And $checkInCheckOutStatus = ?", whereArgs: [id,AllString.checkOut]);
    return res;
  }

// // ! *** Check Out Orders ------------------------

//   // *** functions to insert data in Check Out Table
  Future<int> insertOrderSubList(Map<String, dynamic> row) async {
    Database db = await instance.databse;
    return await db.insert(orderListTable, row);
  }

  // *** function to query all the rows in Check Out Table
  Future<List<Map<String, dynamic>>> fetchAllOrderSubList(
      String checkOutId) async {
    Database db = await instance.databse;
    return await db.query(orderListTable,
        where: "$checkOutIdOrOrderId = ?", whereArgs: [checkOutId]);
  }
  Future<List<Map<String, dynamic>>> fetchAllOrderList(
       ) async {
    Database db = await instance.databse;
    return await db.query(orderListTable );
  }

  

  // *** function to delete some data in Check Out Table
  Future<int> deleteOrderSubList(int id) async {
    Database db = await instance.databse;
    var res =
        await db.delete(orderListTable, where: "id = ?", whereArgs: [id]);
    return res;
  }
   
}
