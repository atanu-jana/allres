import 'package:hr/db/handler.dart';
import 'package:hr/pages/splashScreen.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';

Random random = new Random();
bool checkForExpenseAndVisitPurpose=false;
bool tgtsAvailable=false;
bool taskAvailable=false;
bool requestAvailable=false;
double screenWidth = 0.0;
double screenHeight = 0.0;
SharedPreferences? sharedPreferences;
String loginUserId = "";
String loginIndivisualId = "";
String loginToken = "";
String loginCompanyId = "";
String appVersion = "";
Databasehelper dbhelper = Databasehelper.instance;
List<String> dealerList = [AllString.select];
List<String> expenseTypeList = [AllString.select];
List<String> categoryList = [AllString.select];
List<String> brandList = [AllString.select];

List<String> teamMemberList = [];
List<String> allTeamMemberList = [];

List<String> leaveTypeDetailsData = [AllString.select,"PL","CL","SL/ML","maternity Leave"];
List<String> loanTypeDetailsData = [AllString.select];
List<String> departmentDetails = [AllString.select];
List<String> suggestionTypeDetails = [AllString.select];

// Future<void> initializeService() async {
//   final service = FlutterBackgroundService();
//   await service.configure(
//     androidConfiguration: AndroidConfiguration(
//       // this will executed when app is in foreground or background in separated isolate
//       onStart: onStart,

//       // auto start service
//       autoStart: true,
//       isForegroundMode: true,
//     ),
//     iosConfiguration: IosConfiguration(
//       // auto start service
//       autoStart: true,

//       // this will executed when app is in foreground in separated isolate
//       onForeground: onStart,

//       // you have to enable background fetch capability on xcode project
//       onBackground: onIosBackground,
//     ),
//   );
// }

// void onIosBackground() {
//   WidgetsFlutterBinding.ensureInitialized();
//   print('FLUTTER BACKGROUND FETCH');
// }

// void onStart() {
//   WidgetsFlutterBinding.ensureInitialized();

//   final service = FlutterBackgroundService();
//   service.setForegroundMode(false);
//   FlutterBackgroundService().sendData({"action": "setAsBackground"});
//   // Timer.periodic(const Duration(seconds: 5), (timer) async {
//   //   if (!(await service.isServiceRunning())) timer.cancel();

//   //   Map data = {"companyId": 1};
//   //   var headers = {'Content-Type': 'application/json'};
//   //   var request = http.Request(
//   //       'POST', Uri.parse('http://api.easeurbiz.com:3002/testAPI'));
//   //   request.body = '''{\n    "companyId":"1"\n}''';
//   //   request.headers.addAll(headers);

//   //   http.StreamedResponse response = await request.send();

//   //   if (response.statusCode == 200) {
//   //     print(await response.stream.bytesToString());
//   //   } else {
//   //     print(response.reasonPhrase);
//   //   }

//   //   log(data.toString());
//   // });
// }

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // SharedPreferences.setMockInitialValues({});
  sharedPreferences = await SharedPreferences.getInstance();
  ResponsiveSizingConfig.instance.setCustomBreakpoints(
    ScreenBreakpoints(desktop: 800, tablet: 550, watch: 200),
  );
  loadAllDataFromLocal();
  // await initializeService();

  runApp(MyApp());
}

loadAllDataFromLocal() {
  loginToken = sharedPreferences!.getString(
        AllSharedPreferencesKey.token,
      ) ??
      "";

  loginUserId = sharedPreferences!.getString(
        AllSharedPreferencesKey.userId,
      ) ??
      "";
  if (sharedPreferences!.getString(AllSharedPreferencesKey.checkInId) == null) {
    sharedPreferences!.setString(AllSharedPreferencesKey.checkInId, "");
  }
  if (sharedPreferences!.getDouble(AllSharedPreferencesKey.positionForSend) ==
      null) {
    sharedPreferences!.setDouble(AllSharedPreferencesKey.positionForSend, 0.0);
  }
  loginIndivisualId = sharedPreferences!.getString(
        AllSharedPreferencesKey.individualTypeId,
      ) ??
      "";
  loginCompanyId = sharedPreferences!.getString(
        AllSharedPreferencesKey.companyId,
      ) ??
      "";
  if (sharedPreferences!.getString(
        AllSharedPreferencesKey.colorPrimary,
      ) !=
      null) {
    // AllColor.primaryColor = Color(int.parse(
    //     'FF${sharedPreferences!.getString(
    //       AllSharedPreferencesKey.colorPrimary,
    //     )}',
    //     radix: 16));
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    // SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    //     statusBarColor: AllColor.black, statusBarBrightness: Brightness.dark));
    return AppBuilder(builder: (context) {
      return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            fontFamily: AllString.fontFamily,
            // appBarTheme: Theme.of(context)
            //     .appBarTheme
            //     .copyWith(brightness: Brightness.dark),
          ),
          home: SplashScreen());
    });
  }
}

class AppBuilder extends StatefulWidget {
  final Function(BuildContext)? builder;

  const AppBuilder({Key? key, this.builder}) : super(key: key);

  @override
  AppBuilderState createState() => new AppBuilderState();

  static AppBuilderState? of(BuildContext context) {
    // return context.ancestorStateOfType(const TypeMatcher<AppBuilderState>());

    return context.findAncestorStateOfType<AppBuilderState>();
  }
}

class AppBuilderState extends State<AppBuilder> {
  @override
  Widget build(BuildContext context) {
    return widget.builder!(context);
  }

  void rebuild() {
    setState(() {});
  }
}
