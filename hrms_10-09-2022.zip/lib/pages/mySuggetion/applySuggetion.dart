import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/mySuggetion/mySuggetion.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ApplySuggetion extends StatefulWidget {
  const ApplySuggetion({
    Key? key,
  }) : super(key: key);
  @override
  _ApplySuggetionState createState() => _ApplySuggetionState();
}

class _ApplySuggetionState extends State<ApplySuggetion> {
  bool loading = false;
  String currentDepartment = AllString.select;
  String currentDepartmentHead = AllString.select;

  TextEditingController _commentTextEditingController = TextEditingController();
  String _currentSuggetionType = AllString.select;
  String _currentDepartment = AllString.select;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.suggetion),
        body: LoadingOverlay(
            isLoading: loading,
            opacity: 0.5,
            color: AllColor.black,
            progressIndicator: commonLoader(),
            child: Container(
                width: screenWidth,
                height: screenHeight,
                child: ListView(physics: BouncingScrollPhysics(), children: [
                  textFieldHeader(AllString.pleaseSelectSuggetionType+" *",
                      fontWeight: FontWeight.bold),
                  Container(
                    child: DropdownButtonWithSearchForSuggetionType(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentSuggetionType,
                      dropdownList: suggestionTypeDetails,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentSuggetionType = newValue!;
                        });
                      },
                    ),
                  ),
                  textFieldHeader(AllString.pleaseSelectDepartment+" *",
                      fontWeight: FontWeight.bold),
                  Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentDepartment,
                      dropdownList: departmentDetails,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentDepartment = newValue!;
                        });
                      },
                    ),
                  ),
                  textFieldHeader(AllString.suggetionRemark+" *",
                      fontWeight: FontWeight.bold),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enterRemark,
                        _commentTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03),
                      // child: customAnimatedButton(context,
                      //     // enable: currentExpenseType == AllString.select ||
                      //     //         !acceptAgreement
                      //     //     ? false
                      //     //     : true,
                      //     function: (_) {
                      // },
                      //     // if (currentExpenseType != AllString.select &&
                      //     //     acceptAgreement) {
                      //     //   commonAlertDialog(context, AllString.success,
                      //     //       "Successfully Apply " + currentExpenseType,
                      //     //       function: () {
                      //     //     setState(() {
                      //     //       acceptAgreement = false;
                      //     //       currentExpenseType = AllString.select;
                      //     //     });
                      //     //     _amountFocusNode.unfocus();
                      //     //     Navigator.pop(context);
                      //     //   });
                      //     // }
                      //     color: AllColor.primaryColor,
                      //     deepColor: AllColor.primaryDeepColor,
                      //     textColor: AllColor.white,
                      //     text: AllString.apply,
                      //     width: screenWidth)
                      child: button(
                        context,
                        // enable: currentExpenseType == AllString.select ||
                        //         !acceptAgreement
                        //     ? false
                        //     : true,
                        function: () {
                          if (validateAndProceed()) {
                            addSuggetion();
                          }
                        },
                        // if (currentExpenseType != AllString.select &&
                        //     acceptAgreement) {
                        //   commonAlertDialog(context, AllString.success,
                        //       "Successfully Apply " + currentExpenseType,
                        //       function: () {
                        //     setState(() {
                        //       acceptAgreement = false;
                        //       currentExpenseType = AllString.select;
                        //     });
                        //     _amountFocusNode.unfocus();
                        //     Navigator.pop(context);
                        //   });
                        // }

                        color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.apply,
                      )),
                ]))));
  }

  bool validateAndProceed() {
    if (_currentSuggetionType == AllString.select) {
      return false;
    } else if (_currentDepartment == AllString.select) {
      return false;
    } else if (_commentTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }

  addSuggetion() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });

      Map data = {
        "departmentId": _currentDepartment.split(AllString.splitText).last,
        "suggestionTypeId":
            _currentSuggetionType.split(AllString.splitText).last,
        "employeeName": "",
        "subject": "",
        "comment": _commentTextEditingController.text,
        "suggestionImage": "",
        "userLoginId": loginUserId,
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.addSuggestion, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).push(
                  CupertinoPageRoute(builder: (context) => MySuggetion()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
