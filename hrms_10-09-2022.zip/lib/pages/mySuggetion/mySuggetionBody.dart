import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/mySuggetion/applySuggetion.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customCatender.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class MySuggetionBody extends StatefulWidget {
  @override
  _MySuggetionBodyState createState() => _MySuggetionBodyState();
}

class _MySuggetionBodyState extends State<MySuggetionBody> {
  bool loading = false;
  List _mySuggetionList = [];
  String _currentSuggetionType = AllString.select;
  String _currentDepartment = AllString.select;
  String currentUser = AllString.select;
  // var userTypeList = [
  //   AllString.select,
  //   "Hr",
  // ];
  String currentYear = AllString.select;
  // var yearList = [
  //   AllString.select,
  //   "2019",
  //   "2020",
  //   "2021",
  // ];
  @override
  void initState() {
    super.initState();
    fetchExpense();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                              decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Positioned(
              top: 0,
              child: Container(
                margin: EdgeInsets.only(top: screenWidth * 0.03),
                padding: EdgeInsets.only(bottom: screenWidth * 0.02),
                width: screenWidth,
                height: screenWidth * 0.3,
                decoration: BoxDecoration(
                    border:
                        Border(bottom: BorderSide(color: AllColor.lightBlack))),
                alignment: Alignment.center,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: screenWidth / 2,
                      child: Column(
                        children: [
                          textFieldHeader(AllString.selectSuggetionType,
                              fontWeight: FontWeight.bold),
                          Container(
                            child: DropdownButtonWithSearchForSuggetionType(
                              icon: LineIcons.sortAmountDown,
                              selectedValue: _currentSuggetionType,
                              dropdownList: suggestionTypeDetails,
                              onChanged: (String? newValue) {
                                setState(() {
                                  _currentSuggetionType = newValue!;
                                }); 
                                fetchExpense();
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: screenWidth / 2,
                      child: Column(
                        children: [
                          textFieldHeader(AllString.selectDepartment,
                              fontWeight: FontWeight.bold),
                          Container(
                            child: DropdownButtonWithSearch(
                              icon: LineIcons.sortAmountDown,
                              selectedValue: _currentDepartment,
                              dropdownList: departmentDetails,
                              onChanged: (String? newValue) {
                                setState(() {
                                  _currentDepartment = newValue!;
                                });
                                fetchExpense();
                              },
                            ),
                          ),
                        ],
                      ),
                    )
                    // Container(
                    //   width: screenWidth / 2.3,
                    //   margin:
                    //       EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    //   child: FormField<String>(
                    //       builder: (FormFieldState<String> state) {
                    //     return InputDecorator(
                    //         decoration: InputDecoration(
                    //             isDense: true,
                    //             contentPadding: EdgeInsets.symmetric(
                    //               horizontal: screenWidth * 0.03,
                    //               vertical: screenWidth * 0.02,
                    //             ),
                    //             labelStyle:
                    //                 smallTextStyle(color: AllColor.greyColor),
                    //             errorStyle: TextStyle(
                    //                 color: Colors.redAccent, fontSize: 16.0),
                    //             prefixIcon: Icon(
                    //               LineIcons.user,
                    //               color: AllColor.black,
                    //             ),
                    //             suffixIcon: smallIcon(
                    //               Icons.expand_more_outlined,
                    //               color: AllColor.black,
                    //             ),
                    //             border: OutlineInputBorder(
                    //                 borderRadius: BorderRadius.circular(5.0))),
                    //         isEmpty: currentUser == '',
                    //         child: DropdownButtonHideUnderline(
                    //             child: DropdownButton<String>(
                    //                 icon: Visibility(
                    //                     visible: false,
                    //                     child: Icon(Icons.arrow_downward)),
                    //                 value: currentUser,
                    //                 isDense: true,
                    //                 onChanged: (String? newValue) {
                    //                   setState(() {
                    //                     currentUser = newValue!;

                    //                     state.didChange(newValue);
                    //                   });
                    //                 },
                    //                 items: userTypeList.map((String value) {
                    //                   return DropdownMenuItem<String>(
                    //                     value: value,
                    //                     child: smallText(value,
                    //                         color: AllColor.black),
                    //                   );
                    //                 }).toList())));
                    //   }),
                    // ),
                    // Container(
                    //   width: screenWidth / 2.3,
                    //   margin:
                    //       EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    //   child: FormField<String>(
                    //       builder: (FormFieldState<String> state) {
                    //     return InputDecorator(
                    //         decoration: InputDecoration(
                    //             isDense: true,
                    //             contentPadding: EdgeInsets.symmetric(
                    //               horizontal: screenWidth * 0.03,
                    //               vertical: screenWidth * 0.02,
                    //             ),
                    //             labelStyle:
                    //                 smallTextStyle(color: AllColor.greyColor),
                    //             errorStyle: TextStyle(
                    //                 color: Colors.redAccent, fontSize: 16.0),
                    //             prefixIcon: Icon(
                    //               LineIcons.yammer,
                    //               color: AllColor.black,
                    //             ),
                    //             suffixIcon: smallIcon(
                    //               Icons.expand_more_outlined,
                    //               color: AllColor.black,
                    //             ),
                    //             border: OutlineInputBorder(
                    //                 borderRadius: BorderRadius.circular(5.0))),
                    //         isEmpty: currentYear == '',
                    //         child: DropdownButtonHideUnderline(
                    //             child: DropdownButton<String>(
                    //                 icon: Visibility(
                    //                     visible: false,
                    //                     child: Icon(Icons.arrow_downward)),
                    //                 value: currentYear,
                    //                 isDense: true,
                    //                 onChanged: (String? newValue) {
                    //                   setState(() {
                    //                     currentYear = newValue!;

                    //                     state.didChange(newValue);
                    //                   });
                    //                 },
                    //                 items: yearList.map((String value) {
                    //                   return DropdownMenuItem<String>(
                    //                     value: value,
                    //                     child: smallText(value,
                    //                         color: AllColor.black),
                    //                   );
                    //                 }).toList())));
                    //   }),
                    // ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: screenWidth * 0.25),
              child:_mySuggetionList.isEmpty?commonNoDataFound(): ListView.builder(
                padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                physics: BouncingScrollPhysics(),
                itemCount: _mySuggetionList.length,
                itemBuilder: (context, index) =>
                    customMyLoanItem(_mySuggetionList[index], index),
              ),
            ),
            Positioned(
                bottom: screenWidth * 0.05,
                right: screenWidth * 0.05,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.of(context).push(CupertinoPageRoute(
                        builder: (context) => ApplySuggetion()));
                  },
                  child: normalIcon(Icons.add),
                  backgroundColor: AllColor.primaryDeepColor,
                )),
          ],
        ),
      ),
    );
  }

  customMyLoanItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth >= 600 ? screenWidth * 0.17 : screenWidth * 0.27,
        margin: customMarginCardItem(),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              checkApiValueValid(itemData["createdDate"])
                  ? Container(
                      width: screenWidth * 0.23,
                      height: screenWidth >= 600
                          ? screenWidth * 0.18
                          : screenWidth * 0.27,
                      alignment: Alignment.center,
                      child: headingText(AllString.na, color: AllColor.black),
                    )
                  : calendarCard(
                      screenWidth * 0.23,
                      screenWidth >= 600
                          ? screenWidth * 0.18
                          : screenWidth * 0.27,
                      screenWidth * 0.18,
                      DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.6,
                      widthTitle: screenWidth * 0.28,
                      title: "Suggestion Type",
                      value: itemData["suggestionTypeName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.6,
                      widthTitle: screenWidth * 0.28,
                      title: "Head",
                      value: itemData["departmentName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.6,
                      widthTitle: screenWidth * 0.28,
                      title: "Comment",
                      value: itemData["comment"].toString()),
                  // customCardRowDetails(
                  //     itemData["comment"].toString()),
                ],
              ),
              // itemData["Status"] == "Reimbursment"
              //     ? Container(
              //         margin: EdgeInsets.only(right: screenWidth * 0.02),
              //         child: normalIcon(Icons.arrow_forward_ios,
              //             color: AllColor.greyColor))
              //     : Container()
            ],
          ),
        ),
      ),
    );
  }

  customCardRowDetails(String value) {
    return Container(
      width: screenWidth * 0.65,
      padding: EdgeInsets.symmetric(
          vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
      child: Container(
        width: screenWidth * 0.65,
        child: Text(
          value,
          softWrap: true,
          style: smallTextStyle(color: AllColor.black),
        ),
      ),
    );
  }

  fetchExpense() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "suggestionTypeId":
            _currentSuggetionType.split(AllString.splitText).last,
        "departmentId": _currentDepartment.split(AllString.splitText).last,
        "loanTypeId": "",
        "individualName": "",
        "userId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getSuggestionList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _mySuggetionList.clear();

            if (jsonData["suggestionData"] == "") {
              _mySuggetionList = [];
            } else {
              _mySuggetionList = jsonData["suggestionData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
