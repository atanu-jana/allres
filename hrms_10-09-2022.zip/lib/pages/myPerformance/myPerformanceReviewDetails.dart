import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/myPerformance/finalReview.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class MyPerformanceReviewDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const MyPerformanceReviewDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);

  // const MyPerformanceReviewDetails({
  //   Key? key,
  // }) : super(key: key);
  @override
  _MyPerformanceReviewState createState() => _MyPerformanceReviewState();
}

class _MyPerformanceReviewState extends State<MyPerformanceReviewDetails> {
  bool loading = false;
  List _kpiDeatilsList = [];
  @override
  void initState() {
    super.initState();
    fetchKRApercentageDetailsData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.myPerformanceReview),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
            width: screenWidth,
            height: screenHeight,
                                  decoration:customBackgroundGradient(),

            child: ListView(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  decoration: BoxDecoration(
                      border:
                          Border(bottom: BorderSide(color: AllColor.black))),
                  width: screenWidth,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                          width: screenWidth * 0.3,
                          child: CircularPercentIndicator(
                            radius: 100.0,
                            lineWidth: 20.0,
                            percent: double.parse(widget
                                    .singleData["getPercentage"]
                                    .toString()) /
                                100,
                            center: smallText(
                                widget.singleData["getPercentage"].toString() +
                                    "%",
                                color: AllColor.black),
                            progressColor: AllColor.deepGreen,
                            backgroundColor: AllColor.green.withOpacity(0.5),
                          )),
                      Container(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            child: normalText(
                                widget.singleData["kraTemplate"].toString(),
                                color: AllColor.primaryDeepColor),
                          ),
                          Container(
                            child: normalText("Total Target: 100",
                                color: AllColor.black),
                          ),
                          Container(
                            child: normalText(
                                "Target Reached: " +
                                    widget.singleData["getPercentage"]
                                        .toString(),
                                color: AllColor.black),
                          ),
                        ],
                      )),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.02),
                  decoration: BoxDecoration(
                      border:
                          Border(bottom: BorderSide(color: AllColor.black))),
                  width: screenWidth,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            child: normalText("KRA (Key Responsibility Area)",
                                color: AllColor.primaryDeepColor),
                          ),
                          Container(
                            child: normalText(
                                widget.singleData["markObtain"].toString() +
                                    " reached out of " +
                                    widget.singleData["totalMarks"].toString(),
                                color: AllColor.black),
                          ),
                          Container(
                            child: normalText(
                                widget.singleData["kraTemplate"].toString(),
                                color: AllColor.black),
                          ),
                        ],
                      )),
                      Container(
                          width: screenWidth * 0.3,
                          alignment: Alignment.centerRight,
                          child: CircularPercentIndicator(
                            radius: 70.0,
                            lineWidth: 15.0,
                            percent: double.parse(widget
                                    .singleData["markObtain"]
                                    .toString()) /
                                widget.singleData["totalMarks"],
                            center: smallText("", color: AllColor.black),
                            progressColor: AllColor.primaryDeepColor,
                            backgroundColor:
                                AllColor.primaryColor.withOpacity(0.5),
                          )),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.005,
                  ),
                  decoration: BoxDecoration(
                    color: AllColor.tableBackground,
                    // border:
                    //     Border(bottom: BorderSide(color: AllColor.black))
                  ),
                  width: screenWidth,
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: screenWidth * 0.45,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "KPI",
                          textAlign: TextAlign.center,
                          style: smallTextStyle(color: AllColor.white),
                        ),
                      ),
                      Container(
                        width: screenWidth * 0.2,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Target (Point)",
                          textAlign: TextAlign.center,
                          style: smallTextStyle(color: AllColor.white),
                        ),
                      ),
                      Container(
                        width: screenWidth * 0.2,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Reached Target",
                          textAlign: TextAlign.center,
                          style: smallTextStyle(color: AllColor.white),
                        ),
                      ),
                      Container(
                        width: screenWidth * 0.06,
                      ),
                    ],
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(top: screenWidth * 0.005),
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: _kpiDeatilsList.length,
                        itemBuilder: (context, index) => customRowForDetails(
                            _kpiDeatilsList[index], index))),
              ],
            )
            //     Container(
            //       margin: EdgeInsets.only(top: screenWidth * 0.11),
            //       child: ListView.builder(
            //           shrinkWrap: true,
            //           itemCount: 2,
            //           itemBuilder: (context, index) => customPerformanceReview()),
            // ),
            ),
      ),
    );
  }

  customPerformanceReview() {
    return Container(
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.008),
      decoration: BoxDecoration(
        color: AllColor.lightBlueGrey,
        borderRadius: BorderRadius.circular(7),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: screenWidth * 0.008,
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            width: screenWidth,
            alignment: Alignment.centerLeft,
            child: normalText("HR", color: AllColor.primaryColor),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            width: screenWidth,
            alignment: Alignment.centerLeft,
            child:
                normalText("Reviewed by: Aritri Bose", color: AllColor.black),
          ),
          SizedBox(
            height: screenWidth * 0.008,
          ),
          customViewPerformanceProgress("60", "HR"),
          Container(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            width: screenWidth,
            alignment: Alignment.centerRight,
            child: smallText("More details...", color: AllColor.greyColor),
          ),
          SizedBox(
            height: screenWidth * 0.008,
          ),
        ],
      ),
    );
  }

  fetchKRApercentageDetailsData() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "employeeKraReviewId":
            widget.singleData["employeeKraReviewId"].toString(),
      };
      apiPostRequestWithHeader(data, AllUrls.getKRApercentageDetailsList,
              this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _kpiDeatilsList = jsonData["kpiDetailsData"];
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customViewPerformanceProgress(String percentage, String name) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: screenWidth,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: screenWidth * 0.3,
                child: CircularPercentIndicator(
                  radius: 100.0,
                  lineWidth: 20.0,
                  percent: double.parse(percentage) / 100,
                  center: smallText("$percentage%", color: AllColor.black),
                  progressColor: AllColor.deepGreen,
                  backgroundColor: AllColor.green.withOpacity(0.5),
                )),
            Container(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  child: normalText("Total Target: 100", color: AllColor.black),
                ),
                Container(
                  child:
                      normalText("Target Reached: 60", color: AllColor.black),
                ),
              ],
            )),
          ],
        ),
      ),
    );
  }

  customRowForDetails(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => FinalReview(
                  singleData: itemData,
                  parentSingleData: widget.singleData,
                  visible: false,
                  callBack: widget.callBack
                 
                )));
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: screenWidth * 0.01,
        ),
        decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: AllColor.black))),
        width: screenWidth,
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: screenWidth * 0.45,
              alignment: Alignment.centerLeft,
              child: Text(
                itemData["kpiTemplate"].toString(),
                textAlign: TextAlign.left,
                style: smallTextStyle(color: AllColor.black),
              ),
            ),
            Container(
              width: screenWidth * 0.2,
              alignment: Alignment.center,
              child: Text(
                itemData["kpiTarget"].toString(),
                textAlign: TextAlign.left,
                style: smallTextStyle(color: AllColor.black),
              ),
            ),
            Container(
              width: screenWidth * 0.2,
              alignment: Alignment.center,
              child: Text(
                itemData["kpiReached"] ??"0",
                textAlign: TextAlign.left,
                style: smallTextStyle(color: AllColor.black),
              ),
            ),
            Container(
                width: screenWidth * 0.06,
                alignment: Alignment.center,
                child: smallIcon(Icons.arrow_forward_ios,
                    color: AllColor.greyColor)),
          ],
        ),
      ),
    );
  }
}

class SalesData {
  SalesData(this.month, this.sales);
  final String month;
  final double sales;
}
