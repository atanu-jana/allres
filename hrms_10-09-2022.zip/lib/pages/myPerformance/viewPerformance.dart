import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animation_progress_bar/flutter_animation_progress_bar.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/myPerformance/myPerformanceReview.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:intl/intl.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ViewPerformance extends StatefulWidget {
  const ViewPerformance({
    Key? key,
  }) : super(key: key);
  @override
  _ViewPerformanceState createState() => _ViewPerformanceState();
}

class _ViewPerformanceState extends State<ViewPerformance> {
  bool loading = false;
  List<Color> colorList = [
    Color(0xff0277bd),
        Color(0xffc85a54),
        Color(0xffc60055),
        Color(0xff3f1dcb),
         Color(0xffc56000),
        Color(0xff000070),
        Color(0xff004c8c),
        Color(0xff005005),
       
        Color(0xff260e04),        
        Color(0xff0094cc)
  ];
  List graphList = [];
  List<ChartSeries> _graphDataList = [];
  List _kraPercentageList = [];
  @override
  void initState() {
    super.initState();
    final DateFormat formatter = DateFormat('yyyy');
    String currentYear = formatter.format(DateTime.now());
    //log(currentYear.toString());

    fetchGraphData(currentYear);
    fetchKRApercentageData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.viewPerformance),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                  decoration:customBackgroundGradient(),

          child: ListView(
              shrinkWrap: true,
              padding: EdgeInsets.only(bottom: screenWidth * 0.03),
              physics: BouncingScrollPhysics(),
              children: [
                _graphDataList.isEmpty
                    ? Container()
                    : Container(
                        child: SfCartesianChart(
                            primaryXAxis: CategoryAxis(),
                            series: _graphDataList)),
                Container(
                    height: screenWidth * 0.1,
                    width: screenWidth,
                    margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.05,
                        vertical: screenWidth * 0.02),
                    child: Center(
                      child: ListView.builder(
                        shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          itemCount: graphList.length,
                          itemBuilder: (context, index) {
                            return Center(child:details(colorList[index], graphList[index]["kraTemplate"],
                                screenWidth * 0.25));
                          }),
                    )),
                Container(
                  child: _kraPercentageList.isEmpty
                      ? commonNoDataFound()
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: 1,
                          itemBuilder: (context, index) =>
                              customViewPerformance(
                                  _kraPercentageList[index], index)),
                )
              ]),
        ),
      ),
    );
  }

  customLeaveItem() {
    return Container(
      height: screenWidth * 0.46,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      decoration: BoxDecoration(
          color: AllColor.lightBlueGrey,
          borderRadius: BorderRadius.circular(10)),
      width: screenWidth,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          customCardRowDetails(
              "Applied On", convertStringToDate(DateTime.now())),
          customCardRowDetails("Status", "Approved"),
          customCardRowDetails("Day Requested", "Half Day"),
          customCardRowDetails("Leave Used", "1.5"),
          customCardRowDetails("Leave Left", "5"),
          customCardRowDetails("Reason", "Personal work"),
        ],
      ),
    );
  }

  customCardRowDetails(String title, value) {
    return Container(
      width: screenWidth,
      padding: EdgeInsets.symmetric(
          vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: screenWidth * 0.28,
            child: smallText(title + " :", color: AllColor.greyColor),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
          ),
          normalText(value,
              color: value == "Approved" ? AllColor.green : AllColor.black)
        ],
      ),
    );
  }

  fetchGraphData(String _currentYear) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "year": _currentYear,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getKRAGraphList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            graphList = jsonData["kraGraphData"];
            for (int topI = 0; topI < graphList.length; topI++) {
      
              List temp = jsonData["kraGraphData"][topI]["graphData"];
              List<GrapgData> _graphList = [];
              temp.forEach((element) {
                _graphList.add(
                    GrapgData(element["month"].toString(), element["score"]));
                setState(() {});
              });

              _graphDataList.add(LineSeries<GrapgData, String>(
                dataSource: _graphList,
                color: colorList[topI],
                xValueMapper: (GrapgData score, _) =>
                    month[int.parse(score.month) - 1]
                        .toString()
                        .substring(0, 3)
                        .toUpperCase(),
                onPointTap: (val) {},
                yValueMapper: (GrapgData score, _) => score.score,
              ));
            }

            setState(() {});
            //log(temp.toString());
            // temp.forEach((element) {
            //   // log(element.toString());

            //   // if (element["DesignationName"] == "Marketing") {
            //   //   List tempp = element["GraphData"];
            //   //   log(tempp.length.toString());
            //   //   tempp.forEach((element) {
            //   //     markeing.dataSource.add(GrapgData(element["month"],
            //   //         double.parse(element["score"].toString())));
            //   //   });
            //   // }
            //   // if (element["DesignationName"] == "OverAll") {
            //   //   List tempp = element["GraphData"];
            //   //   log(tempp.length.toString());
            //   //   tempp.forEach((element) {
            //   //     overAll.dataSource.add(GrapgData(element["month"],
            //   //         double.parse(element["score"].toString())));
            //   //   });
            //   // }
            //   // if (element["DesignationName"] == "HR") {
            //   //   List tempp = element["GraphData"];
            //   //   log(tempp.length.toString());
            //   //   tempp.forEach((element) {
            //   //     hr.dataSource.add(GrapgData(element["month"],
            //   //         double.parse(element["score"].toString())));
            //   //   });
            //   // }
            // });

            //_loadList.clear();

            // if (jsonData["kraTemplateData"] == "") {
            //   _loadList = [];
            // } else {
            //   _loadList = jsonData["kraTemplateData"]["kraDetails"];
            //   _totalMark = jsonData["kraTemplateData"]["totalMark"].toString();
            //   _individualName = jsonData["kraTemplateData"]["individualName"];
            // }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  fetchKRApercentageData() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getKRApercentageList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _kraPercentageList = jsonData["kraPercentageData"];
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // fetchGraphData2() async {
  //   setState(() {
  //     loading = true;
  //   });
  //   var jsonData = json
  //       .decode(await rootBundle.loadString('assets/json/LineGraphData.json'));
  //   log(jsonData.toString());

  //   List temp = jsonData["LineGraphData"];

  //   log(temp.toString());
  //   temp.forEach((element) {
  //     log(element.toString());
  //     if (element["DesignationName"] == "Marketing") {
  //       List tempp = element["GraphData"];
  //       log(tempp.length.toString());
  //       tempp.forEach((element) {
  //         markeing.dataSource.add(GrapgData(
  //             element["month"], double.parse(element["score"].toString())));
  //       });
  //     }
  //     if (element["DesignationName"] == "OverAll") {
  //       List tempp = element["GraphData"];
  //       log(tempp.length.toString());
  //       tempp.forEach((element) {
  //         overAll.dataSource.add(GrapgData(
  //             element["month"], double.parse(element["score"].toString())));
  //       });
  //     }
  //     if (element["DesignationName"] == "HR") {
  //       List tempp = element["GraphData"];
  //       log(tempp.length.toString());
  //       tempp.forEach((element) {
  //         hr.dataSource.add(GrapgData(
  //             element["month"], double.parse(element["score"].toString())));
  //       });
  //     }
  //   });
  //   //   List overAll = jsonData["ReimbursementListData"];
  //   //   List hr = jsonData["ReimbursementListData"];

  //   //   marketing.forEach((element) {
  //   //     GrapgData(element["month"], element["score"]);
  //   //   });
  //   //   marketing.forEach((element) {
  //   //     GrapgData(element["month"], element["score"]);
  //   //   });
  //   //   setState(() {});
  //   setState(() {
  //     loading = false;
  //   });
  // }

  details(Color color, String text, double width) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: screenWidth*0.02
      ),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(100)),
            width: screenWidth * 0.03,
            height: screenWidth * 0.03,
            margin: EdgeInsets.only(right: screenWidth * 0.01),
          ),
          smallText(text, color: AllColor.black.withOpacity(0.6))
        ],
      ),
    );
  }

  customViewPerformance(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => MyPerformanceReview()));
      },
      child: Container(
        decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: AllColor.greyColor))),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
              width: screenWidth,
              alignment: Alignment.centerLeft,
              height: screenWidth * 0.1,
              color: AllColor.lightBlueGrey,
              child: normalText(convertStringToMonthYear(DateTime.now()),
                  color: AllColor.primaryColor),
            ),
            Container(
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _kraPercentageList.length,
                  itemBuilder: (context, indexx) =>
                      customViewPerformanceProgress(
                          _kraPercentageList[indexx]["getPercentage"]
                              .toString(),
                          _kraPercentageList[indexx]["kraTemplate"]
                              .toString())),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
              width: screenWidth,
              alignment: Alignment.centerRight,
              height: screenWidth * 0.1,
              child: smallText("More details...", color: AllColor.greyColor),
            ),
          ],
        ),
      ),
    );
  }

  customViewPerformanceProgress(String percentage, String name) {
    return GestureDetector(
      child: Container(
        margin: EdgeInsets.symmetric(vertical: screenWidth * 0.008),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: screenWidth * 0.5,
                child: FAProgressBar(
                  // border: Border(left: BorderSide(
                  //   color: AllColor.green.withOpacity(0.5),width: 0
                  // ),right: BorderSide(
                  //   color: AllColor.transparentColor, width: 0
                  // ),top: BorderSide(
                  //   color: AllColor.transparentColor, width: 0
                  // ),bottom: BorderSide(
                  //   color: AllColor.transparentColor, width: 0
                  // )),
                  border: Border.all(
                    
                    color: AllColor.green.withOpacity(0.5),width: 5
                     ),
                  backgroundColor: AllColor.green.withOpacity(0.5),
                  progressColor: AllColor.deepGreen,
                  currentValue: double.parse(percentage),
                  displayText: '%',
                  displayTextStyle: smallTextStyle(
                    fontWeight: FontWeight.bold,color:AllColor.white
                  ),
                )),
            Container(
                width: screenWidth *0.3,

                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  child: normalText(name, color: AllColor.greyColor),
                ),
                Container(
                  child: normalText(percentage + "% Reached",
                      color: AllColor.black),
                ),
              ],
            )),
          ],
        ),
      ),
    );
  }
}

class GrapgData {
  GrapgData(this.month, this.score);
  final String month;
  final int score;
}
