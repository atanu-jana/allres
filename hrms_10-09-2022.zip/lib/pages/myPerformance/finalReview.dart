import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/myPerformance/myPerformanceReviewDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class FinalReview extends StatefulWidget {
  // const FinalReview({
  //   Key? key,
  // }) : super(key: key);
  final Map<String, dynamic> singleData;
  final Map<String, dynamic> parentSingleData;
  final bool visible;
  final Function() callBack;
  const FinalReview(
      {Key? key,
      required this.singleData,
      required this.parentSingleData,
      required this.callBack,
      required this.visible})
      : super(key: key);

  @override
  _FinalReviewState createState() => _FinalReviewState();
}

class _FinalReviewState extends State<FinalReview> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.myPerformanceReview),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
            width: screenWidth,
            height: screenHeight,
                                  decoration:customBackgroundGradient(),

            child: ListView(
              children: [
                Container(
                  padding: EdgeInsets.all(1),
                  decoration: customCardItemGradinet(),
                  margin: customMarginCardItem(),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.03,
                    ),
                    decoration: BoxDecoration(
                        color: AllColor.lightBlueGrey,
                        borderRadius: BorderRadius.circular(7)),
                    width: screenWidth,
                    alignment: Alignment.centerLeft,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: headingText(
                              widget.singleData["kpiTemplate"].toString(),
                              color: AllColor.primaryDeepColor),
                        ),
                        Container(
                          // width: screenWidth * 0.45,
                          alignment: Alignment.centerLeft,
                          child: normalText(
                              "Reviewed Comment: " +
                                  widget.singleData["reviewComment"].toString(),
                              color: AllColor.black),
                        ),
                        Container(
                          child: smallText(
                              "Reviewed By: " +
                                  widget.singleData["reviewedBy"].toString(),
                              color: AllColor.black),
                        ),
                      widget.singleData["reviewDate"]==null? Container(): Container(
                          child: extraSmallText(
                              "Reviewed On: " +
                                  convertStringToDate(DateTime.parse(
                                          widget.singleData["reviewDate"]))
                                      .toString(),
                              color: AllColor.greyColor),
                        ),
                      ],
                    ),
                  ),
                ),
                widget.singleData["reviewAcceptStatus"].toString() == "1"
                    ? Container()
                    : Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03,
                            vertical: screenWidth * 0.01),
                        alignment: Alignment.centerLeft,
                        child: normalText(AllString.comments + ": ",
                            color: AllColor.black),
                      ),
                widget.singleData["reviewAcceptStatus"].toString() == "1"
                    ? Container()
                    : Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.comment + "*",
                            _commentTextEditingController,
                            2,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                widget.singleData["reviewAcceptStatus"].toString() == "1"
                    ? Container()
                    : Container(
                        child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            alignment: Alignment.centerLeft,
                            child: button(context, function: () {
                              if (_commentTextEditingController.text.isEmpty) {
                                commonAlertDialog(context, AllString.warning,
                                    AllString.enterComment);
                              } else {
                                acceptReviewRatingApi(
                                    "1"); //0=Pending,1=Accepted,2=Apply For Review
                              }
                            },color:
                            AllColor.primaryColor,
                                textColor: AllColor.white,
                                text: AllString.acceptRating,
                                width: screenWidth / 2.5),
                          ),
                          Container(
                            alignment: Alignment.centerLeft,
                            child: button(context, function: () {
                              if (_commentTextEditingController.text.isEmpty) {
                                commonAlertDialog(context, AllString.warning,
                                    AllString.enterComment);
                              } else {
                                acceptReviewRatingApi(
                                    "2"); //0=Pending,1=Accepted,2=Apply For Review
                              }
                            },
                             color: AllColor.primaryColor,
                                textColor: AllColor.white,
                                text: AllString.reviewRating,
                                width: screenWidth / 2.5),
                          )
                        ],
                      )),
              ],
            )),
      ),
    );
  }

  acceptReviewRatingApi(String acceptStatus) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });

      Map data = {
        "userLoginId": loginUserId.toString(),
        "employeeKpiId": widget.singleData["employeeKpiId"].toString(),
        "acceptStatus": acceptStatus.toString(),
        "acceptComment": _commentTextEditingController.text,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getAcceptReviewRating, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.pushReplacement(
                  context,
                  CupertinoPageRoute(
                      builder: (context) => MyPerformanceReviewDetails(
                          singleData: widget.parentSingleData,
                          callBack: widget.callBack,
                          visible: widget.visible)));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
