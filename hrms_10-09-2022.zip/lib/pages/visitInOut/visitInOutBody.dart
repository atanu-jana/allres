import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/recordAttendance/myAttendance.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/buttonWithIcon.dart';
import 'package:hr/widget/customIconRowDetails.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:permission_handler/permission_handler.dart';

class VisitInOutBody extends StatefulWidget {
  @override
  _VisitInOutBodyState createState() => _VisitInOutBodyState();
}

class _VisitInOutBodyState extends State<VisitInOutBody> {
  bool loading = false;
  List _fieldData = [];
  String location = "";
  String _selectCheckInOptions = AllString.office;
  late Position currentPosition;
  bool _showCheckOut = false;
  bool _visibleCheckInCheckOutOption = false;
  String _currentDealer = AllString.select;
  TextEditingController _officeTextEditingController = TextEditingController();
  FocusNode _officeFocusNode = FocusNode();
  TextEditingController _othersTextEditingController = TextEditingController();
  FocusNode _othersFocusNode = FocusNode();
  String _currentCategory = AllString.select;
  List<String> _categoryList = [AllString.select];
  String _currentBrand = AllString.select;
  String _currentProduct = AllString.select;
  List<String> _productList = [AllString.select];
  List<Map<String, dynamic>> _orderList = [];
  TextEditingController _orderQuentityTextEditingController =
      TextEditingController();
  FocusNode _orderQuentityFocusNode = FocusNode();
  TextEditingController _paymentAmountTextEditingController =
      TextEditingController();
  FocusNode _paymentAmountFocusNode = FocusNode();
  TextEditingController _paymentRemarksTextEditingController =
      TextEditingController();
  FocusNode _paymentRemarksAmountFocusNode = FocusNode();
  TextEditingController _conveyanceAmountTextEditingController =
      TextEditingController();
  FocusNode _conveyanceAmountFocusNode = FocusNode();
  TextEditingController _conveyanceRemarksTextEditingController =
      TextEditingController();
  TextEditingController _commentTextEditingController = TextEditingController();
  FocusNode _conveyanceRemarksAmountFocusNode = FocusNode();
  PickedFile? _paymentImageFile;
  String _paymentImageUrl = "";
  PickedFile? _attatchmentImageFile1;
  String _attatchmentImageUrl1 = "";
  PickedFile? _attatchmentImageFile2;
  String _attatchmentImageUrl2 = "";
  List<String> _purposeOfVisitList = [];
  String selectedPurposeOfVisit = AllString.select;

  @override
  void initState() {
    super.initState();
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.checkInOptionName)!);
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.checkInOptionNameWithId)!);
    getVisitOutField();
    Future.delayed(Duration(milliseconds: 300), () {
      setDropDownValueByDefaultUponCondition();
    });
    fetchPurposeOfVisit();

    checkAndFetchLocation();
    // checkOutAllOffileData();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: customBackgroundGradient(),
        child: _showCheckOut ? checkOutView() : checkInView(),
      ),
    );
  }

  getVisitOutField() async {
    if (await internetCheck()) {
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)
      };
      apiPostRequestWithHeader(
              data, AllUrls.getVisitOutField, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            sharedPreferences!.setString(
                AllSharedPreferencesKey.allCheckOutFields, response.toString());

            if (jsonData["fieldData"] == "") {
              _fieldData = [];
            } else {
              _fieldData = jsonData["fieldData"];
            }

            setState(() {});
          } else {
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      if (sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCheckOutFields) ==
              null ||
          sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCheckOutFields) ==
              "") {
        sharedPreferences!
            .setString(AllSharedPreferencesKey.allCheckOutFields, "");
      } else {
        Map<String, dynamic> jsonDataForField = json.decode(sharedPreferences!
            .getString(AllSharedPreferencesKey.allCheckOutFields)!);

        _fieldData = jsonDataForField["fieldData"];
      }
      log("allCheckOutFields: " +
          sharedPreferences!
              .getString(AllSharedPreferencesKey.allCheckOutFields)!);
      // showOfflineSnakbar(context);
    }
  }

  getCurrentLocation() async {
    if (await internetCheck()) {
      loading = true;
      setState(() {});
      Permission.location.request().then((value) async {
        var status = await Permission.location.status;
        log(status.toString());
        if (await Permission.location.isRestricted) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForRestrictedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          if (status.isDenied) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForDeniedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            // StreamSubscription positionStream = await Geolocator.getPositionStream(desiredAccuracy: LocationAccuracy.high,forceAndroidLocationManager: true).listen(
            //           (Position position) {
            //       });

            Position position = await Geolocator.getCurrentPosition(
                desiredAccuracy: LocationAccuracy.high);
            currentPosition = position;
            // location = position.latitude.toString() +
            //     " " +
            //     position.longitude.toString();
            // setState(() {});
            // GeoHasher geoHasher = GeoHasher();
            // location += geoHasher.encode(position.latitude, position.longitude,
            //     precision: 10);
            // setState(() {});
            sharedPreferences!.setString(
                AllSharedPreferencesKey.latitude, position.latitude.toString());
            sharedPreferences!.setString(AllSharedPreferencesKey.longitude,
                position.longitude.toString());
            List<Placemark> placemarks = await placemarkFromCoordinates(
                position.latitude, position.longitude);
            if (placemarks.isNotEmpty) {
              Placemark placeMark = placemarks[0];
              setState(() {});
              log(placeMark.toString());
              location = placeMark.locality! +
                  ", " +
                  placeMark.subLocality! +
                  " " +
                  placeMark.name! +
                  ", Street: " +
                  placeMark.street! +
                  ", " +
                  placeMark.administrativeArea! +
                  " " +
                  placeMark.subAdministrativeArea! +
                  ", Pincode: " +
                  placeMark.postalCode! +
                  ", " +
                  placeMark.country!;
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.location, location);
              loading = false;
              setState(() {});
            }
            setState(() {});
          }
        }
      });
    }
  }

  customCardForShowUserDetails({bool visibleOnlyLocation = false}) {
    return Container(
      padding: EdgeInsets.all(1),
      margin: customMarginCardItem(),
      decoration: customCardItemGradinet(),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth * 0.95,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            visibleOnlyLocation
                ? Container()
                : customIconRowDetails(
                    width: screenWidth * 0.95,
                    icon: Icons.person,
                    value: sharedPreferences!
                        .getString(AllSharedPreferencesKey.firstName)!),
            visibleOnlyLocation
                ? Container()
                : customIconRowDetails(
                    width: screenWidth * 0.95,
                    icon: Icons.email,
                    value: checkApiValueValid(sharedPreferences!
                            .getString(AllSharedPreferencesKey.email)!)
                        ? AllString.na
                        : sharedPreferences!
                            .getString(AllSharedPreferencesKey.email)!),
            visibleOnlyLocation
                ? Container()
                : customIconRowDetails(
                    width: screenWidth * 0.95,
                    icon: Icons.phone_android,
                    value: sharedPreferences!
                        .getString(AllSharedPreferencesKey.contact1)!),
            customIconRowDetails(
                width: screenWidth * 0.95,
                icon: Icons.location_on,
                value: sharedPreferences!
                                .getString(AllSharedPreferencesKey.location) ==
                            null ||
                        sharedPreferences!
                            .getString(AllSharedPreferencesKey.location)!
                            .toString()
                            .isEmpty
                    ? AllString.na
                    : "Location: " +
                        sharedPreferences!
                            .getString(AllSharedPreferencesKey.location)!,
                displayFullValue: true),
            visibleOnlyLocation
                ? Container()
                : GestureDetector(
                    onTap: () {
                      checkAndFetchLocation();
                    },
                    child: Container(
                      height: screenWidth * 0.1,
                      decoration: BoxDecoration(
                        color: AllColor.primaryDeepColor,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: screenWidth * 0.08,
                            height: screenWidth * 0.06,
                            child: normalIcon(Icons.location_searching),
                          ),
                          Container(
                            child: normalText(AllString.refreshYourLocation,
                                color: AllColor.white),
                          )
                        ],
                      ),
                    ),
                  )
          ],
        ),
      ),
    );
  }

  customCheckInOption() {
    return Container(
      padding: EdgeInsets.all(1),
      margin: customMarginCardItem(),
      decoration: customCardItemGradinet(),
      width: screenWidth * 0.95,
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            Container(
              width: screenWidth * 0.95,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectCheckInOptions = AllString.office;
                        AppBuilder.of(context)!.rebuild();
                      });
                    },
                    child: Container(
                      color: AllColor.white,
                      margin: EdgeInsets.only(left: screenWidth * 0.01),
                      width: screenWidth * 0.27,
                      alignment: Alignment.center,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Radio(
                            activeColor: AllColor.primaryColor,
                            value: AllString.office,
                            groupValue: _selectCheckInOptions,
                            onChanged: (String? value) {
                              setState(() {
                                _selectCheckInOptions = value!;
                                AppBuilder.of(context)!.rebuild();
                              });
                            },
                          ),
                          Container(
                            margin: EdgeInsets.only(left: screenWidth * 0.01),
                            child: smallText(AllString.office,
                                color: AllColor.black),
                          )
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectCheckInOptions = AllString.dealer;
                        AppBuilder.of(context)!.rebuild();
                      });
                    },
                    child: Container(
                      color: AllColor.white,
                      margin: EdgeInsets.only(left: screenWidth * 0.01),
                      width: screenWidth * 0.27,
                      alignment: Alignment.center,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Radio(
                            activeColor: AllColor.primaryColor,
                            value: AllString.dealer,
                            groupValue: _selectCheckInOptions,
                            onChanged: (String? value) {
                              setState(() {
                                _selectCheckInOptions = value!;
                                AppBuilder.of(context)!.rebuild();
                              });
                            },
                          ),
                          Container(
                            margin: EdgeInsets.only(left: screenWidth * 0.01),
                            child: smallText(
                                AllString.dealer + " /\n" + AllString.customer,
                                color: AllColor.black),
                          )
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectCheckInOptions = AllString.others;
                        AppBuilder.of(context)!.rebuild();
                      });
                    },
                    child: Container(
                      color: AllColor.white,
                      margin: EdgeInsets.only(left: screenWidth * 0.01),
                      width: screenWidth * 0.27,
                      alignment: Alignment.center,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Radio(
                            activeColor: AllColor.primaryColor,
                            value: AllString.others,
                            groupValue: _selectCheckInOptions,
                            onChanged: (String? value) {
                              setState(() {
                                _selectCheckInOptions = value!;
                                AppBuilder.of(context)!.rebuild();
                              });
                            },
                          ),
                          Container(
                            margin: EdgeInsets.only(left: screenWidth * 0.01),
                            child: smallText(AllString.others,
                                color: AllColor.black),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_selectCheckInOptions == AllString.office)
              Container(
                margin: customMarginCardItem(),
                width: screenWidth * 0.95,
                child: Container(
                    child: RoundedInputField(
                  controller: _officeTextEditingController,
                  focusNode: _officeFocusNode,
                  textInputAction: TextInputAction.next,
                  textInputType: TextInputType.text,
                  hintText: AllString.office,
                  errorText: "",
                  showToolTip: false,
                  icon: LineIcons.desktop,
                  onchangeFunction: (String val) {
                    setState(() {});
                  },
                )),
              )
            else if (_selectCheckInOptions == AllString.dealer)
              // Container(
              //   margin: customMarginCardItem(),
              //   width: screenWidth * 0.95,
              //   child: Container(
              //       child: dropdownButton(dealerList, (String? newValue) {
              //     setState(() {
              //       _currentDealer = newValue!;
              //     });
              //   }, _currentDealer)),
              // )
              Container(
                  margin: customMarginCardItem(),
                  width: screenWidth * 0.95,
                  child: DropdownButtonWithSearchForDealerList(
                    icon: LineIcons.sortAmountDown,
                    selectedValue: _currentDealer,
                    dropdownList: dealerList,
                    onChanged: (String? newValue) {
                      setState(() {
                        _currentDealer = newValue!;
                      });
                    },
                  ))
            else if (_selectCheckInOptions == AllString.others)
              Container(
                margin: customMarginCardItem(),
                width: screenWidth * 0.95,
                child: Container(
                    child: RoundedInputField(
                  controller: _othersTextEditingController,
                  focusNode: _othersFocusNode,
                  textInputAction: TextInputAction.next,
                  textInputType: TextInputType.text,
                  hintText: AllString.others,
                  errorText: "",
                  showToolTip: false,
                  icon: LineIcons.flag,
                  onchangeFunction: (String val) {
                    setState(() {});
                  },
                )),
              ),
            checkForExpenseAndVisitPurpose
                ? Container(
                    margin: customMarginCardItem(),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        textFieldHeader(AllString.purposeOfVisit,
                            fontWeight: FontWeight.bold),
                        dropdownButton(_purposeOfVisitList,
                            onDropdownPurposeOfVisit, selectedPurposeOfVisit),
                      ],
                    ),
                  )
                : Container(),
            Container(
              width: screenWidth * 0.95,
              margin: AllMargin.customTop(),
              height: screenWidth * 0.1,
              decoration: BoxDecoration(
                color: AllColor.primaryDeepColor,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _visibleCheckInCheckOutOption = false;
                      });
                    },
                    child: Container(
                        width: (screenWidth * 0.95) / 2.1,
                        height: screenWidth * 0.1,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AllColor.primaryDeepColor,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          ),
                        ),
                        child: Container(
                          child: Text(AllString.cancel,
                              textAlign: TextAlign.center,
                              style: normalTextStyle(color: AllColor.white)),
                        )),
                  ),
                  Container(
                    height: screenWidth * 0.1,
                    width: screenWidth * 0.006,
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: screenWidth * 0.006,
                      height: screenWidth * 0.08,
                      decoration: BoxDecoration(
                        color: AllColor.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      if (validateCheckInAndProceed()) {
                        if (await internetCheck()) {
                          loading = true;
                          setState(() {});
                          Permission.location.request().then((value) async {
                            var status = await Permission.location.status;
                            log(status.toString());
                            if (await Permission.location.isRestricted) {
                              commonAlertDialog(context, AllString.error,
                                  AllString.msgForRestrictedLocation,
                                  function: () {
                                Navigator.of(context).pushReplacement(
                                    CupertinoPageRoute(
                                        builder: (context) => Home()));
                              });
                            } else {
                              if (status.isDenied) {
                                commonAlertDialog(context, AllString.error,
                                    AllString.msgForDeniedLocation,
                                    function: () {
                                  Navigator.of(context).pushReplacement(
                                      CupertinoPageRoute(
                                          builder: (context) => Home()));
                                });
                              } else {
                                // StreamSubscription positionStream = await Geolocator.getPositionStream(desiredAccuracy: LocationAccuracy.high,forceAndroidLocationManager: true).listen(
                                //           (Position position) {
                                //       });

                                Position position =
                                    await Geolocator.getCurrentPosition(
                                        desiredAccuracy: LocationAccuracy.high);
                                currentPosition = position;
                                // location = position.latitude.toString() +
                                //     " " +
                                //     position.longitude.toString();
                                // setState(() {});
                                // GeoHasher geoHasher = GeoHasher();
                                // location += geoHasher.encode(position.latitude, position.longitude,
                                //     precision: 10);
                                // setState(() {});
                                sharedPreferences!.setString(
                                    AllSharedPreferencesKey.latitude,
                                    position.latitude.toString());
                                sharedPreferences!.setString(
                                    AllSharedPreferencesKey.longitude,
                                    position.longitude.toString());
                                List<Placemark> placemarks =
                                    await placemarkFromCoordinates(
                                        position.latitude, position.longitude);
                                if (placemarks.isNotEmpty) {
                                  Placemark placeMark = placemarks[0];
                                  setState(() {});
                                  log(placeMark.toString());
                                  location = placeMark.locality! +
                                      ", " +
                                      placeMark.subLocality! +
                                      " " +
                                      placeMark.name! +
                                      ", Street: " +
                                      placeMark.street! +
                                      ", " +
                                      placeMark.administrativeArea! +
                                      " " +
                                      placeMark.subAdministrativeArea! +
                                      ", Pincode: " +
                                      placeMark.postalCode! +
                                      ", " +
                                      placeMark.country!;
                                  sharedPreferences!.setString(
                                      AllSharedPreferencesKey.location,
                                      location);
                                  checkIn();
                                }
                                setState(() {});
                              }
                            }
                          });
                        } else {
                          // offlineCheckIn();
                        }
                      }
                    },
                    child: Container(
                        alignment: Alignment.center,
                        width: (screenWidth * 0.95) / 2.1,
                        height: screenWidth * 0.1,
                        decoration: BoxDecoration(
                          color: AllColor.primaryDeepColor,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          ),
                        ),
                        child: Container(
                          child: Text(AllString.ok,
                              textAlign: TextAlign.center,
                              style: normalTextStyle(color: AllColor.white)),
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  onDropdownPurposeOfVisit(String? value) {
    selectedPurposeOfVisit = value!;
    setState(() {});
  }

  bool validateCheckInAndProceed() {
// *** Validate Office
    if (_selectCheckInOptions.isEmpty) {
      return false;
    } else if (_selectCheckInOptions == AllString.office) {
      if (_officeTextEditingController.text.isNotEmpty) {
        return true;
      } else {
        return false;
      }
    } else if (_selectCheckInOptions == AllString.dealer) {
      if (_currentDealer == AllString.select || _currentDealer == "") {
        return false;
      } else {
        return true;
      }
    } else if (_selectCheckInOptions == AllString.others) {
      if (_othersTextEditingController.text.isNotEmpty) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  bool validateCheckOutAndProceed() {
    if (sharedPreferences!.getString(AllSharedPreferencesKey.checkInOption)! ==
        AllString.office) {
      if (_attatchmentImageFile1 == null ||
          _commentTextEditingController.text.isEmpty) {
        return false;
      } else {
        return true;
      }
    } else {
      // if (_conveyanceRemarksTextEditingController.text.isEmpty) {
      //   return false;
      // } else if (_attatchmentImageFile1 == null) {
      if (_attatchmentImageFile1 == null ||
          _commentTextEditingController.text.isEmpty) {
        return false;
      } else {
        return true;
      }
    }
    // return true;
  }

  checkInView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              children: [
                Container(
                  width: screenWidth,
                  alignment: Alignment.center,
                  child: customCardForShowUserDetails(),
                ),
                _visibleCheckInCheckOutOption
                    ? Container(
                        width: screenWidth,
                        alignment: Alignment.center,
                        child: customCheckInOption(),
                      )
                    : Container(),
              ],
            ),
            _visibleCheckInCheckOutOption
                ? Container()
                : Container(
                    margin: EdgeInsets.symmetric(
                        vertical: _visibleCheckInCheckOutOption
                            ? screenWidth * 0.1
                            : screenWidth * 0.45,
                        horizontal: screenWidth * 0.03),
                    child: buttonWithIcon(
                      context,
                      icon: Icons.check,
                      function: () {
                        FocusManager.instance.primaryFocus?.unfocus();
                        // requestBodyForOffileCheckInAndCheckOut();
                        if (sharedPreferences!.getString(
                                    AllSharedPreferencesKey.checkInOption) ==
                                null ||
                            sharedPreferences!.getString(
                                    AllSharedPreferencesKey.checkInOption) ==
                                "") {
                          if (_visibleCheckInCheckOutOption) {
                            if (validateCheckInAndProceed()) {
                              checkIn();
                            }
                          } else {
                            _visibleCheckInCheckOutOption = true;
                            setState(() {});
                          }
                        } else {
                          _showCheckOut = true;
                          setState(() {});
                        }
                      },
                      color1: _visibleCheckInCheckOutOption
                          ? validateCheckInAndProceed()
                              ? Color(0xff536976)
                              : AllColor.greyColor
                          : Color(0xff536976),
                      color2: _visibleCheckInCheckOutOption
                          ? validateCheckInAndProceed()
                              ? AllColor.primaryColor
                              : AllColor.greyColor
                          : AllColor.primaryColor,
                      textColor: AllColor.white,
                      text: sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption) ==
                                  null ||
                              sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption) ==
                                  ""
                          ? AllString.checkIn
                          : AllString.checkOut,
                    ),
                  )
          ],
        ),
      ),
    );
  }

  checkOutView() {
    return _fieldData.isEmpty
        ? Container()
        : Stack(
            children: [
              ListView(
                shrinkWrap: true,
                children: [
                  Container(
                    width: screenWidth,
                    alignment: Alignment.center,
                    child:
                        customCardForShowUserDetails(visibleOnlyLocation: true),
                  ),
                  Container(
                    margin: customMarginCardItem(),
                    child: Row(
                      children: [
                        Container(
                          child: Text(
                              sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption)! +
                                  " Name: ",
                              style: normalTextStyle(
                                  color: AllColor.black,
                                  fontWeight: FontWeight.bold)),
                        ),
                        SizedBox(
                          width: screenWidth * 0.02,
                        ),
                        Container(
                          width: screenWidth * 0.65,
                          child: Text(
                              sharedPreferences!.getString(
                                  AllSharedPreferencesKey.checkInOptionName)!,
                              style: normalTextStyle(
                                  color: AllColor.black,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ),
                  _fieldData[0]["activeStatus"].toString() == "1"
                      ? Container(
                          margin: EdgeInsets.symmetric(
                              vertical: screenWidth * 0.02),
                          child: Row(
                            children: [
                              textFieldHeader(
                                  _fieldData[0]["fieldName"].toString(),
                                  // AllString.addOrder,
                                  fontWeight: FontWeight.bold),
                              GestureDetector(
                                onTap: () => addOrderDialog(),
                                // child: normalIcon(Icons.add, color: AllColor.deepGreen),
                                child: Center(
                                    child: SvgPicture.asset(
                                  "assets/images/addButton.svg",
                                  color: AllColor.deepGreen,
                                  height: screenWidth * 0.06,
                                  // width: screenWidth * 0.06,
                                )),
                              )
                            ],
                          ),
                        )
                      : Container(),
                  _orderList.isEmpty
                      ? Container()
                      : Container(
                          height: screenWidth * 0.1,
                          padding: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.1,
                          ),
                          decoration: BoxDecoration(
                            color: AllColor.tableBackground,
                          ),
                          width: screenWidth,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: screenWidth * 0.25,
                                child: Text(
                                  "Category Name",
                                  textAlign: TextAlign.center,
                                  style: smallTextStyle(color: AllColor.white),
                                ),
                              ),
                              Container(
                                width: screenWidth * 0.25,
                                child: Text(
                                  "Product Name",
                                  textAlign: TextAlign.center,
                                  style: smallTextStyle(color: AllColor.white),
                                ),
                              ),
                              Container(
                                width: screenWidth * 0.16,
                                child: Text(
                                  "Quantity",
                                  textAlign: TextAlign.center,
                                  style: smallTextStyle(color: AllColor.white),
                                ),
                              ),
                              Container(
                                width: screenWidth * 0.1,
                              ),
                            ],
                          ),
                        ),
                  _orderList.isEmpty
                      ? Container()
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: _orderList.length,
                          itemBuilder: (context, index) =>
                              customOrderItem(_orderList[index])),
                  checkOutPaymentCard(),
                  sharedPreferences!.getString(
                              AllSharedPreferencesKey.checkInOption)! ==
                          AllString.office
                      ? Container()
                      : checkOutConveyanceCard(),
                  checkOutCommentCard(),
                  checkOutAttatchmentCard(),
                  Container(
                      margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03),
                      child: buttonWithIcon(
                        context,
                        icon: Icons.check,
                        function: () async {
                          FocusManager.instance.primaryFocus?.unfocus();
                          if (validateCheckOutAndProceed()) {
                            if (await internetCheck()) {
                              loading = true;
                              setState(() {});
                              Permission.location.request().then((value) async {
                                var status = await Permission.location.status;
                                log(status.toString());
                                if (await Permission.location.isRestricted) {
                                  commonAlertDialog(context, AllString.error,
                                      AllString.msgForRestrictedLocation,
                                      function: () {
                                    Navigator.of(context).pushReplacement(
                                        CupertinoPageRoute(
                                            builder: (context) => Home()));
                                  });
                                } else {
                                  if (status.isDenied) {
                                    commonAlertDialog(context, AllString.error,
                                        AllString.msgForDeniedLocation,
                                        function: () {
                                      Navigator.of(context).pushReplacement(
                                          CupertinoPageRoute(
                                              builder: (context) => Home()));
                                    });
                                  } else {
                                    // StreamSubscription positionStream = await Geolocator.getPositionStream(desiredAccuracy: LocationAccuracy.high,forceAndroidLocationManager: true).listen(
                                    //           (Position position) {
                                    //       });

                                    Position position =
                                        await Geolocator.getCurrentPosition(
                                            desiredAccuracy:
                                                LocationAccuracy.high);
                                    currentPosition = position;
                                    // location = position.latitude.toString() +
                                    //     " " +
                                    //     position.longitude.toString();
                                    // setState(() {});
                                    // GeoHasher geoHasher = GeoHasher();
                                    // location += geoHasher.encode(position.latitude, position.longitude,
                                    //     precision: 10);
                                    // setState(() {});
                                    sharedPreferences!.setString(
                                        AllSharedPreferencesKey.latitude,
                                        position.latitude.toString());
                                    sharedPreferences!.setString(
                                        AllSharedPreferencesKey.longitude,
                                        position.longitude.toString());
                                    List<Placemark> placemarks =
                                        await placemarkFromCoordinates(
                                            position.latitude,
                                            position.longitude);
                                    if (placemarks.isNotEmpty) {
                                      Placemark placeMark = placemarks[0];
                                      setState(() {});
                                      log(placeMark.toString());
                                      location = placeMark.locality! +
                                          ", " +
                                          placeMark.subLocality! +
                                          " " +
                                          placeMark.name! +
                                          ", Street: " +
                                          placeMark.street! +
                                          ", " +
                                          placeMark.administrativeArea! +
                                          " " +
                                          placeMark.subAdministrativeArea! +
                                          ", Pincode: " +
                                          placeMark.postalCode! +
                                          ", " +
                                          placeMark.country!;
                                      sharedPreferences!.setString(
                                          AllSharedPreferencesKey.location,
                                          location);
                                      checkOut();
                                    }
                                    setState(() {});
                                  }
                                }
                              });
                            } else {
                              offlineCheckOut();
                            }
                          }
                        },
                        color1: validateCheckOutAndProceed()
                            ? AllColor.primaryColor
                            : AllColor.greyColor,
                        color2: validateCheckOutAndProceed()
                            ? AllColor.primaryColor
                            : AllColor.greyColor,
                        textColor: AllColor.white,
                        text: AllString.checkOut,
                      )),
                ],
              )
            ],
          );
  }

  customOrderItem(Map<String, dynamic> orderItem) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 3),
      decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: AllColor.greyColor))),
      margin: customMarginCardItem(),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: screenWidth * 0.005),
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: screenWidth * 0.25,
              child: Text(
                orderItem["categoryName"],
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.greyColor),
              ),
            ),
            Container(
              width: screenWidth * 0.25,
              child: Text(
                orderItem["productName"],
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.greyColor),
              ),
            ),
            Container(
              width: screenWidth * 0.16,
              child: Text(
                orderItem["quantity"].toString(),
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.greyColor),
              ),
            ),
            GestureDetector(
              onTap: () {
                _orderList.remove(orderItem);
                setState(() {});
                // _orderList.forEach((element) {if(
                //   element["categoryId"].toString()==orderItem["categoryId"]){
                //   }
                // });
              },
              child: Container(
                width: screenWidth * 0.1,
                child: smallIcon(Icons.close, color: AllColor.red),
              ),
            ),
          ],
        ),
      ),
    );
  }

  fetchProduct(String productId) {
    setState(() {
      loading = true;
    });
    _currentDealer = _currentDealer;
    _productList.clear();
    setState(() {});

    _productList.add(AllString.select);

    setState(() {});
    Navigator.pop(context);

    // loading = true;
    // setState(() {});
    // Map data = {
    //   "companyId":
    //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
    //   "divisionId": _currentCategory.split(AllString.splitText).last
    // };
    // apiPostRequestWithHeader(
    //         data, AllUrls.getModelByDivision, this.context, loginToken)
    //     .then((response) {
    //   if (response == null) {
    //     loading = false;
    //     setState(() {});
    //     commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    //   } else {
    //     Map<String, dynamic> jsonData = json.decode(response);
    //     if (checkApiResponseSuccessOrNot(jsonData)) {
    // if (jsonData["modelData"] == "" || jsonData["modelData"] == []) {
    //   _productList = [];
    // } else {
    //   List _tempList = jsonData["modelData"];
    //   _tempList.forEach((element) {
    //     _productList.add(element["modelNo"].toString() +
    //         AllString.splitText +
    //         element["productModelId"].toString());
    //   });
    // }

    // if (_productList.length == 2) {
    //   _currentProduct = _productList.last;
    // }
    // _currentDealer = _currentDealer;

    // AppBuilder.of(context)!.rebuild();
    // Future.delayed(Duration(milliseconds: 300), () {
    //   _currentDealer = _currentDealer;

    //   addOrderDialog();
    //   setState(() {
    //     loading = false;
    //   });
    // });
    //     } else {
    //       setState(() {
    //         loading = false;
    //       });
    //       commonAlertDialog(context, jsonData["status"], jsonData["message"]);
    //     }
    //   }
    // });
    if (sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            null ||
        sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            "") {
      sharedPreferences!
          .setString(AllSharedPreferencesKey.allCommonDataJson, "");
    } else {
      Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
          .getString(AllSharedPreferencesKey.allCommonDataJson)!);
      log(json.encode(jsonDataForCommon));
      if (jsonDataForCommon["commonData"]["modelDetails"] == "" ||
          jsonDataForCommon["commonData"]["modelDetails"] == []) {
        _productList = [];
      } else {
        List _tempList = jsonDataForCommon["commonData"]["modelDetails"];
        _tempList.forEach((element) {
          if (element["productCategoryId"].toString() == productId) {
            _productList.add(element["modelNo"].toString() +
                AllString.splitText +
                element["productModelId"].toString());
          }
        });

        if (_productList.length == 2) {
          _currentProduct = _productList.last;
        }
        _currentDealer = _currentDealer;

        AppBuilder.of(context)!.rebuild();
        Future.delayed(Duration(milliseconds: 300), () {
          _currentDealer = _currentDealer;

          addOrderDialog();
          setState(() {
            loading = false;
          });
        });
      }

      // Map<String, dynamic> jsonDataForAllProduct = json.decode(
      //     sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
      // List tempListForAllProduct = jsonDataForAllProduct["data"];
      // tempListForAllProduct.forEach((element) {
      //   if (element["categoryId"].toString() == productId) {
      //     _productList.add(element["productname"].toString() +
      //         AllString.splitText +
      //         element["productId"].toString());
      //   }
      // });
    }
  }

  addOrderDialog() {
    commonAlertDialogWithCloseButtonWithWidget(
        context,
        AllColor.red,
        Column(
          children: [
            textFieldHeader(AllString.selectBrand),
            Container(
              child: DropdownButtonWithSearchForBrandList(
                icon: LineIcons.sortAmountDown,
                selectedValue: _currentBrand,
                dropdownList: brandList,
                onChanged: (String? newValue) {
                  _currentBrand = newValue!;
                  AppBuilder.of(context)!.rebuild();
                  fetchCategory(_currentBrand.split(AllString.splitText).last);
                },
              ),
            ),
            textFieldHeader(AllString.selectCategory),
            // textFieldHeader(
            //     _currentBrand.split(AllString.splitText).last.toString()),
            Container(
              child: DropdownButtonWithSearchForLocalCategory(
                icon: LineIcons.sortAmountDown,
                selectedValue: _currentCategory,
                dropdownList: _categoryList,
                onChanged: (String? newValue) {
                  _currentCategory = newValue!;
                  AppBuilder.of(context)!.rebuild();
                  fetchProduct(
                      _currentCategory.split(AllString.splitText).last);
                },
              ),
              //     child: dropdownButton(categoryList, (String? newValue) {
              // _currentCategory = newValue!;
              // AppBuilder.of(context)!.rebuild();
              // fetchProduct(_currentCategory.split(AllString.splitText).last);
              // }, _currentCategory)
            ),
            _productList.length == 1
                ? Container()
                : textFieldHeader(AllString.selectProduct),
            _productList.length == 1
                ? Container()
                : Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentProduct,
                      dropdownList: _productList,
                      onChanged: (String? newValue) {
                        _currentProduct = newValue!;
                        setState(() {});
                        log(_currentProduct);
                        AppBuilder.of(context)!.rebuild();
                        Navigator.pop(context);
                        addOrderDialog();
                      },
                    ),
                    //   child: dropdownButton(_productList, (String? newValue) {
                    // _currentProduct = newValue!;
                    // setState(() {});
                    // log(_currentProduct);
                    // AppBuilder.of(context)!.rebuild();
                    // Navigator.pop(context);
                    // addOrderDialog();
                    // }, _currentProduct)
                  ),
            (_currentCategory == AllString.select || _currentCategory == "") ||
                    (_currentProduct == AllString.select ||
                        _currentProduct == "")
                ? Container()
                : textFieldHeader(AllString.enterQuantity),
            (_currentCategory == AllString.select || _currentCategory == "") ||
                    (_currentProduct == AllString.select ||
                        _currentProduct == "")
                ? Container()
                : Container(
                    child: RoundedInputField(
                    controller: _orderQuentityTextEditingController,
                    focusNode: _orderQuentityFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    hintText: AllString.quantity,
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.sortNumericUp,
                    onchangeFunction: (String val) {},
                  )),
            Container(
                margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.015,
                    horizontal: screenWidth * 0.03),
                child: button(
                  context,
                  function: () {
                    if (_currentCategory == AllString.select) {
                      commonAlertDialog(
                          context, AllString.warning, "Select category");
                    }
                    if (_productList.isEmpty || _productList.length == 1) {
                      commonAlertDialog(
                          context, AllString.warning, "No product found");
                    } else if (_currentProduct == AllString.select) {
                      commonAlertDialog(
                          context, AllString.warning, "Select product");
                    } else if (_orderQuentityTextEditingController
                        .text.isEmpty) {
                      commonAlertDialog(
                          context, AllString.warning, "Enter quantity");
                    } else {
                      Map<String, dynamic> jsonData = {
                        "categoryId":
                            _currentCategory.split(AllString.splitText).last,
                        "categoryName":
                            _currentCategory.split(AllString.splitText).first,
                        "productId":
                            _currentProduct.split(AllString.splitText).last,
                        "brandId":
                            _currentBrand.split(AllString.splitText).last,
                        "productName":
                            _currentProduct.split(AllString.splitText).first,
                        "quantity": _orderQuentityTextEditingController.text
                      };
                      _orderList.add(jsonData);
                      setState(() {});
                      clearAllDataForAddOrder();
                      Navigator.pop(context);
                    }
                  },
                  color: AllColor.primaryColor,
                  textColor: AllColor.white,
                  width: screenWidth - 200,
                  text: AllString.add,
                )),
          ],
        ), onCloseButtonPress: () {
      clearAllDataForAddOrder();
      // if (categoryList.length == 2) {
      //   _currentCategory = categoryList.last;
      //   setState(() {});
      //   _productList.clear();
      //   _categoryList.clear();

      //   _productList.add(AllString.select);

      //   setState(() {});
      //   Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
      //       .getString(AllSharedPreferencesKey.allCommonDataJson)!);

      //   if (jsonDataForCommon["modelDetails"] == "" ||
      //       jsonDataForCommon["modelDetails"] == []) {
      //     _productList = [];
      //   } else {
      //     List _tempList = jsonDataForCommon["modelDetails"];
      //     _tempList.forEach((element) {
      //       if (element["productCategoryId"].toString() ==
      //           _currentCategory.split(AllString.splitText).first) {
      //         _productList.add(element["modelNo"].toString() +
      //             AllString.splitText +
      //             element["productModelId"].toString());
      //       }
      //     });
      //   }

      //   // Map<String, dynamic> jsonDataForAllProduct = json.decode(
      //   //     sharedPreferences!
      //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
      //   // List tempListForAllProduct = jsonDataForAllProduct["data"];
      //   // tempListForAllProduct.forEach((element) {
      //   //   if (element["categoryId"].toString() ==
      //   //       _currentCategory.split(AllString.splitText).last) {
      //   //     _productList.add(element["productname"].toString() +
      //   //         AllString.splitText +
      //   //         element["productId"].toString());
      //   //   }
      //   // });
      //   if (_productList.length == 2) {
      //     _currentProduct = _productList.last;
      //   }
      // }

      Navigator.pop(context);
    });
  }

  clearAllDataForAddOrder() {
    _currentDealer = _currentDealer;
    _currentCategory = AllString.select;
    _currentProduct = AllString.select;
    _productList.clear();
    _productList.add(AllString.select);
    _orderQuentityTextEditingController.clear();
    setState(() {});
  }

  checkOutPaymentCard() {
    return Container(
      padding: EdgeInsets.all(1),
      margin: customMarginCardItem(),
      decoration: customCardItemGradinet(),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth * 0.85,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _fieldData[1]["activeStatus"].toString() == "1"
                ? textFieldHeader(
                    _fieldData[1]["fieldName"].toString(),
                    // AllString.paymentAmount
                  )
                : Container(),
            _fieldData[1]["activeStatus"].toString() == "1"
                ? Container(
                    child: RoundedInputField(
                    controller: _paymentAmountTextEditingController,
                    focusNode: _paymentAmountFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    // hintText: AllString.enterAmount,
                    hintText: AllString.enter +
                        " " +
                        _fieldData[1]["fieldName"].toString(),
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.handHoldingUsDollar,
                    onchangeFunction: (String val) {
                      // if (val.isNotEmpty && int.parse(val) >= 5001) {
                      //   _paymentAmountTextEditingController.text = "";
                      // }
                      setState(() {});
                    },
                  ))
                : Container(),
            _fieldData[2]["activeStatus"].toString() == "1"
                ? textFieldHeader(_fieldData[2]["fieldName"].toString()
                    // AllString.paymentRemark
                    )
                : Container(),
            _fieldData[2]["activeStatus"].toString() == "1"
                ? Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enter +
                            " " +
                            _fieldData[2]["fieldName"].toString(),

                        // AllString.enterRemark,
                        _paymentRemarksTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  )
                : Container(),
            _fieldData[3]["activeStatus"].toString() == "1"
                ? textFieldHeader(_fieldData[3]["fieldName"].toString(),
                    // AllString.uploadAttachment,
                    fontWeight: FontWeight.bold)
                : Container(),

            _fieldData[3]["activeStatus"].toString() == "1"
                ? Container(
                    margin: EdgeInsets.only(
                      bottom: screenWidth * 0.03,
                      left: screenWidth * 0.03,
                      right: screenWidth * 0.03,
                    ),
                    child: Row(
                      children: [
                        Container(
                          child: GestureDetector(
                            onTap: () {
                              _onImageButtonPressed(ImageSource.camera,
                                  paymentImage: true,
                                  attatchmentImage1: false,
                                  attatchmentImage2: false);
                              // pickImageOption();
                            },
                            child: Stack(
                              children: [
                                Container(
                                  width: screenWidth * 0.2,
                                  height: screenWidth * 0.2,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    color: AllColor.greyColor.withOpacity(0.5),
                                  ),
                                  child: Material(
                                    color: AllColor.lightBlack.withOpacity(0.5),
                                    //display new updated image here
                                    child: _paymentImageFile == null
                                        ? mediumIcon(Icons.attach_file,
                                            color: AllColor.black)
                                        : Image.file(
                                            File(_paymentImageFile!.path),
                                            fit: BoxFit.cover,
                                          ),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    clipBehavior: Clip.hardEdge,
                                  ),
                                ),
                                _paymentImageFile == null
                                    ? Container()
                                    : Positioned(
                                        top: screenWidth * 0.01,
                                        right: screenWidth * 0.01,
                                        child: GestureDetector(
                                          onTap: () {
                                            _paymentImageFile = null;
                                            setState(() {});
                                          },
                                          child: Container(
                                            child: normalIcon(Icons.close),
                                          ),
                                        ))
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : Container(),

            // GestureDetector(
            //   onTap: () {
            //     _onImageButtonPressed(ImageSource.camera,
            //         paymentImage: true,
            //         attatchmentImage1: false,
            //         attatchmentImage2: false);
            //     // pickImageOption(
            //     //   paymentImage: true,
            //     //     attatchmentImage1: false,
            //     //     attatchmentImage2: false
            //     //   );
            //   },
            //   child: Container(
            //     height: screenWidth * 0.08,
            //     width: screenWidth,
            //     margin: EdgeInsets.symmetric(
            //         horizontal: screenWidth * 0.03,
            //         vertical: screenWidth * 0.02),
            //     padding: EdgeInsets.symmetric(
            //       horizontal: screenWidth * 0.015,
            //     ),
            //     alignment: Alignment.center,
            //     decoration: BoxDecoration(
            //         border: Border.all(
            //             style: BorderStyle.solid, color: AllColor.greyColor),
            //         color: AllColor.lightBlack,
            //         borderRadius: BorderRadius.circular(7)),
            //     child: Row(
            //       children: [
            //         normalIcon(Icons.attachment_outlined,
            //             color: AllColor.greyColor),
            //         Container(
            //           width: screenWidth * 0.03,
            //         ),
            //         normalText(AllString.uploadAttachment,
            //             color: AllColor.black.withOpacity(0.7))
            //       ],
            //     ),
            //   ),
            // ),
            // _paymentImageFile == null
            //     ? Container()
            //     : Center(
            //         child: Stack(
            //           children: [
            //             Container(
            //               width: screenWidth * 0.2,
            //               height: screenWidth * 0.2,
            //               decoration: BoxDecoration(
            //                 borderRadius: BorderRadius.all(Radius.circular(5)),
            //                 color: AllColor.greyColor.withOpacity(0.5),
            //               ),
            //               child: Material(
            //                 //display new updated image here
            //                 child: Image.file(
            //                   File(_paymentImageFile!.path),
            //                   fit: BoxFit.cover,
            //                 ),
            //                 borderRadius: BorderRadius.all(Radius.circular(5)),
            //                 clipBehavior: Clip.hardEdge,
            //               ),
            //             ),
            //             Positioned(
            //                 top: screenWidth * 0.01,
            //                 right: screenWidth * 0.01,
            //                 child: GestureDetector(
            //                   onTap: () {
            //                     _paymentImageFile = null;
            //                     setState(() {});
            //                   },
            //                   child: Container(
            //                     child: normalIcon(Icons.close),
            //                   ),
            //                 ))
            //           ],
            //         ),
            //       ),
          ],
        ),
      ),
    );
  }

  checkOutConveyanceCard() {
    return Container(
      padding: EdgeInsets.all(1),
      margin: customMarginCardItem(),
      decoration: customCardItemGradinet(),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth * 0.85,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _fieldData[4]["activeStatus"].toString() == "1"
                ? textFieldHeader(_fieldData[4]["fieldName"].toString()
                    // AllString.conveyanceAmount

                    )
                : Container(),
            _fieldData[4]["activeStatus"].toString() == "1"
                ? Container(
                    child: RoundedInputField(
                    controller: _conveyanceAmountTextEditingController,
                    focusNode: _conveyanceAmountFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    // hintText: AllString.enterAmount,
                    hintText: AllString.enter +
                        " " +
                        _fieldData[4]["fieldName"].toString(),
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.handHoldingUsDollar,
                    onchangeFunction: (String val) {
                      // if (val.isNotEmpty && int.parse(val) >= 5001) {
                      //   _conveyanceAmountTextEditingController.text = "";
                      // }
                      setState(() {});
                    },
                  ))
                : Container(),
            _fieldData[5]["activeStatus"].toString() == "1" ? textFieldHeader(
                // AllString.conveyanceRemark
                _fieldData[5]["fieldName"].toString()) : Container(),
            _fieldData[5]["activeStatus"].toString() == "1"
                ? Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enter +
                            " " +
                            _fieldData[5]["fieldName"].toString()
                        // AllString.enterRemark
                        ,
                        _conveyanceRemarksTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }

  checkOutCommentCard() {
    return Container(
      padding: EdgeInsets.all(1),
      margin: customMarginCardItem(),
      decoration: customCardItemGradinet(),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth * 0.85,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            textFieldHeader(
                // AllString.conveyanceRemark
                AllString.output + " *"),
            Container(
              margin: EdgeInsets.symmetric(
                vertical: screenWidth * 0.0,
                horizontal: screenWidth * 0.03,
              ),
              child: Center(
                child: textAreaField(
                  context,
                  AllString.enterOutputRemarks,
                  _commentTextEditingController,
                  4,
                  200,
                  TextInputAction.done,
                  TextInputType.text,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  checkOutAttatchmentCard() {
    return Container(
      child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            _fieldData[6]["activeStatus"].toString() == "1"
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      extraSmallText(
                          _fieldData[6]["fieldName"].toString() + " *     ",
                          // AllString.attachSnap + " 1*",
                          fontWeight: FontWeight.bold,
                          color: AllColor.black),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.05,
                        ),
                        child: Row(
                          children: [
                            Container(
                              child: GestureDetector(
                                onTap: () {
                                  _onImageButtonPressed(ImageSource.camera,
                                      paymentImage: false,
                                      attatchmentImage1: true,
                                      attatchmentImage2: false);
                                  // pickImageOption();
                                },
                                child: Stack(
                                  children: [
                                    Container(
                                      width: screenWidth * 0.2,
                                      height: screenWidth * 0.2,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5)),
                                        color:
                                            AllColor.greyColor.withOpacity(0.5),
                                      ),
                                      child: Material(
                                        color: AllColor.lightBlack
                                            .withOpacity(0.5),
                                        //display new updated image here
                                        child: _attatchmentImageFile1 == null
                                            ? mediumIcon(Icons.attach_file,
                                                color: AllColor.black)
                                            : Image.file(
                                                File(_attatchmentImageFile1!
                                                    .path),
                                                fit: BoxFit.cover,
                                              ),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5)),
                                        clipBehavior: Clip.hardEdge,
                                      ),
                                    ),
                                    _attatchmentImageFile1 == null
                                        ? Container()
                                        : Positioned(
                                            top: screenWidth * 0.01,
                                            right: screenWidth * 0.01,
                                            child: GestureDetector(
                                              onTap: () {
                                                _attatchmentImageFile1 = null;
                                                setState(() {});
                                              },
                                              child: Container(
                                                child: normalIcon(Icons.close),
                                              ),
                                            ))
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  )
                : Container(),
            _fieldData[7]["activeStatus"].toString() == "1"
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      extraSmallText(_fieldData[7]["fieldName"].toString(),
                          // AllString.attachSnap + " 2",
                          fontWeight: FontWeight.bold,
                          color: AllColor.black),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Row(
                          children: [
                            Container(
                              child: GestureDetector(
                                onTap: () {
                                  _onImageButtonPressed(ImageSource.camera,
                                      paymentImage: false,
                                      attatchmentImage1: false,
                                      attatchmentImage2: true);
                                  // pickImageOption();
                                },
                                child: Stack(
                                  children: [
                                    Container(
                                      width: screenWidth * 0.2,
                                      height: screenWidth * 0.2,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5)),
                                        color:
                                            AllColor.greyColor.withOpacity(0.5),
                                      ),
                                      child: Material(
                                        color: AllColor.lightBlack
                                            .withOpacity(0.5),
                                        //display new updated image here
                                        child: _attatchmentImageFile2 == null
                                            ? mediumIcon(Icons.attach_file,
                                                color: AllColor.black)
                                            : Image.file(
                                                File(_attatchmentImageFile2!
                                                    .path),
                                                fit: BoxFit.cover,
                                              ),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5)),
                                        clipBehavior: Clip.hardEdge,
                                      ),
                                    ),
                                    _attatchmentImageFile2 == null
                                        ? Container()
                                        : Positioned(
                                            top: screenWidth * 0.01,
                                            right: screenWidth * 0.01,
                                            child: GestureDetector(
                                              onTap: () {
                                                _attatchmentImageFile2 = null;
                                                setState(() {});
                                              },
                                              child: Container(
                                                child: normalIcon(Icons.close),
                                              ),
                                            ))
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  )
                : Container()

            // GestureDetector(
            //   onTap: () {
            //     _onImageButtonPressed(ImageSource.camera,
            //         paymentImage: false,
            //         attatchmentImage1: true,
            //         attatchmentImage2: false);
            //     // pickImageOption(
            //     //     paymentImage: false,
            //     //     attatchmentImage1: true,
            //     //     attatchmentImage2: false);
            //   },
            //   child: Container(
            //     height: screenWidth * 0.08,
            //     width: screenWidth,
            //     margin: EdgeInsets.symmetric(
            //         horizontal: screenWidth * 0.03,
            //         vertical: screenWidth * 0.02),
            //     padding: EdgeInsets.symmetric(
            //       horizontal: screenWidth * 0.015,
            //     ),
            //     alignment: Alignment.center,
            //     decoration: BoxDecoration(
            //         border: Border.all(
            //             style: BorderStyle.solid, color: AllColor.greyColor),
            //         color: AllColor.lightBlack,
            //         borderRadius: BorderRadius.circular(7)),
            //     child: Row(
            //       children: [
            //         normalIcon(Icons.attachment_outlined,
            //             color: AllColor.greyColor),
            //         Container(
            //           width: screenWidth * 0.03,
            //         ),
            //         normalText(AllString.attachSnap + " 1*",
            //             color: AllColor.black.withOpacity(0.7))
            //       ],
            //     ),
            //   ),
            // ),
            // _attatchmentImageFile1 == null
            //     ? Container()
            //     : Center(
            //         child: Stack(
            //           children: [
            //             Container(
            //               width: screenWidth * 0.2,
            //               height: screenWidth * 0.2,
            //               decoration: BoxDecoration(
            //                 borderRadius: BorderRadius.all(Radius.circular(5)),
            //                 color: AllColor.greyColor.withOpacity(0.5),
            //               ),
            //               child: Material(
            //                 //display new updated image here
            //                 child: Image.file(
            //                   File(_attatchmentImageFile1!.path),
            //                   fit: BoxFit.cover,
            //                 ),
            //                 borderRadius: BorderRadius.all(Radius.circular(5)),
            //                 clipBehavior: Clip.hardEdge,
            //               ),
            //             ),
            //             Positioned(
            //                 top: screenWidth * 0.01,
            //                 right: screenWidth * 0.01,
            //                 child: GestureDetector(
            //                   onTap: () {
            //                     _attatchmentImageFile1 = null;
            //                     setState(() {});
            //                   },
            //                   child: Container(
            //                     child: normalIcon(Icons.close),
            //                   ),
            //                 ))
            //           ],
            //         ),
            //       ),

            // GestureDetector(
            //   onTap: () {
            //     _onImageButtonPressed(ImageSource.camera,
            //         paymentImage: false,
            //         attatchmentImage1: false,
            //         attatchmentImage2: true);
            //     // pickImageOption(
            //     //     paymentImage: false,
            //     //     attatchmentImage1: false,
            //     //     attatchmentImage2: true);
            //   },
            //   child: Container(
            //     height: screenWidth * 0.08,
            //     width: screenWidth,
            //     margin: EdgeInsets.symmetric(
            //         horizontal: screenWidth * 0.03,
            //         vertical: screenWidth * 0.02),
            //     padding: EdgeInsets.symmetric(
            //       horizontal: screenWidth * 0.015,
            //     ),
            //     alignment: Alignment.center,
            //     decoration: BoxDecoration(
            //         border: Border.all(
            //             style: BorderStyle.solid, color: AllColor.greyColor),
            //         color: AllColor.lightBlack,
            //         borderRadius: BorderRadius.circular(7)),
            //     child: Row(
            //       children: [
            //         normalIcon(Icons.attachment_outlined,
            //             color: AllColor.greyColor),
            //         Container(
            //           width: screenWidth * 0.03,
            //         ),
            //         normalText(AllString.attachSnap + " 2",
            //             color: AllColor.black.withOpacity(0.7))
            //       ],
            //     ),
            //   ),
            // ),
            // _attatchmentImageFile2 == null
            //     ? Container()
            //     : Center(
            //         child: Stack(
            //           children: [
            //             Container(
            //               width: screenWidth * 0.2,
            //               height: screenWidth * 0.2,
            //               decoration: BoxDecoration(
            //                 borderRadius: BorderRadius.all(Radius.circular(5)),
            //                 color: AllColor.greyColor.withOpacity(0.5),
            //               ),
            //               child: Material(
            //                 //display new updated image here
            //                 child: Image.file(
            //                   File(_attatchmentImageFile2!.path),
            //                   fit: BoxFit.cover,
            //                 ),
            //                 borderRadius: BorderRadius.all(Radius.circular(5)),
            //                 clipBehavior: Clip.hardEdge,
            //               ),
            //             ),
            //             Positioned(
            //                 top: screenWidth * 0.01,
            //                 right: screenWidth * 0.01,
            //                 child: GestureDetector(
            //                   onTap: () {
            //                     _attatchmentImageFile2 = null;
            //                     setState(() {});
            //                   },
            //                   child: Container(
            //                     child: normalIcon(Icons.close),
            //                   ),
            //                 ))
            //           ],
            //         ),
            //       ),
          ]),
    );
  }

  // pickImageOption(
  //     {required bool paymentImage,
  //     required bool attatchmentImage1,
  //     required bool attatchmentImage2}) {
  //   return showDialog(
  //       // barrierDismissible: false,
  //       context: context,
  //       builder: (context) {
  //         return SimpleDialog(
  //           backgroundColor: AllColor.white,
  //           contentPadding: EdgeInsets.all(0),
  //           shape: RoundedRectangleBorder(
  //               borderRadius: BorderRadius.circular(16.0)),
  //           elevation: 0.0,
  //           title: normalText(AllString.selectImageFrom + ":",
  //               color: AllColor.black),
  //           children: [
  //             Container(
  //               margin: EdgeInsets.only(top: screenWidth * 0.03),
  //               decoration: BoxDecoration(
  //                   border: Border(top: BorderSide(color: Colors.grey))),
  //             ),
  //             SimpleDialogOption(
  //                 padding: EdgeInsets.all(0),
  // child: ListTile(
  //   contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //   leading: normalIcon(Icons.camera_alt,
  //       color: AllColor.primaryColor),
  //   title: normalText(AllString.camera, color: AllColor.black),
  // ),
  // onPressed: () {
  //   _onImageButtonPressed(ImageSource.camera,
  //       paymentImage: paymentImage,
  //       attatchmentImage1: attatchmentImage1,
  //       attatchmentImage2: attatchmentImage2);
  //   Navigator.pop(context);
  // }),
  //             SimpleDialogOption(
  //                 padding: EdgeInsets.all(0),
  //                 child: ListTile(
  //                   contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //                   leading: normalIcon(Icons.photo_library,
  //                       color: AllColor.primaryColor),
  //                   title: normalText(AllString.gallery, color: AllColor.black),
  //                 ),
  //                 onPressed: () {
  //                   _onImageButtonPressed(ImageSource.gallery,
  //                       paymentImage: paymentImage,
  //                       attatchmentImage1: attatchmentImage1,
  //                       attatchmentImage2: attatchmentImage2);
  //                   Navigator.pop(context);
  //                 }),
  //           ],
  //         );
  //       });
  // }

  _onImageButtonPressed(ImageSource source,
      {required bool paymentImage,
      required bool attatchmentImage1,
      required bool attatchmentImage2}) async {
    try {
      final pickedFile = await imagePickerQuality(source);

      final bytes = File(pickedFile!.path).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      final mb = kb / 1024;
      log("kb: " + kb.toString());
      log("mb: " + mb.toString());
      if (paymentImage) {
        _paymentImageFile = pickedFile;
        setState(() {});
      } else if (attatchmentImage1) {
        _attatchmentImageFile1 = pickedFile;
        setState(() {});
      } else if (attatchmentImage2) {
        _attatchmentImageFile2 = pickedFile;
        setState(() {});
      }

      setState(() {
        loading = false;
      });
    } catch (e) {}
  }

  checkIn() async {
    setState(() {
      loading = true;
    });
    int officeType = 1;
    // 1 = Dealer,  2 = Office, 3 = Others

    if (_selectCheckInOptions == AllString.office) {
      officeType = 2;
      setState(() {});
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
          _officeTextEditingController.text);
    } else if (_selectCheckInOptions == AllString.dealer) {
      officeType = 1;
      setState(() {});
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
          _currentDealer.split(AllString.splitText).first);
    } else if (_selectCheckInOptions == AllString.others) {
      officeType = 3;
      setState(() {});
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
          _othersTextEditingController.text);
    }
    sharedPreferences!
        .setString(AllSharedPreferencesKey.officeType, officeType.toString());
    if (await internetCheck()) {
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "userLoginId":
            sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        "checkInData": [
          {
            "officeName": sharedPreferences!
                .getString(AllSharedPreferencesKey.checkInOptionName),
            "officeType": officeType,
            "dealerId": _selectCheckInOptions == AllString.dealer
                ? _currentDealer.split(AllString.splitText).last.toString()
                : 0,
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "visitTypeName": sharedPreferences!
                .getString(AllSharedPreferencesKey.checkInOptionName),
            "visitType": officeType,
            "visitPurposeId": selectedPurposeOfVisit == AllString.select
                ? ""
                : selectedPurposeOfVisit.split(AllString.splitText).last,
            "location": location,
            "latitude": currentPosition.latitude,
            "longitude": currentPosition.longitude,
            "checkInTime": DateTime.now().toString(),
          }
        ]
      };

      log(data.toString());
      apiPostRequestWithHeader(
              data, AllUrls.employeeVisitIn, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () async {
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.checkInOption, _selectCheckInOptions);
              fetchAndSetAllIdSettingConfig(context);
              Future.delayed(Duration(milliseconds: 600), () {
                AppBuilder.of(context)!.rebuild();
              });
              AppBuilder.of(context)!.rebuild();
              if (_selectCheckInOptions == AllString.office) {
                setState(() {});
                sharedPreferences!.setString(
                    AllSharedPreferencesKey.checkInOptionName,
                    _officeTextEditingController.text);
              } else if (_selectCheckInOptions == AllString.dealer) {
                setState(() {});
                sharedPreferences!.setString(
                    AllSharedPreferencesKey.checkInOptionName,
                    _currentDealer.split(AllString.splitText).first);
                sharedPreferences!.setString(
                    AllSharedPreferencesKey.checkInOptionNameWithId,
                    _currentDealer.split(AllString.splitText).last);
              } else if (_selectCheckInOptions == AllString.others) {
                setState(() {});
                sharedPreferences!.setString(
                    AllSharedPreferencesKey.checkInOptionName,
                    _othersTextEditingController.text);
              }
              _visibleCheckInCheckOutOption = false;
              AppBuilder.of(context)!.rebuild();

              setState(() {});
              Navigator.pop(context);
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    }
  }

  checkInAllOffileData() async {
    setState(() {
      loading = true;
    });
    if (await internetCheck()) {
      var allrows = await dbhelper.fetchAllCheckIn();

      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        "checkInData": allrows
      };

      log(data.toString());
      apiPostRequestWithHeader(
              data, AllUrls.employeeVisitIn, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () async {
              List allCheckInList = allrows;
              allCheckInList.forEach((element) {
                dbhelper.deleteCheckIn(element["id"]);
              });
              var allrowsss = await dbhelper.fetchAllCheckIn();
              log(allrowsss.toString());
              setState(() {});
              Navigator.pop(context);
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    }
  }

  checkOutAllOffileData() async {
    // setState(() {
    //   loading = true;
    // });
    // if (await internetCheck()) {
    var allrows = await dbhelper.fetchAllCheckOut();
    List allrowsCheckOutOrder = [];
    allrows.forEach((element) async {
      log("element " + element.toString());
      var allrowsCheckOutOrder = await dbhelper
          .fetchAllOrderSubList(element["id"].toString() + "_CheckOut");

      log(allrowsCheckOutOrder.toString());
    });
    allrowsCheckOutOrder.forEach((element) async {
      log(element.toString());
    });
    // Map data = {
    //   "companyId":
    //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
    //   "individualId":
    //       sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    //   "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
    //   "checkOutData": allrows,
    //   "allrowsCheckOutOrder": allrowsCheckOutOrder
    // };

    // log(data.toString());
    // apiPostRequestWithHeader(
    //         data, AllUrls.employeeVisitIn, this.context, loginToken)
    //     .then((response) {
    //   if (response == null) {
    //     loading = false;
    //     setState(() {});
    //     commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    //   } else {
    //     Map<String, dynamic> jsonData = json.decode(response);
    //     if (checkApiResponseSuccessOrNot(jsonData)) {
    //       setState(() {
    //         loading = false;
    //       });

    //       commonAlertDialog(context, jsonData["status"], jsonData["message"],
    //           function: () async {
    //         List allCheckOutList = allrows;
    //         allCheckOutList.forEach((element) {
    //           dbhelper.deleteCheckIn(element["id"]);
    //         });
    //         List allCheckOutOrderList = allrowsCheckOutOrder;
    //         allCheckOutOrderList.forEach((element) {
    //           dbhelper.deleteCheckOutOrder(element["id"]);
    //         });
    //         var allrowsss = await dbhelper.fetchAllCheckOut();
    //         var allrowsssss = await dbhelper.fetchAllCheckOutOrders();
    //         log(allrowsss.toString());
    //         log(allrowsssss.toString());
    //         setState(() {});
    //         Navigator.pop(context);
    //       });
    //     } else {
    //       setState(() {
    //         loading = false;
    //       });
    //       commonAlertDialog(context, jsonData["status"], jsonData["message"]);
    //     }
    //   }
    // });
    // }
  }

  offlineCheckOut() async {
    String _attatchmentImageBase641 = "";
    String _attatchmentImageBase642 = "";
    String _paymentImageBase64 = "";
    if (_paymentImageFile != null) {
      File imageFile = new File(_paymentImageFile!.path);
      List<int> imageBytes = imageFile.readAsBytesSync();
      _paymentImageBase64 = base64Encode(imageBytes);
      setState(() {});
    }
    if (_attatchmentImageFile1 != null) {
      File imageFile = new File(_attatchmentImageFile1!.path);
      List<int> imageBytes = imageFile.readAsBytesSync();
      _attatchmentImageBase641 = base64Encode(imageBytes);
      setState(() {});
    }
    if (_attatchmentImageFile2 != null) {
      File imageFile = new File(_attatchmentImageFile2!.path);
      List<int> imageBytes = imageFile.readAsBytesSync();
      _attatchmentImageBase642 = base64Encode(imageBytes);
      setState(() {});
    }

    List _orderListForRequest = [];

    String orderIds = "";
    if (_orderList.isNotEmpty) {
      _orderList.forEach((element) {
        if (element["categoryId"] == "") {
        } else {
          orderIds = element["categoryId"].toString() + "," + orderIds;
        }
        _orderListForRequest.add({
          "productCategoryId": element["categoryId"],
          "productId": element["productId"],
          "brandId": element["brandId"],
          "quantity": element["quantity"]
        });
        setState(() {});
      });
    }
    orderIds = orderIds.endsWith(",")
        ? orderIds.substring(0, orderIds.length - 1)
        : orderIds;
    setState(() {});

    Map<String, dynamic> rowForCheckOut = {
      Databasehelper.checkInofficeName: "",
      Databasehelper.checkInIdForCheckOut:
          sharedPreferences!.getString(AllSharedPreferencesKey.checkInId),
      Databasehelper.checkInofficeType: "",
      Databasehelper.checkIndealerId: "",
      Databasehelper.checkInvisitTypeName: "",
      Databasehelper.checkInvisitType: "",
      Databasehelper.checkInCheckOutStatus: AllString.checkOut,
      Databasehelper.checkInlocation: "",
      Databasehelper.checkInlatitude: "",
      Databasehelper.checkInlongitude: "",
      Databasehelper.checkInTime: "",
      Databasehelper.checkOutDealerId: sharedPreferences!
                  .getString(AllSharedPreferencesKey.checkInOptionName) ==
              AllString.dealer
          ? sharedPreferences!
              .getString(AllSharedPreferencesKey.checkInOptionNameWithId)
          : 0,
      Databasehelper.checkInIdForCheckOut:
          sharedPreferences!.getString(AllSharedPreferencesKey.checkInId),
      Databasehelper.checkOutordersId: orderIds,
      Databasehelper.checkOutlocation: location,
      Databasehelper.checkOutlatitude: currentPosition.latitude,
      Databasehelper.checkOutlongitude: currentPosition.longitude,
      Databasehelper.checkInCheckOutStatus: AllString.checkOut,
      Databasehelper.checkOutofficeName: sharedPreferences!
          .getString(AllSharedPreferencesKey.checkInOptionName),
      Databasehelper.checkOutDealerId: sharedPreferences!
                  .getString(AllSharedPreferencesKey.checkInOptionName) ==
              AllString.dealer
          ? sharedPreferences!
              .getString(AllSharedPreferencesKey.checkInOptionNameWithId)
          : 0,
      Databasehelper.checkOutvisitType:
          sharedPreferences!.getString(AllSharedPreferencesKey.officeType),
      Databasehelper.checkOutvisitTypeName: sharedPreferences!
          .getString(AllSharedPreferencesKey.checkInOptionName),
      Databasehelper.checkOutindividualId:
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      Databasehelper.checkOutcheckOutTime: DateTime.now().toString()
    };

    if (_paymentAmountTextEditingController.text.isEmpty &&
        _paymentRemarksTextEditingController.text.isEmpty &&
        _paymentImageUrl.isEmpty) {
      rowForCheckOut[Databasehelper.checkOutpaymentAmount] = "";
      rowForCheckOut[Databasehelper.checkOutpaymentRemark] = "";
    } else {
      rowForCheckOut[Databasehelper.checkOutpaymentAmount] =
          _paymentAmountTextEditingController.text;
      rowForCheckOut[Databasehelper.checkOutpaymentRemark] =
          _paymentRemarksTextEditingController.text;
    }

    if (_conveyanceAmountTextEditingController.text.isEmpty &&
        _conveyanceRemarksTextEditingController.text.isEmpty) {
      rowForCheckOut[Databasehelper.checkOutconveyanceAmount] = "";
      rowForCheckOut[Databasehelper.checkOutconveyanceRemark] = "";
    } else {
      rowForCheckOut[Databasehelper.checkOutconveyanceAmount] =
          _conveyanceAmountTextEditingController.text;
      rowForCheckOut[Databasehelper.checkOutconveyanceRemark] =
          _conveyanceRemarksTextEditingController.text;
    }

    commonAlertDialog(
        context, AllString.success, AllString.checkOutSuccessfully,
        function: () async {
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOption, "");
      AppBuilder.of(context)!.rebuild();
      sharedPreferences!
          .setString(AllSharedPreferencesKey.checkInOptionName, "");
      sharedPreferences!
          .setString(AllSharedPreferencesKey.checkInOptionNameWithId, "");

      // ! Insert Row on check Out Table
      log("rowForCheckOut: " + rowForCheckOut.toString());
      await dbhelper.insertCheckOut(rowForCheckOut).then((checkOutId) async {
        log("checkOutId: " + checkOutId.toString());
        Map<String, dynamic> dataForImage = {
          Databasehelper.orderId: checkOutId,
          Databasehelper.checkOutAttatchmentImageFile1:
              _attatchmentImageBase641,
          Databasehelper.checkOutAttatchmentImageFile2:
              _attatchmentImageBase642,
          Databasehelper.checkOutPaymentImage: _paymentImageBase64
        };
        final idPaymentImage = await dbhelper.insertCheckOutImage(dataForImage);
        // ! Insert Row on check Out Order Table
        if (_orderList.isNotEmpty) {
          _orderList.forEach((element) async {
            Map<String, dynamic> rowForCheckOutOrder = {
              Databasehelper.checkOutIdOrOrderId:
                  checkOutId.toString() + "_CheckOut",
              Databasehelper.productCategoryId: element["categoryId"],
              Databasehelper.productId: element["productId"],
              Databasehelper.brandId: element["brandId"],
              Databasehelper.quantity: element["quantity"]
            };
            setState(() {});
            final checkOutOrderId =
                await dbhelper.insertOrderSubList(rowForCheckOutOrder);
          });
        }

        sharedPreferences!.setString(AllSharedPreferencesKey.checkInOption, "");
        sharedPreferences!
            .setString(AllSharedPreferencesKey.checkInOptionName, "");
        sharedPreferences!
            .setString(AllSharedPreferencesKey.checkInOptionNameWithId, "");
        sharedPreferences!.setString(AllSharedPreferencesKey.checkInId, "");
        setState(() {});
        Navigator.push(
            context, CupertinoPageRoute(builder: (context) => Home()));
      });
    });
  }

  offlineCheckIn() async {
    setState(() {
      loading = true;
    });
    int officeType = 1;
    // 1 = Dealer,  2 = Office, 3 = Others

    if (_selectCheckInOptions == AllString.office) {
      officeType = 2;
      setState(() {});
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
          _officeTextEditingController.text);
    } else if (_selectCheckInOptions == AllString.dealer) {
      officeType = 1;
      setState(() {});
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
          _currentDealer.split(AllString.splitText).first);
    } else if (_selectCheckInOptions == AllString.others) {
      officeType = 3;
      setState(() {});
      sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
          _othersTextEditingController.text);
    }
    sharedPreferences!
        .setString(AllSharedPreferencesKey.officeType, officeType.toString());
    sharedPreferences!.setString(
        AllSharedPreferencesKey.checkInId, random.nextInt(100).toString());
    Map<String, dynamic> data = {
      Databasehelper.checkInofficeName: sharedPreferences!
          .getString(AllSharedPreferencesKey.checkInOptionName),
      Databasehelper.checkInIdForCheckOut:
          sharedPreferences!.getString(AllSharedPreferencesKey.checkInId),
      Databasehelper.checkInofficeType: officeType,
      Databasehelper.checkInCheckOutStatus: AllString.checkIn,
      Databasehelper.checkIndealerId: _selectCheckInOptions == AllString.dealer
          ? _currentDealer.split(AllString.splitText).last.toString()
          : 0,
      Databasehelper.checkInvisitTypeName: sharedPreferences!
          .getString(AllSharedPreferencesKey.checkInOptionName),
      Databasehelper.checkInvisitType: officeType,
      Databasehelper.checkInCheckOutStatus: AllString.checkIn,
      Databasehelper.checkInlocation: location,
      Databasehelper.checkInlatitude: currentPosition.latitude,
      Databasehelper.checkInlongitude: currentPosition.longitude,
      Databasehelper.checkInTime: DateTime.now().toString(),
      Databasehelper.checkOutDealerId: "",
      Databasehelper.checkOutordersId: "",
      Databasehelper.checkOutlatitude: "",
      Databasehelper.checkOutlongitude: "",
      Databasehelper.checkOutlocation: "",
      Databasehelper.checkOutofficeName: "",
      Databasehelper.checkOutconveyanceAmount: "",
      Databasehelper.checkOutconveyanceRemark: "",
      Databasehelper.checkOutpaymentRemark: "",
      Databasehelper.checkOutpaymentAmount: "",
      Databasehelper.checkOutvisitType: "",
      Databasehelper.checkOutvisitTypeName: "",
      Databasehelper.checkOutindividualId: "",
      Databasehelper.checkOutcheckOutTime: "",
    };
    // ! Insert Row on check In Table

    AppBuilder.of(context)!.rebuild();

    final id = await dbhelper.insertCheckIn(data);
    var allrows = await dbhelper.fetchAllCheckIn();
    log(allrows.toString());

    commonAlertDialog(context, AllString.success, AllString.checkInSuccessfully,
        function: () async {
      sharedPreferences!.setString(
          AllSharedPreferencesKey.checkInOption, _selectCheckInOptions);

      AppBuilder.of(context)!.rebuild();
      if (_selectCheckInOptions == AllString.office) {
        setState(() {});
        sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
            _officeTextEditingController.text);
      } else if (_selectCheckInOptions == AllString.dealer) {
        setState(() {});
        sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
            _currentDealer.split(AllString.splitText).first);
        sharedPreferences!.setString(
            AllSharedPreferencesKey.checkInOptionNameWithId,
            _currentDealer.split(AllString.splitText).last);
      } else if (_selectCheckInOptions == AllString.others) {
        setState(() {});
        sharedPreferences!.setString(AllSharedPreferencesKey.checkInOptionName,
            _othersTextEditingController.text);
      }
      sharedPreferences!.setString(
          AllSharedPreferencesKey.checkInOption, _selectCheckInOptions);
      _visibleCheckInCheckOutOption = false;
      AppBuilder.of(context)!.rebuild();
      loading = false;
      setState(() {});
      Navigator.pop(context);
    });
  }

  checkOut() async {
    if (await internetCheck()) {
      if (_paymentImageFile == null &&
          _attatchmentImageFile1 == null &&
          _attatchmentImageFile2 == null) {
        callApiForCheckOut();
      } else if (_attatchmentImageFile1 == null &&
          _attatchmentImageFile2 == null) {
        setState(() {
          loading = true;
        });
        imageToUrlApiImage(_paymentImageFile!.path, context).then((value) {
          _paymentImageUrl = value;
          setState(() {});
          callApiForCheckOut();
        });
      } else if (_paymentImageFile == null && _attatchmentImageFile2 == null) {
        setState(() {
          loading = true;
        });
        imageToUrlApiImage(_attatchmentImageFile1!.path, context).then((value) {
          _attatchmentImageUrl1 = value;
          setState(() {});
          callApiForCheckOut();
        });
      } else if (_paymentImageFile == null && _attatchmentImageFile1 == null) {
        setState(() {
          loading = true;
        });
        imageToUrlApiImage(_attatchmentImageFile2!.path, context).then((value) {
          _attatchmentImageUrl2 = value;
          setState(() {});
          callApiForCheckOut();
        });
      } else if (_attatchmentImageFile2 == null) {
        setState(() {
          loading = true;
        });
        if (_paymentImageFile != null) {
          imageToUrlApiImage(_paymentImageFile!.path, context).then((value) {
            _paymentImageUrl = value;
            setState(() {});
            if (_attatchmentImageFile1 != null) {
              imageToUrlApiImage(_attatchmentImageFile1!.path, context)
                  .then((value) {
                _attatchmentImageUrl1 = value;
                setState(() {});
                callApiForCheckOut();
              });
            }
          });
        }
      }else if (_paymentImageFile == null && _attatchmentImageFile1!=null &&_attatchmentImageFile2!=null ) {
        setState(() {
          loading = true;
        });
        if (_attatchmentImageFile2 != null) {
          imageToUrlApiImage(_attatchmentImageFile2!.path, context).then((value) {
            _attatchmentImageUrl2 = value;
            setState(() {});
            if (_attatchmentImageFile1 != null) {
              imageToUrlApiImage(_attatchmentImageFile1!.path, context)
                  .then((value) {
                _attatchmentImageUrl1 = value;
                setState(() {});
                callApiForCheckOut();
              });
            }
          });
        }
      }  else {
        setState(() {
          loading = true;
        });
        if (_paymentImageFile != null) {
          imageToUrlApiImage(_paymentImageFile!.path, context).then((value) {
            _paymentImageUrl = value;
            setState(() {});
            if (_attatchmentImageFile1 != null) {
              imageToUrlApiImage(_attatchmentImageFile1!.path, context)
                  .then((value) {
                _attatchmentImageUrl1 = value;
                setState(() {});
                if (_attatchmentImageFile2 != null) {
                  imageToUrlApiImage(_attatchmentImageFile2!.path, context)
                      .then((value) {
                    _attatchmentImageUrl2 = value;
                    setState(() {});
                    callApiForCheckOut();
                  });
                }
              });
            }
          });
        }
      }
      // callApiForCheckOut();
    }
  }

  callApiForCheckOut() {
    setState(() {
      loading = true;
    });
// 22-07-2022 base64 image
    // String _attatchmentImageBase641 = "";
    // String _attatchmentImageBase642 = "";
    // String _paymentImageBase64 = "";
    // if (_paymentImageFile != null) {
    //   File imageFile = new File(_paymentImageFile!.path);
    //   List<int> imageBytes = imageFile.readAsBytesSync();
    //   _paymentImageBase64 = base64Encode(imageBytes);
    //   setState(() {});
    // }
    // if (_attatchmentImageFile1 != null) {
    //   File imageFile = new File(_attatchmentImageFile1!.path);
    //   List<int> imageBytes = imageFile.readAsBytesSync();
    //   _attatchmentImageBase641 = base64Encode(imageBytes);
    //   setState(() {});
    // }
    // if (_attatchmentImageFile2 != null) {
    //   File imageFile = new File(_attatchmentImageFile2!.path);
    //   List<int> imageBytes = imageFile.readAsBytesSync();
    //   _attatchmentImageBase642 = base64Encode(imageBytes);
    //   setState(() {});
    // }
    List _orderListForRequest = [];

    if (_orderList.isNotEmpty) {
      _orderList.forEach((element) {
        _orderListForRequest.add({
          "productCategoryId": element["categoryId"],
          "brandId": element["brandId"],
          "productId": element["productId"],
          "quantity": element["quantity"]
        });
        setState(() {});
      });
    }

    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
      "checkOutData": [
        {
          "id": "",
          "payment": {
            "amount": _paymentAmountTextEditingController.text,
            "remarks": _paymentRemarksTextEditingController.text,
          },
          "conveyance": {
            "amount": _conveyanceAmountTextEditingController.text,
            "remarks": _conveyanceRemarksTextEditingController.text
          },
          "location": location,
          "latitude": currentPosition.latitude,
          "longitude": currentPosition.longitude,
          "officeName": sharedPreferences!
              .getString(AllSharedPreferencesKey.checkInOptionName),
          "dealerId": sharedPreferences!
                      .getString(AllSharedPreferencesKey.checkInOption) ==
                  AllString.dealer
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.checkInOptionNameWithId)
              : 0,
          "companyId":
              sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
          "visitType":
              sharedPreferences!.getString(AllSharedPreferencesKey.officeType),
          "visitTypeName": sharedPreferences!
              .getString(AllSharedPreferencesKey.checkInOptionName),
          "individualId": sharedPreferences!
              .getString(AllSharedPreferencesKey.individualId),
          "checkInId":
              sharedPreferences!.getString(AllSharedPreferencesKey.checkInId),
          // "attatchmentImageFile1": _attatchmentImageBase641,
          // "attatchmentImageFile2": _attatchmentImageBase642,
          // "paymentPaymentImage": _paymentImageBase64,

          "attatchmentImageFile1": _attatchmentImageUrl1,
          "attatchmentImageFile2": _attatchmentImageUrl2,
          "paymentPaymentImage": _paymentImageUrl,
          "comment": _commentTextEditingController.text,
          "orders": _orderListForRequest,
          "checkOutTime": DateTime.now().toString(),
        },
      ],
    };

    apiPostRequestWithHeader(
            data, AllUrls.employeeVisitOut, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          setState(() {
            loading = false;
          });

          commonAlertDialog(context, jsonData["status"], jsonData["message"],
              function: () async {
            sharedPreferences!
                .setString(AllSharedPreferencesKey.checkInOption, "");
            sharedPreferences!
                .setString(AllSharedPreferencesKey.checkInOptionName, "");
            sharedPreferences!
                .setString(AllSharedPreferencesKey.checkInOptionNameWithId, "");
            fetchAndSetAllIdSettingConfig(context);
            Future.delayed(Duration(milliseconds: 600), () {
              AppBuilder.of(context)!.rebuild();
            });
            setState(() {});
            Navigator.push(
                context, CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  checkAndFetchLocation() async {
    if (await internetCheck()) {
      Permission.location.request().then((value) async {
        var status = await Permission.location.status;
        log(status.toString());
        if (await Permission.location.isRestricted) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForRestrictedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          if (status.isDenied) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForDeniedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            Position position = await Geolocator.getCurrentPosition(
                desiredAccuracy: LocationAccuracy.high);
            currentPosition = position;
            if ((sharedPreferences!
                        .getString(AllSharedPreferencesKey.latitude) !=
                    position.latitude.toString()) &&
                (sharedPreferences!
                        .getString(AllSharedPreferencesKey.longitude) !=
                    position.longitude.toString())) {
              getCurrentLocation();
            }

            loading = false;
            setState(() {});
          }
          setState(() {});
        }
      });
    } else {
      if (sharedPreferences!.getString(AllSharedPreferencesKey.location) ==
              null ||
          sharedPreferences!.getString(AllSharedPreferencesKey.location) ==
              "") {
        sharedPreferences!.setString(AllSharedPreferencesKey.location, "");
      }
      if (sharedPreferences!.getString(AllSharedPreferencesKey.latitude) ==
              null ||
          sharedPreferences!.getString(AllSharedPreferencesKey.latitude) ==
              "") {
        sharedPreferences!.setString(AllSharedPreferencesKey.latitude, "");
      }
      if (sharedPreferences!.getString(AllSharedPreferencesKey.longitude) ==
              null ||
          sharedPreferences!.getString(AllSharedPreferencesKey.longitude) ==
              "") {
        sharedPreferences!.setString(AllSharedPreferencesKey.longitude, "");
      }
      loading = true;
      setState(() {});
      Permission.location.request().then((value) async {
        var status = await Permission.location.status;
        log(status.toString());
        if (await Permission.location.isRestricted) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForRestrictedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          if (status.isDenied) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForDeniedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            Position position = await Geolocator.getCurrentPosition(
                desiredAccuracy: LocationAccuracy.high);
            currentPosition = position;

            sharedPreferences!.setString(
                AllSharedPreferencesKey.latitude, position.latitude.toString());
            sharedPreferences!.setString(AllSharedPreferencesKey.longitude,
                position.longitude.toString());
            loading = false;
            setState(() {});
          }
          setState(() {});
        }
      });
    }
  }

//   setDropDownValueByDefaultUponCondition() {
//     if (dealerList.length == 2) {
//       _currentDealer = dealerList.last;
//     }
//     if (brandList.length == 2) {
//       _currentBrand = brandList.last;
//     }
//     if (categoryList.length == 2) {
//       _currentCategory = categoryList.last;
//       setState(() {});
//       _productList.clear();

//       _productList.add(AllString.select);

//       setState(() {});
//       Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
//           .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//       if (jsonDataForCommon["modelDetails"] == "" ||
//           jsonDataForCommon["modelDetails"] == []) {
//         _productList = [];
//       } else {
//         List _tempList = jsonDataForCommon["modelDetails"];
//         _tempList.forEach((element) {
//           _productList.add(element["modelNo"].toString() +
//               AllString.splitText +
//               element["productModelId"].toString());
//         });
//       }

//       // Map<String, dynamic> jsonDataForAllProduct = json.decode(
//       //     sharedPreferences!
//       //         .getString(AllSharedPreferencesKey.allProductJson)!);
//       // List tempListForAllProduct = jsonDataForAllProduct["data"];
//       // tempListForAllProduct.forEach((element) {
//       //   if (element["categoryId"].toString() ==
//       //       _currentCategory.split(AllString.splitText).last) {validate
//       //     _productList.add(element["productname"].toString() +
//       //         AllString.splitText +
//       //         element["productId"].toString());
//       //   }
//       // });
//       if (_productList.length == 2) {
//         _currentProduct = _productList.last;
//       }
//     }
// //     if(expenseTypeList.length==2){
// // _currentExpenseType=expenseTypeList.last;
// //     }
//     setState(() {});
//   }
  setDropDownValueByDefaultUponCondition() {
    if (dealerList.length == 2) {
      _currentDealer = dealerList.last;
    }
    if (brandList.length == 2) {
      _currentBrand = brandList.last;

      Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
          .getString(AllSharedPreferencesKey.allCommonDataJson)!);
      if (jsonDataForCommon["commonData"]["divisionDetails"] == "" ||
          jsonDataForCommon["commonData"]["divisionDetails"] == []) {
        _categoryList = [];
      } else {
        List _tempList = jsonDataForCommon["commonData"]["divisionDetails"];
        _tempList.forEach((element) {
          if (element["brandId"].toString() ==
              _currentBrand.split(AllString.splitText).last) {
            _categoryList.add(element["productCategoryName"].toString() +
                AllString.splitText +
                element["productCategoryId"].toString());
          }
        });

        if (_categoryList.length == 2) {
          _currentCategory = _categoryList.last;
        }
      }
    }
    // if (categoryList.length == 2) {
    //   _currentCategory = categoryList.last;
    //   setState(() {});
    //   _productList.clear();

    //   _productList.add(AllString.select);

    //   setState(() {});

    //   // Map<String, dynamic> jsonDataForAllProduct = json.decode(
    //   //     sharedPreferences!
    //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
    //   // List tempListForAllProduct = json.decode(
    //   //     sharedPreferences!
    //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
    //   // tempListForAllProduct.forEach((element) {
    //   //   if (element["divisionName"].toString() ==
    //   //       _currentCategory.split(AllString.splitText).first) {
    //   //     _productList.add(element["modelNo"].toString() +
    //   //         AllString.splitText +
    //   //         element["productModelId"].toString());
    //   //   }
    //   // });
    //   // Map<String, dynamic> jsonDataForAllProduct = json.decode(
    //   //     sharedPreferences!
    //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
    //   // List tempListForAllProduct = jsonDataForAllProduct["data"];
    //   // tempListForAllProduct.forEach((element) {
    //   //   if (element["categoryId"].toString() ==
    //   //       _currentCategory.split(AllString.splitText).last) {
    //   //     _productList.add(element["productname"].toString() +
    //   //         AllString.splitText +
    //   //         element["productId"].toString());
    //   //   }
    //   // });
    //   if (_productList.length == 2) {
    //     _currentProduct = _productList.last;
    //   }
    // }

//     if(expenseTypeList.length==2){
// _currentExpenseType=expenseTypeList.last;
//     }
    setState(() {});
  }

  // requestBodyForOffileCheckInAndCheckOut() async {
  //   // var allrows = await dbhelper.fetchAllCheckIn();
  //   // log(allrows.toString());
  //   List offlineCheckOutBody = [];
  //   await dbhelper.fetchAllCheckOut().then((allCheckOutRows) {
  //     // log(allCheckOutRows.toString());
  //     allCheckOutRows.forEach((element) async {
  //       Map<String, dynamic> jsonBody = {
  //         "dealerId": element["dealerId"],
  //         "checkInId": element["checkInId"],

  //          "attatchmentImageFile1": element["attatchmentImageFile1"],
  //          "attatchmentImageFile2": element["attatchmentImageFile2"],
  //       };
  //       if (element["paymentAmount"].toString().isEmpty &&
  //           element["paymentRemark"].toString().isEmpty &&
  //           element["paymentImage"].toString().isEmpty) {
  //         jsonBody["payment"] = null;
  //       } else {
  //         jsonBody["payment"] = {
  //           "amount": element["paymentAmount"].toString(),
  //           "remark": element["paymentRemark"].toString(),
  //           "image": element["paymentImage"].toString()
  //         };
  //       }
  //       if (element["conveyanceAmount"].toString().isEmpty &&
  //           element["conveyanceRemark"].toString().isEmpty) {
  //         jsonBody["conveyance"] = null;
  //       } else {
  //         jsonBody["conveyance"] = {
  //           "amount": element["conveyanceAmount"].toString(),
  //           "remark": element["conveyanceRemark"].toString()
  //         };
  //       }

  //       await dbhelper
  //           .fetchAllCheckOutOrder(element["id"])
  //           .then((allCheckOutOrderRows) {
  //         log(allCheckOutOrderRows.toString());
  //         log(element["id"].toString());
  //         if (allCheckOutOrderRows.isEmpty) {
  //           jsonBody["orders"] = [];
  //         } else {
  //           List _orderListForRequest = [];

  //           allCheckOutOrderRows.forEach((elementForCheckOutOrders) {
  //             // log("categoryId " + elementForCheckOutOrders["categoryId"].toString());

  //             _orderListForRequest.add({
  //               "categoryId": elementForCheckOutOrders["categoryId"],
  //               "productId": elementForCheckOutOrders["productId"],
  //               "quantity": elementForCheckOutOrders["quantity"]
  //             });
  //             setState(() {});
  //           });
  //           log(_orderListForRequest.length.toString());
  //           jsonBody["orders"] = _orderListForRequest;
  //           log(jsonBody["orders"].toString());
  //         }
  //         setState(() {});
  //         offlineCheckOutBody.add(jsonBody);
  //         log("offlineCheckOutBody " + offlineCheckOutBody.length.toString());

  //         setState(() {});

  //         log("offlineCheckOutBody Final " +
  //             offlineCheckOutBody.length.toString());
  //         log("offlineCheckOutBody Final " + offlineCheckOutBody.toString());
  //         offlineCheckOutBody.forEach((element) {
  //           log(element.toString());
  //         });
  //       });
  //     });
  //   });

  //   // offlineCheckOutBody.add(value)
  //   // var allCheckOutOrderRows = await dbhelper.fetchAllCheckOutOrder(checkOutId);
  //   // log(allCheckOutOrderRows.toString());
  // }

  fetchCategory(String brandId) {
    setState(() {
      loading = true;
    });
    _currentDealer = _currentDealer;
    _categoryList.clear();
    setState(() {});

    _categoryList.add(AllString.select);

    setState(() {});
    Navigator.pop(context);

    // loading = true;
    // setState(() {});
    // Map data = {
    //   "companyId":
    //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
    //   "divisionId": _currentCategory.split(AllString.splitText).last
    // };
    // apiPostRequestWithHeader(
    //         data, AllUrls.getModelByDivision, this.context, loginToken)
    //     .then((response) {
    //   if (response == null) {
    //     loading = false;
    //     setState(() {});
    //     commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    //   } else {
    //     Map<String, dynamic> jsonData = json.decode(response);
    //     if (checkApiResponseSuccessOrNot(jsonData)) {
    // if (jsonData["modelData"] == "" || jsonData["modelData"] == []) {
    //   _productList = [];
    // } else {
    //   List _tempList = jsonData["modelData"];
    //   _tempList.forEach((element) {
    //     _productList.add(element["modelNo"].toString() +
    //         AllString.splitText +
    //         element["productModelId"].toString());
    //   });
    // }

    // if (_productList.length == 2) {
    //   _currentProduct = _productList.last;
    // }
    // _currentDealer = _currentDealer;

    // AppBuilder.of(context)!.rebuild();
    // Future.delayed(Duration(milliseconds: 300), () {
    //   _currentDealer = _currentDealer;

    //   addOrderDialog();
    //   setState(() {
    //     loading = false;
    //   });
    // });
    //     } else {
    //       setState(() {
    //         loading = false;
    //       });
    //       commonAlertDialog(context, jsonData["status"], jsonData["message"]);
    //     }
    //   }
    // });
    if (sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            null ||
        sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            "") {
      sharedPreferences!
          .setString(AllSharedPreferencesKey.allCommonDataJson, "");
    } else {
      Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
          .getString(AllSharedPreferencesKey.allCommonDataJson)!);
      log("divisionDetailsssss " +
          jsonDataForCommon["commonData"]["divisionDetails"].toString());
      if (jsonDataForCommon["commonData"]["divisionDetails"] == "" ||
          jsonDataForCommon["commonData"]["divisionDetails"] == []) {
        _categoryList = [];
      } else {
        List _tempList = jsonDataForCommon["commonData"]["divisionDetails"];

        _tempList.forEach((element) {
          if (element["brandId"].toString() == brandId) {
            _categoryList.add(element["productCategoryName"].toString() +
                AllString.splitText +
                element["productCategoryId"].toString());
          }
        });

        if (_categoryList.length == 2) {
          _currentCategory = _categoryList.last;
        }
        _currentDealer = _currentDealer;

        AppBuilder.of(context)!.rebuild();
        Future.delayed(Duration(milliseconds: 300), () {
          _currentDealer = _currentDealer;

          addOrderDialog();
          setState(() {
            loading = false;
          });
        });
      }

      // Map<String, dynamic> jsonDataForAllProduct = json.decode(
      //     sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
      // List tempListForAllProduct = jsonDataForAllProduct["data"];
      // tempListForAllProduct.forEach((element) {
      //   if (element["categoryId"].toString() == productId) {
      //     _productList.add(element["productname"].toString() +
      //         AllString.splitText +
      //         element["productId"].toString());
      //   }
      // });
    }
  }

  fetchPurposeOfVisit() {
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.visitingPurpose, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _purposeOfVisitList.clear();
          _purposeOfVisitList.add(AllString.select);

          if (jsonData["vivsitingList"].toString() == "") {
            _purposeOfVisitList.clear();
          } else {
            List _tempList = jsonData["vivsitingList"];
            _tempList.forEach((element) {
              _purposeOfVisitList.add(element["visitPurposeName"].toString() +
                  AllString.splitText +
                  element["visitPurposeId"].toString());
            });
          }
          if (_purposeOfVisitList.length > 1) {
            selectedPurposeOfVisit = _purposeOfVisitList[1];
            setState(() {});
          }
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}
