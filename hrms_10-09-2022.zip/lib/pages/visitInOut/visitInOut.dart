import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/visitInOut/visitInOutBody.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class VisitInOut extends StatefulWidget {
  const VisitInOut({Key? key}) : super(key: key);
  @override
  _VisitInOutState createState() => _VisitInOutState();
}

class _VisitInOutState extends State<VisitInOut> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
              context, CupertinoPageRoute(builder: (context) => Home()));
          return true;
        },
        child: Scaffold(
            backgroundColor: AllColor.white,
            appBar:
                customAppBarForBackHome(context, AllString.visitDetailsInOut),
            body: VisitInOutBody()));
  }
}
