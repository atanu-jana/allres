import 'package:flutter/material.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class PdfView extends StatefulWidget {
  final String title;
  final String url;
  const PdfView({Key? key, required this.title, required this.url})
      : super(key: key);

  @override
  _PdfViewState createState() => _PdfViewState();
}

class _PdfViewState extends State<PdfView> {
  Future<void> secureScreen() async {
    await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
  }

  Future<void> unsecureScreen() async {
    await FlutterWindowManager.clearFlags(FlutterWindowManager.FLAG_SECURE);
  }

  @override
  void initState() {
    secureScreen();
    super.initState();
  }

  @override
  void dispose() {
    unsecureScreen();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: customAppBarForBackHome(context, widget.title),
        body: Container(
            child: SfPdfViewer.network(
          widget.url,
          //  canShowScrollHead: false,
          // canShowScrollStatus: false,
          // canShowPaginationDialog: false
        )));
  }
}
