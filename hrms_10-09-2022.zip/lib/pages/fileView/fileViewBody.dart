import 'dart:developer';
import 'dart:convert';
import 'dart:io';
import 'package:hr/common/commonFluttertoast.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/fileView/pdfView.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/requestPermission.dart';
import 'package:open_file/open_file.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:permission_handler/permission_handler.dart';

class FileViewBody extends StatefulWidget {
  @override
  _FileViewBodyState createState() => _FileViewBodyState();
}

class _FileViewBodyState extends State<FileViewBody> {
  bool loading = false;
  int indexForBottomDetails = 0;
  Widget bottomDetailsWidget = Container();
  List _employeeSupportDocuments = [];
  List _companyRoleDocuments = [];
  @override
  void initState() {
    super.initState();

    fetchFiles();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
                        decoration:customBackgroundGradient(),

        width: screenWidth,
        height: screenHeight,
        child: ListView(
          shrinkWrap: true,
          children: [
            customTabBar(),
            SizedBox(
              height: screenWidth * 0.03,
            ),
            Container(
              child: bottomDetailsWidget,
            )
          ],
        ),
      ),
    );
  }

  customEmployeeSupportItem(Map<String, dynamic> itemData) {
    return GestureDetector(
      onTap: () {
        Navigator.of(this.context).push(CupertinoPageRoute(
            builder: (context) => PdfView(
                  title: itemData["paySlipMonth"],
                  url: itemData["paySlipPDFLink"],
                )));
        // downloadControl(itemData["documentPDFLink"]);
      },
      child: Container(
        height: screenWidth * 0.23,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        decoration: BoxDecoration(
            color: AllColor.lightBlueGrey,
            borderRadius: BorderRadius.circular(10)),
        child: Container(
          width: screenWidth * 0.22,
          height: screenWidth * 0.23,
          decoration: BoxDecoration(
              border: Border.all(color: AllColor.black),
              color: AllColor.white,
              borderRadius: BorderRadius.circular(10)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              largeIcon(LineIcons.pdfFile, color: AllColor.black),
              Text(
                itemData["paySlipMonth"],
                textAlign: TextAlign.start,
                style: normalTextStyle(color: AllColor.black),
              ),
            ],
          ),
        ),
      ),
    );
  }

  customComapanySupportItem(Map<String, dynamic> itemData) {
    return GestureDetector(
      onTap: () {
        Navigator.of(this.context).push(CupertinoPageRoute(
            builder: (context) => PdfView(
                  title: itemData["docName"],
                  url: itemData["docLink"],
                )));
        // downloadControl(itemData["RoleDocument"]);
      },
      child: Container(
        height: screenWidth * 0.23,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        decoration: BoxDecoration(
            color: AllColor.lightBlueGrey,
            borderRadius: BorderRadius.circular(10)),
        child: Container(
          width: screenWidth * 0.22,
          height: screenWidth * 0.23,
          decoration: BoxDecoration(
              border: Border.all(color: AllColor.black),
              color: AllColor.white,
              borderRadius: BorderRadius.circular(10)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              largeIcon(LineIcons.pdfFile, color: AllColor.black),
              Text(
                itemData["docName"],
                textAlign: TextAlign.start,
                style: normalTextStyle(color: AllColor.black),
              ),
            ],
          ),
        ),
      ),
    );
  }

  fetchFiles() async {
    var jsonData = json.decode(personalFile);
    log(jsonData.toString());
    _employeeSupportDocuments = jsonData["paySlipDocuments"];
    _companyRoleDocuments = jsonData["CompanyRoleDocuments"];
    setState(() {});
    widgetBottomDetails();
  }

  widgetBottomDetails() {
    if (indexForBottomDetails == 0) {
      bottomDetailsWidget = Container(
          margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
          child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 1.5,
                mainAxisSpacing: 1.5,
                childAspectRatio: 1.5,
              ),
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              padding: EdgeInsets.zero,
              itemCount: _employeeSupportDocuments.length,
              itemBuilder: (context, index) =>
                  customEmployeeSupportItem(_employeeSupportDocuments[index]))
          // child: ListView.builder(
          //     shrinkWrap: true,
          //     padding: EdgeInsets.only(bottom: screenWidth * 0.03),
          //     physics: BouncingScrollPhysics(),
          //     itemCount: _employeeSupportDocuments.length,
          //     itemBuilder: (context, index) =>
          //         customEmployeeSupportItem(_employeeSupportDocuments[index])),
          );
    } else {
      bottomDetailsWidget = Container(
          margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
          child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 1.5,
                mainAxisSpacing: 1.5,
                childAspectRatio: 1.5,
              ),
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              padding: EdgeInsets.zero,
              itemCount: _companyRoleDocuments.length,
              itemBuilder: (context, index) =>
                  customComapanySupportItem(_companyRoleDocuments[index]))
          // child: ListView.builder(
          //     shrinkWrap: true,
          //     padding: EdgeInsets.only(bottom: screenWidth * 0.03),
          //     physics: BouncingScrollPhysics(),
          //     itemCount: _companyRoleDocuments.length,
          //     itemBuilder: (context, index) =>
          //         customComapanySupportItem(_companyRoleDocuments[index])),
          );
    }
  }

  customTabBar() {
    return Container(
      width: screenWidth,
      decoration: BoxDecoration(
          color: AllColor.white,
          border: Border(
              bottom: BorderSide(color: AllColor.lightGrey, width: 1.5))),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              indexForBottomDetails = 0;
              setState(() {});

              widgetBottomDetails();
            },
            child: Container(
              alignment: Alignment.center,
              height: screenWidth * 0.1,
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
              decoration: BoxDecoration(
                  color: AllColor.white,
                  border: Border(
                      bottom: BorderSide(
                          color: indexForBottomDetails == 0
                              ? AllColor.primaryColor
                              : AllColor.transparentColor,
                          width: 3))),
              child: normalText(AllString.paySlip, color: AllColor.black),
            ),
          ),
          GestureDetector(
            onTap: () {
              indexForBottomDetails = 1;
              setState(() {});
              widgetBottomDetails();
            },
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
              alignment: Alignment.center,
              height: screenWidth * 0.1,
              decoration: BoxDecoration(
                  color: AllColor.white,
                  border: Border(
                      bottom: BorderSide(
                          color: indexForBottomDetails == 1
                              ? AllColor.primaryColor
                              : AllColor.transparentColor,
                          width: 3))),
              child: normalText(AllString.companyPolicy, color: AllColor.black),
            ),
          ),
        ],
      ),
    );
  }

  downloadControl(String url) async {
    try {
      if (Platform.isAndroid) {
        try {
          if (await requestPermission(Permission.storage, this.context)) {
            try {
              commonFluttertoast(msg: "Download Starting...");

              final http.Response downloadData = await http.get(Uri.parse(url));
              Directory directory;

              directory = (await getExternalStorageDirectory())!;
              String newPath = "";
              List<String> folders = directory.path.split("/");
              for (int x = 1; x < folders.length; x++) {
                String folder = folders[x];
                if (folder != "Android") {
                  newPath += "/" + folder;
                } else {
                  break;
                }
              }

              newPath = newPath + "/HR/Files";
              directory = Directory(newPath);
              if (!await directory.exists()) {
                await directory.create(recursive: true);
              }
              if (await directory.exists()) {
                File filge =
                    new File(join('${directory.path}/${timestamp()}.pdf'));
                var bodyBytfes = downloadData.bodyBytes;
                commonFluttertoast(
                    msg: "Download File into: " +
                        '${directory.path}/${timestamp()}.pdf');
                filge.writeAsBytesSync(bodyBytfes);
                // ignore: unnecessary_cast
                Uint8List bytes = filge.readAsBytesSync() as Uint8List;
                ByteData.view(bytes.buffer);
                OpenFile.open(filge.path);
              }
            } catch (e) {}
          } else {
            commonFluttertoast(msg: "Need storage permission");
          }
        } catch (e) {}
      } else {
        // Not IOS
      }
    } catch (e) {}
  }

  String personalFile = '''
 {
  "paySlipDocuments": [
    {
      "id": "1",
      "paySlipMonth": "April 2021",
      "paySlipPDFLink": "http://3.20.47.115/website/hrms-pdf/Salary%20Slip%204.pdf"
    },
    {
      "id": "2",
      "paySlipMonth": "May 2021",
      "paySlipPDFLink": "http://3.20.47.115/website/hrms-pdf/Salary%20Slip%204.pdf"
    },
    {
      "id": "3",
      "paySlipMonth": "June 2021",
      "paySlipPDFLink": "http://3.20.47.115/website/hrms-pdf/Salary%20Slip%204.pdf"
    },
    {
      "id": "4",
      "paySlipMonth": "July 2021",
      "paySlipPDFLink": "http://3.20.47.115/website/hrms-pdf/Salary%20Slip%204.pdf"
    }
  ],
  "CompanyRoleDocuments": [
    {
      "id": "1",
      "docName": "Manager",
      "docLink": "http://3.20.47.115/website/hrms-pdf/EMPLOYEE%20HANDBOOK%202021.pdf"
    },
    {
      "id": "2",
      "docName": "HR",
      "docLink": "http://3.20.47.115/website/hrms-pdf/EMPLOYEE%20HANDBOOK%202021.pdf"
    }
  ]
}
  ''';
}
