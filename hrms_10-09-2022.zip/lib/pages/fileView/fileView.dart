import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/pages/fileView/fileViewBody.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpenseBody.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class FileView extends StatefulWidget {
  const FileView({Key? key}) : super(key: key);
  @override
  _FileViewState createState() => _FileViewState();
}

class _FileViewState extends State<FileView> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBarForBackHome(context, AllString.fileView),
        body: FileViewBody());
  }
}
