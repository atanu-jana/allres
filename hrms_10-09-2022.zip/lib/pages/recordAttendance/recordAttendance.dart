import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/recordAttendance/recordAttendanceBody.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class RecordAttendance extends StatefulWidget {
  @override
  _RecordAttendanceState createState() => _RecordAttendanceState();
}

class _RecordAttendanceState extends State<RecordAttendance> {
  bool loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,

      appBar: customAppBarForBackHome(context, AllString.recordAttendance),
      body: RecordAttendanceBody(),
    );
  }
}
