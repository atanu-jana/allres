import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonAlertDialogWithYesNo.dart';
import 'package:hr/common/commonFluttertoast.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/recordAttendance/myAttendance.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:intl/intl.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:permission_handler/permission_handler.dart';

class RecordAttendanceBody extends StatefulWidget {
  @override
  _RecordAttendanceBodyState createState() => _RecordAttendanceBodyState();
}

class _RecordAttendanceBodyState extends State<RecordAttendanceBody> {
  bool isPunchInEnable = false;
  bool isPunchInClicked = false;

  bool isPunchOutEnable = false;
  bool isPunchOutClicked = false;

  bool isStartBreakEnable = false;
  bool isStartBreakClicked = false;

  bool isEndBreakEnable = false;
  bool isEndBreakClicked = false;
  bool loading = false;
  final List<Marker> _markers = [];
  String location = "";
  late GoogleMapController _controller;

  late Position currentPosition;
  @override
  void initState() {
    super.initState();
    checkAndFetchLocation();
    offlineDayStartDayEndAllDataFetch();
    // offlineBreakStartBreakEndAllDataFetch();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: SingleChildScrollView(
        child: Container(
          width: screenWidth,
          height: screenHeight - 80,
          decoration: customBackgroundGradient(),
          child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.05,
            ),
            child: ListView(
              padding: AllMargin.customBottomLarge(),
              physics: BouncingScrollPhysics(),
              // mainAxisAlignment: MainAxisAlignment.spaceAround,
              // crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                topCard(),
                Container(
                  width: screenWidth,
                  // height: screenWidth * 0.7,
                  height: screenWidth >= 600
                      ? screenWidth * 0.45
                      : screenWidth * 0.7,
                  decoration: BoxDecoration(
                      border: Border.all(width: 5, color: AllColor.lightBlack),
                      color: AllColor.primaryColor,
                      borderRadius: BorderRadius.circular(15)),
                  child: GoogleMap(
                    // myLocationEnabled: true,
                    // myLocationButtonEnabled: true,

                    compassEnabled: true,
                    mapType: MapType.normal,
                    scrollGesturesEnabled: false,
                    cameraTargetBounds: CameraTargetBounds.unbounded,
                    markers: _markers.toSet(),

                    zoomGesturesEnabled: true,
                    initialCameraPosition: CameraPosition(
                        target: LatLng(
                          22.6069698,
                          88.40281379999999,
                        ),
                        zoom: 12.0),
                    onMapCreated: (GoogleMapController controller) {
                      _controller = controller;
                      _controller = _controller;
                    },
                  ),
                ),
                SizedBox(
                  // height: screenWidth * 0.03,
                  height: screenWidth * 0.05,
                ),
                // customAnimatedButton(context, function: (_) {
                //   commonAlertDialogWithCloseButtonWithWidget(
                //       context,
                //       AllColor.blueGrey,
                //       Container(
                //         child: Column(
                //           mainAxisSize: MainAxisSize.min,
                //           children: [
                //             Container(
                //               alignment: Alignment.center,
                //               width: screenWidth,
                //               height: screenWidth * 0.1,
                //               decoration: BoxDecoration(
                //                 color: AllColor.blueGrey,
                //                 borderRadius: BorderRadius.only(
                //                   topLeft: Radius.circular(16.0),
                //                   topRight: Radius.circular(16.0),
                //                 ),
                //               ),
                //               child: headingText(AllString.timeLogged,
                //                   color: AllColor.white),
                //             ),
                //             SizedBox(height: screenWidth * 0.03),
                //             ListView.builder(
                //               shrinkWrap: true,
                //               itemCount: 5,
                //               itemBuilder: (context, index) =>
                //                   customAttendanceLog(),
                //             ),
                //           ],
                //         ),
                //       ));
                // },
                //     color: AllColor.primaryColor,
                //     deepColor: AllColor.primaryDeepColor,
                //     textColor: AllColor.white,
                //     text: AllString.viewAttendanceLog,
                //     width: screenWidth),
                // button(
                //   context,
                //   function: () {
                //     commonAlertDialogWithCloseButtonWithWidget(
                //         context,
                //         AllColor.blueGrey,
                //         Container(
                //           child: Column(
                //             mainAxisSize: MainAxisSize.min,
                //             children: [
                //               Container(
                //                 alignment: Alignment.center,
                //                 width: screenWidth,
                //                 height: screenWidth * 0.1,
                //                 decoration: BoxDecoration(
                //                   color: AllColor.blueGrey,
                //                   borderRadius: BorderRadius.only(
                //                     topLeft: Radius.circular(16.0),
                //                     topRight: Radius.circular(16.0),
                //                   ),
                //                 ),
                //                 child: headingText(AllString.timeLogged,
                //                     color: AllColor.white),
                //               ),
                //               SizedBox(height: screenWidth * 0.03),
                //               ListView.builder(
                //                 shrinkWrap: true,
                //                 itemCount: 5,
                //                 itemBuilder: (context, index) =>
                //                     customAttendanceLog(),
                //               ),
                //             ],
                //           ),
                //         ));
                //   },
                //   color1: Color(0xff536976),
                //   color2: Color(0xff292E49),
                //   textColor: AllColor.white,
                //   text: AllString.viewAttendanceLog,
                // ),
                SizedBox(
                  height: screenWidth * 0.03,
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.03,
                  ),
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 7,
                          offset: Offset(0, 3), // changes position of shadow
                        ),
                      ],
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(7)),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: screenWidth,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                // if (sharedPreferences!
                                //         .getString(AllSharedPreferencesKey
                                //             .attendanceStatus)!
                                //         .trim() ==
                                //     "1") {
                                //   isPunchInEnable = false;
                                //   isPunchInClicked = false;

                                //   isPunchOutEnable = false;
                                //   isPunchOutClicked = false;

                                //   isStartBreakEnable = false;
                                //   isStartBreakClicked = false;

                                //   isEndBreakEnable = false;
                                //   isEndBreakClicked = false;
                                //   setState(() {});

                                //   //commonAlertDialog(context, AllString.alert, AllString.alreadyPunchAlert);

                                //   commonAlertDialog(context, AllString.alert,
                                //       AllString.alreadyPunchAlert,
                                //       function: () {
                                //     Navigator.pop(context);
                                //   });
                                // } else
                                if ((sharedPreferences!
                                        .getString(
                                            AllSharedPreferencesKey.punchInId)!
                                        .isEmpty) &&
                                    (sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .breakPunchId)!
                                        .isEmpty) &&
                                    isPunchInEnable) {
                                  commonAlertDialogWithYesNo(
                                      context,
                                      AllString.alert,
                                      AllString
                                          .areYouSureYouWanttoStartYourDayWithPunchIn,
                                      yesFunction: () {
                                    sharedPreferences!.setDouble(
                                        AllSharedPreferencesKey.positionForSend,
                                        0.0);

                                    commonPunchInPunch('');

                                    isPunchInEnable = true;
                                    isPunchInClicked = true;

                                    isPunchOutEnable = true;
                                    isPunchOutClicked = false;

                                    isStartBreakEnable = true;
                                    isStartBreakClicked = false;

                                    isEndBreakEnable = false;
                                    isEndBreakClicked = false;
                                    setState(() {});
                                    Navigator.pop(context);
                                  });
                                }
                              },
                              child: Container(
                                width: screenWidth * 0.405,
                                height: screenWidth * 0.13,
                                decoration: BoxDecoration(
                                    color: isPunchInEnable
                                        ? isPunchInClicked
                                            ? AllColor.white
                                            : Color(0xff2e7d32)
                                        : AllColor.white,
                                    borderRadius: BorderRadius.circular(7),
                                    border: Border.all(
                                        color: isPunchInEnable
                                            ? Color(0xff2e7d32)
                                            : isPunchInClicked
                                                ? AllColor.white
                                                : AllColor.greyColor,
                                        width: 2)),
                                alignment: Alignment.center,
                                child: normalText("Start Your Day",
                                    color: isPunchInEnable
                                        ? isPunchInClicked
                                            ? Color(0xff2e7d32)
                                            : AllColor.white
                                        : AllColor.greyColor),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                if ((sharedPreferences!
                                        .getString(
                                            AllSharedPreferencesKey.punchInId)!
                                        .isNotEmpty) &&
                                    (sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .breakPunchId)!
                                        .isEmpty) &&
                                    isPunchOutEnable) {
                                  if (sharedPreferences!
                                      .getString(
                                          AllSharedPreferencesKey.checkInId)!
                                      .isNotEmpty) {
                                    commonAlertDialog(context, AllString.alert,
                                        AllString.pleaseVisitOutBeforePunchOut);
                                  } else {
                                    commonAlertDialogWithYesNo(
                                        context,
                                        AllString.alert,
                                        AllString
                                            .areYouSureYouWanttoEndYourDayWithPunchOut,
                                        yesFunction: () {
                                      if (!isStartBreakClicked) {
                                        isPunchInEnable = false;
                                        isPunchInClicked = false;

                                        isPunchOutEnable = false;
                                        isPunchOutClicked = false;

                                        isEndBreakEnable = false;
                                        isEndBreakClicked = false;

                                        isStartBreakEnable = false;
                                        isStartBreakClicked = false;
                                        sharedPreferences!.setDouble(
                                            AllSharedPreferencesKey
                                                .positionForSend,
                                            0.0);
                                        commonPunchInPunch(sharedPreferences!
                                            .getString(AllSharedPreferencesKey
                                                .punchInId)!);
                                      }
                                      Navigator.pop(context);
                                    }, noFunction: () {
                                      Navigator.pop(context);
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                              builder: (context) =>
                                                  MyExpense()));
                                    });
                                  }
                                }

                                // commonAlertDialog(
                                //     context,
                                //     "",
                                //     AllString
                                //         .youHaveSuccessfullyPunchOutForToday,
                                //     function: () {
                                //   isPunchInEnable = false;
                                //   isPunchInClicked = false;

                                //   isPunchOutEnable = false;
                                //   isPunchOutClicked = false;

                                //   isEndBreakEnable = false;
                                //   isEndBreakClicked = false;

                                //   isStartBreakEnable = false;
                                //   isStartBreakClicked = false;
                                //   setState(() {});
                                //   Navigator.of(context).pushReplacement(
                                //       CupertinoPageRoute(
                                //           builder: (context) => Home()));
                                // });
                              },
                              child: Container(
                                width: screenWidth * 0.405,
                                height: screenWidth * 0.13,
                                decoration: BoxDecoration(
                                    color: isPunchOutEnable
                                        ? Color(0xff2e7d32)
                                        : AllColor.white,
                                    borderRadius: BorderRadius.circular(7),
                                    border: Border.all(
                                        color: isPunchOutEnable
                                            ? Color(0xff2e7d32)
                                            : AllColor.greyColor,
                                        width: 2)),
                                alignment: Alignment.center,
                                child: normalText("End Your Day",
                                    // AllString.punchOut,
                                    color: isPunchOutEnable
                                        ? AllColor.white
                                        : AllColor.greyColor),
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: screenWidth * 0.03,
                      ),
                      Container(
                        width: screenWidth,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                if ((sharedPreferences!
                                        .getString(
                                            AllSharedPreferencesKey.punchInId)!
                                        .isNotEmpty) &&
                                    (sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .breakPunchId)!
                                        .isEmpty) &&
                                    isStartBreakEnable) {
                                  commonStartBreakAndEnd(
                                      '',
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey.punchInId)!);
                                  isPunchInEnable = true;
                                  isPunchInClicked = true;

                                  isPunchOutEnable = false;
                                  isPunchOutClicked = false;

                                  isStartBreakEnable = true;
                                  isStartBreakClicked = true;

                                  isEndBreakEnable = true;
                                  isEndBreakClicked = false;
                                  setState(() {});
                                }
                              },
                              child: Container(
                                width: screenWidth * 0.405,
                                height: screenWidth * 0.13,
                                decoration: BoxDecoration(
                                    color: isStartBreakEnable
                                        ? isStartBreakClicked
                                            ? AllColor.white
                                            : Color(0xff1976d2)
                                        : AllColor.white,
                                    borderRadius: BorderRadius.circular(7),
                                    border: Border.all(
                                        color: isStartBreakEnable
                                            ? isStartBreakClicked
                                                ? Color(0xff1976d2)
                                                : Color(0xff1976d2)
                                            : AllColor.greyColor,
                                        width: 2)),
                                alignment: Alignment.center,
                                child: normalText(AllString.startBreak,
                                    color: isStartBreakEnable
                                        ? isStartBreakClicked
                                            ? Color(0xff1976d2)
                                            : AllColor.white
                                        : AllColor.greyColor),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                if ((sharedPreferences!
                                        .getString(
                                            AllSharedPreferencesKey.punchInId)!
                                        .isNotEmpty) &&
                                    (sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .breakPunchId)!
                                        .isNotEmpty) &&
                                    isEndBreakEnable) {
                                  commonStartBreakAndEnd(
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey
                                              .breakPunchId)!,
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey.punchInId)!);
                                  isPunchInEnable = true;
                                  isPunchInClicked = true;

                                  isPunchOutEnable = true;
                                  isPunchOutClicked = false;

                                  isStartBreakEnable = true;
                                  isStartBreakClicked = false;

                                  isEndBreakEnable = false;
                                  isEndBreakClicked = false;
                                  setState(() {});
                                }
                              },
                              child: Container(
                                width: screenWidth * 0.405,
                                height: screenWidth * 0.13,
                                decoration: BoxDecoration(
                                    color: isEndBreakEnable
                                        ? Color(0xff1976d2)
                                        : AllColor.white,
                                    borderRadius: BorderRadius.circular(7),
                                    border: Border.all(
                                        color: isEndBreakEnable
                                            ? Color(0xff1976d2)
                                            : AllColor.greyColor,
                                        width: 2)),
                                alignment: Alignment.center,
                                child: normalText(AllString.endBreak,
                                    color: isEndBreakEnable
                                        ? AllColor.white
                                        : AllColor.greyColor),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: screenWidth * 0.03,
                ),
                // customAnimatedButton(context, function: (_) {
                //   Navigator.push(context,
                //       CupertinoPageRoute(builder: (context) => MyAttendance()));
                // },
                //     color: AllColor.primaryColor,
                //     deepColor: AllColor.primaryDeepColor,
                //     textColor: AllColor.white,
                //     text: AllString.myAttendance,
                //     width: screenWidth),
                button(
                  context,
                  function: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => MyAttendance(
                                  fromRecordAttendance: true,
                                )));
                  },
                  color: AllColor.primaryColor,
                  textColor: AllColor.white,
                  text: AllString.viewAttendance,
                ),

                sharedPreferences!.getString(
                            AllSharedPreferencesKey.attendanceStatus) ==
                        "1"
                    ? Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.03,
                          vertical: screenWidth * 0.03,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(
                                  vertical: screenWidth * 0.03),
                              child: Column(
                                children: [
                                  Container(
                                      alignment: Alignment.center,
                                      padding: EdgeInsets.symmetric(
                                          vertical: screenWidth * 0.01),
                                      child: extraSmallText(
                                          "*" + AllString.alreadyPunchAlert,
                                          color: AllColor.red,
                                          center: true,
                                          fontWeight: FontWeight.bold)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  topCard() {
    return Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 7,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
          color: AllColor.white,
          borderRadius: BorderRadius.all(
            Radius.circular(7),
          ),
        ),
        margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: screenWidth * 0.01,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.015),
              child: Text(
                sharedPreferences!
                                .getString(AllSharedPreferencesKey.location) ==
                            null ||
                        sharedPreferences!
                            .getString(AllSharedPreferencesKey.location)!
                            .toString()
                            .isEmpty
                    ? AllString.na
                    : "Location: " +
                        sharedPreferences!
                            .getString(AllSharedPreferencesKey.location)!,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.black),
              ),
            ),
            SizedBox(
              height: screenWidth * 0.02,
            ),
            StreamBuilder(
              stream: Stream.periodic(const Duration(seconds: 1)),
              builder: (context, snapshot) {
                return Center(
                  child: normalText(
                      DateFormat('hh:mm:ss a').format(DateTime.now()),
                      color: AllColor.black,
                      fontWeight: FontWeight.bold),
                );
              },
            ),
            SizedBox(
              height: screenWidth * 0.02,
            ),
            ClipRRect(
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(7),
                bottomRight: Radius.circular(7),
              ),
              child: Stack(
                children: [
                  Container(
                    height: screenWidth * 0.1,
                    width: screenWidth,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(7),
                        bottomRight: Radius.circular(7),
                      ),
                    ),
                    child: Container(
                      child: normalText(AllString.recordTodaysAttendance,
                          color: AllColor.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Positioned(
                    right: screenWidth * 0.02,
                    bottom: 0,
                    child: IconButton(
                        onPressed: () {
                          checkAndFetchLocation();
                        },
                        icon:
                            Icon(Icons.refresh, color: AllColor.primaryColor)),
                  ),
                ],
              ),
            )
          ],
        ));
  }

  // customAttendanceLog() {
  //   return customRowContainer("Day Start", "20-08-2021 10:00 AM",
  //       bottomborder: true);
  // }

  customRowContainer(String title, String text, {bool bottomborder = true}) {
    return Container(
      width: screenWidth * 0.75,
      margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
      padding: EdgeInsets.only(bottom: screenWidth * 0.02),
      decoration: bottomborder
          ? BoxDecoration(
              border: Border(
                  bottom:
                      BorderSide(color: AllColor.greyColor.withOpacity(0.45))))
          : BoxDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: screenWidth * 0.23,
            child: smallText(title + ":", color: AllColor.greyColor),
          ),
          Container(
            width: screenWidth * 0.45,
            child: normalText(text, color: AllColor.black),
          ),
        ],
      ),
    );
  }

  getCurrentLocation() async {
    Permission.location.request().then((value) async {
      var status = await Permission.location.status;
      log(status.toString());
      if (await Permission.location.isRestricted) {
        commonAlertDialog(
            context, AllString.error, AllString.msgForRestrictedLocation,
            function: () {
          Navigator.of(context).pushReplacement(
              CupertinoPageRoute(builder: (context) => Home()));
        });
      } else {
        if (status.isDenied) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForDeniedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          Position position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high);
          currentPosition = position;
          setState(() {});
          List<Placemark> placemarks = await placemarkFromCoordinates(
              position.latitude, position.longitude);
          if (placemarks.isNotEmpty) {
            Placemark placeMark = placemarks[0];
            setState(() {});
            log(placeMark.toString());
            location = placeMark.locality! +
                ", " +
                placeMark.subLocality! +
                " " +
                placeMark.name! +
                ", Street: " +
                placeMark.street! +
                ", " +
                placeMark.administrativeArea! +
                " " +
                placeMark.subAdministrativeArea! +
                ", Pincode: " +
                placeMark.postalCode! +
                ", " +
                placeMark.country!;
            sharedPreferences!
                .setString(AllSharedPreferencesKey.location, location);
            checkAttendanceStatus();
            //checkAllButtonValidation();
            // locationLatLon.text =
            //     position.latitude.toString() + " " + position.longitude.toString();
          }
          setState(() {});
          final marker = Marker(
            markerId: MarkerId("ID"),
            position: LatLng(position.latitude, position.longitude),
            infoWindow: InfoWindow(
              title: "Home",
              // snippet: "address",
            ),
            onTap: () {
              //_pageController.jumpToPage(i);
            },
            icon: BitmapDescriptor.defaultMarker,
          );
          _markers.add(marker);
          setState(() {});
          Future.delayed(Duration(seconds: 3), () {
            _controller.animateCamera(CameraUpdate.newCameraPosition(
                CameraPosition(
                    target: LatLng(position.latitude, position.longitude),
                    zoom: 18.0)));
          });

          setState(() {});
        }
      }
    });
  }

  commonPunchInPunch(String punchInId) async {
    if (await internetCheck()) {
      loading = true;
      setState(() {});

      Permission.location.request().then((value) async {
        var status = await Permission.location.status;
        log(status.toString());
        if (await Permission.location.isRestricted) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForRestrictedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          if (status.isDenied) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForDeniedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            Position position = await Geolocator.getCurrentPosition(
                desiredAccuracy: LocationAccuracy.high);
            currentPosition = position;

            setState(() {});
            List<Placemark> placemarks = await placemarkFromCoordinates(
                position.latitude, position.longitude);
            if (placemarks.isNotEmpty) {
              Placemark placeMark = placemarks[0];
              setState(() {});
              log(placeMark.toString());
              location = placeMark.locality! +
                  ", " +
                  placeMark.subLocality! +
                  " " +
                  placeMark.name! +
                  ", Street: " +
                  placeMark.street! +
                  ", " +
                  placeMark.administrativeArea! +
                  " " +
                  placeMark.subAdministrativeArea! +
                  ", Pincode: " +
                  placeMark.postalCode! +
                  ", " +
                  placeMark.country!;
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.location, location);
              sharedPreferences!.setString(AllSharedPreferencesKey.sendLatitude,
                  position.latitude.toString());
              log("(sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude): " +
                  (sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLatitude)!));
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.sendLongitude,
                  position.longitude.toString());

              Map data = {
                "userLoginId": loginUserId,
                "companyId": sharedPreferences!
                    .getString(AllSharedPreferencesKey.companyId),
                "individualId": sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId),
                "attendanceData": [
                  {
                    "attendanceId": punchInId,
                    "checkInLocation": punchInId.isNotEmpty
                        ? ""
                        : sharedPreferences!
                            .getString(AllSharedPreferencesKey.location),
                    "checkInLatitude":
                        punchInId.isNotEmpty ? "" : currentPosition.latitude,
                    "inTime":
                        punchInId.isNotEmpty ? "" : DateTime.now().toString(),
                    "outTime":
                        punchInId.isEmpty ? "" : DateTime.now().toString(),
                    "checkInLongitude":
                        punchInId.isNotEmpty ? "" : currentPosition.longitude,
                    "checkOutLocation": punchInId.isEmpty
                        ? ""
                        : sharedPreferences!
                            .getString(AllSharedPreferencesKey.location),
                    "checkOutLatitude":
                        punchInId.isEmpty ? "" : currentPosition.latitude,
                    "checkOutLongitude":
                        punchInId.isEmpty ? "" : currentPosition.longitude,
                  }
                ]
              };
              apiPostRequestWithHeader(data, AllUrls.addEmployeeAttendance,
                      this.context, loginToken)
                  .then((response) {
                if (response == null) {
                  loading = false;
                  setState(() {});
                  commonAlertDialog(
                      context, AllString.warning, AllString.connectionFailure);
                } else {
                  Map<String, dynamic> jsonData = json.decode(response);
                  if (checkApiResponseSuccessOrNot(jsonData)) {
                    setState(() {
                      loading = false;
                    });
                    log(jsonData["attendenceData"]["attendanceId"].toString());

                    fetchAndSetAllIdSettingConfig(context);

                    setState(() {});
                    Future.delayed(Duration(milliseconds: 600), () {
                      AppBuilder.of(context)!.rebuild();
                      setState(() {});
                    });
                    // sharedPreferences!.setString(
                    //     AllSharedPreferencesKey.attendanceStatus, "1");

                    commonAlertDialog(
                        context, jsonData["status"], jsonData["message"],
                        alertMsg: jsonData["notifiedMessage"] == null ||
                                jsonData["notifiedMessage"].isEmpty
                            ? null
                            : jsonData["notifiedMessage"].toString(),
                        function: () {
                      Navigator.pop(context);
                      checkAttendanceStatus();

                      // checkAllButtonValidation();
                    });
                  } else {
                    setState(() {
                      loading = false;
                    });
                    commonAlertDialog(
                        context, jsonData["status"], jsonData["message"]);
                  }
                }
              });
            }
            setState(() {});
          }
        }
      });
    } else {
      commonOfflinePunchInPunch(punchInId);
      // showOfflineSnakbar(context);
    }
  }

  commonStartBreakAndEnd(String breakPunchId, String punchInId) async {
    if (await internetCheck()) {
      loading = true;
      setState(() {});
      Map data = {
        "userLoginId":
            sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId)!,
        "breakData": [
          {
            "attendanceId": punchInId,
            "breakPunchId": breakPunchId,
            "inTime": breakPunchId.isNotEmpty ? "" : DateTime.now().toString(),
            "outTime": breakPunchId.isEmpty ? "" : DateTime.now().toString(),
          }
        ]
      };
      apiPostRequestWithHeader(
              data, AllUrls.breakStartEnd, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            fetchAndSetAllIdSettingConfig(context);
            Future.delayed(Duration(milliseconds: 600), () {
              AppBuilder.of(context)!.rebuild();
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.pop(context);
              //checkAttendanceStatus();
              checkAllButtonValidation();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      commonOfflineStartBreakAndEnd(breakPunchId, punchInId);

      // showOfflineSnakbar(context);
    }
  }

  checkAttendanceStatus() {
    if (sharedPreferences!
                .getString(AllSharedPreferencesKey.attendanceStatus) !=
            null &&
        sharedPreferences!
                .getString(AllSharedPreferencesKey.attendanceStatus)!
                .trim() ==
            "1") {
      isPunchInEnable = false;
      isPunchInClicked = false;

      isPunchOutEnable = false;
      isPunchOutClicked = false;

      isStartBreakEnable = false;
      isStartBreakClicked = false;

      isEndBreakEnable = false;
      isEndBreakClicked = false;
      setState(() {});

      //commonAlertDialog(context, AllString.alert, AllString.alreadyPunchAlert);

      commonAlertDialog(context, AllString.alert, AllString.alreadyPunchAlert,
          function: () {
        Navigator.pop(context);
      });
    } else {
      checkAllButtonValidation();
    }
  }

  checkAllButtonValidation() {
    if (sharedPreferences!.getString(AllSharedPreferencesKey.punchInId) ==
            null ||
        sharedPreferences!
                .getString(AllSharedPreferencesKey.punchInId)
                .toString()
                .toLowerCase() ==
            "null") {
      sharedPreferences!.setString(AllSharedPreferencesKey.punchInId, "");
    }
    if (sharedPreferences!.getString(AllSharedPreferencesKey.breakPunchId) ==
            null ||
        sharedPreferences!
                .getString(AllSharedPreferencesKey.breakPunchId)
                .toString()
                .toLowerCase() ==
            "null") {
      sharedPreferences!.setString(AllSharedPreferencesKey.breakPunchId, "");
    }
    setState(() {});
    print("Day Start Id: " +
        (sharedPreferences!.getString(AllSharedPreferencesKey.punchInId)!)
            .isEmpty
            .toString());
    print("Break Day Start Id: " +
        (sharedPreferences!.getString(AllSharedPreferencesKey.breakPunchId)!));

    //*    Mainly Punch In And Punch Out     *//
    if (sharedPreferences!
        .getString(AllSharedPreferencesKey.punchInId)!
        .isEmpty) {
      //! Only Punch In Enable Not Clicked
      isPunchInEnable = true;
      isPunchInClicked = false;

      isPunchOutEnable = false;
      isPunchOutClicked = false;

      isStartBreakEnable = false;
      isStartBreakClicked = false;

      isEndBreakEnable = false;
      isEndBreakClicked = false;
      setState(() {});
    } else {
      //!  Punch In Enable And Clicked By User And Also Enable Start Break and Punch Out

      isPunchInEnable = true;
      isPunchInClicked = true;

      isPunchOutEnable = true;
      isPunchOutClicked = false;

      isStartBreakEnable = true;
      isStartBreakClicked = false;

      isEndBreakEnable = false;
      isEndBreakClicked = false;
      setState(() {});
    }

    //*   Mainly Start And End Break Also Punch In And Punch Out      *//
    if ((sharedPreferences!
            .getString(AllSharedPreferencesKey.punchInId)!
            .isEmpty &&
        sharedPreferences!
            .getString(AllSharedPreferencesKey.breakPunchId)!
            .isEmpty)) {
      //! Only Punch In Enable Not Clicked

      isPunchInEnable = true;
      isPunchInClicked = false;

      isPunchOutEnable = false;
      isPunchOutClicked = false;

      isStartBreakEnable = false;
      isStartBreakClicked = false;

      isEndBreakEnable = false;
      isEndBreakClicked = false;
      setState(() {});
    } else if (sharedPreferences!
            .getString(AllSharedPreferencesKey.punchInId)!
            .isNotEmpty &&
        sharedPreferences!
            .getString(AllSharedPreferencesKey.breakPunchId)!
            .isEmpty) {
      //!  Punch In Enable And Clicked By User And Also Enable Start Break and Punch Out

      isPunchInEnable = true;
      isPunchInClicked = true;

      isPunchOutEnable = true;
      isPunchOutClicked = false;

      isStartBreakEnable = true;
      isStartBreakClicked = false;

      isEndBreakEnable = false;
      isEndBreakClicked = false;
      setState(() {});
    } else {
      //!  Punch In and Punch Out Disable And Also Enable and Clicked Start Break and End Break Enable

      isPunchInEnable = true;
      isPunchInClicked = true;

      isPunchOutEnable = false;
      isPunchOutClicked = false;

      isStartBreakEnable = true;
      isStartBreakClicked = true;

      isEndBreakEnable = true;
      isEndBreakClicked = false;
      setState(() {});
    }
  }

  checkAndFetchLocation() async {
    if (await internetCheck()) {
      getCurrentLocation();
    } else {
      if (sharedPreferences!.getString(AllSharedPreferencesKey.location) ==
              null ||
          sharedPreferences!.getString(AllSharedPreferencesKey.location) ==
              "") {
        sharedPreferences!.setString(AllSharedPreferencesKey.location, "");
      }
      if (sharedPreferences!.getString(AllSharedPreferencesKey.latitude) ==
              null ||
          sharedPreferences!.getString(AllSharedPreferencesKey.latitude) ==
              "") {
        sharedPreferences!.setString(AllSharedPreferencesKey.latitude, "");
      }
      if (sharedPreferences!.getString(AllSharedPreferencesKey.longitude) ==
              null ||
          sharedPreferences!.getString(AllSharedPreferencesKey.longitude) ==
              "") {
        sharedPreferences!.setString(AllSharedPreferencesKey.longitude, "");
      }
      loading = true;
      setState(() {});
      Permission.location.request().then((value) async {
        var status = await Permission.location.status;
        log(status.toString());
        if (await Permission.location.isRestricted) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForRestrictedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          if (status.isDenied) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForDeniedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            Position position = await Geolocator.getCurrentPosition(
                desiredAccuracy: LocationAccuracy.high);
            currentPosition = position;

            sharedPreferences!.setString(
                AllSharedPreferencesKey.latitude, position.latitude.toString());
            sharedPreferences!.setString(AllSharedPreferencesKey.longitude,
                position.longitude.toString());
            checkAttendanceStatus();
            //checkAllButtonValidation();
            loading = false;
            setState(() {});
          }
          setState(() {});
        }
      });
    }
  }

  commonOfflinePunchInPunch(String punchInId) {
    if (sharedPreferences!.getString(AllSharedPreferencesKey.location) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.location) == "") {
      sharedPreferences!.setString(AllSharedPreferencesKey.location, "");
    }
    if (sharedPreferences!.getString(AllSharedPreferencesKey.latitude) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.latitude) == "") {
      sharedPreferences!.setString(AllSharedPreferencesKey.latitude, "");
    }
    if (sharedPreferences!.getString(AllSharedPreferencesKey.longitude) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.longitude) == "") {
      sharedPreferences!.setString(AllSharedPreferencesKey.longitude, "");
    }
    loading = true;
    setState(() {});
    Permission.location.request().then((value) async {
      var status = await Permission.location.status;
      log(status.toString());
      if (await Permission.location.isRestricted) {
        commonAlertDialog(
            context, AllString.error, AllString.msgForRestrictedLocation,
            function: () {
          Navigator.of(context).pushReplacement(
              CupertinoPageRoute(builder: (context) => Home()));
        });
      } else {
        if (status.isDenied) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForDeniedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          Position position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high);
          currentPosition = position;

          sharedPreferences!.setString(
              AllSharedPreferencesKey.latitude, position.latitude.toString());
          sharedPreferences!.setString(
              AllSharedPreferencesKey.longitude, position.longitude.toString());
          sharedPreferences!.setString(AllSharedPreferencesKey.location,
              sharedPreferences!.getString(AllSharedPreferencesKey.location)!);
          sharedPreferences!.setString(AllSharedPreferencesKey.sendLatitude,
              position.latitude.toString());
          log("(sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude): " +
              (sharedPreferences!
                  .getString(AllSharedPreferencesKey.sendLatitude)!));
          sharedPreferences!.setString(AllSharedPreferencesKey.sendLongitude,
              position.longitude.toString());

          Map<String, dynamic> data = {
            Databasehelper.attendanceId: punchInId,
            Databasehelper.checkInLocation: punchInId.isNotEmpty
                ? ""
                : sharedPreferences!
                    .getString(AllSharedPreferencesKey.location),
            Databasehelper.checkInLatitude:
                punchInId.isNotEmpty ? "" : currentPosition.latitude,
            Databasehelper.punchInTime:
                punchInId.isNotEmpty ? "" : DateTime.now().toString(),
            Databasehelper.checkInLongitude:
                punchInId.isNotEmpty ? "" : currentPosition.longitude,
            Databasehelper.checkOutLocation: punchInId.isEmpty
                ? ""
                : sharedPreferences!
                    .getString(AllSharedPreferencesKey.location),
            Databasehelper.punchOutTime:
                punchInId.isEmpty ? "" : DateTime.now().toString(),
            Databasehelper.checkOutLatitude:
                punchInId.isEmpty ? "" : currentPosition.latitude,
            Databasehelper.checkOutLongitude:
                punchInId.isEmpty ? "" : currentPosition.longitude,
          };
          // ! Insert Row on Day Start and Day End Table

          AppBuilder.of(context)!.rebuild();

          final id = await dbhelper.insertDayStartDayEnd(data);
          var allrows = await dbhelper.fetchAllDayStartDayEnd();
          log(allrows.toString());

          commonAlertDialog(
              context,
              AllString.success,
              punchInId.isEmpty
                  ? "Day Started Successfully"
                  : "Day Ended Successfully", function: () async {
            sharedPreferences!.setString(AllSharedPreferencesKey.punchInId,
                punchInId.isEmpty ? random.nextInt(100).toString() : "");

            AppBuilder.of(context)!.rebuild();
            setState(() {
              loading = false;
            });
            Navigator.pop(context);
            setState(() {
              checkAllButtonValidation();
            });
          });
        }
      }
    });
  }

  commonOfflineStartBreakAndEnd(String breakPunchId, String punchInId) {
    if (sharedPreferences!.getString(AllSharedPreferencesKey.location) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.location) == "") {
      sharedPreferences!.setString(AllSharedPreferencesKey.location, "");
    }
    if (sharedPreferences!.getString(AllSharedPreferencesKey.latitude) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.latitude) == "") {
      sharedPreferences!.setString(AllSharedPreferencesKey.latitude, "");
    }
    if (sharedPreferences!.getString(AllSharedPreferencesKey.longitude) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.longitude) == "") {
      sharedPreferences!.setString(AllSharedPreferencesKey.longitude, "");
    }
    loading = true;
    setState(() {});
    Permission.location.request().then((value) async {
      var status = await Permission.location.status;
      log(status.toString());
      if (await Permission.location.isRestricted) {
        commonAlertDialog(
            context, AllString.error, AllString.msgForRestrictedLocation,
            function: () {
          Navigator.of(context).pushReplacement(
              CupertinoPageRoute(builder: (context) => Home()));
        });
      } else {
        if (status.isDenied) {
          commonAlertDialog(
              context, AllString.error, AllString.msgForDeniedLocation,
              function: () {
            Navigator.of(context).pushReplacement(
                CupertinoPageRoute(builder: (context) => Home()));
          });
        } else {
          Position position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high);
          currentPosition = position;

          sharedPreferences!.setString(
              AllSharedPreferencesKey.latitude, position.latitude.toString());
          sharedPreferences!.setString(
              AllSharedPreferencesKey.longitude, position.longitude.toString());
          sharedPreferences!.setString(AllSharedPreferencesKey.location,
              sharedPreferences!.getString(AllSharedPreferencesKey.location)!);
          sharedPreferences!.setString(AllSharedPreferencesKey.sendLatitude,
              position.latitude.toString());
          log("(sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude): " +
              (sharedPreferences!
                  .getString(AllSharedPreferencesKey.sendLatitude)!));
          sharedPreferences!.setString(AllSharedPreferencesKey.sendLongitude,
              position.longitude.toString());

          Map<String, dynamic> data = {
            Databasehelper.attendanceId: punchInId,
            Databasehelper.breakPunchId: breakPunchId,
            Databasehelper.breakStartTime:
                breakPunchId.isNotEmpty ? "" : DateTime.now().toString(),
            Databasehelper.breakEndTime:
                breakPunchId.isEmpty ? "" : DateTime.now().toString(),
          };
          // ! Insert Row on Day Start and Day End Table

          AppBuilder.of(context)!.rebuild();
          var allrowsTemp = await dbhelper.fetchAllBreakStartAndBreakEnd();
          if (allrowsTemp.isEmpty) {
            final id = await dbhelper.insertBreakStartBreakEnd(data);
            sharedPreferences!.setString(AllSharedPreferencesKey.breakPunchId,
                breakPunchId.isEmpty ? id.toString() : "");
          } else {
            if (breakPunchId.isNotEmpty) {
              final id = await dbhelper.updateBreakStartBreakEnd(
                  int.parse(sharedPreferences!
                      .getString(AllSharedPreferencesKey.breakPunchId)!),
                  DateTime.now().toString());
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.breakPunchId, "");
            } else {
              final id = await dbhelper.insertBreakStartBreakEnd(data);
              sharedPreferences!.setString(AllSharedPreferencesKey.breakPunchId,
                  breakPunchId.isEmpty ? id.toString() : "");
            }
          }
          var allrows = await dbhelper.fetchAllBreakStartAndBreakEnd();
          log(allrows.toString());

          commonAlertDialog(
              context,
              AllString.success,
              breakPunchId.isEmpty
                  ? "Break Started Successfully"
                  : "Break Ended Successfully", function: () async {
            AppBuilder.of(context)!.rebuild();
            setState(() {
              loading = false;
            });
            Navigator.pop(context);
            setState(() {
              checkAllButtonValidation();
            });
          });
        }
      }
    });
  }

  offlineDayStartDayEndAllDataFetch() async {
    // setState(() {
    //   loading = true;
    // });
    // if (await internetCheck()) {
    var allrows = await dbhelper.fetchAllDayStartDayEnd();
    log(allrows.toString());
    //   if (allrows.isNotEmpty) {
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "userLoginId":
          sharedPreferences!.getString(AllSharedPreferencesKey.userId),
      "attendanceData": allrows,
    };

    log(data.toString());
    //     apiPostRequestWithHeader(
    //             data, AllUrls.addEmployeeAttendance, this.context, loginToken)
    //         .then((response) async {
    //       if (response == null) {
    //         loading = false;
    //         setState(() {});
    //         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    //       } else {
    //         Map<String, dynamic> jsonData = json.decode(response);
    //         if (checkApiResponseSuccessOrNot(jsonData)) {
    //           setState(() {
    //             loading = false;
    //           });

    //           // commonAlertDialog(
    //           //     context, jsonData["status"], jsonData["message"],
    //           //     function: () async {
    //           List allCheckOutList = allrows;
    //           allCheckOutList.forEach((element) {
    //             dbhelper.deleteDayStartDayEnd(element["id"]);
    //           });

    //           var allrowsss = await dbhelper.fetchAllDayStartDayEnd();
    //           log(allrowsss.toString());
    //           setState(() {});
    //           //   Navigator.pop(context);
    //           // });
    //         } else {
    //           setState(() {
    //             loading = false;
    //           });
    //           commonAlertDialog(
    //               context, jsonData["status"], jsonData["message"]);
    //         }
    //       }
    //     });
    //   }
    // }
  }

  offlineBreakStartBreakEndAllDataFetch() async {
    // setState(() {
    //   loading = true;
    // });
    if (await internetCheck()) {
      var allrows = await dbhelper.fetchAllBreakStartAndBreakEnd();
      if (allrows.isNotEmpty) {
        Map data = {
          "companyId":
              sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
          "individualId": sharedPreferences!
              .getString(AllSharedPreferencesKey.individualId),
          "userLoginId":
              sharedPreferences!.getString(AllSharedPreferencesKey.userId),
          "breakData": allrows,
        };
        log(data.toString());
        apiPostRequestWithHeader(
                data, AllUrls.breakStartEnd, this.context, loginToken)
            .then((response) async {
          if (response == null) {
            loading = false;
            setState(() {});
            commonAlertDialog(
                context, AllString.warning, AllString.connectionFailure);
          } else {
            Map<String, dynamic> jsonData = json.decode(response);
            if (checkApiResponseSuccessOrNot(jsonData)) {
              setState(() {
                loading = false;
              });

              // commonAlertDialog(
              //     context, jsonData["status"], jsonData["message"],
              //     function: () async {
              List allCheckOutList = allrows;
              allCheckOutList.forEach((element) {
                dbhelper.deleteBreakStartBreakEnd(element["id"]);
              });

              var allrowsss = await dbhelper.fetchAllDayStartDayEnd();
              log(allrowsss.toString());
              setState(() {});
              // Navigator.pop(context);
              // });
            } else {
              setState(() {
                loading = false;
              });
              commonAlertDialog(
                  context, jsonData["status"], jsonData["message"]);
            }
          }
        });
      }
    }
  }
}
