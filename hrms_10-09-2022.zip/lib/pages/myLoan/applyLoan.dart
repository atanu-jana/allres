import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myLoan/myLoan.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ApplyLoan extends StatefulWidget {
  const ApplyLoan({
    Key? key,
  }) : super(key: key);
  @override
  _ApplyLoanState createState() => _ApplyLoanState();
}

class _ApplyLoanState extends State<ApplyLoan> {
  bool loading = false;

  bool acceptAgreement = false;
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _amountTextEditingController = TextEditingController();
  FocusNode _amountFocusNode = FocusNode();
  String _currentLoanType = AllString.select;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.applyLoan),
        body: LoadingOverlay(
            isLoading: loading,
            opacity: 0.5,
            color: AllColor.black,
            progressIndicator: commonLoader(),
            child: Container(
                width: screenWidth,
                height: screenHeight,
                child: ListView(physics: BouncingScrollPhysics(), children: [
                  textFieldHeader(AllString.pleaseSelectLoanType+" *",
                      fontWeight: FontWeight.bold),
                  Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentLoanType,
                      dropdownList: loanTypeDetailsData,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentLoanType = newValue!;
                        });
                      },
                    ),
                  ),
                  // Container(
                  //   margin: EdgeInsets.symmetric(
                  //       horizontal: screenWidth * 0.03,
                  //       vertical: screenWidth * 0.01),
                  //   alignment: Alignment.centerLeft,
                  //   child: normalText(AllString.pleaseEnterLoanAmount + ": ",
                  //       color: AllColor.black.withOpacity(0.6)),
                  // ),
                  // Container(
                  //   margin: EdgeInsets.symmetric(
                  //       horizontal: screenWidth * 0.03,
                  //       vertical: screenWidth * 0.01),
                  //   alignment: Alignment.centerLeft,
                  //   child: normalText(
                  //       AllString.youAreEligibleForTheLoanAmountUpto +
                  //           " " +
                  //           AllString.rs +
                  //           " 5000",
                  //       color: AllColor.black.withOpacity(0.6)),
                  // ),
                  textFieldHeader(AllString.amount+" *",
                      fontWeight: FontWeight.bold),
                  Container(
                      child: RoundedInputField(
                    controller: _amountTextEditingController,
                    focusNode: _amountFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    hintText: AllString.enterAmount,
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.handHoldingUsDollar,
                    onchangeFunction: (String val) {
                      // if (val.isNotEmpty && int.parse(val) >= 5001) {
                      //   _amountTextEditingController.text = "";
                      // }
                      setState(() {});
                    },
                  )),
                  // Container(
                  //   margin: EdgeInsets.symmetric(
                  //       horizontal: screenWidth * 0.03,
                  //       vertical: screenWidth * 0.01),
                  //   alignment: Alignment.centerLeft,
                  //   child: normalText(AllString.remark + ": ",
                  //       color: AllColor.black.withOpacity(0.6)),
                  // ),
                  // Container(
                  //   margin: EdgeInsets.symmetric(
                  //     vertical: screenWidth * 0.0,
                  //     horizontal: screenWidth * 0.03,
                  //   ),
                  //   child: Center(
                  //     child: textAreaField(
                  //       context,
                  //       AllString.comment + "*",
                  //       _commentTextEditingController,
                  //       4,
                  //       100,
                  //       TextInputAction.done,
                  //       TextInputType.text,
                  //     ),
                  //   ),
                  // ),
                  textFieldHeader(AllString.loanRemark+" *",
                      fontWeight: FontWeight.bold),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enterRemark,
                        _commentTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  ),
                  // GestureDetector(
                  //   onTap: () {
                  //     if (currentLoanType == AllString.select) {
                  //       commonAlertDialog(context, AllString.warning,
                  //           AllString.pleaseSelectLoanType);
                  //     } else if (_amountTextEditingController.text.isEmpty) {
                  //       commonAlertDialog(context, AllString.warning,
                  //           AllString.pleaseEnterLoanAmount);
                  //     } else if (_commentTextEditingController.text.isEmpty) {
                  //       commonAlertDialog(context, AllString.warning,
                  //           AllString.pleaseTypeRemark);
                  //     } else {
                  //       setState(() {
                  //         acceptAgreement = !acceptAgreement;
                  //       });
                  //     }
                  //   },
                  //   child: Row(
                  //     children: <Widget>[
                  //       Checkbox(
                  //         value: acceptAgreement,
                  //         activeColor: AllColor.primaryColor,
                  //         checkColor: AllColor.white,
                  //         onChanged: (bool? value) {
                  //           if (currentLoanType == AllString.select) {
                  //             commonAlertDialog(context, AllString.warning,
                  //                 AllString.pleaseSelectLoanType);
                  //           } else if (_amountTextEditingController
                  //               .text.isEmpty) {
                  //             commonAlertDialog(context, AllString.warning,
                  //                 AllString.pleaseEnterLoanAmount);
                  //           } else if (_commentTextEditingController
                  //               .text.isEmpty) {
                  //             commonAlertDialog(context, AllString.warning,
                  //                 AllString.pleaseTypeRemark);
                  //           } else {
                  //             setState(() {
                  //               acceptAgreement = !acceptAgreement;
                  //             });
                  //           }
                  //         },
                  //       ),
                  //       smallText(
                  //           "I've by agree to the Terms & Condition Of Infymax.",
                  //           color: AllColor.primaryColor), //Text
                  //       //Checkbox
                  //     ], //<Widget>[]
                  //   ),
                  // ),

                  Container(
                      margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03),
                      // child: customAnimatedButton(context,
                      //     enable: currentLoanType == AllString.select ||
                      //             !acceptAgreement
                      //         ? false
                      //         : true, function: (_) {
                      //   if (currentLoanType != AllString.select &&
                      //       acceptAgreement) {
                      //     commonAlertDialog(context, AllString.success,
                      //         "Successfully Apply " + currentLoanType,
                      //         function: () {
                      //       setState(() {
                      //         acceptAgreement = false;
                      //         currentLoanType = AllString.select;
                      //       });
                      //       _amountFocusNode.unfocus();
                      //       Navigator.pop(context);
                      //     });
                      //   }
                      // },
                      //     color: AllColor.primaryColor,
                      //     deepColor: AllColor.primaryDeepColor,
                      //     textColor: AllColor.white,
                      //     text: AllString.apply,
                      //     width: screenWidth)
                      // child: button(
                      //   context,
                      //   enable: currentLoanType == AllString.select ||
                      //           !acceptAgreement
                      //       ? false
                      //       : true,
                      //   function: () {
                      //     if (currentLoanType != AllString.select &&
                      //         acceptAgreement) {
                      //       commonAlertDialog(context, AllString.success,
                      //           "Successfully Apply " + currentLoanType,
                      //           function: () {
                      //         setState(() {
                      //           acceptAgreement = false;
                      //           currentLoanType = AllString.select;
                      //         });
                      //         _amountFocusNode.unfocus();
                      //         Navigator.pop(context);
                      //       });
                      //     }
                      //   },
                      //   color1: Color(0xff536976),
                      //   color2: Color(0xff292E49),
                      //   textColor: AllColor.white,
                      //   text: AllString.apply,
                      // )),
                      child: button(
                        context,
                        function: () {
                          if (validateAndProceed()) {
                            applyLoan();
                          }
                        },
                       color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.apply,
                      )),
                ]))));
  }

  applyLoan() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });

      Map data = {
        "userLoginId": loginUserId,
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "loanTypeId": _currentLoanType.split(AllString.splitText).last,
        "loanComment": _commentTextEditingController.text,
        "loanAmount": _amountTextEditingController.text,
      };
      apiPostRequestWithHeader(
              data, AllUrls.applyLoan, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context)
                  .push(CupertinoPageRoute(builder: (context) => MyLoan()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  bool validateAndProceed() {
    if (_currentLoanType == AllString.select) {
      return false;
    } else if (_amountTextEditingController.text.isEmpty) {
      return false;
    } else if (_commentTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }
}
