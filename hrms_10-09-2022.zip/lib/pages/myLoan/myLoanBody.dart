import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/myLoan/myLoan.dart';
import 'package:hr/pages/myLoan/myLoanDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class MyLoanBody extends StatefulWidget {
  @override
  _MyLoanBodyState createState() => _MyLoanBodyState();
}

class _MyLoanBodyState extends State<MyLoanBody> {
  bool loading = false;
  List _loadList = [];
  @override
  void initState() {
    super.initState();
    fetchLoanList();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                               decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Container(
              child: _loadList.isEmpty
                  ? commonNoDataFound()
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: _loadList.length,
                      itemBuilder: (context, index) =>
                          customListItem(_loadList[index], index)),
            ),
            Positioned(
                bottom: screenWidth * 0.05,
                right: screenWidth * 0.05,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.of(context).push(
                        CupertinoPageRoute(builder: (context) => ApplyLoan()));
                  },
                  child: normalIcon(Icons.add),
                  backgroundColor: AllColor.primaryDeepColor,
                )),
          ],
        ),
      ),
    );
  }

  fetchLoanList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "loanTypeId": "",
        "individualName": "",
        "userId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getLoanList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _loadList.clear();

            if (jsonData["loanData"] == "") {
              _loadList = [];
            } else {
              _loadList = jsonData["loanData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
       onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => MyLoanDetails(
                  singleData: itemData,
                  visible: false,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => MyLoan()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth >= 600 ? screenWidth * 0.23 : screenWidth * 0.26,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.25,
                      title: "Loan Amount",
                      value: AllString.rs + itemData["loanAmount"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.25,
                      title: "Loan Type",
                      value: itemData["loanTypeName"].toString()),
                  // customRowDetails(
                  //     width: screenWidth * 0.85,
                  //     widthTitle: screenWidth * 0.25,
                  //     title: "Applied On",
                  //     value: convertStringToDate(DateTime.now())),
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.25,
                      title: AllString.remark,
                      value: checkApiValueValid(itemData["loanComment"])
                          ? AllString.na
                          : itemData["loanComment"]),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }
}
