import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/conveyance/conveyance.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/payment/payment.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ApplyConveyance extends StatefulWidget {
  const ApplyConveyance({
    Key? key,
  }) : super(key: key);
  @override
  _ApplyConveyanceState createState() => _ApplyConveyanceState();
}

class _ApplyConveyanceState extends State<ApplyConveyance> {
  bool loading = false;
  String _currentDealer = AllString.select;
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _amountTextEditingController = TextEditingController();
  FocusNode _amountFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 300), () {
      setDropDownValueByDefaultUponCondition();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.applyConveyance),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                 decoration:customBackgroundGradient(),

          child: Stack(
            children: [
              ListView(
                shrinkWrap: true,
                children: [
                  textFieldHeader(AllString.selectDealer,
                      fontWeight: FontWeight.bold),
                  // Container(
                  //     child: dropdownButton(dealerList, (String? newValue) {
                  // setState(() {
                  //   _currentDealer = newValue!;
                  // });
                  // }, _currentDealer)),
                  Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentDealer,
                      dropdownList: dealerList,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentDealer = newValue!;
                        });
                      },
                    ),
                  ),
                  textFieldHeader(AllString.conveyanceAmount + " *",
                      fontWeight: FontWeight.bold),
                  Container(
                      child: RoundedInputField(
                    controller: _amountTextEditingController,
                    focusNode: _amountFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    hintText: AllString.enterAmount,
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.handHoldingUsDollar,
                    onchangeFunction: (String val) {
                      // if (val.isNotEmpty && int.parse(val) >= 5001) {
                      //   _amountTextEditingController.text = "";
                      // }
                      setState(() {});
                    },
                  )),
                  textFieldHeader(AllString.remark + " *",
                      fontWeight: FontWeight.bold),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enterRemark,
                        _commentTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03),
                      child: button(
                        context,
                        function: () {
                          if (validateAndProceed()) {
                            applyConveyance();
                          }
                        },
                        color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.confirm,
                      )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  applyConveyance() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "userId": loginUserId,
        "dealerId": _currentDealer.split(AllString.splitText).last,
        "amount": _amountTextEditingController.text,
        "remarks": _commentTextEditingController.text,
        "visitTypeName": _currentDealer.split(AllString.splitText).first,
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "visitType": 1,
      };
      apiPostRequestWithHeader(
              data, AllUrls.addConveyancePost, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Conveyance()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  bool validateAndProceed() {
    if (_currentDealer == AllString.select) {
      return false;

      // commonAlertDialog(
      //     context, AllString.warning, "Select dealer");
    } else if (_amountTextEditingController.text.isEmpty) {
      return false;

      // commonAlertDialog(context, AllString.warning,
      //     "Enter payment amount");
    } else if (_commentTextEditingController.text.isEmpty) {
      return false;

      // commonAlertDialog(
      //     context, AllString.warning, "Enter comment");
    } else {
      return true;
    }
  }

  setDropDownValueByDefaultUponCondition() {
    if (dealerList.length == 2) {
      _currentDealer = dealerList.last;
    }
    // if (categoryList.length == 2) {
    //   _currentCategory = categoryList.last;
    // }
//     if(expenseTypeList.length==2){
// _currentExpenseType=expenseTypeList.last;
//     }
    setState(() {});
  }
}
