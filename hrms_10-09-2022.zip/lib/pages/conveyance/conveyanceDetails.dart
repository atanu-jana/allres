import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ConveyanceDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const ConveyanceDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);
  @override
  _ConveyanceDetailsState createState() => _ConveyanceDetailsState();
}

class _ConveyanceDetailsState extends State<ConveyanceDetails> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.conveyanceDetails),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                decoration:customBackgroundGradient(),

          child: ListView(
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: AllColor.black))),
                padding: EdgeInsets.all(1),
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                child: Container(
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10)),
                  width: screenWidth,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Dealer Name",
                              value: widget.singleData["dealername"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Remark",
                              value: checkApiValueValid(
                                      widget.singleData["remarks"])
                                  ? AllString.na
                                  : widget.singleData["remarks"].toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Status",
                              value: widget.singleData["reviewStatus"]
                                          .toString() ==
                                      "0"
                                  // ? "Pending ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                  ? "Pending By Team Manager"
                                  : widget.singleData["reviewStatus"]
                                              .toString() ==
                                          "1"
                                      // ? "Rejected ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                      ? "Rejected By Team Manager": widget.singleData["reviewStatus"]
                                                  .toString() ==
                                              "2"
                                          // ? "Approved ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                          ? "Approved By Team Manager"
                                          : widget.singleData["reviewStatus"]
                                                      .toString() ==
                                                  "3"
                                              ? "Rejected By HR"
                                              : widget.singleData[
                                                              "reviewStatus"]
                                                          .toString() ==
                                                      "4"
                                                  ? "Approved By HR"
                                                  : ""),
                          widget.singleData["level1ReviewComment"]
                                      .toString()
                                      .isEmpty ||
                                  widget.singleData["level1ReviewComment"]
                                          .toString() ==
                                      "null"
                              ? Container()
                              : customRowDetails(
                                  width: screenWidth - 50,
                                  widthTitle: screenWidth * 0.3,
                                  title: "Comment",
                                  value: widget
                                      .singleData["level1ReviewComment"]
                                      .toString()),
                          widget.singleData["level2ReviewComment"]
                                      .toString()
                                      .isEmpty ||
                                  widget.singleData["level2ReviewComment"]
                                          .toString() ==
                                      "null"
                              ? Container()
                              : customRowDetails(
                                  width: screenWidth - 50,
                                  widthTitle: screenWidth * 0.3,
                                  title: "Comment",
                                  value: widget
                                      .singleData["level2ReviewComment"]
                                      .toString()),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              widget.visible
                  ? !checkForApproveAndReject(
                          widget.singleData["reviewStatus"].toString())
                      ? Container()
                      : textFieldHeader(AllString.remark,
                          fontWeight: FontWeight.bold)
                  : Container(),
              widget.visible
                  ? !checkForApproveAndReject(
                          widget.singleData["reviewStatus"].toString())
                      ? Container()
                      : Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.enterRemark,
                              _commentTextEditingController,
                              4,
                              200,
                              TextInputAction.done,
                              TextInputType.text,
                            ),
                          ),
                        )
                  : Container(),
              SizedBox(
                height: screenWidth * 0.03,
              ),
              widget.visible
                  ? !checkForApproveAndReject(
                          widget.singleData["reviewStatus"].toString())
                      ? Container()
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              child: button(context,
                              color:AllColor.red,
                                  text: AllString.reject,
                                  textColor: AllColor.white,
                                  width: screenWidth * 0.35, function: () {
                                approvedAndRejectCall(true);
                              },
                                  enable:
                                      _commentTextEditingController.text.isEmpty
                                          ? false
                                          : true),
                            ),
                            Container(
                              child: button(context,
                              color:AllColor.deepGreen,
                              
                                  text: AllString.approved,
                                  width: screenWidth * 0.35,
                                  textColor: AllColor.white, function: () {
                                approvedAndRejectCall(false);
                              }),
                            ),
                          ],
                        )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  approvedAndRejectCall(bool reject) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        // "amount": widget.singleData["amount"],
        "comment": _commentTextEditingController.text,
        "reviewStatus": reject ? 0 : 1,
        "conveyanceId": widget.singleData["conveyanceId"],
        "userId": loginUserId,
        "reviewstage": (sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualTypeId)
                    .toString() ==
                "17")
            ? 1
            : 2
      };
      apiPostRequestWithHeader(
              data, AllUrls.reviewConveyancePost, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              widget.callBack();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // customCardRowDetails(String title, value) {
  //   return Container(
  //     width: screenWidth,
  //     padding: EdgeInsets.symmetric(
  //         vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.start,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         Container(
  //           width: screenWidth * 0.33,
  //           child: smallText(title + " :", color: AllColor.greyColor),
  //         ),
  //         Container(
  //           margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
  //         ),
  //         normalText(value,
  //             color: value == "Approved" ? AllColor.green : AllColor.black)
  //       ],
  //     ),
  //   );
  // }
}
