import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/conveyance/applyConveyance.dart';
import 'package:hr/pages/conveyance/conveyance.dart';
import 'package:hr/pages/conveyance/conveyanceDetails.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/payment/applyPayment.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customCatender.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:image_picker/image_picker.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ConveyanceBody extends StatefulWidget {
  @override
  _ConveyanceBodyState createState() => _ConveyanceBodyState();
}

class _ConveyanceBodyState extends State<ConveyanceBody> {
  bool loading = false;
  List _conveyanceList = [];
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    fetchConveyance();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(top: screenWidth * 0.13),
              child: _conveyanceList.isEmpty
                  ? commonNoDataFound()
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: _conveyanceList.length,
                      itemBuilder: (context, index) =>
                          customListItem(_conveyanceList[index], index)),
            ),
            Positioned(
                top: screenWidth * 0.01,
                right: screenWidth * 0.05,
                left: screenWidth * 0.05,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      child: normalText(AllString.selectDate + ": ",
                          color: AllColor.black),
                    ),
                    datePickerButton(
                        context, _selectedDate, Icons.calendar_today, () {
                      selectDate(context, _selectedDate).then((value) {
                        _selectedDate = value;
                        setState(() {});
                        log(_selectedDate.toString());
                        fetchConveyance();
                      });
                    }),
                  ],
                )),
            Positioned(
                bottom: screenWidth * 0.05,
                right: screenWidth * 0.05,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.of(context).push(CupertinoPageRoute(
                        builder: (context) => ApplyConveyance()));
                  },
                  child: normalIcon(Icons.add),
                  backgroundColor: AllColor.primaryDeepColor,
                )),
          ],
        ),
      ),
    );
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => ConveyanceDetails(
                  singleData: itemData,
                  visible: false,
                  callBack: (){

              Navigator.push(context,
                  CupertinoPageRoute(builder: (context) => Conveyance()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Dealer Name",
                      value: itemData["dealername"]),
                  customRowDetails(
                    
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Remark",
                      value: checkApiValueValid(itemData["remarks"])
                          ? AllString.na
                          : itemData["remarks"].toString()),
                  customRowDetails(
                    
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Amount",
                      value: AllString.rs + itemData["amount"].toString()),
                  customRowDetails(
                    
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Status",
                              value: itemData["reviewStatus"]
                                          .toString() ==
                                      "0"
                                  ? "Pending By Team Manager"
                                  // ? "Pending ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                  
                                  : itemData["reviewStatus"]
                                              .toString() ==
                                          "1"
                                      ? "Rejected By Team Manager"
                                      // ? "Rejected ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                      : itemData["reviewStatus"]
                                                  .toString() ==
                                              "2"
                                      ? "Approved By Team Manager"
                                          // ? "Approved  ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                          : itemData["reviewStatus"]
                                                      .toString() ==
                                                  "3"
                                              ? "Rejected By HR"
                                              : itemData[
                                                              "reviewStatus"]
                                                          .toString() ==
                                                      "4"
                                                  ? "Approved By HR"
                                                  : ""),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchConveyance() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "userId": loginUserId,
        "date": _selectedDate.toString(),
        "dealerId":0
      };
      apiPostRequestWithHeader(
              data, AllUrls.conveyanceListByIdPost, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _conveyanceList.clear();

            _conveyanceList = jsonData["data"];
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
