import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class LeaveBalanceBody extends StatefulWidget {
  @override
  _LeaveBalanceBodyState createState() => _LeaveBalanceBodyState();
}

class _LeaveBalanceBodyState extends State<LeaveBalanceBody> {
  bool loading = false;
  List _leaveBalanceList = [];
  @override
  void initState() {
    super.initState();
    fetchLeaveList();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                               decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Container(
              child: _leaveBalanceList.isEmpty
                  ? commonNoDataFound()
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: _leaveBalanceList.length,
                      itemBuilder: (context, index) =>
                          customListItem(_leaveBalanceList[index], index)),
            ),
            // Container(
            //   // margin: EdgeInsets.all(screenWidth*0.07 ),
            //   child: Column(
            //     mainAxisSize: MainAxisSize.min,
            //     children: [
            //       Container(
            //         margin: EdgeInsets.only(top: screenWidth * 0.03),
            //         height: screenWidth * 0.1,
            //         padding:
            //             EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            //         decoration: BoxDecoration(
            //           color: AllColor.tableBackground,
            //           // border:
            //           //     Border(bottom: BorderSide(color: AllColor.black))
            //         ),
            //         child: Row(
            //           mainAxisAlignment: MainAxisAlignment.start,
            //           children: [
            //             Container(
            //               width: screenWidth / 2.5,
            //               alignment: Alignment.centerLeft,
            //               child: normalText(AllString.leaveType,
            //                   color: AllColor.white),
            //             ),
            //             Container(
            //               width: screenWidth / 2.5,
            //               alignment: Alignment.center,
            //               child: normalText(AllString.leaveLeft,
            //                   color: AllColor.white),
            //             ),
            //           ],
            //         ),
            //       ),
            //       GestureDetector(
            //         onTap: () {
            //           Navigator.push(
            //               context,
            //               CupertinoPageRoute(
            //                   builder: (context) => Leave(
            //                         appBarTitle: AllString.sickLeave,
            //                       )));
            //         },
            //         child: Container(
            //           padding:
            //               EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            //           margin:
            //               EdgeInsets.symmetric(vertical: screenWidth * 0.015),
            //           height: screenWidth * 0.1,
            //           color: AllColor.lightBlack,
            //           child: Row(
            //             mainAxisAlignment: MainAxisAlignment.start,
            //             children: [
            //               Container(
            //                 width: screenWidth / 2.5,
            //                 alignment: Alignment.centerLeft,
            //                 child: normalText(AllString.sickLeave,
            //                     color: AllColor.black),
            //               ),
            //               Container(
            //                 width: screenWidth / 2.5,
            //                 alignment: Alignment.center,
            //                 child: normalText("10/5", color: AllColor.black),
            //               ),
            //               Container(
            //                 width: screenWidth * 0.08,
            //                 height: screenWidth * 0.08,
            //                 decoration: BoxDecoration(
            //                     color: AllColor.tableBackground,
            //                     borderRadius: BorderRadius.circular(1000)),
            //                 alignment: Alignment.center,
            //                 child: normalIcon(Icons.arrow_forward_ios_sharp,
            //                     color: AllColor.white),
            //               ),
            //             ],
            //           ),
            //         ),
            //       ),
            //       GestureDetector(
            //         onTap: () {
            //           Navigator.push(
            //               context,
            //               CupertinoPageRoute(
            //                   builder: (context) => Leave(
            //                         appBarTitle: AllString.casualLeave,
            //                       )));
            //         },
            //         child: Container(
            //           padding:
            //               EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            //           margin:
            //               EdgeInsets.symmetric(vertical: screenWidth * 0.015),
            //           height: screenWidth * 0.1,
            //           color: AllColor.lightBlack,
            //           child: Row(
            //             mainAxisAlignment: MainAxisAlignment.start,
            //             children: [
            //               Container(
            //                 width: screenWidth / 2.5,
            //                 alignment: Alignment.centerLeft,
            //                 child: normalText(AllString.casualLeave,
            //                     color: AllColor.black),
            //               ),
            //               Container(
            //                 width: screenWidth / 2.5,
            //                 alignment: Alignment.center,
            //                 child: normalText("10/6", color: AllColor.black),
            //               ),
            //               Container(
            //                 width: screenWidth * 0.08,
            //                 height: screenWidth * 0.08,
            //                 decoration: BoxDecoration(
            //                     color: AllColor.tableBackground,
            //                     borderRadius: BorderRadius.circular(1000)),
            //                 alignment: Alignment.center,
            //                 child: normalIcon(Icons.arrow_forward_ios_sharp,
            //                     color: AllColor.white),
            //               ),
            //             ],
            //           ),
            //         ),
            //       ),
            //       GestureDetector(
            //         onTap: () {
            //           Navigator.push(
            //               context,
            //               CupertinoPageRoute(
            //                   builder: (context) => Leave(
            //                         appBarTitle: AllString.planedLeave,
            //                       )));
            //         },
            //         child: Container(
            //           padding:
            //               EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            //           margin:
            //               EdgeInsets.symmetric(vertical: screenWidth * 0.015),
            //           height: screenWidth * 0.1,
            //           color: AllColor.lightBlack,
            //           child: Row(
            //             mainAxisAlignment: MainAxisAlignment.start,
            //             children: [
            //               Container(
            //                 width: screenWidth / 2.5,
            //                 alignment: Alignment.centerLeft,
            //                 child: normalText(AllString.planedLeave,
            //                     color: AllColor.black),
            //               ),
            //               Container(
            //                 width: screenWidth / 2.5,
            //                 alignment: Alignment.center,
            //                 child: normalText("10/9", color: AllColor.black),
            //               ),
            //               Container(
            //                 width: screenWidth * 0.08,
            //                 height: screenWidth * 0.08,
            //                 decoration: BoxDecoration(
            //                     color: AllColor.tableBackground,
            //                     borderRadius: BorderRadius.circular(1000)),
            //                 alignment: Alignment.center,
            //                 child: normalIcon(Icons.arrow_forward_ios_sharp,
            //                     color: AllColor.white),
            //               ),
            //             ],
            //           ),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),

            Positioned(
                bottom: screenWidth * 0.13,
                right: screenWidth * 0.05,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.of(context).push(
                        CupertinoPageRoute(builder: (context) => ApplyLeave()));
                  },
                  child: normalIcon(Icons.add),
                  backgroundColor: AllColor.primaryDeepColor,
                )),
            Positioned(
                bottom: 0,
                // child: customAnimatedButton(context, function: (_) {
                //   Navigator.push(
                //       context,
                //       CupertinoPageRoute(
                //           builder: (context) => Leave(
                //                 appBarTitle: AllString.allLeave,
                //               )));
                // },
                //     color: AllColor.primaryColor,
                //     deepColor: AllColor.primaryDeepColor,
                //     textColor: AllColor.white,
                //     text: AllString.viewAllLeaves,
                //     width: screenWidth),
                child: Container(
                  width: screenWidth,
                  alignment: Alignment.center,
                  child: button(
                    context,
                    function: () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => Leave(
                                    leaveTypeId: "",
                                    appBarTitle: AllString.allLeave,
                                  )));
                    },
                    color:  AllColor.primaryColor,
                    textColor: AllColor.white,
                    text: AllString.viewAllLeaves,
                  ),
                ))
          ],
        ),
      ),
    );
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            CupertinoPageRoute(
                builder: (context) => Leave(
                      leaveTypeId: itemData["leaveTypeId"].toString(),
                      appBarTitle: AllString.casualLeave,
                    )));
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
        margin: EdgeInsets.symmetric(vertical: screenWidth * 0.015),
        height: screenWidth * 0.1,
        color: AllColor.lightBlack,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              width: screenWidth / 2.5,
              alignment: Alignment.centerLeft,
              child: normalText(
                  checkApiValueValid(itemData["leaveTypeName"])
                      ? AllString.na
                      : itemData["leaveTypeName"],
                  color: AllColor.black),
            ),
            Container(
              width: screenWidth / 2.5,
              alignment: Alignment.center,
              child: normalText(
                  itemData["totalLeave"].toString() +
                      "/" +
                      itemData["leaveBalance"].toString(),
                  color: AllColor.black),
            ),
            Container(
              width: screenWidth * 0.08,
              height: screenWidth * 0.08,
              decoration: BoxDecoration(
                  color: AllColor.tableBackground,
                  borderRadius: BorderRadius.circular(1000)),
              alignment: Alignment.center,
              child: normalIcon(Icons.arrow_forward_ios_sharp,
                  color: AllColor.white),
            ),
          ],
        ),
      ),
    );
  }

  fetchLeaveList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data =
          {
        "leaveTypeId": "",
        "individualName": "",
        "userId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getEmployeeLeaveBalance, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _leaveBalanceList.clear();

            if (jsonData["leaveData"] == "") {
              _leaveBalanceList = [];
            } else {
              _leaveBalanceList = jsonData["leaveData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
