import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/leaveBalance/leaveBalance.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/fromToDatePickerButton.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ApplyLeave extends StatefulWidget {
  const ApplyLeave({
    Key? key,
  }) : super(key: key);
  @override
  _ApplyLeaveState createState() => _ApplyLeaveState();
}

class _ApplyLeaveState extends State<ApplyLeave> {
  bool loading = false;
  String _currentLeaveType = AllString.select;

  TextEditingController _fromDateTextEditingController =
      TextEditingController();
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _toDateTextEditingController = TextEditingController();
  DateTime fromDate = DateTime.now();
  DateTime toDate = DateTime.now();
  DateTime startDate = DateTime.now();
  DateTime endDate = DateTime.now();
  String selectDay = "";
  String leaveBalance = "";
  PickedFile? _imageFile;
  @override
  void initState() {
    // leaveTypeDetailsData = [
    //   AllString.select,
    //   "PL",
    //   "CL",
    //   "SL/ML",
    //   "Maternity Leave"
    // ];
    // _fromDateTextEditingController.text = convertStringToDate(fromDate);
    // _toDateTextEditingController.text = convertStringToDate(toDate);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.applyLeave),
        body: LoadingOverlay(
            isLoading: loading,
            opacity: 0.5,
            color: AllColor.black,
            progressIndicator: commonLoader(),
            child: Container(
                width: screenWidth,
                height: screenHeight,
                decoration: customBackgroundGradient(),
                child: ListView(physics: BouncingScrollPhysics(), children: [
                  textFieldHeader(AllString.pleaseSelectLeaveType + " *",
                      fontWeight: FontWeight.bold),
                  Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentLeaveType,
                      dropdownList: leaveTypeDetailsData,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentLeaveType = newValue!;
                          log(_currentLeaveType);
                        });

                        if (_currentLeaveType
                                    .split(AllString.splitText)
                                    .first ==
                                "PL" ||
                            _currentLeaveType
                                    .split(AllString.splitText)
                                    .first ==
                                "CL" ||
                            _currentLeaveType
                                    .split(AllString.splitText)
                                    .first ==
                                "Maternity Leave") {
                          fromDate = DateTime.now();
                          toDate = DateTime.now();
                          _fromDateTextEditingController.text =
                              convertStringToDate(fromDate);
                          _toDateTextEditingController.text =
                              convertStringToDate(toDate);
                          startDate = DateTime(DateTime.now().year,
                              DateTime.now().month, DateTime.now().day);
                          endDate = DateTime(2050);
                          setState(() {});
                        } else if (_currentLeaveType
                                    .split(AllString.splitText)
                                    .first ==
                                "SL/ML" ||
                            _currentLeaveType
                                    .split(AllString.splitText)
                                    .first ==
                                "SL/ML") {
                          fromDate = DateTime.now();
                          toDate = DateTime.now();
                          _fromDateTextEditingController.text =
                              convertStringToDate(fromDate);
                          _toDateTextEditingController.text =
                              convertStringToDate(toDate);
                          endDate = DateTime(DateTime.now().year,
                              DateTime.now().month, DateTime.now().day);
                          startDate = DateTime(2000);
                          setState(() {});
                        }
                      },
                    ),
                  ),
                  // _currentLeaveType == AllString.select
                  //     ? Container()
                  //     : Container(
                  //         margin: EdgeInsets.symmetric(
                  //             horizontal: screenWidth * 0.03,
                  //             vertical: screenWidth * 0.01),
                  //         alignment: Alignment.centerLeft,
                  //         child: normalText(
                  //             AllString.leaveBalance + ": " + leaveBalance,
                  //             color: AllColor.black.withOpacity(0.6)),
                  //       ),
                  if (_currentLeaveType != AllString.select)
                    Column(
                      children: [
                        Container(
                          width: screenWidth,
                          margin: EdgeInsets.symmetric(
                              vertical: screenWidth * 0.01),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: screenWidth / 3,
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      selectDay = AllString.fullDay;
                                      AppBuilder.of(context)!.rebuild();
                                    });
                                  },
                                  child: Container(
                                    color: AllColor.white,
                                    width: screenWidth,
                                    alignment: Alignment.center,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          activeColor: AllColor.primaryColor,
                                          value: AllString.fullDay,
                                          groupValue: selectDay,
                                          onChanged: (String? value) {
                                            setState(() {
                                              selectDay = value!;
                                              AppBuilder.of(context)!.rebuild();
                                            });
                                          },
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: screenWidth * 0.03),
                                          child: normalText(AllString.fullDay,
                                              color: AllColor.black),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                width: screenWidth / 3,
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      selectDay = AllString.halfDay;
                                      AppBuilder.of(context)!.rebuild();
                                    });
                                  },
                                  child: Container(
                                    width: screenWidth,
                                    color: AllColor.white,
                                    alignment: Alignment.center,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Radio(
                                          activeColor: AllColor.primaryColor,
                                          value: AllString.halfDay,
                                          groupValue: selectDay,
                                          onChanged: (String? value) {
                                            setState(() {
                                              selectDay = value!;
                                              AppBuilder.of(context)!.rebuild();
                                            });
                                          },
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: screenWidth * 0.03),
                                          child: normalText(AllString.halfDay,
                                              color: AllColor.black),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        fromToDatePickerButton(context, screenWidth, fromDate,
                            toDate, Icons.calendar_today, () {
                          // selectDateWithFromAndToDate(
                          //         context, fromDate, startDate, endDate)
                          //     .then((value) {
                          //   fromDate = value;
                          //   setState(() {});
                          //   _fromDateTextEditingController.text =
                          //       convertStringToDate(fromDate);
                          // });
                          dateTimeRangePicker();

                          // selectDateForFromAndTO(context, fromDate, false)
                          //     .then((value) {
                          // fromDate = value;
                          // setState(() {});
                          // _fromDateTextEditingController.text =
                          //     convertStringToDate(fromDate);
                          // });
                        }, () {
                          // selectDateWithFromAndToDate(
                          //         context, toDate, startDate, endDate)
                          //     .then((value) {
                          //   toDate = value;
                          //   setState(() {});
                          //   _toDateTextEditingController.text =
                          //       convertStringToDate(toDate);
                          // });
                          dateTimeRangePicker();

                          // selectDateForFromAndTO(context, toDate, true).then((value) {
                          //   toDate = value;
                          //   setState(() {});
                          //   _toDateTextEditingController.text =
                          //       convertStringToDate(toDate);
                          // });
                        }),
                        Container(
                          margin: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.03,
                              vertical: screenWidth * 0.005),
                          alignment: Alignment.centerLeft,
                          child: normalText(
                              fromDate.difference(toDate).inDays == 0
                                  // ? AllString.leaveAppliedfor2Days
                                  ? ""
                                  : AllString.noOfLeave +
                                      ": " +
                                      fromDate
                                          .difference(toDate)
                                          .inDays
                                          .toString()
                                          .replaceAll("-", "") +
                                      " " +
                                      AllString.days,
                              color: AllColor.black.withOpacity(0.6)),
                        ),
                        textFieldHeader(AllString.leaveRemark,
                            fontWeight: FontWeight.bold),
                        Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.enterRemark,
                              _commentTextEditingController,
                              4,
                              200,
                              TextInputAction.done,
                              TextInputType.text,
                            ),
                          ),
                        ),
                        _currentLeaveType.split(AllString.splitText).first ==
                                    "SL/ML" &&
                                int.parse(fromDate
                                        .difference(toDate)
                                        .inDays
                                        .toString()
                                        .replaceAll("-", "")) >=
                                    2
                            ? GestureDetector(
                                onTap: () {
                                  // pickImageOption();
                                  _onImageButtonPressed(ImageSource.camera);
                                },
                                child: Container(
                                  height: screenWidth * 0.08,
                                  width: screenWidth,
                                  margin: EdgeInsets.symmetric(
                                      horizontal: screenWidth * 0.03,
                                      vertical: screenWidth * 0.02),
                                  padding: EdgeInsets.symmetric(
                                    horizontal: screenWidth * 0.015,
                                  ),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          style: BorderStyle.solid,
                                          color: AllColor.greyColor),
                                      color: AllColor.lightBlack,
                                      borderRadius: BorderRadius.circular(7)),
                                  child: Row(
                                    children: [
                                      normalIcon(Icons.attachment_outlined,
                                          color: AllColor.greyColor),
                                      Container(
                                        width: screenWidth * 0.03,
                                      ),
                                      normalText(
                                          AllString.uploadAttachment + "*",
                                          color:
                                              AllColor.black.withOpacity(0.7))
                                    ],
                                  ),
                                ),
                              )
                            : Container(),
                        _currentLeaveType.split(AllString.splitText).first !=
                                "SL/ML"
                            ? Container()
                            : _imageFile == null
                                ? Container()
                                : Center(
                                    child: Stack(
                                      children: [
                                        Container(
                                          width: screenWidth * 0.2,
                                          height: screenWidth * 0.2,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(5)),
                                            color: AllColor.greyColor
                                                .withOpacity(0.5),
                                          ),
                                          child: Material(
                                            //display new updated image here
                                            child: Image.file(
                                              File(_imageFile!.path),
                                              fit: BoxFit.cover,
                                            ),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(5)),
                                            clipBehavior: Clip.hardEdge,
                                          ),
                                        ),
                                        Positioned(
                                            top: screenWidth * 0.01,
                                            right: screenWidth * 0.01,
                                            child: GestureDetector(
                                              onTap: () {
                                                _imageFile = null;
                                                setState(() {});
                                              },
                                              child: Container(
                                                child: normalIcon(Icons.close),
                                              ),
                                            ))
                                      ],
                                    ),
                                  ),
                        Container(
                            margin: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.015,
                                horizontal: screenWidth * 0.03),
                            // child: customAnimatedButton(context,
                            //     function: (_) {},
                            //     color: AllColor.primaryColor,
                            //     deepColor: AllColor.primaryDeepColor,
                            //     textColor: AllColor.white,
                            //     text: AllString.apply,
                            //     width: screenWidth)
                            child: button(
                              context,
                              function: () {
                                if (validateAndProceed()) {
                                  applyLeave();
                                }
                              },
                              color: !validateAndProceed()
                                  ? Colors.grey
                                  : AllColor.primaryColor,
                              textColor: AllColor.white,
                              text: AllString.apply,
                            )),
                      ],
                    )
                ]))));
  }

  applyLeave() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      String _attatchmentFile = "";
      if (_imageFile != null) {
        File imageFile = new File(_imageFile!.path);
        List<int> imageBytes = imageFile.readAsBytesSync();
        _attatchmentFile = base64Encode(imageBytes);
        setState(() {});
      }
      Map data = {
        "userLoginId": loginUserId,
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "leaveTypeId": _currentLeaveType.split(AllString.splitText).last,
        "leaveAppliedFor": selectDay == AllString.fullDay ? "1" : "2",
        "leaveFromDate": fromDate.toString(),
        "reviewById": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
        "leaveToDate": toDate.toString(),
        "comment": _commentTextEditingController.text,
        "attachment": _attatchmentFile
      };
      apiPostRequestWithHeader(
              data, AllUrls.applyLeave, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).push(
                  CupertinoPageRoute(builder: (context) => LeaveBalance()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  bool validateAndProceed() {
    if (_currentLeaveType == AllString.select) {
      return false;
    } else if ((_currentLeaveType == "SL/ML" &&
            int.parse(fromDate
                    .difference(toDate)
                    .inDays
                    .toString()
                    .replaceAll("-", "")) >=
                2) &&
        _imageFile == null) {
      return false;
    } else if (selectDay.isEmpty) {
      return false;
    } else if (_fromDateTextEditingController.text.isEmpty) {
      return false;
    } else if (_toDateTextEditingController.text.isEmpty) {
      return false;
    } else if (_commentTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }
  // pickImageOption() {
  //   return showDialog(
  //       // barrierDismissible: false,
  //       context: context,
  //       builder: (context) {
  //         return SimpleDialog(
  //           backgroundColor: AllColor.white,
  //           contentPadding: EdgeInsets.all(0),
  //           shape: RoundedRectangleBorder(
  //               borderRadius: BorderRadius.circular(16.0)),
  //           elevation: 0.0,
  //           title: normalText(AllString.selectImageFrom + ":",
  //               color: AllColor.black),
  //           children: [
  //             Container(
  //               margin: EdgeInsets.only(top: screenWidth * 0.03),
  //               decoration: BoxDecoration(
  //                   border: Border(top: BorderSide(color: Colors.grey))),
  //             ),
  //             SimpleDialogOption(
  //                 padding: EdgeInsets.all(0),
  //                 child: ListTile(
  //                   contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //                   leading: normalIcon(Icons.camera_alt,
  //                       color: AllColor.primaryColor),
  //                   title: normalText(AllString.camera, color: AllColor.black),
  //                 ),
  //                 onPressed: () {
  //                   _onImageButtonPressed(ImageSource.camera);
  //                   Navigator.pop(context);
  //                 }),
  //             SimpleDialogOption(
  //                 padding: EdgeInsets.all(0),
  //                 child: ListTile(
  //                   contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //                   leading: normalIcon(Icons.photo_library,
  //                       color: AllColor.primaryColor),
  //                   title: normalText(AllString.gallery, color: AllColor.black),
  //                 ),
  //                 onPressed: () {
  //                   _onImageButtonPressed(ImageSource.gallery);
  //                   Navigator.pop(context);
  //                 }),
  //           ],
  //         );
  //       });
  // }

  _onImageButtonPressed(
    ImageSource source,
  ) async {
    try {
      final pickedFile = await imagePickerQuality(source);

      setState(() {
        _imageFile = pickedFile;
      });
      setState(() {
        loading = true;
      });
      String base64Image = "";
      if (_imageFile == null) {
        base64Image = "";
      } else {
        File imageFile = new File(_imageFile!.path);
        List<int> imageBytes = imageFile.readAsBytesSync();
        base64Image = base64Encode(imageBytes);
        log(base64Image);
      }
      setState(() {
        loading = false;
      });
    } catch (e) {}
  }

  dateTimeRangePicker() async {
    final dateRange = await showDateRangePicker(
        context: context,
        firstDate: startDate,
        lastDate: endDate,
        currentDate: fromDate,
        initialDateRange: DateTimeRange(start: fromDate, end: toDate));
    if (dateRange == null) {
      fromDate = DateTime.now();
      toDate = DateTime.now();
      AppBuilder.of(context)!.rebuild();
    } else {
      fromDate = dateRange.start;
      toDate = dateRange.end;
      AppBuilder.of(context)!.rebuild();
    }
    setState(() {});
    // if (dateRange is DateTimeRange) {
    //   setState(() {
    //     fromDate = dateRange.start;

    //     if (dateRange.end.isBefore(DateTime.now())) {
    //       //change it as your wish
    //       toDate = DateTime.now();
    //       ScaffoldMessenger.of(context).showSnackBar(
    //         SnackBar(
    //           content: Text("Invalid Date Range!"),
    //         ),
    //       );
    //     } else {
    //       toDate = dateRange.end;
    //     }
    //   });
    // }
  }
}
