import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class LeaveDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const LeaveDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);
  @override
  _LeaveDetailsState createState() => _LeaveDetailsState();
}

class _LeaveDetailsState extends State<LeaveDetails> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.leaveDetails),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
          decoration: customBackgroundGradient(),
          child: ListView(
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: AllColor.black))),
                padding: EdgeInsets.all(1),
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                child: Container(
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10)),
                  width: screenWidth,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Leave Type",
                              value: checkApiValueValid(
                                      widget.singleData["leaveTypeName"])
                                  ? AllString.na
                                  : widget.singleData["leaveTypeName"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "From Date",
                              value: convertStringToDate(DateTime.parse(
                                  widget.singleData["leaveFromDate"]).toLocal())),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "To Date",
                              value: convertStringToDate(DateTime.parse(
                                  widget.singleData["leaveToDate"]).toLocal())),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Day Requested",
                              value: widget.singleData["leaveAppliedFor"]
                                              .toString() ==
                                          "null" ||
                                      widget.singleData["leaveAppliedFor"]
                                              .toString() ==
                                          ""
                                  ? AllString.na
                                  : widget.singleData["leaveAppliedFor"]
                                              .toString() ==
                                          "1"
                                      ? AllString.halfDay
                                      : AllString.fullDay),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Remark",
                              value: checkApiValueValid(
                                      widget.singleData["comment"])
                                  ? AllString.na
                                  : widget.singleData["comment"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Status",
                              value: widget.singleData["leaveStatus"]
                                          .toString() ==
                                      "0"
                                  // ? "Pending By Team Manager"
                                  ? "Pending By ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                  : widget.singleData["leaveStatus"]
                                              .toString() ==
                                          "1"
                                      ? "Rejected By ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                      : widget.singleData["leaveStatus"]
                                                  .toString() ==
                                              "2"
                                          ? "Approved By ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                          : widget.singleData["leaveStatus"]
                                                      .toString() ==
                                                  "3"
                                              ? "Rejected By HR"
                                              : widget.singleData["leaveStatus"]
                                                          .toString() ==
                                                      "4"
                                                  ? "Approved By HR"
                                                  : ""),
                          widget.singleData["commentReview"]
                                      .toString()
                                      .isEmpty ||
                                  widget.singleData["commentReview"]
                                          .toString() ==
                                      "null"
                              ? Container()
                              : customRowDetails(
                                  width: screenWidth - 50,
                                  widthTitle: screenWidth * 0.3,
                                  title: "Comment",
                                  value: widget.singleData["commentReview"]
                                      .toString()),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              widget.visible
                  ? !checkForApproveAndReject(
                          widget.singleData["leaveStatus"].toString())
                      ? Container()
                      : textFieldHeader(AllString.remark,
                          fontWeight: FontWeight.bold)
                  : Container(),
              widget.visible
                  ? !checkForApproveAndReject(
                          widget.singleData["leaveStatus"].toString())
                      ? Container()
                      : Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.enterRemark,
                              _commentTextEditingController,
                              4,
                              200,
                              TextInputAction.done,
                              TextInputType.text,
                            ),
                          ),
                        )
                  : Container(),
              SizedBox(
                height: screenWidth * 0.03,
              ),
              widget.singleData["attachment"].toString().isEmpty ||
                      widget.singleData["attachment"].toString() == "null"
                  ? Container()
                  : GestureDetector(
                      onTap: () {
                        Navigator.of(context)
                            .push(CupertinoPageRoute(builder: (context) {
                          return NetworkImageView(
                            url: widget.singleData["attachment"].toString(),
                          );
                        }));
                      },
                      child: Center(
                        child: Container(
                          margin: customVertical(),
                          width: screenWidth * 0.3,
                          height: screenWidth * 0.3,
                          decoration: BoxDecoration(
                              color: AllColor.white,
                              borderRadius: BorderRadius.circular(10),
                              border:
                                  Border.all(width: 2, color: AllColor.black)),
                          child: Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: CachedNetworkImage(
                                  width: screenWidth * 0.3,
                                  height: screenWidth * 0.3,
                                  fit: BoxFit.cover,
                                  placeholder: (_, __) {
                                    return Center(
                                      child: CircularProgressIndicator(),
                                    );
                                  },
                                  errorWidget: (_, __, ___) {
                                    return Center(
                                      child: Image.asset(
                                          "assets/images/appLogo.png"),
                                    );
                                  },
                                  imageUrl: widget.singleData["attachment"]
                                      .toString()),
                              // child: Image.memory(
                              //   Base64Decoder().convert(base64.normalize(widget
                              //       .singleData["attachment"]
                              //       .toString()
                              //       .trim())),
                              //   width: screenWidth * 0.3,
                              //   height: screenWidth * 0.3,
                              //   fit: BoxFit.cover,
                              // ),
                            ),
                          ),
                        ),
                      ),
                    ),
              widget.visible
                  ? !checkForApproveAndReject(
                          widget.singleData["leaveStatus"].toString())
                      ? Container()
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              child: button(context,
                                  color: AllColor.red,
                                  text: AllString.reject,
                                  textColor: AllColor.white,
                                  width: screenWidth * 0.35, function: () {
                                approvedAndRejectCall(true);
                              },
                                  enable:
                                      _commentTextEditingController.text.isEmpty
                                          ? false
                                          : true),
                            ),
                            Container(
                              child: button(context,
                                  color: AllColor.deepGreen,
                                  text: AllString.approved,
                                  width: screenWidth * 0.35,
                                  textColor: AllColor.white, function: () {
                                approvedAndRejectCall(false);
                              }),
                            ),
                          ],
                        )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  approvedAndRejectCall(bool reject) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "approveStatus": sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualTypeId)
                    .toString() ==
                "17"
            ? reject
                ? "1"
                : "2"
            : reject
                ? "3"
                : "4",
        "employeeLeaveDetailsId": widget.singleData["employeeLeaveDetailsId"],
        "comment": _commentTextEditingController.text,
        "reviewById": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
        "companyId": sharedPreferences!
            .getString(AllSharedPreferencesKey.companyId)
            .toString(),
        "userLoginId": singleTeamMember["userId"],
      };
      apiPostRequestWithHeader(
              data, AllUrls.leaveApproval, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              widget.callBack();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // customCardRowDetails(String title, value) {
  //   return Container(
  //     width: screenWidth,
  //     padding: EdgeInsets.symmetric(
  //         vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.start,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         Container(
  //           width: screenWidth * 0.33,
  //           child: smallText(title + " :", color: AllColor.greyColor),
  //         ),
  //         Container(
  //           margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
  //         ),
  //         normalText(value,
  //             color: value == "Approved" ? AllColor.green : AllColor.black)
  //       ],
  //     ),
  //   );
  // }
}
