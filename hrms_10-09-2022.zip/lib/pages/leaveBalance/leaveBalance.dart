import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/leaveBalanceBody.dart';
import 'package:hr/pages/recordAttendance/myAttendanceBody.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class LeaveBalance extends StatefulWidget {
  @override
  _LeaveBalanceState createState() => _LeaveBalanceState();
}

class _LeaveBalanceState extends State<LeaveBalance> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.leaveBalance, onBackPress: () {
        Navigator.push(
            context, CupertinoPageRoute(builder: (context) => Home()));
      }),
      body: WillPopScope(
          onWillPop: () async {
            Navigator.push(context,
                CupertinoPageRoute(builder: (context) => Home()));
            return true;
          },
          child: LeaveBalanceBody()),
    );
  }
}
