import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/widget/customDevelopedByButton.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class AboutBody extends StatefulWidget {
  @override
  _AboutBodyState createState() => _AboutBodyState();
}

class _AboutBodyState extends State<AboutBody> {
  bool loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
        decoration:customBackgroundGradient(),
        child: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(top: screenHeight * 0.2),
              child: Column(
                children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03,
                            vertical: screenWidth * 0.03),
                        child: Center(
                          child:  sharedPreferences!.getString(
                                    AllSharedPreferencesKey.companyLogo) ==
                                null ||
                            sharedPreferences!
                                .getString(AllSharedPreferencesKey.companyLogo)!
                                .isEmpty
                        ? Image.asset(
                            "assets/images/logo.png",
                                 width: screenWidth * 0.55,
                            height: screenWidth * 0.5,
                          )
                        : Image.network(
                            sharedPreferences!.getString(
                                AllSharedPreferencesKey.companyLogo)!,
                          width: screenWidth * 0.55,
                            height: screenWidth * 0.5,
                          )
                        ),
                      ),
                  Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.03,
                        vertical: screenWidth * 0.01),
                    child: Center(
                      child: Text(
                        AllString.versionNameWithVersion,
                        textAlign: TextAlign.start,
                        style: headingTextStyle(
                          color: AllColor.black.withOpacity(0.6),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(bottom: 5, child: customDevelopedByButton(context))
          ],
        ),
      ),
    );
  }
}
