import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class PaymentDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final Function() callBack;
  const PaymentDetails(
      {Key? key, required this.singleData, required this.callBack})
      : super(key: key);
  @override
  _PaymentDetailsState createState() => _PaymentDetailsState();
}

class _PaymentDetailsState extends State<PaymentDetails> {
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.paymentDetails),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                 decoration:customBackgroundGradient(),

          child: ListView(
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: AllColor.black))),
                padding: EdgeInsets.all(1),
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                child: Container(
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10)),
                  width: screenWidth,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Dealer Name",
                              value:
                                  widget.singleData["dealerName"].toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Remark",
                              value: checkApiValueValid(
                                      widget.singleData["remarks"])
                                  ? AllString.na
                                  : widget.singleData["remarks"].toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Amount",
                              value: AllString.rs +
                                  widget.singleData["paymentAmount"]
                                      .toString()),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              widget.singleData["document"].toString().isEmpty ||
                      widget.singleData["document"].toString() == "null"
                  ? Container()
                  : GestureDetector(
                      onTap: () {
                        Navigator.of(context)
                            .push(CupertinoPageRoute(builder: (context) {
                          return NetworkImageView(
                            url: widget.singleData["document"].toString(),
                          );
                        }));
                      },
                      child: Center(
                        child: Container(
                          margin: customVertical(),
                          width: screenWidth * 0.3,
                          height: screenWidth * 0.3,
                          decoration: BoxDecoration(
                              color: AllColor.white,
                              borderRadius: BorderRadius.circular(10),
                              border:
                                  Border.all(width: 2, color: AllColor.black)),
                          child: Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: CachedNetworkImage(
                                  width: screenWidth * 0.3,
                                  height: screenWidth * 0.3,
                                  fit: BoxFit.cover,
                                  placeholder: (_, __) {
                                    return Center(
                                      child: CircularProgressIndicator(),
                                    );
                                  },
                                  errorWidget: (_, __, ___) {
                                    return Center(
                                      child: Image.asset(
                                          "assets/images/appLogo.png"),
                                    );
                                  },
                                  imageUrl:
                                      widget.singleData["document"].toString()),
                              // child: Image.memory(
                              //   Base64Decoder().convert(base64.normalize(widget
                              //       .singleData["document"]
                              //       .toString()
                              //       .trim())),
                              // ),
                            ),
                          ),
                        ),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
