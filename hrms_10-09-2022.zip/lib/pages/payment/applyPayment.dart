import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/payment/payment.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApplyPayment extends StatefulWidget {
  const ApplyPayment({
    Key? key,
  }) : super(key: key);
  @override
  _ApplyPaymentState createState() => _ApplyPaymentState();
}

class _ApplyPaymentState extends State<ApplyPayment> {
  bool loading = false;
  PickedFile? _imageFile;
  String _currentDealer = AllString.select;
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _amountTextEditingController = TextEditingController();
  TextEditingController _paymentIdTextEditingController =
      TextEditingController();
  FocusNode _amountFocusNode = FocusNode();
  FocusNode _paymentIdFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 300), () {
      setDropDownValueByDefaultUponCondition();
    });
    //offlineUploadApplyPaymentData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.applyPayment),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
          decoration: customBackgroundGradient(),
          child: Stack(
            children: [
              ListView(
                shrinkWrap: true,
                children: [
                  textFieldHeader(AllString.selectDealer + " *",
                      fontWeight: FontWeight.bold),
                  // Container(
                  //     child: dropdownButton(dealerList, (String? newValue) {
                  //   setState(() {
                  //     _currentDealer = newValue!;
                  //   });
                  // }, _currentDealer)),
                  Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentDealer,
                      dropdownList: dealerList,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentDealer = newValue!;
                        });
                      },
                    ),
                  ),
                  textFieldHeader(AllString.paymentAmount + " *",
                      fontWeight: FontWeight.bold),
                  Container(
                      child: RoundedInputField(
                    controller: _amountTextEditingController,
                    focusNode: _amountFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    hintText: AllString.enterAmount,
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.handHoldingUsDollar,
                    onchangeFunction: (String val) {
                      // if (val.isNotEmpty && int.parse(val) >= 5001) {
                      //   _amountTextEditingController.text = "";
                      // }
                      setState(() {});
                    },
                  )),
                  textFieldHeader(AllString.paymentUniqueId + " *",
                      fontWeight: FontWeight.bold),
                  Container(
                      child: RoundedInputField(
                    controller: _paymentIdTextEditingController,
                    focusNode: _paymentIdFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.text,
                    hintText: AllString.paymentUniqueId,
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.sortNumericUp,
                    onchangeFunction: (String val) {
                      setState(() {});
                    },
                  )),
                  textFieldHeader(AllString.remark,
                      fontWeight: FontWeight.bold),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enterRemark,
                        _commentTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  ),

                  textFieldHeader(AllString.uploadAttachment,
                      fontWeight: FontWeight.bold),

                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Row(
                      children: [
                        Container(
                          child: GestureDetector(
                            onTap: () {
                              _onImageButtonPressed(ImageSource.camera);

                              // pickImageOption();
                            },
                            child: Stack(
                              children: [
                                Container(
                                  width: screenWidth * 0.2,
                                  height: screenWidth * 0.2,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    color: AllColor.greyColor.withOpacity(0.5),
                                  ),
                                  child: Material(
                                    color: AllColor.lightBlack.withOpacity(0.5),
                                    //display new updated image here
                                    child: _imageFile == null
                                        ? mediumIcon(Icons.attach_file,
                                            color: AllColor.black)
                                        : Image.file(
                                            File(_imageFile!.path),
                                            fit: BoxFit.cover,
                                          ),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    clipBehavior: Clip.hardEdge,
                                  ),
                                ),
                                _imageFile == null
                                    ? Container()
                                    : Positioned(
                                        top: screenWidth * 0.01,
                                        right: screenWidth * 0.01,
                                        child: GestureDetector(
                                          onTap: () {
                                            _imageFile = null;
                                            setState(() {});
                                          },
                                          child: Container(
                                            child: normalIcon(Icons.close),
                                          ),
                                        ))
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // GestureDetector(
                  //   onTap: () {
                  //   _onImageButtonPressed(ImageSource.camera);
                  //     // pickImageOption();

                  //   },
                  //   child: Container(
                  //     height: screenWidth * 0.08,
                  //     width: screenWidth,
                  //     margin: EdgeInsets.symmetric(
                  //         horizontal: screenWidth * 0.03,
                  //         vertical: screenWidth * 0.02),
                  //     padding: EdgeInsets.symmetric(
                  //       horizontal: screenWidth * 0.015,
                  //     ),
                  //     alignment: Alignment.center,
                  //     decoration: BoxDecoration(
                  //         border: Border.all(
                  //             style: BorderStyle.solid,
                  //             color: AllColor.greyColor),
                  //         color: AllColor.lightBlack,
                  //         borderRadius: BorderRadius.circular(7)),
                  //     child: Row(
                  //       children: [
                  //         normalIcon(Icons.attachment_outlined,
                  //             color: AllColor.greyColor),
                  //         Container(
                  //           width: screenWidth * 0.03,
                  //         ),
                  //         normalText(AllString.uploadAttachment,
                  //             color: AllColor.black.withOpacity(0.7))
                  //       ],
                  //     ),
                  //   ),
                  // ),

                  // _imageFile == null
                  //     ? Container()
                  //     : Center(
                  //         child: Stack(
                  //           children: [
                  //             Container(
                  //               width: screenWidth * 0.2,
                  //               height: screenWidth * 0.2,
                  //               decoration: BoxDecoration(
                  //                 borderRadius:
                  //                     BorderRadius.all(Radius.circular(5)),
                  //                 color: AllColor.greyColor.withOpacity(0.5),
                  //               ),
                  //               child: Material(
                  //                 //display new updated image here
                  //                 child: Image.file(
                  //                   File(_imageFile!.path),
                  //                   fit: BoxFit.cover,
                  //                 ),
                  //                 borderRadius:
                  //                     BorderRadius.all(Radius.circular(5)),
                  //                 clipBehavior: Clip.hardEdge,
                  //               ),
                  //             ),
                  //             Positioned(
                  //                 top: screenWidth * 0.01,
                  //                 right: screenWidth * 0.01,
                  //                 child: GestureDetector(
                  //                   onTap: () {
                  //                     _imageFile = null;
                  //                     setState(() {});
                  //                   },
                  //                   child: Container(
                  //                     child: normalIcon(Icons.close),
                  //                   ),
                  //                 ))
                  //           ],
                  //         ),
                  //       ),

                  Container(
                      margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03),
                      child: button(
                        context,
                        function: () {
                          if (validateAndProceed()) {
                            applyPayment();
                          }
                        },
                        color: !validateAndProceed()
                            ? Colors.grey
                            : AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.confirm,
                      )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // pickImageOption() {
  //   return showDialog(
  //       // barrierDismissible: false,
  //       context: context,
  //       builder: (context) {
  //         return SimpleDialog(
  //           backgroundColor: AllColor.white,
  //           contentPadding: EdgeInsets.all(0),
  //           shape: RoundedRectangleBorder(
  //               borderRadius: BorderRadius.circular(16.0)),
  //           elevation: 0.0,
  //           title: normalText(AllString.selectImageFrom + ":",
  //               color: AllColor.black),
  //           children: [
  //             Container(
  //               margin: EdgeInsets.only(top: screenWidth * 0.03),
  //               decoration: BoxDecoration(
  //                   border: Border(top: BorderSide(color: Colors.grey))),
  //             ),
  //             SimpleDialogOption(
  //                 padding: EdgeInsets.all(0),
  //                 child: ListTile(
  //                   contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //                   leading: normalIcon(Icons.camera_alt,
  //                       color: AllColor.primaryColor),
  //                   title: normalText(AllString.camera, color: AllColor.black),
  //                 ),
  //                 onPressed: () {
  //                   _onImageButtonPressed(ImageSource.camera);
  //                   Navigator.pop(context);
  //                 }),
  //             SimpleDialogOption(
  //                 padding: EdgeInsets.all(0),
  //                 child: ListTile(
  //                   contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //                   leading: normalIcon(Icons.photo_library,
  //                       color: AllColor.primaryColor),
  //                   title: normalText(AllString.gallery, color: AllColor.black),
  //                 ),
  //                 onPressed: () {
  //                   _onImageButtonPressed(ImageSource.gallery);
  //                   Navigator.pop(context);
  //                 }),
  //           ],
  //         );
  //       });
  // }

  _onImageButtonPressed(
    ImageSource source,
  ) async {
    try {
      final pickedFile = await imagePickerQuality(source);

      setState(() {
        _imageFile = pickedFile;
      });

      setState(() {
        loading = false;
      });
    } catch (e) {}
  }

  applyPayment() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      if (_imageFile == null) {
        Map data = {
          "companyId":
              sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
          "individualId": sharedPreferences!
              .getString(AllSharedPreferencesKey.individualId),
          "userLoginId":
              sharedPreferences!.getString(AllSharedPreferencesKey.userId),
          "paymentData": [
            {
              "paymentImage": "",
              "userLoginId": loginUserId,
              "dealerId": _currentDealer.split(AllString.splitText).last,
              "amount": _amountTextEditingController.text,
              "comment": _commentTextEditingController.text,
              "visitTypeName": _currentDealer.split(AllString.splitText).first,
              "individualId": sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId),
              "companyId": sharedPreferences!
                  .getString(AllSharedPreferencesKey.companyId),
              "visitTypeId": _currentDealer.split(AllString.splitText).first,
              "paymentUniqueId": _paymentIdTextEditingController.text
            }
          ],
        };
        apiPostRequestWithHeader(
                data, AllUrls.addPaymentPost, this.context, loginToken)
            .then((response) {
          if (response == null) {
            loading = false;
            setState(() {});
            commonAlertDialog(
                context, AllString.warning, AllString.connectionFailure);
          } else {
            Map<String, dynamic> jsonData = json.decode(response);
            if (checkApiResponseSuccessOrNot(jsonData)) {
              setState(() {
                loading = false;
              });

              commonAlertDialog(
                  context, jsonData["status"], jsonData["message"],
                  function: () {
                Navigator.of(context).pushReplacement(
                    CupertinoPageRoute(builder: (context) => Payment()));
              });
            } else {
              setState(() {
                loading = false;
              });
              commonAlertDialog(
                  context, jsonData["status"], jsonData["message"]);
            }
          }
        });
      } else {
        // File imageFile = new File(_imageFile!.path);
        // List<int> imageBytes = imageFile.readAsBytesSync();
        // String paymentImage = base64Encode(imageBytes);

        setState(() {
          loading = true;
        });
        imageToUrlApiImage(_imageFile!.path, context).then((value) {
          Map data = {
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "userLoginId":
                sharedPreferences!.getString(AllSharedPreferencesKey.userId),
            "paymentData": [
              {
                "paymentImage": value,
                "userLoginId": loginUserId,
                "dealerId": _currentDealer.split(AllString.splitText).last,
                "amount": _amountTextEditingController.text,
                "comment": _commentTextEditingController.text,
                "visitTypeName":
                    _currentDealer.split(AllString.splitText).first,
                "individualId": sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId),
                "companyId": sharedPreferences!
                    .getString(AllSharedPreferencesKey.companyId),
                "visitTypeId": _currentDealer.split(AllString.splitText).first,
                "paymentUniqueId": _paymentIdTextEditingController.text
              }
            ],
          };
          apiPostRequestWithHeader(
                  data, AllUrls.addPaymentPost, this.context, loginToken)
              .then((response) {
            if (response == null) {
              loading = false;
              setState(() {});
              commonAlertDialog(
                  context, AllString.warning, AllString.connectionFailure);
            } else {
              Map<String, dynamic> jsonData = json.decode(response);
              if (checkApiResponseSuccessOrNot(jsonData)) {
                setState(() {
                  loading = false;
                });

                commonAlertDialog(
                    context, jsonData["status"], jsonData["message"],
                    function: () {
                  Navigator.of(context).push(
                      CupertinoPageRoute(builder: (context) => Payment()));
                });
              } else {
                setState(() {
                  loading = false;
                });
                commonAlertDialog(
                    context, jsonData["status"], jsonData["message"]);
              }
            }
          });
        });
      }
    } else {
      //showOfflineSnakbar(context);
      commonOfflineApplyPayment();
    }
  }

  commonOfflineApplyPayment() async {
    loading = true;
    setState(() {});

    Map<String, dynamic> data = {
      // Databasehelper.paymentId: punchInId,
      Databasehelper.paymentVisitTypeName:
          _currentDealer.split(AllString.splitText).first,
      Databasehelper.paymentDealerId:
          _currentDealer.split(AllString.splitText).last,
      Databasehelper.paymentPayAmount: _amountTextEditingController.text,
      Databasehelper.paymentComment: _commentTextEditingController.text,
      Databasehelper.paymentVisitTypeId:
          _currentDealer.split(AllString.splitText).first,
      Databasehelper.paymentUniqueId: _paymentIdTextEditingController.text
    };
    // ! Insert Row on Day Start and Day End Table

    AppBuilder.of(context)!.rebuild();

    final id = await dbhelper.insertApplyPayment(data);
    if (_imageFile != null) {
      File imageFile = new File(_imageFile!.path);
      List<int> imageBytes = imageFile.readAsBytesSync();
      String paymentImage = base64Encode(imageBytes);
      setState(() {});
      Map<String, dynamic> dataForImage = {
        Databasehelper.paymentId: id,
        Databasehelper.paymentPaymentImage: paymentImage
      };
      final idPaymentImage = await dbhelper.insertPaymentImage(dataForImage);
    }
    var allrows = await dbhelper.fetchAllApplyPayment();
    var allrows2 = await dbhelper.fetchAllPaymentImage();
    log(allrows.toString());
    log(allrows2.toString());

    commonAlertDialog(context, AllString.success, "Apply Payment Successfully",
        function: () async {
      AppBuilder.of(context)!.rebuild();
      setState(() {
        loading = false;
      });
      Navigator.of(context)
          .push(CupertinoPageRoute(builder: (context) => Payment()));
    });
  }

  offlineUploadApplyPaymentData() async {
    setState(() {
      loading = true;
    });
    if (await internetCheck()) {
      var alldbrows = await dbhelper.fetchAllApplyPayment();
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        "breakData": alldbrows,
      };
      log(data.toString());
      apiPostRequestWithHeader(
              data, AllUrls.addPaymentPost, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () async {
              List allpaymentList = alldbrows;
              allpaymentList.forEach((element) {
                dbhelper.deleteApplyPayment(element["id"]);
              });

              var allrowsss = await dbhelper.fetchAllApplyPayment();
              log(allrowsss.toString());
              setState(() {});
              Navigator.pop(context);
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    }
  }

  bool validateAndProceed() {
    if (_currentDealer == AllString.select) {
      return false;

      // commonAlertDialog(
      //     context, AllString.warning, AllString.selectDealer);
    } else if (_amountTextEditingController.text.isEmpty) {
      return false;

      // commonAlertDialog(context, AllString.warning,
      //    AllString.enterPaymentAmount);
    } else if (_paymentIdTextEditingController.text.isEmpty) {
      return false;

      // commonAlertDialog(context, AllString.warning,
      //    AllString.enterPaymentAmount);
    } else {
      return true;
    }
  }

  setDropDownValueByDefaultUponCondition() {
    if (dealerList.length == 2) {
      _currentDealer = dealerList.last;
    }
    // if (categoryList.length == 2) {
    //   _currentCategory = categoryList.last;
    // }
//     if(expenseTypeList.length==2){
// _currentExpenseType=expenseTypeList.last;
//     }
    setState(() {});
  }
}
