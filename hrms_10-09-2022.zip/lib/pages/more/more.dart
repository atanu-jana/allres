import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/profile/profile.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class More extends StatefulWidget {
  @override
  _MoreState createState() => _MoreState();
}

class _MoreState extends State<More> {
  bool loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                               decoration:customBackgroundGradient(),

        child: ListView(
          children: [
            Container(
                      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
              child: ListTile(
                onTap: (){
                       Navigator.of(context).push(
                        CupertinoPageRoute(builder: (context) => Profile()));
                },
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)
                ),
                tileColor: AllColor.white,
                leading: Icon(Icons.person,color:AllColor.black),
                title: normalText(AllString.profile,color:AllColor.black),
                trailing: smallIcon(Icons.arrow_forward_ios_outlined,color:AllColor.greyColor),
                
              ),
            )
          ],
        )
      ),
    );
  }
}
