import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentDetails.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/widget/customCatender.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class MyReimbursmentBody extends StatefulWidget {
  @override
  _MyReimbursmentBodyState createState() => _MyReimbursmentBodyState();
}

class _MyReimbursmentBodyState extends State<MyReimbursmentBody> {
  bool loading = false;
  List _myReimbursmentList = [];
  @override
  void initState() {
    super.initState();
    fetchReimbursment();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
   opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                              decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            ListView.builder(
                padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                physics: BouncingScrollPhysics(),
                itemCount: _myReimbursmentList.length,
                itemBuilder: (context, index) => customMyReimbursmentItem(
                    _myReimbursmentList[index], index)),
          ],
        ),
      ),
    );
  }

  customMyReimbursmentItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => MyReimbursmentDetails()));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth * 0.25,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              customCatender(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.17 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  index),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.6,
                      widthTitle: screenWidth * 0.15,
                      title: "Amount",
                      value:
                          AllString.rs + " " + itemData["ReimbursementAmount"]),
                  customRowDetails(
                      width: screenWidth * 0.6,
                      widthTitle: screenWidth * 0.15,
                      title: "Time",
                      value: itemData["ReimbursementTime"].toString()),
                ],
              ),
              Container(
                  margin: EdgeInsets.only(right: screenWidth * 0.02),
                  child: normalIcon(Icons.arrow_forward_ios,
                      color: AllColor.greyColor))
            ],
          ),
        ),
      ),
    );
  }

  fetchReimbursment() async {
    var jsonData = json.decode(
        await rootBundle.loadString('assets/json/ReimbursmentListData.json'));
    log(jsonData.toString());
    _myReimbursmentList = jsonData["ReimbursementListData"];
    setState(() {});
  }
}
