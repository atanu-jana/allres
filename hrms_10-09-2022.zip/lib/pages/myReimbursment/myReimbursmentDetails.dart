import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class MyReimbursmentDetails extends StatefulWidget {
  const MyReimbursmentDetails({Key? key}) : super(key: key);
  @override
  _MyReimbursmentDetailsState createState() => _MyReimbursmentDetailsState();
}

class _MyReimbursmentDetailsState extends State<MyReimbursmentDetails> {
  bool loading = false;
  List _myReimbursmentDetailsList = [];
  String remark = "";
  @override
  void initState() {
    super.initState();
    fetchReimbursmentDetails();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar:
          customAppBar(context, AllString.reimbursementBreakupDetails),
      body: LoadingOverlay(
        isLoading: loading,
         opacity: 0.5,
      color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                margin: EdgeInsets.only(bottom: screenWidth * 0.015),
                height: screenWidth * 0.12,
                decoration: BoxDecoration(
                  color: AllColor.tableBackground,

                  // border: Border(
                  //     bottom: BorderSide(
                  //   color: AllColor.black,
                  // ))
                ),
                width: screenWidth,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.27,
                      child: Text(
                        "Requested \n Date",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.25,
                      child: Text(
                        "Requested\nAmount",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.15,
                      child: Text(
                        "Reason",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.25,
                      child: Text(
                        "Approve\nAmount",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                  ],
                ),
              ),
              ListView.builder(
                  shrinkWrap: true,
                  padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                  physics: BouncingScrollPhysics(),
                  itemCount: _myReimbursmentDetailsList.length,
                  itemBuilder: (context, index) =>
                      customMyReimbursmentDetailsItem(
                          _myReimbursmentDetailsList[index], index)),
              Divider(),
              Container(
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.0),
                alignment: Alignment.centerLeft,
                child: normalText("Remarks:", color: AllColor.black),
              ),
              Container(
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                width: screenWidth,
                padding: EdgeInsets.all(7),
                height: screenWidth * 0.3,
                decoration: BoxDecoration(
                    color: AllColor.white,
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(color: AllColor.black, width: 2)),
                alignment: Alignment.topLeft,
                child: normalText(remark, color: AllColor.black),
              ),
            ],
          ),
        ),
      ),
    );
  }

  customMyReimbursmentDetailsItem(Map<String, dynamic> itemData, int i) {
    return Container(
      height: screenWidth * 0.1,
      color: i % 2 != 0 ? AllColor.lightBlueGrey : AllColor.white,
      width: screenWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.27,
            child: Text(
              convertStringToDate(DateTime.now()),
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.25,
            child: Text(
              AllString.rs + " " + itemData["RequestAmount"],
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.15,
            child: Text(
              itemData["Reason"],
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.25,
            child: Text(
              AllString.rs + " " + itemData["ApproveAmount"],
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
        ],
      ),
    );
  }

  fetchReimbursmentDetails() async {
    var jsonData = json.decode(await rootBundle
        .loadString('assets/json/ReimbursementDetailData.json'));
    log(jsonData.toString());
    remark = jsonData["Remarks"];
    _myReimbursmentDetailsList = jsonData["ReimbursementDetailData"];
    setState(() {});
  }
}
