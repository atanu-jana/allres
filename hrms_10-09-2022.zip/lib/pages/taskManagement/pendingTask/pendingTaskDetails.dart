import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/requestManagement/requestManagementBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class PendingTaskDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const PendingTaskDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);
  @override
  _PendingTaskDetailsState createState() => _PendingTaskDetailsState();
}

class _PendingTaskDetailsState extends State<PendingTaskDetails> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();
  @override
  void initState() {
    super.initState();
    log(widget.singleData.toString());
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.individualId)
        .toString());
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.individualTypeId)
        .toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, "View Task Details"),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                  decoration:customBackgroundGradient(),

          child: ListView(
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: AllColor.black))),
                padding: EdgeInsets.all(1),
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                child: Container(
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10)),
                  width: screenWidth,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Task Type",
                              value: showValidValue(widget
                                  .singleData["taskTypeName"]
                                  .toString())),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Comment",
                              value: showValidValue(
                                  widget.singleData["comment"].toString())),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Status",
                              value:
                                  checkAndDisplayTaskStatus(widget.singleData)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              widget.visible
                  ? widget.singleData["approvalStatus"].toString() == "0"
                      ? textFieldHeader(AllString.remark,
                          fontWeight: FontWeight.bold)
                      : Container()
                  : Container(),
              widget.visible
                  ? widget.singleData["approvalStatus"].toString() == "0"
                      ? Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.enterRemark,
                              _commentTextEditingController,
                              4,
                              200,
                              TextInputAction.done,
                              TextInputType.text,
                            ),
                          ),
                        )
                      : Container()
                  : Container(),
              SizedBox(
                height: screenWidth * 0.03,
              ),
              widget.visible
                  ? widget.singleData["approvalStatus"].toString() == "0"
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              child: button(context,
                              color:AllColor.red,

                                  text: AllString.reject,
                                  textColor: AllColor.white,
                                  width: screenWidth * 0.35, function: () {
                                approvedAndRejectCall(widget.singleData, true);
                              },
                                  enable:
                                      _commentTextEditingController.text.isEmpty
                                          ? false
                                          : true),
                            ),
                            Container(
                              child: button(context,
                              color:AllColor.deepGreen,
                              text: AllString.approved,
                                  width: screenWidth * 0.35,
                                  enable:
                                      _commentTextEditingController.text.isEmpty
                                          ? false
                                          : true,
                                  textColor: AllColor.white, function: () {
                                approvedAndRejectCall(widget.singleData, false);
                              }),
                            ),
                          ],
                        )
                      : Container()
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  approvedAndRejectCall(Map<String, dynamic> itemData, bool reject) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "approvalStatus":
             reject
                    ? 2
                    : 1
                ,
       
        "comment":   _commentTextEditingController.text
            ,
        
        "taskApprovalId": widget.singleData["taskApprovalId"],
        // "userLoginId": loginUserId,
        "individualTypeId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
        "companyId": sharedPreferences!
            .getString(AllSharedPreferencesKey.companyId)
            .toString(),
        "individualId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualId)
            .toString(),
        // "employeeTaskId": sharedPreferences!
        //     .getString(AllSharedPreferencesKey.individualId)
        //     .toString(),
        // "employeeTaskId":  widget.singleData["taskApprovalId"],
      };

      apiPostRequestWithHeader(
              data, AllUrls.updateTaskStatus, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              widget.callBack();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // customCardRowDetails(String title, value) {
  //   return Container(
  //     width: screenWidth,
  //     padding: EdgeInsets.symmetric(
  //         vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.start,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         Container(
  //           width: screenWidth * 0.33,
  //           child: smallText(title + " :", color: AllColor.greyColor),
  //         ),
  //         Container(
  //           margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
  //         ),
  //         normalText(value,
  //             color: value == "Approved" ? AllColor.green : AllColor.black)
  //       ],
  //     ),
  //   );
  // }

  // String checkAndSiaplayStatus(Map<String, dynamic> itemData) {
  //   if (itemData["approvalLevel"].toString() == "1") {
  //     if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //       return "Approved By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else {
  //       return "Unknown";
  //     }
  //   } else if (itemData["approvalLevel"].toString() == "2") {
  //     if (itemData["firstLevelApproveStatus"].toString() == "0" &&
  //         itemData["secondLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]) +
  //           ", " +
  //           showValidValue(itemData["secondLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2" ||
  //         itemData["secondLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " + itemData["firstLevelApprovalBy"].toString() ==
  //                   "null" ||
  //               itemData["firstLevelApprovalBy"].isEmpty
  //           ? showValidValue(itemData["secondLevelApprovalBy"])
  //           : showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "1" ||
  //         itemData["secondLevelApproveStatus"].toString() == "1") {
  //       return "Approved By " + itemData["firstLevelApprovalBy"].toString() ==
  //                   "null" ||
  //               itemData["firstLevelApprovalBy"].isEmpty
  //           ? showValidValue(itemData["secondLevelApprovalBy"])
  //           : showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else {
  //       return "Unknown";
  //     }
  //   } else {
  //     if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else {
  //       if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //         return "Pending By " +
  //             showValidValue(itemData["secondLevelApprovalBy"]);
  //       } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //         return "Approved By " +
  //             showValidValue(itemData["secondLevelApprovalBy"]);
  //       } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //         return "Rejected By " +
  //             showValidValue(itemData["secondLevelApprovalBy"]);
  //       } else {
  //         return "Unknown";
  //       }
  //     }
  //   }
  // }

  // bool checkForAprovedAndReject(Map<String, dynamic> itemData) {
  //   if ((sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "17") ||
  //       (sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "16") ||
  //       (sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "19")) {
  //     if (itemData["approvalLevel"].toString() == "2" &&
  //         (itemData["firstLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString() ||
  //             itemData["secondLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString())) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "0" &&
  //         (itemData["firstLevelIndividualId"].toString() ==
  //             sharedPreferences!
  //                 .getString(AllSharedPreferencesKey.individualId)
  //                 .toString())) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "1" &&
  //         (itemData["firstLevelApproveStatus"].toString() == "0" &&
  //             (itemData["firstLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString()))) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "1" &&
  //         (itemData["firstLevelApproveStatus"].toString() == "1" &&
  //             itemData["secondLevelApproveStatus"].toString() == "0" &&
  //             (itemData["secondLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString()))) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else {
  //       return false;
  //     }

  //     // if (status == "1") {
  //     //   return false;
  //     // } else if (status == "3" ||status == "4") {
  //     //   return false;
  //     // } else if (status == "0" &&
  //     //     (sharedPreferences!
  //     //             .getString(AllSharedPreferencesKey.individualTypeId)
  //     //             .toString() ==
  //     //         "17")) {
  //     //   return true;
  //     // } else if (int.parse(status) > 0 &&
  //     //     (sharedPreferences!
  //     //             .getString(AllSharedPreferencesKey.individualTypeId)
  //     //             .toString() ==
  //     //         "16")) {
  //     //   return true;
  //     // } else {
  //     //   return false;
  //     // }
  //   } else {
  //     return false;
  //   }
  // }
}
