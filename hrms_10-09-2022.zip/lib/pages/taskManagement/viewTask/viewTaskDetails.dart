import 'dart:convert';
import 'dart:developer';

import 'package:hr/util/allIcon.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/requestManagement/requestManagementBody.dart';
import 'package:hr/pages/taskManagement/taskManagement.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ViewTaskDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const ViewTaskDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);
  @override
  _ViewTaskDetailsState createState() => _ViewTaskDetailsState();
}

class _ViewTaskDetailsState extends State<ViewTaskDetails> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();
  bool assign = false;
  bool approval = false;
  String selectTeamMember = AllString.select;

  String selectedDepartment = AllString.select;
  String selectedDepartmentEmployee = AllString.select;
  String selectedDepartmentForAproval = AllString.select;
  String selectedDepartmentEmployeeForAproval = AllString.select;
  List<String> _departmentList = [];
  List<String> _departmentEmployeeList = [];

  List<String> _departmentListForAproval = [];
  List<String> _departmentEmployeeListForAproval = [];
  @override
  void initState() {
    super.initState();
    log(widget.singleData.toString());
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.individualId)
        .toString());
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.individualTypeId)
        .toString());
    departmentList();
  }

  onDapartmentTypeChanged(String? value) {
    selectedDepartmentEmployee = value!;
    setState(() {});
  }

  onDepartmentChanged(String? value) {
    selectedDepartment = value!;
    setState(() {});
    if (selectedDepartment == AllString.select) {
      _departmentEmployeeList.clear();
      setState(() {});
    } else {
      departmentListSearch();
    }
  }

  departmentList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.departmentList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _departmentList.clear();
          _departmentListForAproval.clear();
          _departmentList.add(AllString.select);
          _departmentListForAproval.add(AllString.select);

          if (jsonData["departmentData"].isEmpty ||
              jsonData["departmentData"].toString() == "") {
            _departmentList.clear();
            _departmentListForAproval.clear();
          } else {
            List _tempList = jsonData["departmentData"];
            _tempList.forEach((element) {
              _departmentList.add(element["departmentName"].toString() +
                  AllString.splitText +
                  element["departmentId"].toString());
              _departmentListForAproval.add(
                  element["departmentName"].toString() +
                      AllString.splitText +
                      element["departmentId"].toString());
            });
          }

          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  departmentListSearch() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "departmentId": selectedDepartment.split(AllString.splitText).last,
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.departmentWiseEmployee, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          selectedDepartmentEmployee = AllString.select;
          _departmentEmployeeList.clear();
          _departmentEmployeeList.add(AllString.select);

          if (jsonData["employeeData"].isEmpty ||
              jsonData["employeeData"].toString() == "") {
            _departmentEmployeeList.clear();
          } else {
            List _tempList = jsonData["employeeData"];
            _tempList.forEach((element) {
              _departmentEmployeeList.add(element["individualName"].toString() +
                  AllString.splitText +
                  element["individualId"].toString());
            });
          }

          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  departmentListSearchForAproval() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "departmentId":
          selectedDepartmentForAproval.split(AllString.splitText).last,
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.departmentWiseEmployee, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          selectedDepartmentEmployeeForAproval = AllString.select;
          _departmentEmployeeListForAproval.clear();
          _departmentEmployeeListForAproval.add(AllString.select);

          if (jsonData["employeeData"].isEmpty ||
              jsonData["employeeData"].toString() == "") {
            _departmentEmployeeListForAproval.clear();
          } else {
            List _tempList = jsonData["employeeData"];
            _tempList.forEach((element) {
              _departmentEmployeeListForAproval.add(
                  element["individualName"].toString() +
                      AllString.splitText +
                      element["individualId"].toString());
            });
          }

          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  bool validateAndProceedForAssign() {
    if (assign &&
        (selectedDepartment == AllString.select ||
            selectedDepartmentEmployee == AllString.select)) {
      return false;
    } else {
      return true;
    }
  }

  bool validateAndProceedForApproval() {
    if (approval &&
        // (selectedDepartmentForAproval == AllString.select ||
        //     selectedDepartmentEmployeeForAproval == AllString.select)) {
        (selectTeamMember == AllString.select)) {
      return false;
    } else {
      return true;
    }
  }

  reassign() {
    setState(() {
      loading = true;
    });
    Map data = {
      "employeeTaskId": widget.singleData["employeeTaskId"],
      "taskAssignedFrom":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "taskAssignedTo":
          selectedDepartmentEmployee.split(AllString.splitText).last,
      "userLoginId":
          sharedPreferences!.getString(AllSharedPreferencesKey.userId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.reassignEmployeeTask, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).push(
                  CupertinoPageRoute(builder: (context) => TaskManagement()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  sendApproval() {
    setState(() {
      loading = true;
    });
    Map data = {
      "employeeTaskId": widget.singleData["employeeTaskId"],
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "taskReviewBy": selectTeamMember.split(AllString.splitText).last,
      "userLoginId":
          sharedPreferences!.getString(AllSharedPreferencesKey.userId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.taskApproval, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).push(
                  CupertinoPageRoute(builder: (context) => TaskManagement()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  selfClose() {
    setState(() {
      loading = true;
    });
    Map data = {
      "employeeTaskId": widget.singleData["employeeTaskId"],
      "taskAssignedFrom":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "status": 1,
      "userLoginId":
          sharedPreferences!.getString(AllSharedPreferencesKey.userId),
    };
    apiPostRequestWithHeader(data, AllUrls.closedTask, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).push(
                  CupertinoPageRoute(builder: (context) => TaskManagement()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, "Task Details"),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
          decoration: customBackgroundGradient(),
          child: approval
              ? ListView(
                  physics: BouncingScrollPhysics(),
                  children: [
                    textFieldHeader(AllString.selectMember,
                        fontWeight: FontWeight.bold, center: true),
                    Container(
                      width: screenWidth,
                      child: Container(
                        child: DropdownButtonWithSearch(
                          icon: LineIcons.sortAmountDown,
                          selectedValue: selectTeamMember,
                          dropdownList: allTeamMemberList,
                          onChanged: onTeamMemberChanged,
                        ),
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.015,
                            horizontal: screenWidth * 0.03),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                                child: button(context, function: () {
                              approval = false;
                              assign = false;
                              setState(() {});
                            },
                                    color: AllColor.red,
                                    textColor: AllColor.white,
                                    text: AllString.cancel,
                                    width: screenWidth * 0.3)),
                            Container(
                                child: button(context, function: () {
                              if (validateAndProceedForApproval()) {
                                sendApproval();
                              }
                            },
                                    color: !validateAndProceedForApproval()
                                        ? Colors.grey
                                        : AllColor.primaryColor,
                                    textColor: AllColor.white,
                                    text: AllString.sendApproval,
                                    width: screenWidth * 0.3))
                          ],
                        )),
                  ],
                )
              : assign
                  ? ListView(
                      physics: BouncingScrollPhysics(),
                      children: [
                        textFieldHeader("Department Type*",
                            fontWeight: FontWeight.bold),
                        Container(
                          child: dropdownButton(_departmentList,
                              onDepartmentChanged, selectedDepartment),
                        ),
                        _departmentEmployeeList.isEmpty
                            ? Container()
                            : textFieldHeader("Assign to",
                                fontWeight: FontWeight.bold),
                        _departmentEmployeeList.isEmpty
                            ? Container()
                            : Container(
                                child: dropdownButton(
                                    _departmentEmployeeList,
                                    onDapartmentTypeChanged,
                                    selectedDepartmentEmployee),
                              ),
                        Container(
                            margin: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.015,
                                horizontal: screenWidth * 0.03),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                    child: button(context, function: () {
                                  approval = false;
                                  assign = false;
                                  setState(() {});
                                },
                                        color: AllColor.red,
                                        textColor: AllColor.white,
                                        text: AllString.reset,
                                        width: screenWidth * 0.3)),
                                Container(
                                    child: button(context, function: () {
                                  if (validateAndProceedForAssign()) {
                                    reassign();
                                  }
                                },
                                        color: !validateAndProceedForAssign()
                                            ? Colors.grey
                                            : AllColor.primaryColor,
                                        textColor: AllColor.white,
                                        text: AllString.add,
                                        width: screenWidth * 0.3))
                              ],
                            )),
                      ],
                    )
                  : ListView(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              border: Border(
                                  bottom: BorderSide(color: AllColor.black))),
                          padding: EdgeInsets.all(1),
                          margin: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.03,
                              vertical: screenWidth * 0.01),
                          child: Container(
                            decoration: BoxDecoration(
                                color: AllColor.white,
                                borderRadius: BorderRadius.circular(10)),
                            width: screenWidth,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    customRowDetails(
                                        width: screenWidth * 0.65,
                                        widthTitle: screenWidth * 0.18,
                                        title: "Task Type",
                                        value: showValidValue(widget
                                            .singleData["taskTypeName"]
                                            .toString())),
                                    customRowDetails(
                                        width: screenWidth * 0.65,
                                        widthTitle: screenWidth * 0.18,
                                        title: "Comment",
                                        value: showValidValue(
                                            widget.singleData["comment"])),
                                    customRowDetails(
                                        width: screenWidth * 0.65,
                                        widthTitle: screenWidth * 0.18,
                                        title: "Status",
                                        value: showValidValue(widget
                                                    .singleData["status"]) ==
                                                "0"
                                            ? "Open Task"
                                            : "Closed Task"),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          margin: AllMargin.customMarginCardItem(),
                          child: Row(
                            children: [
                              widget.singleData["imageFileName"]
                                          .toString()
                                          .isEmpty ||
                                      widget.singleData["imageFileName"]
                                              .toString() ==
                                          "null"
                                  ? Container()
                                  : GestureDetector(
                                      onTap: () {
                                        Navigator.of(context).push(
                                            CupertinoPageRoute(
                                                builder: (context) {
                                          return NetworkImageView(
                                            url: widget
                                                .singleData["imageFileName"]
                                                .toString(),
                                          );
                                        }));
                                      },
                                      child: Center(
                                        child: Container(
                                          margin: customVertical(),
                                          width: screenWidth * 0.3,
                                          height: screenWidth * 0.3,
                                          decoration: BoxDecoration(
                                              color: AllColor.white,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              border: Border.all(
                                                  width: 2,
                                                  color: AllColor.black)),
                                          child: Center(
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: CachedNetworkImage(
                                              width: screenWidth * 0.3,
                                              height: screenWidth * 0.3,
                                              fit: BoxFit.cover,
                                                  placeholder: (_, __) {
                                                    return Center(
                                                      child: CircularProgressIndicator(),
                                                    );
                                                  },
                                                  errorWidget: (_, __, ___) {
                                                    return Center(
                                                      child: Image.asset(
                                                          "assets/images/appLogo.png"),
                                                    );
                                                  },
                                                  imageUrl: widget
                                                      .singleData["imageFileName"]
                                                      .toString()),
                                              // child: Image.memory(
                                              //   Base64Decoder().convert(
                                              //       base64.normalize(widget
                                              //           .singleData[
                                              //               "imageFileName"]
                                              //           .toString()
                                              //           .trim())),
                                              //   width: screenWidth * 0.3,
                                              //   height: screenWidth * 0.3,
                                              //   fit: BoxFit.cover,
                                              // ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                              widget.singleData["videoFileName"]
                                          .toString()
                                          .isEmpty ||
                                      widget.singleData["videoFileName"]
                                              .toString() ==
                                          "null"
                                  ? Container()
                                  : GestureDetector(
                                      onTap: () {
                                        showDialog(
                                          context: context,
                                          builder: (_) => VideoPlay(
                                              url: widget
                                                  .singleData["videoFileName"]),
                                        );
                                      },
                                      child: Center(
                                        child: Container(
                                          margin:
                                              AllMargin.customMarginCardItem(),
                                          width: screenWidth * 0.3,
                                          height: screenWidth * 0.3,
                                          decoration: BoxDecoration(
                                              color: AllColor.white,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              border: Border.all(
                                                  width: 2,
                                                  color: AllColor.black)),
                                          child: Center(
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: normalIcon(
                                                  Icons.video_library,
                                                  color: AllColor.green
                                                  // width: screenWidth * 0.3,
                                                  // height: screenWidth * 0.3,
                                                  // fit: BoxFit.cover,
                                                  ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                            ],
                          ),
                        ),
                        showValidValue(widget.singleData["status"]) == "1"
                            ? Container()
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    child: button(context,
                                        color: AllColor.primaryColor,
                                        text: "Send for approval",
                                        width: screenWidth / 2,
                                        textColor: AllColor.white,
                                        function: () {
                                      approval = true;
                                      assign = false;
                                      setState(() {});
                                    }),
                                  ),
                                ],
                              ),
                        showValidValue(widget.singleData["status"]) == "1"
                            ? Container()
                            : Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    child: button(
                                      context,
                                      color: AllColor.deepGreen,
                                      text: "Self",
                                      textColor: AllColor.white,
                                      width: screenWidth * 0.35,
                                      function: () {
                                        approval = false;
                                        setState(() {});
                                        selfClose();
                                      },
                                    ),
                                  ),
                                  Container(
                                    child: button(context,
                                        color: AllColor.blue,
                                        text: "Reassigned",
                                        width: screenWidth * 0.35,
                                        textColor: AllColor.white,
                                        function: () {
                                      assign = true;
                                      approval = false;
                                      setState(() {});
                                    }),
                                  ),
                                ],
                              )
                        // widget.visible
                        //     ? !checkForAprovedAndReject(widget.singleData)
                        //         ? Container()
                        //         : textFieldHeader(AllString.remark,
                        //             fontWeight: FontWeight.bold)
                        //     : Container(),
                        // widget.visible
                        //     ? !checkForAprovedAndReject(widget.singleData)
                        //         ? Container()
                        //         : Container(
                        //             margin: EdgeInsets.symmetric(
                        //               vertical: screenWidth * 0.0,
                        //               horizontal: screenWidth * 0.03,
                        //             ),
                        //             child: Center(
                        //               child: textAreaField(
                        //                 context,
                        //                 AllString.enterRemark,
                        //                 _commentTextEditingController,
                        //                 4,
                        //                 100,
                        //                 TextInputAction.done,
                        //                 TextInputType.text,
                        //               ),
                        //             ),
                        //           )
                        //     : Container(),
                        // SizedBox(
                        //   height: screenWidth * 0.03,
                        // ),
                        // widget.visible
                        //     ? !checkForAprovedAndReject(widget.singleData)
                        //         ? Container()
                        // : Row(
                        //     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        //     crossAxisAlignment: CrossAxisAlignment.center,
                        //     children: [
                        //       Container(
                        //         child: button(context,
                        //             color1: AllColor.red,
                        //             color2: AllColor.red,
                        //             text: AllString.reject,
                        //             textColor: AllColor.white,
                        //             width: screenWidth * 0.35, function: () {
                        //           approvedAndRejectCall(widget.singleData, true);
                        //         },
                        //             enable:
                        //                 _commentTextEditingController.text.isEmpty
                        //                     ? false
                        //                     : true),
                        //       ),
                        //       Container(
                        //         child: button(context,
                        //             color1: AllColor.deepGreen,
                        //             color2: AllColor.deepGreen,
                        //             text: AllString.approved,
                        //             width: screenWidth * 0.35,
                        //             enable:
                        //                 _commentTextEditingController.text.isEmpty
                        //                     ? false
                        //                     : true,
                        //             textColor: AllColor.white, function: () {
                        //           approvedAndRejectCall(widget.singleData, false);
                        //         }),
                        //       ),
                        //     ],
                        //   )
                        //     : Container(),
                      ],
                    ),
        ),
      ),
    );
  }

  onTeamMemberChanged(String? value) {
    selectTeamMember = value!;
    setState(() {});
  }

  approvedAndRejectCall(Map<String, dynamic> itemData, bool reject) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "firstLevelApproveStatus":
            itemData["firstLevelIndividualId"].toString() ==
                    sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualId)
                        .toString()
                ? reject
                    ? 2
                    : 1
                : "",
        "secondLevelApproveStatus":
            itemData["secondLevelIndividualId"].toString() ==
                    sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualId)
                        .toString()
                ? reject
                    ? 2
                    : 1
                : "",
        "firstLevelComment": itemData["firstLevelIndividualId"].toString() ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)
                    .toString()
            ? _commentTextEditingController.text
            : "",
        "secondLevelComment": itemData["secondLevelIndividualId"].toString() ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)
                    .toString()
            ? _commentTextEditingController.text
            : "",
        "employeeRequestDetailId": widget.singleData["employeeRequestDetailId"],
        "userLoginId": loginUserId,
        "individualTypeId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
        "companyId": sharedPreferences!
            .getString(AllSharedPreferencesKey.companyId)
            .toString(),
        "individualId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualId)
            .toString(),
      };

      apiPostRequestWithHeader(
              data, AllUrls.updateEmployeeRequest, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              widget.callBack();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // customCardRowDetails(String title, value) {
  //   return Container(
  //     width: screenWidth,
  //     padding: EdgeInsets.symmetric(
  //         vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.start,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         Container(
  //           width: screenWidth * 0.33,
  //           child: smallText(title + " :", color: AllColor.greyColor),
  //         ),
  //         Container(
  //           margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
  //         ),
  //         normalText(value,
  //             color: value == "Approved" ? AllColor.green : AllColor.black)
  //       ],
  //     ),
  //   );
  // }

  // bool checkForAprovedAndReject(Map<String, dynamic> itemData) {
  //   if ((sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "17") ||
  //       (sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "16") ||
  //       (sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "19")) {
  //     if (itemData["approvalLevel"].toString() == "2" &&
  //         (itemData["firstLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString() ||
  //             itemData["secondLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString())) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "0" &&
  //         (itemData["firstLevelIndividualId"].toString() ==
  //             sharedPreferences!
  //                 .getString(AllSharedPreferencesKey.individualId)
  //                 .toString())) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "1" &&
  //         (itemData["firstLevelApproveStatus"].toString() == "0" &&
  //             (itemData["firstLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString()))) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "1" &&
  //         (itemData["firstLevelApproveStatus"].toString() == "1" &&
  //             itemData["secondLevelApproveStatus"].toString() == "0" &&
  //             (itemData["secondLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString()))) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else {
  //       return false;
  //     }

  //     // if (status == "1") {
  //     //   return false;
  //     // } else if (status == "3" ||status == "4") {
  //     //   return false;
  //     // } else if (status == "0" &&
  //     //     (sharedPreferences!
  //     //             .getString(AllSharedPreferencesKey.individualTypeId)
  //     //             .toString() ==
  //     //         "17")) {
  //     //   return true;
  //     // } else if (int.parse(status) > 0 &&
  //     //     (sharedPreferences!
  //     //             .getString(AllSharedPreferencesKey.individualTypeId)
  //     //             .toString() ==
  //     //         "16")) {
  //     //   return true;
  //     // } else {
  //     //   return false;
  //     // }
  //   } else {
  //     return false;
  //   }
  // }
}

class VideoPlay extends StatefulWidget {
  final String url;

  const VideoPlay({Key? key, required this.url}) : super(key: key);
  @override
  State<StatefulWidget> createState() => VideoPlayState();
}

class VideoPlayState extends State<VideoPlay>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;
  Animation<double>? scaleAnimation;
  late VideoPlayerController _controller;
  bool isClicked = true;
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    scaleAnimation = CurvedAnimation(parent: controller!, curve: Curves.linear);

    controller!.addListener(() {
      setState(() {});
    });

    _controller = VideoPlayerController.network(
      widget.url,
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    );
    _controller.addListener(() {
      setState(() {});
    });
    _controller.setLooping(true);
    _controller.initialize();
    controller!.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: scaleAnimation!,
      child: Container(
        width: screenWidth,
        height: screenHeight,
        margin: EdgeInsets.only(left: 0.0, right: 0.0),
        child: Stack(
          children: <Widget>[
            Container(
              width: screenWidth,
              height: screenHeight,
              child: Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  Container(
                    child: AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: <Widget>[
                          VideoPlayer(_controller),
                          VideoProgressIndicator(_controller,
                              allowScrubbing: true),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isClicked = true;
                        Future.delayed(Duration(seconds: 1), () {
                          isClicked = false;
                        });
                        if (_controller.value.isPlaying) {
                          _controller.pause();
                        } else {
                          _controller.play();
                        }
                      });
                    },
                    child: Container(
                        width: screenWidth * 0.15,
                        height: screenWidth * 0.15,
                        color: AllColor.transparentColor,
                        child: !isClicked
                            ? Container()
                            : largeIcon(
                                _controller.value.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: AllColor.white)),
                  )
                ],
              ),
            ),
            Positioned(
              right: 15.0,
              top: 10.0,
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Align(
                  alignment: Alignment.topRight,
                  child: Container(
                      width: screenWidth * 0.1,
                      height: screenWidth * 0.1,
                      decoration: BoxDecoration(
                          color: AllColor.red,
                          borderRadius: BorderRadius.circular(10000)),
                      child: largeIcon(Icons.close, color: AllColor.white)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
