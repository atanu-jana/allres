import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ApplyOrder extends StatefulWidget {
  const ApplyOrder({
    Key? key,
  }) : super(key: key);
  @override
  _ApplyOrderState createState() => _ApplyOrderState();
}

class _ApplyOrderState extends State<ApplyOrder> {
  bool loading = false;
  List<String> _productList = [AllString.select];
  List<String> _categoryList = [AllString.select];
  List<Map<String, dynamic>> _orderList = [];
  String _currentDealer = AllString.select;
  String _currentCategory = AllString.select;
  String _currentProduct = AllString.select;
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _quentityTextEditingController =
      TextEditingController();
  FocusNode _quentityFocusNode = FocusNode();
  String _currentBrand = AllString.select;

  @override
  void initState() {
    super.initState();
    // print(
    //     sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
    Future.delayed(Duration(milliseconds: 300), () {
      setDropDownValueByDefaultUponCondition();
    });
    // offlineUploadOrderData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.applyOrder),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
          decoration: customBackgroundGradient(),
          child: Stack(
            children: [
              ListView(
                children: [
                  textFieldHeader(AllString.selectDealer + "*",
                      fontWeight: FontWeight.bold),
                  // Container(
                  //     child: dropdownButton(dealerList, (String? newValue) {
                  // setState(() {
                  //   _currentDealer = newValue!;
                  // });
                  // }, _currentDealer)),
                  Container(
                    child: DropdownButtonWithSearchForDealerList(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentDealer,
                      dropdownList: dealerList,
                      onChanged: (String? newValue) {
                        setState(() {
                          _currentDealer = newValue!;
                        });
                      },
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                    child: Row(
                      children: [
                        textFieldHeader(AllString.addOrder + " *",
                            fontWeight: FontWeight.bold),
                        GestureDetector(
                          onTap: () => addOrderDialog(),
                          // child: normalIcon(Icons.add, color: AllColor.deepGreen),
                          child: Center(
                              child: SvgPicture.asset(
                            "assets/images/addButton.svg",
                            color: AllColor.deepGreen,
                            height: screenWidth * 0.06,
                            // width: screenWidth * 0.06,
                          )),
                        )
                      ],
                    ),
                  ),
                  _orderList.isEmpty
                      ? Container()
                      : Container(
                          height: screenWidth * 0.1,
                          padding: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.1,
                          ),
                          decoration: BoxDecoration(
                            color: AllColor.tableBackground,
                          ),
                          width: screenWidth,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                width: screenWidth * 0.25,
                                child: Text(
                                  "Category Name",
                                  textAlign: TextAlign.center,
                                  style: smallTextStyle(color: AllColor.white),
                                ),
                              ),
                              Container(
                                width: screenWidth * 0.25,
                                child: Text(
                                  "Product Name",
                                  textAlign: TextAlign.center,
                                  style: smallTextStyle(color: AllColor.white),
                                ),
                              ),
                              Container(
                                width: screenWidth * 0.16,
                                child: Text(
                                  "Quantity",
                                  textAlign: TextAlign.center,
                                  style: smallTextStyle(color: AllColor.white),
                                ),
                              ),
                              Container(
                                width: screenWidth * 0.1,
                              ),
                            ],
                          ),
                        ),
                  _orderList.isEmpty
                      ? Container()
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: _orderList.length,
                          itemBuilder: (context, index) =>
                              customOrderItem(_orderList[index])),
                  textFieldHeader(AllString.remark,
                      fontWeight: FontWeight.bold),
                  Container(
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.0,
                      horizontal: screenWidth * 0.03,
                    ),
                    child: Center(
                      child: textAreaField(
                        context,
                        AllString.enterRemark,
                        _commentTextEditingController,
                        4,
                        200,
                        TextInputAction.done,
                        TextInputType.text,
                      ),
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03),
                      child: button(
                        context,
                        function: () {
                          if (validateAndProceed()) {
                            applyOrder();
                          }
                        },
                        color: !validateAndProceed()
                            ? Colors.grey
                            : AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.confirm,
                      )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  clearAllDataForAddOrder() {
    _currentDealer = _currentDealer;
    _currentCategory = AllString.select;
    _currentProduct = AllString.select;
    _productList.clear();
    _productList.add(AllString.select);
    _quentityTextEditingController.clear();
    setState(() {});
  }

  fetchProduct(String productId) {
    setState(() {
      loading = true;
    });
    _currentDealer = _currentDealer;
    _productList.clear();
    setState(() {});

    _productList.add(AllString.select);

    setState(() {});
    Navigator.pop(context);

    // loading = true;
    // setState(() {});
    // Map data = {
    //   "companyId":
    //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
    //   "divisionId": _currentCategory.split(AllString.splitText).last
    // };
    // apiPostRequestWithHeader(
    //         data, AllUrls.getModelByDivision, this.context, loginToken)
    //     .then((response) {
    //   if (response == null) {
    //     loading = false;
    //     setState(() {});
    //     commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    //   } else {
    //     Map<String, dynamic> jsonData = json.decode(response);
    //     if (checkApiResponseSuccessOrNot(jsonData)) {
    // if (jsonData["modelData"] == "" || jsonData["modelData"] == []) {
    //   _productList = [];
    // } else {
    //   List _tempList = jsonData["modelData"];
    //   _tempList.forEach((element) {
    //     _productList.add(element["modelNo"].toString() +
    //         AllString.splitText +
    //         element["productModelId"].toString());
    //   });
    // }

    // if (_productList.length == 2) {
    //   _currentProduct = _productList.last;
    // }
    // _currentDealer = _currentDealer;

    // AppBuilder.of(context)!.rebuild();
    // Future.delayed(Duration(milliseconds: 300), () {
    //   _currentDealer = _currentDealer;

    //   addOrderDialog();
    //   setState(() {
    //     loading = false;
    //   });
    // });
    //     } else {
    //       setState(() {
    //         loading = false;
    //       });
    //       commonAlertDialog(context, jsonData["status"], jsonData["message"]);
    //     }
    //   }
    // });
    if (sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            null ||
        sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            "") {
      sharedPreferences!
          .setString(AllSharedPreferencesKey.allCommonDataJson, "");
    } else {
      Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
          .getString(AllSharedPreferencesKey.allCommonDataJson)!);

      if (jsonDataForCommon["commonData"]["modelDetails"] == "" ||
          jsonDataForCommon["commonData"]["modelDetails"] == []) {
        _productList = [];
      } else {
        List _tempList = jsonDataForCommon["commonData"]["modelDetails"];

        _tempList.forEach((element) {
          if (element["productCategoryId"].toString() == productId) {
            _productList.add(element["modelNo"].toString() +
                AllString.splitText +
                element["productModelId"].toString());
          }
        });

        if (_productList.length == 2) {
          _currentProduct = _productList.last;
        }
        _currentDealer = _currentDealer;

        AppBuilder.of(context)!.rebuild();
        Future.delayed(Duration(milliseconds: 300), () {
          _currentDealer = _currentDealer;

          addOrderDialog();
          setState(() {
            loading = false;
          });
        });
      }

      // Map<String, dynamic> jsonDataForAllProduct = json.decode(
      //     sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
      // List tempListForAllProduct = jsonDataForAllProduct["data"];
      // tempListForAllProduct.forEach((element) {
      //   if (element["categoryId"].toString() == productId) {
      //     _productList.add(element["productname"].toString() +
      //         AllString.splitText +
      //         element["productId"].toString());
      //   }
      // });
    }
  }

  fetchCategory(String brandId) {
    setState(() {
      loading = true;
    });
    _currentDealer = _currentDealer;
    _categoryList.clear();
    setState(() {});

    _categoryList.add(AllString.select);

    setState(() {});
    Navigator.pop(context);

    // loading = true;
    // setState(() {});
    // Map data = {
    //   "companyId":
    //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
    //   "divisionId": _currentCategory.split(AllString.splitText).last
    // };
    // apiPostRequestWithHeader(
    //         data, AllUrls.getModelByDivision, this.context, loginToken)
    //     .then((response) {
    //   if (response == null) {
    //     loading = false;
    //     setState(() {});
    //     commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    //   } else {
    //     Map<String, dynamic> jsonData = json.decode(response);
    //     if (checkApiResponseSuccessOrNot(jsonData)) {
    // if (jsonData["modelData"] == "" || jsonData["modelData"] == []) {
    //   _productList = [];
    // } else {
    //   List _tempList = jsonData["modelData"];
    //   _tempList.forEach((element) {
    //     _productList.add(element["modelNo"].toString() +
    //         AllString.splitText +
    //         element["productModelId"].toString());
    //   });
    // }

    // if (_productList.length == 2) {
    //   _currentProduct = _productList.last;
    // }
    // _currentDealer = _currentDealer;

    // AppBuilder.of(context)!.rebuild();
    // Future.delayed(Duration(milliseconds: 300), () {
    //   _currentDealer = _currentDealer;

    //   addOrderDialog();
    //   setState(() {
    //     loading = false;
    //   });
    // });
    //     } else {
    //       setState(() {
    //         loading = false;
    //       });
    //       commonAlertDialog(context, jsonData["status"], jsonData["message"]);
    //     }
    //   }
    // });
    if (sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            null ||
        sharedPreferences!
                .getString(AllSharedPreferencesKey.allCommonDataJson) ==
            "") {
      sharedPreferences!
          .setString(AllSharedPreferencesKey.allCommonDataJson, "");
    } else {
      Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
          .getString(AllSharedPreferencesKey.allCommonDataJson)!);
      log("divisionDetailsssss " +
          jsonDataForCommon["commonData"]["divisionDetails"].toString());
      if (jsonDataForCommon["commonData"]["divisionDetails"] == "" ||
          jsonDataForCommon["commonData"]["divisionDetails"] == []) {
        _categoryList = [];
      } else {
        List _tempList = jsonDataForCommon["commonData"]["divisionDetails"];

        _tempList.forEach((element) {
          if (element["brandId"].toString() == brandId) {
            _categoryList.add(element["productCategoryName"].toString() +
                AllString.splitText +
                element["productCategoryId"].toString());
          }
        });

        if (_categoryList.length == 2) {
          _currentCategory = _categoryList.last;
        }
        _currentDealer = _currentDealer;

        AppBuilder.of(context)!.rebuild();
        Future.delayed(Duration(milliseconds: 300), () {
          _currentDealer = _currentDealer;

          addOrderDialog();
          setState(() {
            loading = false;
          });
        });
      }

      // Map<String, dynamic> jsonDataForAllProduct = json.decode(
      //     sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
      // List tempListForAllProduct = jsonDataForAllProduct["data"];
      // tempListForAllProduct.forEach((element) {
      //   if (element["categoryId"].toString() == productId) {
      //     _productList.add(element["productname"].toString() +
      //         AllString.splitText +
      //         element["productId"].toString());
      //   }
      // });
    }
  }

  customOrderItem(Map<String, dynamic> orderItem) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 3),
      decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: AllColor.greyColor))),
      margin: customMarginCardItem(),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: screenWidth * 0.005),
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: screenWidth * 0.25,
              child: Text(
                orderItem["categoryName"],
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.greyColor),
              ),
            ),
            Container(
              width: screenWidth * 0.25,
              child: Text(
                orderItem["productName"],
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.greyColor),
              ),
            ),
            Container(
              width: screenWidth * 0.16,
              child: Text(
                orderItem["quantity"].toString(),
                textAlign: TextAlign.center,
                style: smallTextStyle(color: AllColor.greyColor),
              ),
            ),
            GestureDetector(
              onTap: () {
                _orderList.remove(orderItem);
                setState(() {});
                // _orderList.forEach((element) {if(
                //   element["categoryId"].toString()==orderItem["categoryId"]){
                //   }
                // });
              },
              child: Container(
                width: screenWidth * 0.1,
                child: smallIcon(Icons.close, color: AllColor.red),
              ),
            ),
          ],
        ),
      ),
    );
  }

  addOrderDialog() {
    commonAlertDialogWithCloseButtonWithWidget(
        context,
        AllColor.red,
        Column(
          children: [
            textFieldHeader(AllString.selectBrand),
            Container(
              child: DropdownButtonWithSearchForBrandList(
                icon: LineIcons.sortAmountDown,
                selectedValue: _currentBrand,
                dropdownList: brandList,
                onChanged: (String? newValue) {
                  _currentBrand = newValue!;
                  AppBuilder.of(context)!.rebuild();
                  fetchCategory(_currentBrand.split(AllString.splitText).last);
                },
              ),
            ),
            textFieldHeader(AllString.selectCategory),
            // textFieldHeader(
            //     _currentBrand.split(AllString.splitText).last.toString()),
            Container(
              child: DropdownButtonWithSearchForLocalCategory(
                icon: LineIcons.sortAmountDown,
                selectedValue: _currentCategory,
                dropdownList: _categoryList,
                onChanged: (String? newValue) {
                  _currentCategory = newValue!;
                  AppBuilder.of(context)!.rebuild();
                  fetchProduct(
                      _currentCategory.split(AllString.splitText).last);
                },
              ),
              //     child: dropdownButton(categoryList, (String? newValue) {
              // _currentCategory = newValue!;
              // AppBuilder.of(context)!.rebuild();
              // fetchProduct(_currentCategory.split(AllString.splitText).last);
              // }, _currentCategory)
            ),
            _productList.length == 1
                ? Container()
                : textFieldHeader(AllString.selectProduct),
            _productList.length == 1
                ? Container()
                : Container(
                    child: DropdownButtonWithSearch(
                      icon: LineIcons.sortAmountDown,
                      selectedValue: _currentProduct,
                      dropdownList: _productList,
                      onChanged: (String? newValue) {
                        _currentProduct = newValue!;
                        setState(() {});
                        log(_currentProduct);
                        AppBuilder.of(context)!.rebuild();
                        Navigator.pop(context);
                        addOrderDialog();
                      },
                    ),
                    //   child: dropdownButton(_productList, (String? newValue) {
                    // _currentProduct = newValue!;
                    // setState(() {});
                    // log(_currentProduct);
                    // AppBuilder.of(context)!.rebuild();
                    // Navigator.pop(context);
                    // addOrderDialog();
                    // }, _currentProduct)
                  ),
            (_currentCategory == AllString.select || _currentCategory == "") ||
                    (_currentProduct == AllString.select ||
                        _currentProduct == "")
                ? Container()
                : textFieldHeader(AllString.enterQuantity),
            (_currentCategory == AllString.select || _currentCategory == "") ||
                    (_currentProduct == AllString.select ||
                        _currentProduct == "")
                ? Container()
                : Container(
                    child: RoundedInputField(
                    controller: _quentityTextEditingController,
                    focusNode: _quentityFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    hintText: AllString.quantity,
                    errorText: "",
                    showToolTip: false,
                    icon: LineIcons.sortNumericUp,
                    onchangeFunction: (String val) {},
                  )),
            Container(
                margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.015,
                    horizontal: screenWidth * 0.03),
                child: button(
                  context,
                  function: () {
                    if (_currentCategory == AllString.select) {
                      commonAlertDialog(
                          context, AllString.warning, "Select category");
                    }
                    if (_productList.isEmpty || _productList.length == 1) {
                      commonAlertDialog(
                          context, AllString.warning, "No product found");
                    } else if (_currentProduct == AllString.select) {
                      commonAlertDialog(
                          context, AllString.warning, "Select product");
                    } else if (_quentityTextEditingController.text.isEmpty) {
                      commonAlertDialog(
                          context, AllString.warning, "Enter quantity");
                    } else {
                      Map<String, dynamic> jsonData = {
                        "categoryId":
                            _currentCategory.split(AllString.splitText).last,
                        "categoryName":
                            _currentCategory.split(AllString.splitText).first,
                        "productId":
                            _currentProduct.split(AllString.splitText).last,
                        "brandId":
                            _currentBrand.split(AllString.splitText).last,
                        "productName":
                            _currentProduct.split(AllString.splitText).first,
                        "quantity": _quentityTextEditingController.text
                      };
                      _orderList.add(jsonData);
                      setState(() {});
                      clearAllDataForAddOrder();
                      Navigator.pop(context);
                    }
                  },
                  color: AllColor.primaryColor,
                  textColor: AllColor.white,
                  width: screenWidth - 200,
                  text: AllString.add,
                )),
          ],
        ), onCloseButtonPress: () {
      clearAllDataForAddOrder();
      // if (categoryList.length == 2) {
      //   _currentCategory = categoryList.last;
      //   setState(() {});
      //   _productList.clear();
      //   _categoryList.clear();

      //   _productList.add(AllString.select);

      //   setState(() {});
      //   Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
      //       .getString(AllSharedPreferencesKey.allCommonDataJson)!);

      //   if (jsonDataForCommon["modelDetails"] == "" ||
      //       jsonDataForCommon["modelDetails"] == []) {
      //     _productList = [];
      //   } else {
      //     List _tempList = jsonDataForCommon["modelDetails"];
      //     _tempList.forEach((element) {
      //       if (element["productCategoryId"].toString() ==
      //           _currentCategory.split(AllString.splitText).first) {
      //         _productList.add(element["modelNo"].toString() +
      //             AllString.splitText +
      //             element["productModelId"].toString());
      //       }
      //     });
      //   }

      //   // Map<String, dynamic> jsonDataForAllProduct = json.decode(
      //   //     sharedPreferences!
      //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
      //   // List tempListForAllProduct = jsonDataForAllProduct["data"];
      //   // tempListForAllProduct.forEach((element) {
      //   //   if (element["categoryId"].toString() ==
      //   //       _currentCategory.split(AllString.splitText).last) {
      //   //     _productList.add(element["productname"].toString() +
      //   //         AllString.splitText +
      //   //         element["productId"].toString());
      //   //   }
      //   // });
      //   if (_productList.length == 2) {
      //     _currentProduct = _productList.last;
      //   }
      // }

      Navigator.pop(context);
    });
  }

  applyOrder() async {
    if (await internetCheck()) {
      List _orderListForRequest = [];
      _orderList.forEach((element) {
        _orderListForRequest.add({
          "productCategoryId": element["categoryId"],
          "productId": element["productId"],
          "brandId": element["brandId"],
          "quantity": element["quantity"]
        });
        setState(() {});
      });

      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "userLoginId":
            sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        "userId": loginUserId,
        "orderDetails": [
          {
            "dealerId": _currentDealer.split(AllString.splitText).last,
            "remarks": _commentTextEditingController.text,
            "orderData": _orderListForRequest,
            "visitTypeName": _currentDealer.split(AllString.splitText).first,
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "visitType": 1,
          }
        ],
      };
      apiPostRequestWithHeader(data, AllUrls.addOrder, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Order()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      //showOfflineSnakbar(context);
      storeLocalRecordsOrder();
    }
  }

  storeLocalRecordsOrder() async {
    loading = true;
    setState(() {});

    List _orderListForRequest = [];
    String orderListIds = "";

    if (_orderList.isNotEmpty) {
      _orderList.forEach((element) {
        _orderListForRequest.add({
          "productCategoryId": element["categoryId"],
          "productId": element["productId"],
          "brandId": element["brandId"],
          "quantity": element["quantity"]
        });
        setState(() {});
      });
    }
    orderListIds = orderListIds.endsWith(",")
        ? orderListIds.substring(0, orderListIds.length - 1)
        : orderListIds;
    setState(() {});

    Map<String, dynamic> data = {
      Databasehelper.orderDealerId:
          _currentDealer.split(AllString.splitText).last,
      Databasehelper.orderRemarks: _commentTextEditingController.text,
      Databasehelper.orderVisitTypeName:
          _currentDealer.split(AllString.splitText).first,
      Databasehelper.orderIndividualId:
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      Databasehelper.orderVisitType: 1,
    };
    // ! Insert Row on Day Start and Day End Table

    AppBuilder.of(context)!.rebuild();

    final id = await dbhelper.insertOrder(data);
    var allrows = await dbhelper.fetchAllOrder();
    // log(allrows.toString());
    // log(_orderListForRequest.toString());

    if (_orderListForRequest.isNotEmpty) {
      _orderListForRequest.forEach((element) async {
        Map<String, dynamic> rowForCheckOutOrder = {
          Databasehelper.checkOutIdOrOrderId: id.toString() + "_Order",
          Databasehelper.productCategoryId: element["productCategoryId"],
          Databasehelper.productId: element["productId"],
          Databasehelper.brandId: element["brandId"],
          Databasehelper.quantity: element["quantity"]
        };
        setState(() {});
        final orderIdOrdersListId =
            await dbhelper.insertOrderSubList(rowForCheckOutOrder);
        // log(orderIdOrdersListId.toString());
        // log( "OrderElement: "+rowForCheckOutOrder.toString());
      });
    }
    allrows.forEach((element) async {
      // log(element.toString());
      var allOrderOrderRows = await dbhelper
          .fetchAllOrderSubList(element["id"].toString() + "_Order");
      log(allOrderOrderRows.toString());
    });

    commonAlertDialog(context, AllString.success, "Apply Order Successfully",
        function: () async {
      AppBuilder.of(context)!.rebuild();
      setState(() {
        loading = false;
      });
      Navigator.of(context)
          .pushReplacement(CupertinoPageRoute(builder: (context) => Order()));
      setState(() {});
    });
  }

  offlineUploadOrderData() async {
    setState(() {
      loading = true;
    });

    if (await internetCheck()) {
      // var alldbrows = await dbhelper.fetchAllOrder();
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        // "breakData": alldbrows,
      };
      log(data.toString());
    }
  }

  bool validateAndProceed() {
    if (_currentDealer == AllString.select) {
      return false;

      // commonAlertDialog(
      //     context, AllString.warning, "Select dealer");
    } else if (_orderList.isEmpty) {
      return false;

      // commonAlertDialog(
      //     context, AllString.warning, "Add order");
    } else {
      return true;
    }
  }

  setDropDownValueByDefaultUponCondition() {
    if (dealerList.length == 2) {
      _currentDealer = dealerList.last;
    }
    if (brandList.length == 2) {
      _currentBrand = brandList.last;

      Map<String, dynamic> jsonDataForCommon = json.decode(sharedPreferences!
          .getString(AllSharedPreferencesKey.allCommonDataJson)!);
      if (jsonDataForCommon["commonData"]["divisionDetails"] == "" ||
          jsonDataForCommon["commonData"]["divisionDetails"] == []) {
        _categoryList = [];
      } else {
        List _tempList = jsonDataForCommon["commonData"]["divisionDetails"];
        _tempList.forEach((element) {
          if (element["brandId"].toString() ==
              _currentBrand.split(AllString.splitText).last) {
            _categoryList.add(element["productCategoryName"].toString() +
                AllString.splitText +
                element["productCategoryId"].toString());
          }
        });

        if (_categoryList.length == 2) {
          _currentCategory = _categoryList.last;
        }
      }
    }
    // if (categoryList.length == 2) {
    //   _currentCategory = categoryList.last;
    //   setState(() {});
    //   _productList.clear();

    //   _productList.add(AllString.select);

    //   setState(() {});

    //   // Map<String, dynamic> jsonDataForAllProduct = json.decode(
    //   //     sharedPreferences!
    //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
    //   // List tempListForAllProduct = json.decode(
    //   //     sharedPreferences!
    //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
    //   // tempListForAllProduct.forEach((element) {
    //   //   if (element["divisionName"].toString() ==
    //   //       _currentCategory.split(AllString.splitText).first) {
    //   //     _productList.add(element["modelNo"].toString() +
    //   //         AllString.splitText +
    //   //         element["productModelId"].toString());
    //   //   }
    //   // });
    //   // Map<String, dynamic> jsonDataForAllProduct = json.decode(
    //   //     sharedPreferences!
    //   //         .getString(AllSharedPreferencesKey.allProductJson)!);
    //   // List tempListForAllProduct = jsonDataForAllProduct["data"];
    //   // tempListForAllProduct.forEach((element) {
    //   //   if (element["categoryId"].toString() ==
    //   //       _currentCategory.split(AllString.splitText).last) {
    //   //     _productList.add(element["productname"].toString() +
    //   //         AllString.splitText +
    //   //         element["productId"].toString());
    //   //   }
    //   // });
    //   if (_productList.length == 2) {
    //     _currentProduct = _productList.last;
    //   }
    // }

//     if(expenseTypeList.length==2){
// _currentExpenseType=expenseTypeList.last;
//     }
    setState(() {});
  }
}
