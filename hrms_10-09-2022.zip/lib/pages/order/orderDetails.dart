import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/fromToDatePickerButton.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class OrderDetails extends StatefulWidget {
  final List productList;
  final String dealerName;
  final String remarks;
  final String date;
  const OrderDetails(
      {Key? key,
      required this.productList,
      required this.date,
      required this.dealerName,
      required this.remarks})
      : super(key: key);
  @override
  _OrderDetailsState createState() => _OrderDetailsState();
}

class _OrderDetailsState extends State<OrderDetails> {
  bool loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.orderDetails),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
            decoration: customBackgroundGradient(),
            child: Stack(
              children: [
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Container(
                    decoration: BoxDecoration(
                        border:
                            Border(bottom: BorderSide(color: AllColor.black))),
                    padding: EdgeInsets.all(1),
                    margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.03,
                        vertical: screenWidth * 0.01),
                    child: Container(
                      decoration: BoxDecoration(
                          color: AllColor.white,
                          borderRadius: BorderRadius.circular(10)),
                      width: screenWidth,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              customRowDetails(
                                  width: screenWidth * 0.65,
                                  widthTitle: screenWidth * 0.23,
                                  title: "Dealer Name",
                                  value: widget.dealerName),
                              customRowDetails(
                                  width: screenWidth * 0.65,
                                  widthTitle: screenWidth * 0.23,
                                  title: "Remarks",
                                  value: widget.remarks),
                              customRowDetails(
                                  width: screenWidth * 0.65,
                                  widthTitle: screenWidth * 0.23,
                                  title: "Date",
                                  value: convertStringToDate(
                                      DateTime.parse(widget.date))),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  subtitle: Container(
                    child: widget.productList.isEmpty
                        ? commonNoDataFound()
                        : ListView.builder(
                            padding:
                                EdgeInsets.only(bottom: screenWidth * 0.25),
                            physics: BouncingScrollPhysics(),
                            itemCount: widget.productList.length,
                            itemBuilder: (context, index) => customListItem(
                                widget.productList[index], index)),
                  ),
                )
              ],
            ),
          ),
        ));
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
        padding: customHorizontal(),
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                // customRowDetails(
                //     width: screenWidth * 0.8,
                //     widthTitle: screenWidth * 0.25,

                //     title: "Order Id",
                //     value: itemData["orderId"].toString()),
                customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.25,
                    title: "Pro. Category",
                    value: itemData["productCategoryName"].toString()),
                customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.25,
                    title: "Pro. Name",
                    value: itemData["modelNo"].toString()),
                customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.25,
                    title: "Quantity",
                    value: itemData["quantity"].toString()),
                // customRowDetails(
                //     width: screenWidth * 0.8,
                //     widthTitle: screenWidth * 0.25,
                //     title: "Remark",
                //     value: checkApiValueValid(itemData["remarks"].toString())
                //         ? AllString.na
                //         : itemData["remarks"].toString()),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
