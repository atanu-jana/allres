import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/services.dart';
import 'package:hr/api/apiPostRequest.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/rounded_password_field.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/authtication/forgotPassword.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/res/allUrls.dart';
import 'package:platform_device_id/platform_device_id.dart';

import 'dart:math' as math;

import 'package:responsive_builder/responsive_builder.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';

class SignIn extends StatefulWidget {
  const SignIn({Key? key}) : super(key: key);

  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  //TODO: App Declaration Here
  RoundedLoadingButtonController _btnController =
      RoundedLoadingButtonController();
  FocusNode _passwordfocusNode = FocusNode();
  FocusNode _companyfocusNode = FocusNode();
  TextEditingController _usernameTextEditingController =
      TextEditingController();
  TextEditingController _passwordTextEditingController =
      TextEditingController();
  FocusNode _usernameFocusNode = FocusNode();
  DateTime backButtonPressTime = DateTime.now();
  static const snackBarDuration = Duration(seconds: 3);
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final snackBar = SnackBar(
    content: Text('Press back again to leave'),
    duration: snackBarDuration,
  );

  bool loading = false;
  bool _usernameShowToolTip = false;
  bool _passwordShowToolTip = false;
  String _usernameErrorText = "";
  String _passwordErrorText = "";
  String? _deviceId;
  @override
  void initState() {
    super.initState();
    initPlatformState();
    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);

    // if (loginUsername != null || loginUsername != "") {
    //   _usernameTextEditingController.text =
    //       sharedPreferences!.getString(AllSharedPreferencesKey.us) ?? "";
    // }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var deviceType = getDeviceType(MediaQuery.of(context).size);
    screenWidth = MediaQuery.of(context).size.width;
    screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AllColor.white,
      body:
//       ScreenTypeLayout(
//   breakpoints: ScreenBreakpoints(
//     tablet: 600,
//     desktop: 950,
//     watch: 300
//   ),
//   mobile: Container(color:Colors.blue)
//   tablet: Container(color: Colors.yellow),
//   desktop: Container(color: Colors.red),
//   watch: Container(color: Colors.purple),
// );
          WillPopScope(
              onWillPop: () => handleWillPop(context),
              child: LoadingOverlay(
                  isLoading: loading,
                  opacity: 0.5,
                  color: AllColor.black,
                  progressIndicator: commonLoader(),
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    child: Container(
                      width: screenWidth,
                      height: screenHeight - 100,
                      color: AllColor.white,
                      margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.05,
                      ),
                      alignment: Alignment.center,
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(
                              height: getValueForScreenType<double>(
                                context: context,
                                mobile: screenHeight * 0.05,
                                tablet: screenHeight * 0.0,
                                desktop: screenHeight * 0.0,
                              ),
                            ),
                            Container(
                              height: screenHeight * 0.3,
                              width: screenHeight * 0.3,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  // boxShadow: [
                                  //   BoxShadow(
                                  //     color: AllColor.black.withOpacity(0.3),
                                  //     spreadRadius: 3,
                                  //     blurRadius: 5,
                                  //     offset: Offset(0, 3),
                                  //   ),
                                  // ],
                                  color: AllColor.white,
                                  borderRadius: BorderRadius.circular(15)),
                              child: Image.asset(
                                "assets/images/logo.png",
                                width: screenWidth * 0.3,
                                height: screenWidth * 0.3,
                              ),
                            ),
                            Center(
                              child: Container(
                                child: RoundedInputField(
                                  focusNode: _usernameFocusNode,
                                  maxLength: 30,
                                  controller: _usernameTextEditingController,
                                  hintText: AllString.userName,
                                  icon: Icons.person,
                                  textInputAction: TextInputAction.next,
                                  textInputType: TextInputType.text,
                                  showToolTip: _usernameShowToolTip,
                                  onchangeFunction: (val) {},
                                  errorText: _usernameErrorText,
                                ),
                              ),
                            ),
                            RoundedPasswordField(
                              hintText: AllString.password,
                              focusNode: _passwordfocusNode,
                              iconData: Icons.lock,
                              textInputAction: TextInputAction.next,
                              controller: _passwordTextEditingController,
                              onchangeFunction: (val) {},
                              errorText: _passwordErrorText,
                              showToolTip: _passwordShowToolTip,
                            ),
                            SizedBox(
                              height: screenWidth * 0.05,
                            ),
                            button(
                              context,
                              textColor: AllColor.white,
                              function: () async {
                                // var allrows = await dbhelper.queryall();
                                // log("1: " + allrows.length.toString());
                                // var allrows2 = await dbhelper.queryall2();
                                // log("2: " + allrows2.length.toString());
                                // if (allrows.isEmpty) {
                                // Map<String, dynamic> row = {
                                //   Handler.latitude: "",
                                //   Handler.longitude: "",
                                //   Handler.location: "",
                                //   Handler.currentTime: DateTime.now()
                                //       .millisecondsSinceEpoch
                                //       .toString(),
                                //   Handler.dayStartDayEndUniqueId:
                                //       rng.nextInt(100).toString(),
                                // };
                                // final id = await dbhelper.insert2(row);
                                // final id2 = await dbhelper.insert(row);
                                // log("id: " + id.toString());
                                // log("id2: " + id2.toString());
                                // } else {

                                // }
                                // Navigator.of(context).pushReplacement(
                                //     CupertinoPageRoute(
                                //         builder: (context) => Home()));

                                ///////---------------------------
                                if (_usernameTextEditingController
                                    .text.isEmpty) {
                                  commonAlertDialog(context, AllString.warning,
                                      AllString.usernameEmptyToastString);
                                } else if (_passwordTextEditingController
                                    .text.isEmpty) {
                                  commonAlertDialog(context, AllString.warning,
                                      AllString.passwordEmptyToastString);
                                } else {
                                  userLogin();
                                }
                                // _btnController.start();
                                // Timer(Duration(seconds: 3), () {
                                //   _btnController.success();
                                // });
                              },
                              btnController: _btnController,
                              text: AllString.login,
                             color: AllColor.primaryColor
                            ),
                            // customAnimatedButton(
                            //   context,
                            //   textColor: AllColor.white,
                            //   function: (_) async {
                            //     // var allrows = await dbhelper.queryall();
                            //     // log("1: " + allrows.length.toString());
                            //     // var allrows2 = await dbhelper.queryall2();
                            //     // log("2: " + allrows2.length.toString());
                            //     // if (allrows.isEmpty) {
                            //     // Map<String, dynamic> row = {
                            //     //   Handler.latitude: "",
                            //     //   Handler.longitude: "",
                            //     //   Handler.location: "",
                            //     //   Handler.currentTime: DateTime.now()
                            //     //       .millisecondsSinceEpoch
                            //     //       .toString(),
                            //     //   Handler.dayStartDayEndUniqueId:
                            //     //       rng.nextInt(100).toString(),
                            //     // };
                            //     // final id = await dbhelper.insert2(row);
                            //     // final id2 = await dbhelper.insert(row);
                            //     // log("id: " + id.toString());
                            //     // log("id2: " + id2.toString());
                            //     // } else {

                            //     // }
                            //     // Navigator.of(context).pushReplacement(
                            //     //     CupertinoPageRoute(
                            //     //         builder: (context) => Home()));
                            //     if (_usernameTextEditingController
                            //         .text.isEmpty) {
                            //       commonAlertDialog(context, AllString.warning,
                            //           AllString.usernameEmptyToastString);
                            //     } else if (_passwordTextEditingController
                            //         .text.isEmpty) {
                            //       commonAlertDialog(context, AllString.warning,
                            //           AllString.passwordEmptyToastString);
                            //     } else if (_companyTextEditingController
                            //         .text.isEmpty) {
                            //       commonAlertDialog(context, AllString.warning,
                            //           AllString.companyIdEmptyToastString);
                            //     } else {
                            //       userLogin();
                            //     }
                            //   },
                            //   text: AllString.login,
                            //   color: AllColor.primaryColor,
                            //   deepColor: AllColor.primaryDeepColor,
                            //   width: screenWidth * 0.5,
                            // ),
                            SizedBox(height: screenHeight * 0.05),
                            Container(
                                height: screenWidth * 0.05,
                                width: screenWidth,
                                alignment: Alignment.center,
                                child: smallText(
                                    AllString.versionNameWithVersion,
                                    color: AllColor.greyColor))
                          ]),
                    ),
                  ))),
    );
  }

  //TODO: App methos Here
  userLogin() async {
    if (await internetCheck()) {
      loading = true;
      setState(() {});
      Map data = {
        "userName": _usernameTextEditingController.text.toString(),
        "password": _passwordTextEditingController.text.toString(),
        "deviceId": _deviceId,
      };
      apiPostRequest(data, AllUrls.hrmsLoginPost, this.context)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure,
              function: () {
            setState(() {
              _passwordTextEditingController.text = "";
              _passwordfocusNode.requestFocus();
            });
            Navigator.pop(context);
          });
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            log(jsonData.toString());
            loginCompanyId = sharedPreferences!.getString(
                  AllSharedPreferencesKey.companyId,
                ) ??
                "";

            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyId,
                jsonData["userData"]["companyId"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyId"].toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyName,
                jsonData["userData"]["companyName"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyName"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyContactNo,
                jsonData["userData"]["companyContactNo"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyContactNo"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyEmailId,
                jsonData["userData"]["companyEmailId"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyEmailId"].toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyAddress,
                jsonData["userData"]["companyAddress"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyAddress"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.district,
                jsonData["userData"]["district"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["district"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyPincode,
                jsonData["userData"]["companyPincode"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyPincode"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.userId,
                jsonData["userData"]["userId"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["userId"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.firstName,
                jsonData["userData"]["firstName"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["firstName"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.branchName,
                jsonData["userData"]["branchName"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["branchName"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.branchId,
                jsonData["userData"]["branchId"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["branchId"].toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.userType,
                jsonData["userData"]["userType"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["userType"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.userTypeId,
                jsonData["userData"]["userTypeId"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["userTypeId"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.companyLogo,
                jsonData["userData"]["companyLogo"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["companyLogo"].toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.token,
                jsonData["userData"]["token"].toString() == "null"
                    ? ""
                    : jsonData["userData"]["token"].toString());

            AppBuilder.of(context)!.rebuild();

            loginToken = sharedPreferences!.getString(
                  AllSharedPreferencesKey.token,
                ) ??
                "";

            loginUserId = sharedPreferences!.getString(
                  AllSharedPreferencesKey.userId,
                ) ??
                "";
            loginIndivisualId = sharedPreferences!.getString(
                  AllSharedPreferencesKey.individualTypeId,
                ) ??
                "";

            loading = true;
            setState(() {});
            Map data = {
              "companyId": sharedPreferences!
                  .getString(AllSharedPreferencesKey.companyId)!,
              "userId": loginUserId,
            };
            apiPostRequestWithHeader(data, AllUrls.getEmployeeProfileDetails,
                    this.context, loginToken)
                .then((response) {
              if (response == null) {
                loading = false;
                setState(() {});
                commonAlertDialog(
                    context, AllString.warning ,AllString.connectionFailure);
              } else {
                Map<String, dynamic> jsonDataForDetails = json.decode(response);
                if (checkApiResponseSuccessOrNot(jsonDataForDetails)) {
                  log(checkApiResponseForArray(
                          jsonDataForDetails, "employeeData")
                      .toString());
                  if (checkApiResponseForArray(
                      jsonDataForDetails, "employeeData")) {
                    if (jsonDataForDetails["employeeData"]["visitDetails"] ==
                            "" ||
                        jsonDataForDetails["employeeData"]["visitDetails"]
                            .isEmpty) {
                      sharedPreferences!
                          .setString(AllSharedPreferencesKey.checkInId, "");
                      sharedPreferences!.setString(
                          AllSharedPreferencesKey.checkInOptionNameWithId, "");
                      sharedPreferences!.setString(
                          AllSharedPreferencesKey.checkInOptionName, "");
                      sharedPreferences!
                          .setString(AllSharedPreferencesKey.checkInOption, "");
                    } else {
                      sharedPreferences!.setString(
                          AllSharedPreferencesKey.checkInId,
                          jsonDataForDetails["employeeData"]["visitDetails"][0]
                                              ["employeeVisitId"]
                                          .toString() ==
                                      "null" ||
                                  jsonDataForDetails["employeeData"]
                                                  ["visitDetails"][0]
                                              ["employeeVisitId"]
                                          .toString() ==
                                      "0"
                              ? ""
                              : jsonDataForDetails["employeeData"]
                                      ["visitDetails"][0]["employeeVisitId"]
                                  .toString());
                      sharedPreferences!.setString(
                          AllSharedPreferencesKey.checkInOptionNameWithId,
                          jsonDataForDetails["employeeData"]["visitDetails"][0]
                                              ["dealerId"]
                                          .toString() ==
                                      "null" ||
                                  jsonDataForDetails["employeeData"]
                                              ["visitDetails"][0]["dealerId"]
                                          .toString() ==
                                      "0"
                              ? ""
                              : jsonDataForDetails["employeeData"]
                                      ["visitDetails"][0]["dealerId"]
                                  .toString());
                      sharedPreferences!.setString(
                          AllSharedPreferencesKey.checkInOptionName,
                          jsonDataForDetails["employeeData"]["visitDetails"][0]
                                          ["visitTypeName"]
                                      .toString() ==
                                  "null"
                              ? ""
                              : jsonDataForDetails["employeeData"]
                                      ["visitDetails"][0]["visitTypeName"]
                                  .toString());

                      sharedPreferences!.setString(
                          AllSharedPreferencesKey.checkInOption,
                          jsonDataForDetails["employeeData"]["visitDetails"][0]["visitType"]
                                          .toString() ==
                                      "null" ||
                                  jsonDataForDetails["employeeData"]
                                              ["visitDetails"][0]["visitType"]
                                          .toString() ==
                                      "0"
                              ? ""
                              : jsonDataForDetails["employeeData"]
                                              ["visitDetails"][0]["visitType"]
                                          .toString() ==
                                      "1"
                                  ? AllString.dealer
                                  : jsonDataForDetails["employeeData"]["visitDetails"]
                                                  [0]["visitType"]
                                              .toString() ==
                                          "2"
                                      ? AllString.office
                                      : jsonDataForDetails["employeeData"]
                                                      ["visitDetails"][0]["visitType"]
                                                  .toString() ==
                                              "3"
                                          ? AllString.others
                                          : "");
                    }

                    if (jsonDataForDetails["employeeData"]
                                    ["employeeLastDistance"]
                                .toString() ==
                            "null" ||
                        jsonDataForDetails["employeeData"]
                                    ["employeeLastDistance"]
                                .toString() ==
                            "") {
                      sharedPreferences!.setDouble(
                          AllSharedPreferencesKey.positionForSend, 0.0);
                    } else {
                      sharedPreferences!.setDouble(
                          AllSharedPreferencesKey.positionForSend,
                          double.parse(jsonDataForDetails["employeeData"]
                                  ["employeeLastDistance"]
                              .toString()));
                    }
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.sendLatitude,
                        jsonDataForDetails["employeeData"]["checkInLatitude"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["checkInLatitude"]
                                .toString());

                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.sendLongitude,
                        jsonDataForDetails["employeeData"]["checkInLongitude"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["checkInLongitude"]
                                .toString());
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.breakPunchId,
                        jsonDataForDetails["employeeData"]["breakStatus"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]["breakStatus"]
                                .toString());
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.punchInId,
                        jsonDataForDetails["employeeData"]["attendanceId"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]["attendanceId"]
                                .toString());

                    log(sharedPreferences!
                        .getString(AllSharedPreferencesKey.punchInId)!);

                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.userRoleName,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualType"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["individualType"]
                                .toString());

                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.individualId,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualId"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["individualId"]
                                .toString());

                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.individualTypeId,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualTypeId"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["individualTypeId"]
                                .toString());

                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.image,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualImage"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["individualImage"]
                                .toString());
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.address,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualAddress"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["individualAddress"]
                                .toString());
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.contact1,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualContactNo1"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                        ["employeeDetails"][0]
                                    ["individualContactNo1"]
                                .toString());
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.contact2,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["individualContactNo2"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                        ["employeeDetails"][0]
                                    ["individualContactNo2"]
                                .toString());
                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.dob,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["dateOfBirth"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["dateOfBirth"]
                                .toString());

                    sharedPreferences!.setString(
                        AllSharedPreferencesKey.email,
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                        ["personalEmail"]
                                    .toString() ==
                                "null"
                            ? ""
                            : jsonDataForDetails["employeeData"]
                                    ["employeeDetails"][0]["personalEmail"]
                                .toString());

                    loginToken = sharedPreferences!.getString(
                          AllSharedPreferencesKey.token,
                        ) ??
                        "";

                    loginUserId = sharedPreferences!.getString(
                          AllSharedPreferencesKey.userId,
                        ) ??
                        "";
                    loginIndivisualId = sharedPreferences!.getString(
                          AllSharedPreferencesKey.individualTypeId,
                        ) ??
                        "";
                    AppBuilder.of(context)!.rebuild();
                    Future.delayed(Duration(seconds: 2), () {
                      setState(() {
                        loading = false;
                      });
                      Navigator.of(context).pushReplacement(
                          CupertinoPageRoute(builder: (context) => Home()));
                      // commonAlertDialog(
                      //     context, jsonData["status"], jsonData["message"],
                      //     function: () {
                      //   Navigator.of(context).pushReplacement(
                      //       CupertinoPageRoute(builder: (context) => Home()));
                      // });
                    });
                    setState(() {
                      loading = false;
                    });
                  } else {
                    setState(() {
                      loading = false;
                    });
                    commonAlertDialog(
                        context, jsonData["status"], jsonData["message"]);
                  }
                } else {
                  setState(() {
                    loading = false;
                  });
                  commonAlertDialog(
                      context, jsonData["status"], jsonData["message"]);
                }
              }
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> initPlatformState() async {
    String? deviceId;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      deviceId = await PlatformDeviceId.getDeviceId;
      log("deviceId: " + deviceId.toString());
    } on PlatformException {
      deviceId = 'Failed to get deviceId.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      _deviceId = deviceId;
      //print("deviceId->$_deviceId");
    });
  }

  Future<bool> handleWillPop(BuildContext context) async {
    final now = DateTime.now();
    final backButtonHasNotBeenPressedOrSnackBarHasBeenClosed =
        backButtonPressTime == null ||
            now.difference(backButtonPressTime) > snackBarDuration;

    if (backButtonHasNotBeenPressedOrSnackBarHasBeenClosed) {
      backButtonPressTime = now;
      _scaffoldKey.currentState!.showSnackBar(snackBar);
      return false;
    } else {
      SystemNavigator.pop();
      return true;
    }
  }
}
