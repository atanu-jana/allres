// import 'dart:async';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:easeurbizceo/common/common.dart';
// import 'package:easeurbizceo/common/rounded_input_field.dart';
// import 'package:easeurbizceo/common/rounded_password_field.dart';
// import 'package:easeurbizceo/main.dart';
// import 'package:easeurbizceo/pages/authtication/signIn.dart';
// import 'package:easeurbizceo/res/allColors.dart';
// import 'package:easeurbizceo/res/allSharePreferencesKey.dart';
// import 'package:easeurbizceo/res/allString.dart';
// import 'package:easeurbizceo/res/allUrls.dart';
// import 'dart:convert';

// class ForgotPassword extends StatefulWidget {
//   @override
//   _ForgotPasswordState createState() => _ForgotPasswordState();
// }

// class _ForgotPasswordState extends State<ForgotPassword> {
//   //TODO: App Declaration Here
//   TextEditingController _otpTextEditingController = TextEditingController();
//   bool verifyOTP = false;
//   bool submitNumberForVerifyOTP = false;
//   String otpString = "";
//   bool otpSendSuccessfully = false;
//   FocusNode _otpFocusNode = FocusNode();
//   FocusNode _numberFocusNode = FocusNode();
//   FocusNode _passwordfocusNode = FocusNode();
//   FocusNode _cPasswordfocusNode = FocusNode();
//   TextEditingController _passwordTextEditingController =
//       TextEditingController();
//   TextEditingController _cPasswordTextEditingController =
//       TextEditingController();
//   static const snackBarDuration = Duration(seconds: 3);
//   final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
//   final snackBar = SnackBar(
//     content: Text('Press back again to leave'),
//     duration: snackBarDuration,
//   );
//   int otpTimer = 60;

//   DateTime? backButtonPressTime;
//   TextEditingController _numberTextEditingController = TextEditingController();
//   bool obscureText = true;
//   bool loading = false;
//   String _numberErrorText = "";
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     if (loginPatientUserMobileNumber != null ||
//         loginPatientUserMobileNumber != "") {
//       _numberTextEditingController.text = sharedPreferences!
//               .getString(AllSharedPreferencesKey.primaryNumberSave) ??
//           "";
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     screenHeight = MediaQuery.of(context).size.height;
//     screenWidth = MediaQuery.of(context).size.width;
//     return Scaffold(
//       backgroundColor: AllColor.white,

//       // onPressed: () => Navigator.pop(context))),
//       body: WillPopScope(
//         onWillPop: () async {
//           AllString.selectedPage = AllString.dashboard;
//           AllString.currentPage = AllString.dashboard;
//           AppBuilder.of(context)!.rebuild();
//           Navigator.pushReplacement(
//               context, CupertinoPageRoute(builder: (context) => SignIn()));
//           return true;
//         },
//         child: LoadingOverlay(
//           isLoading: loading,
//           // demo of some additional parameters
//           opacity: 0.1,
//           color: AllColor.primaryAlphaColor,
//           progressIndicator: loaderFadingCudeRed(),
//           child: Container(
//             width: screenWidth,
//             height: screenHeight,
//             child: Stack(
//               alignment: Alignment.center,
//               children: <Widget>[
//                 Positioned(
//                   top: 45,
//                   child: Text(
//                     AllString.forgotPasswordHeader,
//                     style: TextStyle(
//                         fontSize: screenWidth * 0.045, color: AllColor.black),
//                   ),
//                 ),
//                 Positioned(
//                     top: -30,
//                     left: -30,
//                     child: Container(
//                       width: screenWidth * 0.4,
//                       height: screenWidth * 0.4,
//                       decoration: BoxDecoration(
//                           color: AllColor.primaryAlphaColor,
//                           borderRadius: BorderRadius.circular(10000)),
//                     )),
//                 Positioned(
//                   bottom: -60,
//                   right: -60,
//                   child: Container(
//                     width: screenWidth * 0.4,
//                     height: screenWidth * 0.4,
//                     decoration: BoxDecoration(
//                         color: AllColor.accentColor.withOpacity(0.5),
//                         borderRadius: BorderRadius.circular(10000)),
//                   ),
//                 ),
//                 SingleChildScrollView(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: <Widget>[
//                       Image.asset(
//                         "assets/images/logo.png",
//                         width: screenWidth * 0.4,
//                         height: screenWidth * 0.4,
//                       ),
//                       SizedBox(height: screenHeight * 0.05),
//                       submitNumberForVerifyOTP
//                           ? RoundedInputField(
//                               focusNode: _otpFocusNode,
//                               onchangeFunction: (String val) {},
//                               errorText: '',
//                               maxLength: 6,
//                               controller: _otpTextEditingController,
//                               hintText: AllString.oTP,
//                               icon: FontAwesomeIcons.sms,
//                               textInputAction: TextInputAction.done,
//                               textInputType: TextInputType.number,
//                             )
//                           : verifyOTP
//                               ? RoundedPasswordField(
//                                   hintText: AllString.password,
//                                   focusNode: _passwordfocusNode,
//                                   textInputAction: TextInputAction.next,
//                                   controller: _passwordTextEditingController,
//                                 )
//                               : RoundedInputField(
//                                   focusNode: _numberFocusNode,
//                                   onchangeFunction: (String val) {
//                                     if (val.isEmpty) {
//                                       _numberErrorText = "";
//                                       setState(() {});
//                                     } else if (val.length <= 9 &&
//                                         val.isNotEmpty) {
//                                       _numberErrorText = AllString
//                                           .mobileNumberSmallToastString;
//                                       setState(() {});
//                                     } else {
//                                       _numberErrorText = "";
//                                       setState(() {});
//                                     }
//                                   },
//                                   errorText: _numberErrorText,
//                                   maxLength: 10,
//                                   controller: _numberTextEditingController,
//                                   hintText: AllString.mobileNumber,
//                                   icon: FontAwesomeIcons.phoneAlt,
//                                   textInputAction: TextInputAction.done,
//                                   textInputType: TextInputType.number,
//                                 ),
//                       submitNumberForVerifyOTP
//                           ? Container(
//                               margin: EdgeInsets.only(top: screenWidth * 0.01),
//                               alignment: Alignment.centerRight,
//                               width: screenWidth * 0.65,
//                               child: GestureDetector(
//                                 onTap: () =>
//                                     otpSendSuccessfully ? print("") : getOtp(),
//                                 child: lightText(
//                                     otpSendSuccessfully
//                                         ? otpTimer.toString() + " s"
//                                         : AllString.resendOtp,
//                                     color: AllColor.greyColor),
//                               ),
//                             )
//                           : Container(),
//                       // verifyOTP
//                       //     ? Container()
//                       //     : RoundedDropDownButton(
//                       //         controller: _pTitleTextEditingController,
//                       //       ),
//                       verifyOTP
//                           ? RoundedPasswordField(
//                               hintText: AllString.cPassword,
//                               focusNode: _cPasswordfocusNode,
//                               textInputAction: TextInputAction.done,
//                               controller: _cPasswordTextEditingController,
//                             )
//                           : Container(),
//                       submitNumberForVerifyOTP
//                           ? Container()
//                           : SizedBox(height: screenHeight * 0.03),

//                       submitNumberForVerifyOTP
//                           ? customButton(
//                               context,
//                               textColor: AllColor.white,
//                               function: () {
//                                 if (_otpTextEditingController.text.isEmpty) {
//                                   commonAlertDialog(context, AllString.warning,
//                                       AllString.pleaseEnterOTP);
//                                 } else {
//                                   verifyOTPForSignUp();
//                                 }
//                               },
//                               text: AllString.submit, // TODO: Verify otp button
//                               color: AllColor.primaryColor,
//                               width: screenWidth * 0.4,
//                             )
//                           : verifyOTP
//                               ? customButton(
//                                   context,
//                                   textColor: AllColor.white,
//                                   function: () {
//                                     if (_passwordTextEditingController
//                                         .text.isEmpty) {
//                                       commonAlertDialog(
//                                           context,
//                                           AllString.warning,
//                                           AllString.passwordEmptyToastString);
//                                     } else if (_cPasswordTextEditingController
//                                         .text.isEmpty) {
//                                       commonAlertDialog(
//                                           context,
//                                           AllString.warning,
//                                           AllString.cpasswordEmptyToastString);
//                                     } else {
//                                       callPasswordChange();
//                                     }
//                                   },
//                                   text: AllString.changePassword,
//                                   color: AllColor.primaryColor,
//                                   width: screenWidth * 0.5,
//                                 )
//                               : customButton(
//                                   context,
//                                   textColor: AllColor.white,
//                                   function: () {
//                                     if (_numberTextEditingController
//                                         .text.isEmpty) {
//                                       commonAlertDialog(
//                                           context,
//                                           AllString.warning,
//                                           AllString
//                                               .mobileNumberEmptyToastString);
//                                     } else {
//                                       getOtp();
//                                     }
//                                   },
//                                   text: AllString.submit,
//                                   color: AllColor.primaryColor,
//                                   width: screenWidth * 0.5,
//                                 ),
//                       Container(
//                           margin: EdgeInsets.symmetric(
//                               vertical: screenWidth * 0.02),
//                           padding: EdgeInsets.symmetric(
//                             horizontal: 20,
//                           ),
//                           width: screenWidth * 0.8,
//                           alignment: Alignment.center,
//                           child: GestureDetector(
//                             child: normalText(
//                               AllString.moveToLogin,
//                               color: AllColor.primaryColor,
//                             ),
//                             onTap: () => Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                 builder: (context) {
//                                   return SignIn();
//                                 },
//                               ),
//                             ),
//                           ))
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//   //TODO: App methos Here

//   getOtp() async {
//     setState(() {
//       loading = true;
//       otpTimer = 60;
//       otpSendSuccessfully = false;
//     });

//     Map data = {
//       "RBAuthKey": rBAuthKey,
//       "mobile_n": _numberTextEditingController.text.toString()
//     };
//     commonApiPostRequest(
//             data, AllUrls.otpGeneretionUrl_post, this.context, this.loading)
//         .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(
//               context, AllString.warning ,AllString.connectionFailure,
//               function: () {
//             Navigator.pop(context);
//           });
//         } else  if (response.statusCode == 200) {
//         otpSendSuccessfully = true;
//         setState(() {});
//         const oneSec = Duration(seconds: 1);

//         Timer.periodic(oneSec, (Timer t) {
//           if (otpTimer <= 0) {
//             otpSendSuccessfully = false;
//             setState(() {});
//             t.cancel();
//           } else {
//             otpTimer = otpTimer - 1;
//             setState(() {});
//           }
//         });
//         setState(() {
//           loading = false;

//           submitNumberForVerifyOTP = true;
//         });
//         Map<String, dynamic> jsonData = json.decode(response.body);
//         otpString = jsonData["OTP"];
//         // print(response.body);
//         commonAlertDialog(context, AllString.success, otpString);

//         setState(() {});
//       } else {
//         otpSendSuccessfully = false;
//         setState(() {
//           loading = false;

//           submitNumberForVerifyOTP = false;
//         });
//         commonAlertDialog(
//             context, AllString.error, AllString.oTPGenerationFailed);
//       }
//     });
//   }

//   //TODO: App methos Here
//   verifyOTPForSignUp() async {
//     if (otpString == _otpTextEditingController.text) {
//       setState(() {
//         verifyOTP = true;
//         submitNumberForVerifyOTP = false;
//         otpTimer = 0;
//       });
//     } else {
//       commonAlertDialog(context, AllString.error, AllString.invalidOTP);
//     }
//     // setState(() {
//     //   sendOTP = true;
//     // });
//   }

//   callPasswordChange() async {
//     if (_passwordTextEditingController.text ==
//         _cPasswordTextEditingController.text) {
//       Map data = {
//         "RBAuthKey": rBAuthKey,
//         "user_id": sharedPreferences!.getString(
//               AllSharedPreferencesKey.userId,
//             ) ??
//             "",
//         "Pat_status": "0",
//         "Password": _passwordTextEditingController.text
//       };
//       commonApiPostRequest(
//               data, AllUrls.changePwdUrl_post, this.context, this.loading)
//           .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(
//               context, AllString.warning ,AllString.connectionFailure,
//               function: () {
//             Navigator.pop(context);
//           });
//         } else if (response.statusCode == 200) {
//           Map<String, dynamic> jsonData = json.decode(response.body);
//           print(response.body);
//           sharedPreferences!.setString(
//               AllSharedPreferencesKey.userId, jsonData["user_id"] ?? "");

//           commonAlertDialog(
//               context, AllString.alert, AllString.changePasswordSuccessfully,
//               function: () {
//             Navigator.of(context).pushReplacement(
//                 CupertinoPageRoute(builder: (context) => SignIn()));
//           });
//           setState(() {});
//         } else {
//           commonAlertDialog(
//               context, AllString.error, AllString.changePasswordFailed);
//         }
//       });
//     } else {
//       commonAlertDialog(context, AllString.error, AllString.passwordDonotMatch);
//     }
//   }
// }
