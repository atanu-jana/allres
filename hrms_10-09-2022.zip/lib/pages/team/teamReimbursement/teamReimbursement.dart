import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/team/teamReimbursement/teamReimbursmentDetails.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamReimbursement extends StatefulWidget {
  const TeamReimbursement({
    Key? key,
  }) : super(key: key);
  @override
  _TeamReimbursementState createState() => _TeamReimbursementState();
}

class _TeamReimbursementState extends State<TeamReimbursement> {
  bool loading = false;
  List _teamReimbursement = [];
  @override
  void initState() {
    super.initState();
    fetchReimbursement();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.reimbursement),
      body: LoadingOverlay(

  isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                  decoration:customBackgroundGradient(),

          child: Stack(
            children: [
              ListView.builder(
                  padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                  physics: BouncingScrollPhysics(),
                  itemCount: _teamReimbursement.length,
                  itemBuilder: (context, index) =>
                      customReimbursementItem(_teamReimbursement[index])),
            ],
          ),
        ),
      ),
    );
  }

  customReimbursementItem(Map<String, dynamic> itemData) {
    return GestureDetector(
      onTap: () {
        if (itemData["ReviewFirstLevelStatus"] == "Rejected" ||
            itemData["ReviewFirstLevelStatus"] == "Pending") {
        } else {
          Navigator.push(
              context,
              CupertinoPageRoute(
                  builder: (context) => TeamReimbursmentDetails(
                        singleData: itemData,
                      )));
        }
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        height: screenWidth >= 600 ? screenWidth * 0.38 : screenWidth * 0.45,
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.27,
                      title: "Applied On",
                      value: convertStringToDate(DateTime.now())),
                   customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.27,
                      title: "Time",
                      value: itemData["ReimbursementTime"]),
                   customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.27,
                      title: "Status",
                      value: itemData["ReviewFirstLevelStatus"]),
                   customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.27,
                      title: "Loan Amount",
                      value: AllString.rs + " " + itemData["ReimbursementAmount"]),
                 
           
           
                  Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
                    width: screenWidth * 0.78,
                    child: Column(
                      children: [
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: (screenWidth * 0.78),
                              height: screenWidth * 0.01,
                              color: AllColor.greyColor,
                            ),
                            Container(
                              width: (screenWidth * 0.78),
                              height: screenWidth * 0.01,
                              alignment: Alignment.centerLeft,
                              color: AllColor.greyColor,
                              child: Container(
                                // width: (screenWidth * 0.38) ,
                                width: itemData["ReviewFirstLevelStatus"] ==
                                        "Pending"
                                    ? screenWidth * 0.38
                                    : itemData["ReviewFirstLevelStatus"] ==
                                            "Approved"
                                        ? screenWidth * 0.38
                                        : itemData["ReviewFirstLevelStatus"] ==
                                                "Rejected"
                                            ? screenWidth * 0.38
                                            : screenWidth * 0.0,
                                height: screenWidth * 0.01,
                                color: AllColor.green,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(1000),
                                    color: AllColor.green,
                                  ),
                                  width: screenWidth * 0.05,
                                  height: screenWidth * 0.05,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(1000),
                                    color: itemData["ReviewFirstLevelStatus"] ==
                                            "Approved"
                                        ? AllColor.green
                                        : itemData["ReviewFirstLevelStatus"] ==
                                                "Rejected"
                                            ? AllColor.red
                                            : AllColor.greyColor,
                                  ),
                                  width: screenWidth * 0.05,
                                  height: screenWidth * 0.05,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(1000),
                                    color: AllColor.greyColor,
                                  ),
                                  width: screenWidth * 0.05,
                                  height: screenWidth * 0.05,
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            extraSmallText(
                              "Request",
                              color: AllColor.greyColor,
                            ),
                            extraSmallText(
                              "( P.M. ) " + itemData["ReviewFirstLevelStatus"],
                              color: AllColor.greyColor,
                            ),
                            extraSmallText(
                              // "Approved",
                              "",
                              color: AllColor.greyColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
              itemData["ReviewFirstLevelStatus"] == "Rejected" ||
                      itemData["ReviewFirstLevelStatus"] == "Pending"
                  ? Container()
                  : Container(
                      child: smallIcon(Icons.arrow_forward_ios_outlined,
                          color: AllColor.greyColor))
            ],
          ),
        ),
      ),
    );
  }

  fetchReimbursement() async {
    var jsonData = json.decode(await rootBundle
        .loadString('assets/json/HrViewReimbursmentListData.json'));
    _teamReimbursement = jsonData["ReimbursementListData"];
    setState(() {});
  }
}
