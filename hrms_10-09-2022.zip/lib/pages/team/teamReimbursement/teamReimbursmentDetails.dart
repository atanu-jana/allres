import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamReimbursmentDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;

  const TeamReimbursmentDetails({Key? key,
  required this.singleData
  }) : super(key: key);
  @override
  _TeamReimbursmentDetailsState createState() => _TeamReimbursmentDetailsState();
}

class _TeamReimbursmentDetailsState extends State<TeamReimbursmentDetails> {
  bool loading = false;
  List _teamReimbursmentDetailsList = [];
  String remark = "";
  TextEditingController _commentTextEditingController = TextEditingController();


  @override
  void initState() {
    super.initState();
    fetchReimbursmentDetails();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.reimbursementBreakupDetails),
      body: LoadingOverlay(
       
  isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                  decoration:customBackgroundGradient(),

          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                margin: EdgeInsets.only(bottom: screenWidth * 0.015),
                height: screenWidth * 0.12,
             
                decoration: BoxDecoration(
                    color: AllColor.tableBackground,
                    // border: Border(
                    //     bottom: BorderSide(
                    //   color: AllColor.black,
                    // ))
                    ),
                width: screenWidth,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.27,
                      child: Text(
                        "Requested \n Date",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.25,
                      child: Text(
                        "Requested\nAmount",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.15,
                      child: Text(
                        "Reason",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: screenWidth * 0.25,
                      child: Text(
                        "Approve\nAmount",
                        textAlign: TextAlign.center,
                        style: smallTextStyle(color: AllColor.white),
                      ),
                    ),
                  ],
                ),
              ),
              ListView.builder(
                  shrinkWrap: true,
                  padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                  physics: BouncingScrollPhysics(),
                  itemCount: _teamReimbursmentDetailsList.length,
                  itemBuilder: (context, index) =>
                      customTeamReimbursmentDetailsItem(
                          _teamReimbursmentDetailsList[index], index)),
              Divider(),
              Container(
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.0),
                alignment: Alignment.centerLeft,
                child: normalText("Remarks:",
                    color: AllColor.black),
              ),
              Container(
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                width: screenWidth,
                padding: EdgeInsets.all(7),
                height: screenWidth * 0.3,
                decoration: BoxDecoration(
                    color: AllColor.white,
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(color: AllColor.black, width: 2)),
                alignment: Alignment.topLeft,
                child: normalText(remark, color: AllColor.black),
              ),
               Column(
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: screenWidth * 0.015,
                        horizontal: screenWidth * 0.03,
                      ),
                      child: Center(
                        child: textAreaField(
                          context,
                          AllString.comment + "*",
                          _commentTextEditingController,
                          4,
                          200,
                          TextInputAction.done,
                          TextInputType.text,
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        MaterialButton(
                          height: screenWidth * 0.08,
                          onPressed: () {},
                          color: AllColor.lightBlack,
                          child: normalText(
                            AllString.approved,
                            color: AllColor.black,
                          ),
                          splashColor: AllColor.green,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10000),
                              side: BorderSide(color: AllColor.green)),
                        ),
                        MaterialButton(
                          height: screenWidth * 0.08,
                          color: AllColor.lightBlack,
                          onPressed: () {},
                          child: normalText(
                            AllString.rejected,
                            color: AllColor.black,
                          ),
                          splashColor: AllColor.red,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10000),
                              side: BorderSide(color: AllColor.red)),
                        ),
                        MaterialButton(
                          height: screenWidth * 0.08,
                          onPressed: () {},
                          color: AllColor.lightBlack,
                          child: normalText(
                            AllString.cancel,
                            color: AllColor.black,
                          ),
                          splashColor: AllColor.primaryColor,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10000),
                              side: BorderSide(color: AllColor.primaryColor)),
                        ),
                      ],
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  customTeamReimbursmentDetailsItem(Map<String, dynamic> itemData, int i) {
    return Container(
      height: screenWidth * 0.1,
    
      color: i % 2 != 0 ? AllColor.lightBlueGrey : AllColor.white,
      width: screenWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.27,
            child: Text(
              convertStringToDate(DateTime.now()),
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.25,
            child: Text(
              AllString.rs + " " + itemData["RequestAmount"],
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.15,
            child: Text(
              itemData["Reason"],
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: screenWidth * 0.25,
            child: Text(
              AllString.rs + " " + itemData["ApproveAmount"],
              textAlign: TextAlign.center,
              style: normalTextStyle(color: AllColor.black),
            ),
          ),
        ],
      ),
    );
  }

  fetchReimbursmentDetails() async {
    var jsonData = json.decode(await rootBundle
        .loadString('assets/json/ReimbursementDetailData.json'));
    log(jsonData.toString());
    remark = jsonData["Remarks"];
    _teamReimbursmentDetailsList = jsonData["ReimbursementDetailData"];
    setState(() {});
  }
}
