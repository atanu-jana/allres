import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/conveyance/conveyanceDetails.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpenseBody.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentBody.dart';
import 'package:hr/pages/order/orderDetails.dart';
import 'package:hr/pages/payment/paymentDetails.dart';
import 'package:hr/pages/publicHoliday/publicHolidayBody.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamDashboard/teamDashboard.dart';
import 'package:hr/pages/visitHistory/visitHistoryDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customCatender.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamReports extends StatefulWidget {
  const TeamReports({
    Key? key,
  }) : super(key: key);
  @override
  _TeamReportsState createState() => _TeamReportsState();
}

class _TeamReportsState extends State<TeamReports> {
  bool loading = false;
  int tabbedIndex = 0;
  List<String> _teamMemberList = [];
  String _selectTeamMember = AllString.select;
  List _expenseList = [];
  DateTime _expenseSelectedDate = DateTime.now();

  List _visitHistoryList = [];
  DateTime _visitSelectedDate = DateTime.now();
  List _orderList = [];
  DateTime _orderSelectedDate = DateTime.now();

  List _paymentList = [];
  DateTime _paymentSelectedDate = DateTime.now();

  // List _conveyanceList = [];
  // DateTime _conveyanceSelectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    fetchMemberList();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.push(
            context, CupertinoPageRoute(builder: (context) => TeamDashboard()));
        return true;
      },
      child: DefaultTabController(
        length: 4,
        child: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Scaffold(
            appBar: AppBar(
              brightness: Brightness.dark,
              toolbarHeight: screenWidth * 0.28,
              elevation: 0,
              backgroundColor: AllColor.primaryColor,
              centerTitle: true,
              title: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    child: Text(AllString.reports,
                        textAlign: TextAlign.center,
                        style: headingTextStyle(color: AllColor.white)),
                  ),
                  // Container(
                  //   child: Text(
                  //       checkApiValueValid(singleTeamMember["individualName"])
                  //           ? AllString.na
                  //           : singleTeamMember["individualName"],
                  //       textAlign: TextAlign.center,
                  //       style: extraSmallTextStyle(color: AllColor.white)),
                  // ),
                  Container(
                    width: screenWidth,
                    child: Container(
                      child: DropdownButtonWithSearch(
                        icon: LineIcons.sortAmountDown,
                        selectedValue: _selectTeamMember,
                        dropdownList: _teamMemberList,
                        onChanged: onTeamMemberChanged,
                        whiteTheme: true,
                      ),
                      // child: dropdownButton(
                      //     teamMemberList,
                      //     onTeamMemberChanged,
                      //     selectTeamMember)),
                    ),
                  ),
                ],
              ),
              leading: IconButton(
                  icon: Center(
                    child: Icon(
                      Icons.arrow_back,
                      color: AllColor.white,
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => TeamDashboard()));
                  }),
              bottom: TabBar(
                onTap: (int index) {
                  tabbedIndex = index;
                  setState(() {});
                  log(tabbedIndex.toString());
                  callApiForTabBarAction(index);
                },
                isScrollable: true,
                indicatorColor: AllColor.yellow,
                tabs: [
                  Tab(
                    child: normalText(AllString.order,
                        color: tabbedIndex == 0
                            ? AllColor.yellow
                            : AllColor.white.withOpacity(0.7)),
                  ),
                  Tab(
                    child: normalText(AllString.payment,
                        color: tabbedIndex == 1
                            ? AllColor.yellow
                            : AllColor.white.withOpacity(0.7)),
                  ),
                  Tab(
                    child: normalText(AllString.expense,
                        color: tabbedIndex == 2
                            ? AllColor.yellow
                            : AllColor.white.withOpacity(0.7)),
                  ),
                  Tab(
                    child: normalText(AllString.visitHistory,
                        color: tabbedIndex == 3
                            ? AllColor.yellow
                            : AllColor.white.withOpacity(0.7)),
                  ),
                  // Tab(
                  //   child: normalText(AllString.conveyance,
                  //       color: tabbedIndex == 3
                  //           ? AllColor.yellow
                  //           : AllColor.white.withOpacity(0.7)),
                  // ),
                ],
              ),
            ),
            body: loading
                ? Container()
                : TabBarView(
                    physics: NeverScrollableScrollPhysics(),
                    children: [
                      orderView(),
                      paymentView(),
                      expenseView(),
                      visitView(),
                      // conveynenceView()
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  onTeamMemberChanged(String? value) {
    _selectTeamMember = value!;
    setState(() {});
    if (tabbedIndex == 0) {
      fetchOrder();
    } else if (tabbedIndex == 1) {
      fetchPayment();
    } else if (tabbedIndex == 2) {
      fetchReimbursement();
    } else if (tabbedIndex == 3) {
      fetchVisitHistory();
    }
  }

  fetchVisitHistory() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "dealerId": "",
        "individualName": "",
        "individualId": _selectTeamMember.split(AllString.splitText).last,
        "fromDate": formatterForRequest.format(_visitSelectedDate).toString(),
        "toDate": formatterForRequest.format(_visitSelectedDate).toString(),
        "userId": "",
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getVisitDetails, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _visitHistoryList.clear();

            // List  _orderListTemp = jsonData["visitData"];
            //   _orderList =_orderListTemp.reversed.toList();
            if (jsonData["visitData"] == "") {
              _visitHistoryList = [];
            } else {
              _visitHistoryList = jsonData["visitData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // Widget conveynenceView() {
  //   return Container(
  //     width: screenWidth,
  //     height: screenHeight,
  //                        decoration:customBackgroundGradient(),

  //     child: Stack(
  //       children: [
  //         Container(
  //           margin: EdgeInsets.only(top: screenWidth * 0.13),
  //           child: _conveyanceList.isEmpty
  //               ? commonNoDataFound()
  //               : ListView.builder(
  //                   padding: EdgeInsets.only(bottom: screenWidth * 0.03),
  //                   physics: BouncingScrollPhysics(),
  //                   itemCount: _conveyanceList.length,
  //                   itemBuilder: (context, index) =>
  //                       _conveyenceTile(_conveyanceList[index], index)),
  //         ),
  //         Positioned(
  //             top: screenWidth * 0.01,
  //             right: screenWidth * 0.05,
  //             left: screenWidth * 0.05,
  //             child: Row(
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               crossAxisAlignment: CrossAxisAlignment.center,
  //               children: [
  //                 Container(
  //                   child: normalText(AllString.selectDate + ": ",
  //                       color: AllColor.black),
  //                 ),
  //                 datePickerButton(
  //                     context, _conveyanceSelectedDate, Icons.calendar_today,
  //                     () {
  //                   selectDate(context, _conveyanceSelectedDate).then((value) {
  //                     _conveyanceSelectedDate = value;
  //                     setState(() {});
  //                     log(_conveyanceSelectedDate.toString());
  //                     fetchConveyance();
  //                   });
  //                 }),
  //               ],
  //             )),
  //       ],
  //     ),
  //   );
  // }

  // _conveyenceTile(Map<String, dynamic> itemData, int index) {
  //   return GestureDetector(
  //     onTap: () {
  //       Navigator.of(context).push(CupertinoPageRoute(
  //           builder: (context) => ConveyanceDetails(
  //                 singleData: itemData,
  //                 visible: true,
  //                 callBack: () {
  //                   Navigator.push(
  //                       context,
  //                       CupertinoPageRoute(
  //                           builder: (context) => TeamReports()));
  //                 },
  //               )));
  //     },
  //     child: Container(
  //       padding: EdgeInsets.all(1),
  //       decoration: customCardItemGradinet(),
  //       margin: EdgeInsets.symmetric(
  //           horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
  //       child: Container(
  //         decoration: BoxDecoration(
  //             color: AllColor.white, borderRadius: BorderRadius.circular(10)),
  //         width: screenWidth,
  //         child: Row(
  //           mainAxisSize: MainAxisSize.min,
  //           children: [
  //             calendarCard(
  //                 screenWidth * 0.23,
  //                 screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
  //                 screenWidth * 0.18,
  //                 DateTime.parse(itemData["createdDate"])),
  //             Column(
  //               crossAxisAlignment: CrossAxisAlignment.center,
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               mainAxisSize: MainAxisSize.min,
  //               children: [
  //                 customRowDetails(
  //                     width: screenWidth * 0.65,
  //                     widthTitle: screenWidth * 0.23,
  //                     title: "Dealer Name",
  //                     value: itemData["dealername"]),
  //                 customRowDetails(
  //                     width: screenWidth * 0.65,
  //                     widthTitle: screenWidth * 0.23,
  //                     title: "Remark",
  //                     value: checkApiValueValid(itemData["remarks"])
  //                         ? AllString.na
  //                         : itemData["remarks"].toString()),
  //                 customRowDetails(
  //                     width: screenWidth * 0.65,
  //                     widthTitle: screenWidth * 0.23,
  //                     title: "Amount",
  //                     value: AllString.rs + itemData["amount"].toString()),
  //                 customRowDetails(
  //                     width: screenWidth * 0.65,
  //                     widthTitle: screenWidth * 0.23,
  //                     title: "Status",
  //                     value: itemData["reviewStatus"].toString() == "0"
  //                         ? "Pending By Team Manager"
  //                         : itemData["reviewStatus"].toString() == "1"
  //                             ? "Rejected By Team Manager"
  //                             : itemData["reviewStatus"].toString() == "2"
  //                                 ? "Approved By Team Manager"
  //                                 : itemData["reviewStatus"].toString() == "3"
  //                                     ? "Rejected By HR"
  //                                     : itemData["reviewStatus"].toString() ==
  //                                             "4"
  //                                         ? "Approved By HR"
  //                                         : ""),
  //               ],
  //             ),
  //             listDetailsClickedArrow()
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }

  Widget paymentView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
                             decoration:customBackgroundGradient(),

      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.only(top: screenWidth * 0.13),
            child: _paymentList.isEmpty
                ? commonNoDataFound()
                : ListView.builder(
                    padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                    physics: BouncingScrollPhysics(),
                    itemCount: _paymentList.length,
                    itemBuilder: (context, index) =>
                        _paymentTile(_paymentList[index], index)),
          ),
          Positioned(
              top: screenWidth * 0.01,
              right: screenWidth * 0.05,
              left: screenWidth * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    child: normalText(AllString.selectDate + ": ",
                        color: AllColor.black),
                  ),
                  datePickerButton(
                      context, _paymentSelectedDate, Icons.calendar_today, () {
                    selectDate(context, _paymentSelectedDate).then((value) {
                      _paymentSelectedDate = value;
                      setState(() {});
                      log(_paymentSelectedDate.toString());
                      fetchPayment();
                    });
                  }),
                ],
              )),
        ],
      ),
    );
  }

  _paymentTile(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => PaymentDetails(
                  singleData: itemData,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => TeamReports()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Dealer Name",
                      value: itemData["dealerName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Remark",
                      value: checkApiValueValid(itemData["remarks"])
                          ? AllString.na
                          : itemData["remarks"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Amount",
                      value:
                          AllString.rs + itemData["paymentAmount"].toString()),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  Widget orderView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
                        decoration:customBackgroundGradient(),

      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.only(top: screenWidth * 0.13),
            child: _orderList.isEmpty
                ? commonNoDataFound()
                : ListView.builder(
                    padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                    physics: BouncingScrollPhysics(),
                    itemCount: _orderList.length,
                    itemBuilder: (context, index) =>
                        _orderTile(_orderList[index], index)),
          ),
          Positioned(
              top: screenWidth * 0.01,
              right: screenWidth * 0.05,
              left: screenWidth * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    child: normalText(AllString.selectDate + ": ",
                        color: AllColor.black),
                  ),
                  datePickerButton(
                      context, _orderSelectedDate, Icons.calendar_today, () {
                    selectDate(context, _orderSelectedDate).then((value) {
                      _orderSelectedDate = value;
                      setState(() {});
                      log(_orderSelectedDate.toString());
                      fetchOrder();
                    });
                  }),
                ],
              )),
        ],
      ),
    );
  }

  _orderTile(Map<String, dynamic> itemData, int index) {
    List _productList = [];
    if (itemData["orderDetails"] == "") {
      _productList = [];
    } else {
      _productList = itemData["orderDetails"];
    }
    String _orderId = "";
    _productList.forEach((element) {
      _orderId += element["orderId"].toString();
      if (_productList.last["orderId"] != element["orderId"]) _orderId += " / ";
    });
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => OrderDetails(
                  productList: _productList,
                  date: itemData["createdDate"],
                  dealerName: itemData["dealerName"].toString(),
                  remarks: itemData["orderComment"].toString(),
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "OrderNo",
                      value: itemData["orderNo"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Dealer Name",
                      value: itemData["dealerName"].toString()),
                ],
              ),
              _productList.isEmpty ? Container() : listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  Widget expenseView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
                        decoration:customBackgroundGradient(),

      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.only(top: screenWidth * 0.13),
            child: _expenseList.isEmpty
                ? commonNoDataFound()
                : ListView.builder(
                    padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                    physics: BouncingScrollPhysics(),
                    itemCount: _expenseList.length,
                    itemBuilder: (context, index) =>
                        _expenseTile(_expenseList[index], index)),
          ),
          Positioned(
              top: screenWidth * 0.01,
              right: screenWidth * 0.05,
              left: screenWidth * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    child: normalText(AllString.selectDate + ": ",
                        color: AllColor.black),
                  ),
                  datePickerButton(
                      context, _expenseSelectedDate, Icons.calendar_today, () {
                    selectDate(context, _expenseSelectedDate).then((value) {
                      _expenseSelectedDate = value;
                      setState(() {});
                      log(_expenseSelectedDate.toString());
                      fetchReimbursement();
                    });
                  }),
                ],
              )),
        ],
      ),
    );
  }

  Widget visitView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
                        decoration:customBackgroundGradient(),

      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.only(top: screenWidth * 0.13),
            child: _visitHistoryList.isEmpty
                ? commonNoDataFound()
                : ListView.builder(
                    padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                    physics: BouncingScrollPhysics(),
                    itemCount: _visitHistoryList.length,
                    itemBuilder: (context, index) =>
                        _visitTile(_visitHistoryList[index], index)),
          ),
          Positioned(
              top: screenWidth * 0.01,
              right: screenWidth * 0.05,
              left: screenWidth * 0.05,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    child: normalText(AllString.selectDate + ": ",
                        color: AllColor.black),
                  ),
                  datePickerButton(
                      context, _visitSelectedDate, Icons.calendar_today, () {
                    selectDate(context, _visitSelectedDate).then((value) {
                      _visitSelectedDate = value;
                      setState(() {});
                      log(_visitSelectedDate.toString());
                      fetchVisitHistory();
                    });
                  }),
                ],
              )),
        ],
      ),
    );
  }

  _visitTile(Map<String, dynamic> itemData, int index) {
    List orderList = [];
    if (itemData["orderDetails"] == "") {
      orderList = [];
    } else {
      orderList = itemData["orderDetails"];
    }
    List paymentList = [];
    if (itemData["paymentDetails"] == "") {
      paymentList = [];
    } else {
      paymentList = itemData["paymentDetails"];
    }
    List expenceDetails = [];
    if (itemData["expenceDetails"] == "") {
      expenceDetails = [];
    } else {
      expenceDetails = itemData["expenceDetails"];
    }
    // String _orderId = "";
    // _productList.forEach((element) {
    //   _orderId += element["orderId"].toString();
    //   if (_productList.last["orderId"] != element["orderId"]) _orderId += " / ";
    // });
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => VisitHistoryDetails(
                  orderList: orderList,
                  paymentList: paymentList,
                  expenceDetails: expenceDetails,
                  singleJsonData: itemData,
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // customRowDetails(
                  //     width: screenWidth * 0.65,
                  //     widthTitle: screenWidth * 0.23,
                  //     title: "OrderNo",
                  //     value: itemData["orderNo"]),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Visitor Name",
                      value: itemData["visitTypeName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Visitor Type",
                      value: itemData["visitType"].toString() == "1"
                          ? "Dealer"
                          : itemData["visitType"].toString() == "2"
                              ? "Office"
                              : "Other"),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  _expenseTile(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => MyExpenseDetails(
                  singleData: itemData,
                  visible: true,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => TeamReports()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Exp. Type",
                      value: itemData["expenceTypeName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Amount",
                      value: AllString.rs +
                          " " +
                          itemData["claimAmount"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Comment",
                      value: itemData["claimComment"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Status",
                      value: itemData["reviewStatus"].toString() == "0"
                          // ? "Pending ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                          ? "Pending By Team Manager"
                          : itemData["reviewStatus"].toString() == "1"
                              // ? "Rejected ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                              ? "Rejected By Team Manager"
                              : itemData["reviewStatus"].toString() == "2"
                                  // ? "Approved ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
                                  ? "Approved By Team Manager"
                                  : itemData["reviewStatus"].toString() == "3"
                                      ? "Rejected By HR"
                                      : itemData["reviewStatus"].toString() ==
                                              "4"
                                          ? "Approved By HR"
                                          : ""),
                  // customRowDetails(
                  //     width: screenWidth * 0.6,
                  //     widthTitle: screenWidth * 0.15,
                  //     title: "Status",
                  //     value: itemData["Status"]),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchReimbursement() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "expenceTypeId": "",
        // "individualId": singleTeamMember["individualId"],
        "individualId": _selectTeamMember.split(AllString.splitText).last,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "fromDate": formatterForRequest.format(_expenseSelectedDate).toString(),
        "toDate": formatterForRequest.format(_expenseSelectedDate).toString(),
        "userId": singleTeamMember["userId"],
        "dealerId": "",
      };
      apiPostRequestWithHeader(
              data, AllUrls.getExpencelist, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _expenseList.clear();

            if (jsonData["expenceData"] == "") {
              _expenseList = [];
            } else {
              _expenseList = jsonData["expenceData"];
            }
            // fetchOrder();

            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  fetchMemberList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(data, AllUrls.memberList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _teamMemberList.clear();
          _teamMemberList.add(AllString.select);

          if (jsonData["data"]["particularMember"].isEmpty ||
              jsonData["data"]["particularMember"].toString() == "") {
            _teamMemberList.clear();
          } else {
            List _tempList = jsonData["data"]["particularMember"];
            _tempList.forEach((element) {
              if (singleTeamMember["individualId"].toString() ==
                  element["individualId"].toString()) {
                _selectTeamMember = element["individualName"].toString() +
                    AllString.splitText +
                    element["individualId"].toString();
              }
              if (element["individualId"].toString() ==
                  sharedPreferences!
                      .getString(AllSharedPreferencesKey.individualId)!) {
              } else {
                _teamMemberList.add(element["individualName"].toString() +
                    AllString.splitText +
                    element["individualId"].toString());
              }
              setState(() {});
            });
          }

          fetchOrder();
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchOrder() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
        "dealerId": "",
        // "individualId": singleTeamMember["individualId"],
        "individualId": _selectTeamMember.split(AllString.splitText).last,
        "date": _orderSelectedDate.toString(),
        "userId": singleTeamMember["userId"],
      };
      apiPostRequestWithHeader(
              data, AllUrls.getOrderList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _orderList.clear();

            if (jsonData["orderData"] == "") {
              _orderList = [];
            } else {
              _orderList = jsonData["orderData"];
            }
            // fetchPayment();
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  fetchPayment() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "userId": singleTeamMember["userId"],
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        // "individualId": singleTeamMember["individualId"],
        "individualId": _selectTeamMember.split(AllString.splitText).last,

        "fromDate": formatterForRequest.format(_paymentSelectedDate).toString(),
        "toDate": formatterForRequest.format(_paymentSelectedDate).toString(),
        "amount": "",
        "date": ""
      };
      apiPostRequestWithHeader(
              data, AllUrls.getPaymentlist, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _paymentList.clear();
            if (jsonData["expenceData"] == "") {
              _paymentList = [];
            } else {
              _paymentList = jsonData["expenceData"];
            }
            // fetchConveyance();
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // fetchConveyance() async {
  //   if (await internetCheck()) {
  //     setState(() {
  //       loading = true;
  //     });
  //     Map data = {
  //       "dealerId": 0,
  //       "userId": singleTeamMember["userId"],
  //       "date": _conveyanceSelectedDate.toString(),
  //     };
  //     apiPostRequestWithHeader(
  //             data, AllUrls.conveyanceListByIdPost, this.context, loginToken)
  //         .then((response) {
  //       if (response == null) {
  //         loading = false;
  //         setState(() {});
  //         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
  //       } else {
  //         Map<String, dynamic> jsonData = json.decode(response);
  //         if (checkApiResponseSuccessOrNot(jsonData)) {
  //           _conveyanceList.clear();

  //           _conveyanceList = jsonData["data"];
  //           setState(() {
  //             loading = false;
  //           });
  //         } else {
  //           setState(() {
  //             loading = false;
  //           });
  //           commonAlertDialog(context, jsonData["status"], jsonData["message"]);
  //         }
  //       }
  //     });
  //   } else {
  //     showOfflineSnakbar(context);
  //   }
  // }

  callApiForTabBarAction(int index) {
    if (index == 0) {
      // ! Call Order
      if (_orderList.isEmpty) {
        fetchOrder();
      }
    } else if (index == 1) {
      // ! Call Payment
      if (_paymentList.isEmpty) {
        fetchPayment();
      }
    } else if (index == 2) {
      // ! Call Expense
      if (_expenseList.isEmpty) {
        fetchReimbursement();
      }
    } else if (index == 3) {
      fetchVisitHistory();
    }
    //  else if (index == 3) {
    //   // ! Call Conveyance
    //   if (_conveyanceList.isEmpty) {
    //     fetchConveyance();
    //   }
    // }
  }
}
