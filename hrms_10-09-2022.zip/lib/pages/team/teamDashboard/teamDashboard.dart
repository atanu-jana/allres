import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/team/personalProfile/personalProfile.dart';
import 'package:hr/pages/team/ratePerformance/teammyPerformance.dart';
import 'package:hr/pages/team/team.dart';
import 'package:hr/pages/team/teamAttendance/teamAttendance.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamKRASchedule.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamKraAndKpi.dart';
import 'package:hr/pages/team/teamLeave/teamLeave.dart';
import 'package:hr/pages/team/teamLoan/teamLoan.dart';
import 'package:hr/pages/team/teamReports/teamReports.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/widget/customAppBar.dart';

// class TeamDashboard extends StatefulWidget {
//   final Map<String, dynamic> profileData;
//   const TeamDashboard({Key? key, required this.profileData}) : super(key: key);

//   @override
//   _TeamDashboardState createState() =>
//       _TeamDashboardState(profileData: this.profileData);
// }

// class _TeamDashboardState extends State<TeamDashboard> {
//   Map<String, dynamic> profileData;
//   _TeamDashboardState({required this.profileData});
class TeamDashboard extends StatefulWidget {
  const TeamDashboard({
    Key? key,
  }) : super(key: key);

  @override
  _TeamDashboardState createState() => _TeamDashboardState();
}

class _TeamDashboardState extends State<TeamDashboard> {
  List<Color> color = [
    Color(0xffcfd8dc),
    Color(0xffd7ccc8),
    Color(0xffffccbc),
    Color(0xffffecb3),
    Color(0xffc8e6c9),
    Color(0xffb2ebf2),
    Color(0xffbbdefb),
    Color(0xffc5cae9),
    Color(0xffd1c4e9),
    Color(0xffe1bee7),
    Color(0xfff8bbd0),
    Color(0xffffcdd2),
  ];
  Random random = new Random();
  String _configSetting = "";
  @override
  void initState() {
    super.initState();
    _configSetting = sharedPreferences!
        .getString(AllSharedPreferencesKey.userConfigSetting)!;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => Team()));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.teamProfile, onBackPress: () {
          Navigator.of(context)
              .push(CupertinoPageRoute(builder: (context) => Team()));
        }),
        body: Container(
          height: screenHeight,
          width: screenWidth,
          decoration: customBackgroundGradient(),
          child: Stack(
            children: [
              ClipPath(
                clipper:
                    CustomShape(), // this is my own class which extendsCustomClipper
                child: Container(
                    // height: screenWidth * 0.555,
                    height: screenHeight / 2.7,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment(-5, 1),
                            end: Alignment(0, 0),
                            colors: [
                          Color.fromRGBO(0, 212, 255, 1),
                          Color.fromRGBO(2, 0, 36, 1)
                          // Color.fromRGBO(9, 9, 121, 1),
                          // Color.fromRGBO(9, 9, 121, 1),
                          // Color.fromRGBO(0, 212, 255, 1)
                        ]))),
              ),
              Positioned(
                top: screenWidth * 0.03,
                child: Column(
                  children: [
                    profileCard(),
                    Container(
                        width: screenWidth - 50,
                        margin: EdgeInsets.only(
                          top: 5,
                          bottom: 5,
                        ),
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AllColor.lightGrey)),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            smallText(AllString.lastUpdate,
                                color: AllColor.green),
                            SizedBox(
                              height: screenWidth * 0.01,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  child: smallIcon(FontAwesomeIcons.clock,
                                      color: AllColor.amber),
                                ),
                                Container(
                                  child: smallText(
                                      checkApiValueValid(
                                              singleTeamMember["lastTime"])
                                          ? AllString.na
                                          : convertStringToDate(DateTime.parse(
                                              singleTeamMember["lastTime"])),
                                      color: AllColor.greyColor),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: screenWidth * 0.01,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  child: smallIcon(Icons.location_on,
                                      color: AllColor.indigo),
                                ),
                                Container(
                                    width: screenWidth - 100,
                                    child: Text(
                                      checkApiValueValid(
                                              singleTeamMember["lastLocation"])
                                          ? AllString.na
                                          : singleTeamMember["lastLocation"]
                                              .toString(),
                                      maxLines: 3,
                                      textAlign: TextAlign.justify,
                                      style: extraSmallTextStyle(
                                          color: AllColor.greyColor),
                                    )),
                              ],
                            ),
                          ],
                        ))
                  ],
                ),
              ),
              _configSetting == "null"
                  ? Container()
                  : _configSetting == "Both"
                      ? bothConfigView()
                      : _configSetting == "OnlyHrModule"
                          ? onlyHRConfigView()
                          : _configSetting == "OnlySalesManApp"
                              ? onlySalesManConfigView()
                              : Container(),
            ],
          ),
        ),
      ),
    );
  }

  bothConfigView() {
    return Positioned(
      top: screenWidth * 1.05,
      child: Column(
        children: [
          Container(
            width: screenWidth,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      customDashboardButton(
                          AllString.profile, Icons.person_outline, () {
                        Navigator.of(context).push(CupertinoPageRoute(
                            builder: (context) => PersonalProfile()));
                      }, color[random.nextInt(10)]),
                      customDashboardButton(
                          AllString.attendance, Icons.calendar_today_outlined,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamAttendance()));
                      }, color[random.nextInt(12)]),
                      customDashboardButton(AllString.reports, Icons.report,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamReports()));
                      }, color[random.nextInt(12)]),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      customDashboardButton(
                          AllString.loan, Icons.attach_money_outlined, () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamLoan()));
                      }, color[random.nextInt(12)]),
                      customDashboardButton(
                          AllString.leave, Icons.nearby_error_outlined, () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamLeave()));
                      }, color[random.nextInt(12)]),
                      customDashboardButton(
                          AllString.kraKpi, Icons.stacked_line_chart_outlined,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamKRASchedule()));
                      }, color[random.nextInt(12)]),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      customDashboardButton(AllString.ratePerformance,
                          Icons.book_online, () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamMyPerformance()));
                      }, color[random.nextInt(12)]),
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  onlySalesManConfigView() {
    return Positioned(
      top: screenWidth * 1.05,
      child: Column(
        children: [
          Container(
            width: screenWidth,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      customDashboardButton(
                          AllString.profile, Icons.person_outline, () {
                        Navigator.of(context).push(CupertinoPageRoute(
                            builder: (context) => PersonalProfile()));
                      }, color[random.nextInt(10)]),
                      customDashboardButton(
                          AllString.attendance, Icons.calendar_today_outlined,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamAttendance()));
                      }, color[random.nextInt(12)]),
                      customDashboardButton(AllString.reports, Icons.report,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamReports()));
                      }, color[random.nextInt(12)]),
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  onlyHRConfigView() {
    return Positioned(
      top: screenWidth * 1.05,
      child: Column(
        children: [
          Container(
            width: screenWidth,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      customDashboardButton(
                          AllString.profile, Icons.person_outline, () {
                        Navigator.of(context).push(CupertinoPageRoute(
                            builder: (context) => PersonalProfile()));
                      }, color[random.nextInt(10)]),
                      customDashboardButton(
                          AllString.attendance, Icons.calendar_today_outlined,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamAttendance()));
                      }, color[random.nextInt(12)]),
                      customDashboardButton(
                          AllString.loan, Icons.attach_money_outlined, () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamLoan()));
                      }, color[random.nextInt(12)]),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      customDashboardButton(
                          AllString.leave, Icons.nearby_error_outlined, () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamLeave()));
                      }, color[random.nextInt(12)]),
                      customDashboardButton(
                          AllString.kraKpi, Icons.stacked_line_chart_outlined,
                          () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => TeamKRASchedule()));
                      }, color[random.nextInt(12)]),
                    ],
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  customDashboardButton(
      String name, IconData icon, Function() onTap, Color color,
      {bool enable = true}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: screenWidth * 0.33,
        child: Center(
          child: Container(
            width: screenWidth >= 600
                ? screenWidth * 0.25
                : screenWidth > 450
                    ? screenWidth * 0.26
                    : screenWidth * 0.28,
            height: screenWidth >= 600
                ? screenWidth * 0.22
                : screenWidth > 450
                    ? screenWidth * 0.23
                    : screenWidth * 0.25,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: AllColor.transparentColor),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: screenWidth * 0.15,
                  child: Container(
                    child: mediumIcon(icon,
                        color: enable ? Color(0xff59C173) : AllColor.white),
                  ),
                ),
                Container(
                  child: Text(
                    name,
                    textAlign: TextAlign.center,
                    style: smallTextStyle(
                        color: AllColor.black, fontWeight: FontWeight.bold),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
  // customDashboardButton(
  //     String name, IconData icon, Function() onTap, Color color) {
  //   return GestureDetector(
  //     onTap: onTap,
  //     child: Container(
  //       decoration: BoxDecoration(
  //         boxShadow: [
  //           BoxShadow(
  //             color: Colors.grey.withOpacity(0.5),
  //             spreadRadius: 1,
  //             blurRadius: 3,
  //             offset: Offset(0, 2), // changes position of shadow
  //           ),
  //         ],
  //         border: Border.all(width: 1, color: Color(0xff383CC1)),
  //         borderRadius: BorderRadius.circular(10),
  //         color: AllColor.white,

  //         // gradient: LinearGradient(
  //         //     begin: FractionalOffset(0.0, 0.0),
  //         //     end: FractionalOffset(1.0, 0.0),
  //         //     stops: [0.0, 1.0],
  //         //     tileMode: TileMode.clamp,
  //         //     colors: [color, color.withOpacity(0.8)])
  //       ),
  //       width: screenWidth >= 600
  //           ? screenWidth * 0.265
  //           : screenWidth > 450
  //               ? screenWidth * 0.265
  //               : screenWidth * 0.28,
  //       height: screenWidth >= 600
  //           ? screenWidth * 0.265
  //           : screenWidth > 450
  //               ? screenWidth * 0.24
  //               : screenWidth * 0.25,
  //       child: Column(
  //         mainAxisSize: MainAxisSize.min,
  //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  //         crossAxisAlignment: CrossAxisAlignment.center,
  //         children: [
  //           Container(
  //             width: screenWidth * 0.15,
  //             height: screenWidth * 0.15,
  //             child: Container(
  //               child: largeIcon(icon, color: Color(0xff383CC1)),
  //             ),
  //           ),
  //           Container(
  //             child: Text(
  //               name,
  //               textAlign: TextAlign.center,
  //               style: smallTextStyle(
  //                   color: AllColor.black, fontWeight: FontWeight.bold),
  //             ),
  //           )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  profileCard() {
    return Container(
      width: screenWidth,
      alignment: Alignment.center,
      child: Container(
        width: screenWidth,
        // height: screenWidth * 0.37,
        height: screenHeight / 3,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: screenWidth * 0.03,
            ),
            Container(
              width: screenWidth >= 600
                  ? screenWidth * 0.18
                  : screenWidth > 450
                      ? screenWidth * 0.2
                      : screenWidth * 0.22,
              height: screenWidth >= 600
                  ? screenWidth * 0.18
                  : screenWidth > 450
                      ? screenWidth * 0.2
                      : screenWidth * 0.22,
              decoration: BoxDecoration(
                  color: AllColor.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(width: 2, color: AllColor.black)),
              child: Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: singleTeamMember["individualImage"] == null ||
                          singleTeamMember["individualImage"] == ""
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Image.asset("assets/images/defaultUser.png"),
                          ),
                        )
                      : CachedNetworkImage(
                          width: screenWidth >= 600
                              ? screenWidth * 0.16
                              : screenWidth > 450
                                  ? screenWidth * 0.18
                                  : screenWidth * 0.2,
                          height: screenWidth >= 600
                              ? screenWidth * 0.16
                              : screenWidth > 450
                                  ? screenWidth * 0.18
                                  : screenWidth * 0.2,
                          fit: BoxFit.cover,
                          placeholder: (_, __) {
                            return Center(
                              child: CircularProgressIndicator(),
                            );
                          },
                          errorWidget: (_, __, ___) {
                            return Center(
                              child:
                                  Image.asset("assets/images/defaultUser.png"),
                            );
                          },
                          imageUrl: singleTeamMember["individualImage"]),
                ),
              ),
            ),
            SizedBox(
              height: screenWidth * 0.02,
            ),
            Container(
              margin: EdgeInsets.only(
                  left: screenWidth * 0.05, top: screenWidth * 0.03),
              width: screenWidth,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    checkApiValueValid(singleTeamMember["individualName"])
                        ? AllString.na
                        : singleTeamMember["individualName"],
                    style: TextStyle(
                        fontSize: screenWidth >= 600
                            ? screenWidth * 0.042
                            : screenWidth * 0.055,
                        letterSpacing: 1.5,
                        color: AllColor.white,
                        fontWeight: FontWeight.bold),
                  ),
                  normalText(
                      checkApiValueValid(singleTeamMember["individualCode"])
                          ? AllString.na
                          : singleTeamMember["individualCode"],
                      color: AllColor.white),
                  normalText(
                      checkApiValueValid(singleTeamMember["designation"])
                          ? AllString.na
                          : singleTeamMember["designation"],
                      color: AllColor.white),
                  // normalText(
                  //     "( " +
                  //         showValidValue(singleTeamMember["designation"]) +
                  //         " )",
                  //     color: AllColor.white),
                ],
              ),
            )
            // Divider(
            //   height: screenWidth * 0.03,
            //   color: AllColor.white.withOpacity(0.5),
            // ),
            ,
            SizedBox(
              height: screenWidth * 0.02,
            ),
          ],
        ),
      ),
    );
  }
}

class CustomShape extends CustomClipper<Path> {
  @override
  getClip(Size size) {
    double height = size.height;
    double width = size.width;
    var path = Path();
    path.lineTo(0, height - 50);
    path.quadraticBezierTo(width / 2, height, width, height - 54);
    path.lineTo(width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper oldClipper) {
    return true;
  }
}
