import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/leaveBalance/leaveDetails.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamDashboard/teamDashboard.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamLeave extends StatefulWidget {
  const TeamLeave({
    Key? key,
  }) : super(key: key);
  @override
  _TeamLeaveState createState() => _TeamLeaveState();
}

class _TeamLeaveState extends State<TeamLeave> {
  List _leaveList = [];
  bool loading = false;

  @override
  void initState() {
    super.initState();
    fetchLeaveList();
  }

  int _processIndex = 0;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.push(
            context, CupertinoPageRoute(builder: (context) => TeamDashboard()));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.leave, onBackPress: () {
          Navigator.push(context,
              CupertinoPageRoute(builder: (context) => TeamDashboard()));
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                 decoration:customBackgroundGradient(),

            child: Container(
              child: _leaveList.isEmpty
                  ? commonNoDataFound()
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: _leaveList.length,
                      itemBuilder: (context, index) =>
                          customListItem(_leaveList[index], index)),
            ),
          ),
        ),
      ),
    );
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => LeaveDetails(
                  singleData: itemData,
                  visible: true,
                  callBack: () {
                    Navigator.push(context,
                        CupertinoPageRoute(builder: (context) => TeamLeave()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Container(
                  //   width: screenWidth*0.75,
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     crossAxisAlignment: CrossAxisAlignment.center,
                  //     children: [
                  //       Container(
                  //         width: screenWidth*0.75 * 0.55,
                  //         padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
                  //         child: Row(
                  //           mainAxisSize: MainAxisSize.min,
                  //           mainAxisAlignment: MainAxisAlignment.start,
                  //           crossAxisAlignment: CrossAxisAlignment.center,
                  //           children: [
                  //             Container(
                  //               width: screenWidth*0.75 * 0.2,
                  //               child: smallText("From Date" + " :",
                  //                   color: AllColor.black,
                  //                   fontWeight: FontWeight.bold),
                  //             ),
                  //             Container(
                  //               margin: EdgeInsets.symmetric(
                  //                   horizontal: screenWidth * 0.01),
                  //             ),
                  //             Text(
                  //                 convertStringToDate(
                  //                     DateTime.parse(itemData["leaveFromDate"])),
                  //                 maxLines: 1,
                  //                 style: normalTextStyle(
                  //                   color: AllColor.black,
                  //                 )),
                  //           ],
                  //         ),
                  //       ),
                  //       Container(
                  //         width: screenWidth*0.75 * 0.55,
                  //         padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
                  //         child: Row(
                  //           mainAxisSize: MainAxisSize.min,
                  //           mainAxisAlignment: MainAxisAlignment.start,
                  //           crossAxisAlignment: CrossAxisAlignment.center,
                  //           children: [
                  //             Container(
                  //               width: screenWidth*0.75 * 0.2,
                  //               child: smallText("To Date" + " :",
                  //                   color: AllColor.black,
                  //                   fontWeight: FontWeight.bold),
                  //             ),
                  //             Container(
                  //               margin: EdgeInsets.symmetric(
                  //                   horizontal: screenWidth * 0.01),
                  //             ),
                  //             Text(
                  //                 convertStringToDate(
                  //                     DateTime.parse(itemData["leaveToDate"])),
                  //                 maxLines: 1,
                  //                 style: normalTextStyle(
                  //                   color: AllColor.black,
                  //                 )),
                  //           ],
                  //         ),
                  //       ),
                  //       // Container(
                  //       //   width: screenWidth*0.75 * 0.2,
                  //       //   child: Text("Approved",
                  //       //       maxLines: 1,
                  //       //       style: normalTextStyle(
                  //       //         color:

                  //       //             //  value == "Approved"
                  //       //             //     ?

                  //       //             AllColor.green
                  //       //         // : value == "Reimbursment"
                  //       //         //     ? AllColor.indigo
                  //       //         //     : value == "Rejected"
                  //       //         //         ? AllColor.red
                  //       //         //         : value == "Pending"
                  //       //         //             ? AllColor.yellow
                  //       //         //             : AllColor.black

                  //       //         ,
                  //       //       )),
                  //       // ),
                  //     ],
                  //   ),
                  // ),

                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.27,
                      title: "Leave Type",
                      value: checkApiValueValid(itemData["leaveTypeName"])
                          ? AllString.na
                          : itemData["leaveTypeName"]),
                  customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.27,
                    title: "From Date",
                    value: convertStringToDate(
                        DateTime.parse(itemData["leaveFromDate"])),
                  ),
                  customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.27,
                    title: "To Date",
                    value: convertStringToDate(
                        DateTime.parse(itemData["leaveToDate"])),
                  ),
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.27,
                      title: "Day Requested",
                      value: itemData["leaveAppliedFor"].toString() == "null" ||
                              itemData["leaveAppliedFor"].toString() == ""
                          ? AllString.na
                          : itemData["leaveAppliedFor"].toString() == "1"
                              ? AllString.halfDay
                              : AllString.fullDay),
                  // Container(
                  //   width: screenWidth*0.75,
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     crossAxisAlignment: CrossAxisAlignment.center,
                  //     children: [
                  //       Container(
                  //         width: screenWidth*0.75 / 2.5,
                  //         padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
                  //         child: Row(
                  //           mainAxisSize: MainAxisSize.min,
                  //           mainAxisAlignment: MainAxisAlignment.start,
                  //           crossAxisAlignment: CrossAxisAlignment.center,
                  //           children: [
                  //             Container(
                  //               width: screenWidth*0.75 * 0.2,
                  //               child: smallText("Leave Used" + " :",
                  //                   color: AllColor.black,
                  //                   fontWeight: FontWeight.bold),
                  //             ),
                  //             Container(
                  //               margin: EdgeInsets.symmetric(
                  //                   horizontal: screenWidth * 0.01),
                  //             ),
                  //             Container(
                  //               width: screenWidth*0.75 * 0.15,
                  //               child: Text("1.5",
                  //                   maxLines: 1,
                  //                   style: normalTextStyle(
                  //                     color: AllColor.black,
                  //                   )),
                  //             ),
                  //           ],
                  //         ),
                  //       ),
                  //       Container(
                  //         width: screenWidth*0.75 / 2.5,
                  //         padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
                  //         child: Row(
                  //           mainAxisSize: MainAxisSize.min,
                  //           mainAxisAlignment: MainAxisAlignment.start,
                  //           crossAxisAlignment: CrossAxisAlignment.center,
                  //           children: [
                  //             Container(
                  //               width: screenWidth*0.75 * 0.2,
                  //               child: smallText("Leave Left" + " :",
                  //                   color: AllColor.black,
                  //                   fontWeight: FontWeight.bold),
                  //             ),
                  //             Container(
                  //               margin: EdgeInsets.symmetric(
                  //                   horizontal: screenWidth * 0.01),
                  //             ),
                  //             Container(
                  //               width: screenWidth*0.75 * 0.15,
                  //               child: Text("5",
                  //                   maxLines: 1,
                  //                   style: normalTextStyle(
                  //                     color: AllColor.black,
                  //                   )),
                  //             ),
                  //           ],
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),

                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.27,
                      title: "Remark",
                      value: checkApiValueValid(itemData["comment"])
                          ? AllString.na
                          : itemData["comment"]),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchLeaveList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "leaveTypeId": "",
        "individualName": "",
        "userId": singleTeamMember["userId"],
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": singleTeamMember["individualId"],
      };
      apiPostRequestWithHeader(
              data, AllUrls.getLeaveList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _leaveList.clear();

            if (jsonData["leaveData"] == "") {
              _leaveList = [];
            } else {
              _leaveList = jsonData["leaveData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
