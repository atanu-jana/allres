import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_calendar_carousel/classes/event.dart';
import 'package:flutter_calendar_carousel/classes/multiple_marked_dates.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentDetails.dart';
import 'package:hr/pages/team/teamDashboard/teamDashboard.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

Map<String, dynamic> singleTeamMember = {};

class TeamBody extends StatefulWidget {
  @override
  _TeamBodyState createState() => _TeamBodyState();
}

class _TeamBodyState extends State<TeamBody> {
  bool loading = false;
  bool firstTimeLoading = true;

  TextEditingController _searchTextEditingController = TextEditingController();
  FocusNode _focusNode = FocusNode();
  List _teamMembers = [];
  List _searchResult = [];

  @override
  void initState() {
    super.initState();
    fetchTeamMembers();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: customBackgroundGradient(),
        child: Stack(
          children: [
            Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Container(
                  width: screenWidth,
                  margin: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.015),
                  decoration: BoxDecoration(
                      color: AllColor.lightGrey,
                      borderRadius: BorderRadius.circular(10)),
                  height: screenWidth * 0.1,
                  child: Center(
                    child: TextField(
                      focusNode: _focusNode,
                      controller: _searchTextEditingController,
                      onChanged: onSearchTextChanged,
                      decoration: InputDecoration(
                          suffixIcon: _searchTextEditingController.text.isEmpty
                              ? Container(
                                  width: screenWidth * 0,
                                )
                              : GestureDetector(
                                  onTap: () {
                                    _searchTextEditingController.clear();
                                    _focusNode.unfocus();
                                    onSearchTextChanged('');
                                  },
                                  child:
                                      Icon(Icons.close, color: AllColor.black),
                                ),
                          prefixIcon: Icon(
                            Icons.search,
                            color: AllColor.black,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.03,
                              vertical: screenWidth * 0.03),
                          isDense: true,
                          hintStyle: normalTextStyle(color: AllColor.black),
                          hintText:
                              AllString.name + ", " + AllString.employeeCode),
                    ),
                  ),
                )),
            Container(
                margin: EdgeInsets.only(
                  top: screenWidth * 0.14,
                  left: screenWidth * 0.03,
                  right: screenWidth * 0.03,
                ),
                child: Container(
                  child: _searchResult.length != 0 ||
                          _searchTextEditingController.text.isNotEmpty
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: BouncingScrollPhysics(),
                          itemCount: _searchResult.length,
                          itemBuilder: (context, index) =>
                              customMemberItem(_searchResult[index]))
                      : _teamMembers.isEmpty
                          ? commonNoDataFound()
                          : ListView.builder(
                              shrinkWrap: true,
                              physics: BouncingScrollPhysics(),
                              itemCount: _teamMembers.length,
                              itemBuilder: (context, index) =>
                                  customMemberItem(_teamMembers[index])),
                )),
          ],
        ),
      ),
    );
  }

  fetchTeamMembers() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualId)
            .toString(),
        "individualTypeId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
        "individualTypeId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getEmployeeDetailsById, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _teamMembers.clear();
            _teamMembers = jsonData["data"];
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customMemberItem(Map<String, dynamic> singleData) {
    return GestureDetector(
      onTap: () {
        singleTeamMember = singleData;
        setState(() {});
        Navigator.push(
            context, CupertinoPageRoute(builder: (context) => TeamDashboard()));
      },
      child: Container(
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.0, vertical: screenWidth * 0.015),
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.01, vertical: screenWidth * 0.01),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  Container(
                    width: screenWidth * 0.15,
                    height: screenWidth * 0.15,
                    decoration: BoxDecoration(
                        color: AllColor.white,
                        borderRadius: BorderRadius.circular(1000),
                        border: Border.all(width: 2, color: AllColor.black)),
                    child: Center(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(1000),
                        child: singleData["individualImage"] == null ||
                                singleData["individualImage"] == ""
                            ? Center(
                                child: Image.asset(
                                    "assets/images/defaultUser.png"),
                              )
                            : CachedNetworkImage(
                                width: screenWidth * 0.15,
                                height: screenWidth * 0.15,
                                fit: BoxFit.cover,
                                placeholder: (_, __) {
                                  return Center(
                                    child: CircularProgressIndicator(),
                                  );
                                },
                                errorWidget: (_, __, ___) {
                                  return Center(
                                    child: Image.asset(
                                        "assets/images/defaultUser.png"),
                                  );
                                },
                                imageUrl: singleData["individualImage"]),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(
                        top: screenWidth * 0.015, bottom: screenWidth * 0.01),
                    width: screenWidth * 0.15,
                    height: 0.15,
                    decoration: BoxDecoration(color: AllColor.greyColor),
                  ),
                  Container(
                    child: smallText(singleData["individualCode"],
                        color: AllColor.greyColor),
                  )
                ],
              ),
              Container(
                width: screenWidth * 0.65,
                margin: EdgeInsets.only(left: screenWidth * 0.03),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: normal2Text(singleData["individualName"],
                          color: AllColor.primaryDeepColor,
                          fontWeight: FontWeight.bold),
                    ),
                    Container(
                        child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                       Container(
                        width: screenWidth*0.55,
                        child:  normalText(showValidValue(singleData["designation"]),
                            color: AllColor.black,maxLines: 1,overflow: true),
                       ),
                        Container(
                            margin: EdgeInsets.only(right: screenWidth * 0.02),
                            child: normalIcon(Icons.arrow_forward_ios,
                                color: AllColor.greyColor))
                      ],
                    )),
                    // Container(
                    //     child: Row(
                    //   mainAxisAlignment: MainAxisAlignment.start,
                    //   children: [
                    //     normalText(showValidValue(singleData["designation"]),
                    //         color: AllColor.black),

                    //   ],
                    // )),
                    Container(
                        margin: EdgeInsets.only(
                          top: 5,
                          bottom: 5,
                        ),
                        padding: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AllColor.lightGrey)),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            smallText(AllString.lastUpdate,
                                color: AllColor.green),
                            SizedBox(
                              height: screenWidth * 0.01,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  child: smallIcon(FontAwesomeIcons.clock,
                                      color: AllColor.amber),
                                ),
                                Container(
                                  child: smallText(
                                      checkApiValueValid(singleData["lastTime"])
                                          ? AllString.na
                                          : convertStringToDate(DateTime.parse(
                                              singleData["lastTime"])),
                                      color: AllColor.greyColor),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: screenWidth * 0.01,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  child: smallIcon(Icons.location_on,
                                      color: AllColor.indigo),
                                ),
                                Container(
                                    width: screenWidth * 0.55,
                                    child: Text(
                                      checkApiValueValid(
                                              singleData["lastLocation"])
                                          ? AllString.na
                                          : singleData["lastLocation"]
                                              .toString(),
                                      maxLines: 3,
                                      textAlign: TextAlign.justify,
                                      style: extraSmallTextStyle(
                                          color: AllColor.greyColor),
                                    )),
                              ],
                            ),
                          ],
                        ))
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    _teamMembers.forEach((searchDetails) {
      if (searchDetails["individualName"]
              .toString()
              .toLowerCase()
              .contains(text) ||
          searchDetails["individualCode"]
              .toString()
              .toLowerCase()
              .contains(text)) _searchResult.add(searchDetails);
      setState(() {});
    });
    firstTimeLoading = false;

    setState(() {});
  }
}
