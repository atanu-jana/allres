import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpenseBody.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentBody.dart';
import 'package:hr/pages/publicHoliday/publicHolidayBody.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class WorkProfile extends StatefulWidget {
  final Map<String, dynamic> profileData;

  const WorkProfile({Key? key, required this.profileData}) : super(key: key);
  @override
  _WorkProfileState createState() =>
      _WorkProfileState(profileData: this.profileData);
}

class _WorkProfileState extends State<WorkProfile> {
  Map<String, dynamic> profileData;
  _WorkProfileState({required this.profileData});
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.workProfile),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Container(
              height: screenHeight * 1.1,
              color: AllColor.white,
              child: Column(
                children: [
                  Container(
                      height: screenWidth * 0.57,
                      child: Stack(
                        children: [
                          Container(
                            height: screenWidth * 0.4,
                            color: AllColor.primaryDeepColor,
                          ),
                          Positioned(
                              top: screenWidth * 0.15,
                              left: 0,
                              right: 0,
                              child: Center(child: topProfileCard())),
                          Positioned(
                              top: screenWidth * 0.03,
                              child: Container(
                                width: screenWidth,
                                alignment: Alignment.center,
                                child: Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: screenWidth * 0.05),
                                    width: screenWidth * 0.22,
                                    height: screenWidth * 0.22,
                                    padding: EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.withOpacity(0.5),
                                            spreadRadius: 2,
                                            blurRadius: 7,
                                            offset: Offset(0,
                                                3), // changes position of shadow
                                          ),
                                        ],
                                        color: AllColor.white,
                                        borderRadius:
                                            BorderRadius.circular(1000),
                                        border: Border.all(
                                            color: AllColor.white, width: 0)),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(1000),
                                      child: CachedNetworkImage(
                                          width: screenWidth * 0.22,
                                          height: screenWidth * 0.22,
                                          fit: BoxFit.cover,
                                          placeholder: (_, __) {
                                            return Center(
                                              child:
                                                  CircularProgressIndicator(),
                                            );
                                          },
                                          errorWidget: (_, __, ___) {
                                            return Center(
                                              child: Image.asset(
                                                  "assets/images/logo.png"),
                                            );
                                          },
                                          imageUrl: profileData[
                                              "Emp_Profile_imgUrl"]),
                                    )),
                              )),
                        ],
                      )),
                  SizedBox(
                    height: screenWidth * 0.0,
                  ),
                  Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        customProfileRow(
                          AllString.branch,
                          "Kolkata",
                        ),
                        customProfileRow(
                          AllString.sponsor,
                          "JK Protomax",
                        ),
                        customProfileRow(
                          AllString.employeeType,
                          "empType",
                        ),
                        customProfileRow(AllString.reportedToName, "SIR",
                            bottomborder: false),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  customCardRowDetails(IconData icon, String title, value) {
    return Container(
      width: screenWidth * 0.6,
      margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          normalIcon(icon, color: AllColor.primaryColor),
          Container(
            margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
          ),
          normalText(value, color: AllColor.black)
        ],
      ),
    );
  }

  topProfileCard() {
    return Container(
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(
                    color: AllColor.greyColor.withOpacity(0.8), width: 1))),
        padding: EdgeInsets.only(bottom: screenWidth * 0.0),
        alignment: Alignment.center,
        height: screenWidth * 0.38,
        margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
        child: Card(
          color: AllColor.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 0,
          child: Container(
            width: screenWidth,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  height: screenWidth * 0.02,
                ),
                headingText(
                    "${profileData["Emp_Name"]} ( ${profileData["Emp_code"]} )",
                    color: AllColor.black),
                midNormalText(profileData["Emp_Designation"],
                    color: AllColor.greyColor),
                normalText("Created At: ${convertStringToDate(DateTime.now())}",
                    color: AllColor.black),
                SizedBox(
                  height: screenWidth * 0.05,
                ),
              ],
            ),
          ),
        ));
  }

  customProfileRow(String title, String text, {bool bottomborder = true}) {
    return Container(
      width: screenWidth,
      margin: EdgeInsets.symmetric(vertical: screenWidth * 0.015),
      padding: EdgeInsets.only(bottom: screenWidth * 0.02),
      decoration: bottomborder
          ? BoxDecoration(
              border: Border(
                  bottom:
                      BorderSide(color: AllColor.greyColor.withOpacity(0.45))))
          : BoxDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(right: screenWidth * 0.02),
            width: screenWidth * 0.05,
            height: screenWidth * 0.05,
            child: Icon(
              Icons.arrow_forward_ios,
              color: AllColor.greyColor,
              size: screenWidth * 0.03,
            ),
          ),
          Container(
            width: screenWidth * 0.35,
            child: smallText(title + ":", color: AllColor.greyColor),
          ),
          Container(
            width: screenWidth * 0.3,
            child: normalText(text, color: AllColor.black),
          ),
        ],
      ),
    );
  }
}
