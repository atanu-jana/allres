import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/team/teamFeedback/teamFeedbackDetails.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamFeedback extends StatefulWidget {
  const TeamFeedback({
    Key? key,
  }) : super(key: key);
  @override
  _TeamFeedbackState createState() => _TeamFeedbackState();
}

class _TeamFeedbackState extends State<TeamFeedback> {
  bool loading = false;
  List _teamFeedback = [];
  @override
  void initState() {
    super.initState();
    fetchFeedback();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.feedBack),
      body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                        decoration:customBackgroundGradient(),

          child: Stack(
            children: [
              ListView.builder(
                  padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                  physics: BouncingScrollPhysics(),
                  itemCount: _teamFeedback.length,
                  itemBuilder: (context, index) =>
                      customFeedbackItem(_teamFeedback[index])),
            ],
          ),
        ),
      ),
    );
  }

  customFeedbackItem(Map<String, dynamic> itemData) {
    return GestureDetector(
      onTap: () {
        if (itemData["ReviewFirstLevelStatus"] == "Rejected" ||
            itemData["ReviewFirstLevelStatus"] == "Pending") {
        } else {
          Navigator.push(
              context,
              CupertinoPageRoute(
                  builder: (context) => TeamFeedbackDetails(
                        singleData: itemData,
                      )));
        }
      },
      child: Container(
          padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
          height: screenWidth >= 600 ? screenWidth * 0.43 : screenWidth * 0.5,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
         
          decoration: BoxDecoration(
              color: AllColor.white,
              borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
              customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.27,
                      title: "Date",
                      value: convertStringToDate(DateTime.now())),
                  
                    customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.22,
                      title: "Department",
                      value: itemData["SuggestionDepartment"]),
                    customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.22,
                      title: "Head",
                      value: itemData["SuggestionHead"]),
                    customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.22,
                      title: "Suggetion",
                      value: itemData["Remarks"]),
                    customRowDetails(
                      width: screenWidth * 0.78,
                      widthTitle: screenWidth * 0.22,
                      title: "Status",
                      value: itemData["ReviewFirstLevelStatus"]),
                  Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
                    width: screenWidth * 0.78,
                    child: Column(
                      children: [
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: (screenWidth * 0.78),
                              height: screenWidth * 0.01,
                              color: AllColor.greyColor,
                            ),
                            Container(
                              width: (screenWidth * 0.78),
                              height: screenWidth * 0.01,
                              alignment: Alignment.centerLeft,
                              color: AllColor.greyColor,
                              child: Container(
                                // width: (screenWidth * 0.38) ,
                                width: itemData["ReviewFirstLevelStatus"] ==
                                        "Pending"
                                    ? screenWidth * 0.38
                                    : itemData["ReviewFirstLevelStatus"] ==
                                            "Approved"
                                        ? screenWidth * 0.38
                                        : itemData["ReviewFirstLevelStatus"] ==
                                                "Rejected"
                                            ? screenWidth * 0.38
                                            : screenWidth * 0.0,
                                height: screenWidth * 0.01,
                                color: AllColor.green,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(1000),
                                    color: AllColor.green,
                                  ),
                                  width: screenWidth * 0.05,
                                  height: screenWidth * 0.05,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(1000),
                                    color: itemData["ReviewFirstLevelStatus"] ==
                                            "Approved"
                                        ? AllColor.green
                                        : itemData["ReviewFirstLevelStatus"] ==
                                                "Rejected"
                                            ? AllColor.red
                                            : AllColor.greyColor,
                                  ),
                                  width: screenWidth * 0.05,
                                  height: screenWidth * 0.05,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(1000),
                                    color: AllColor.greyColor,
                                  ),
                                  width: screenWidth * 0.05,
                                  height: screenWidth * 0.05,
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            extraSmallText(
                              "Request",
                              color: AllColor.greyColor,
                            ),
                            extraSmallText(
                              "( P.M. ) " + itemData["ReviewFirstLevelStatus"],
                              color: AllColor.greyColor,
                            ),
                            extraSmallText(
                              // "Approved",
                              "",
                              color: AllColor.greyColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
              itemData["ReviewFirstLevelStatus"] == "Rejected" ||
                      itemData["ReviewFirstLevelStatus"] == "Pending"
                  ? Container()
                  : Container(
                      child: smallIcon(Icons.arrow_forward_ios_outlined,
                          color: AllColor.greyColor))
            ],
          ),
        ),
      ),
    );
  }

  customCardRowDetails(String title, value) {
    return Container(
      width: screenWidth * 0.85,
      padding: EdgeInsets.symmetric(
          vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: screenWidth * 0.28,
            child: smallText(title + " :", color: AllColor.greyColor),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
          ),
          normalText(value,
              color: value == "Approved"
                  ? AllColor.green
                  : value == "Rejected"
                      ? AllColor.red
                      : value == "Pending"
                          ? AllColor.yellow
                          : AllColor.black)
        ],
      ),
    );
  }

  fetchFeedback() async {
    var jsonData = json.decode(await rootBundle
        .loadString('assets/json/HrViewSuggestionListData.json'));
    _teamFeedback = jsonData["HrViewSuggestionListData"];
    setState(() {});
  }
}
