import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamLoanDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  const TeamLoanDetails({Key? key, required this.singleData}) : super(key: key);
  @override
  _TeamLoanDetailsState createState() => _TeamLoanDetailsState();
}

class _TeamLoanDetailsState extends State<TeamLoanDetails> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.loanDetails),
      body: LoadingOverlay(
     
  isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                        decoration:customBackgroundGradient(),

            child: ListTile(
                title: Container(
                  padding: EdgeInsets.all(1),
                  decoration: customCardItemGradinet(),
                  margin: customMarginCardItem(),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.01,
                    ),
                    decoration: BoxDecoration(
                        color: AllColor.white,
                        borderRadius: BorderRadius.circular(10)),
                    width: screenWidth,
                    child: Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            customRowDetails(
                                width: screenWidth * 0.75,
                                widthTitle: screenWidth * 0.28,
                                title: "Loadn Id",
                                value: widget.singleData["LoanId"]),
                            customRowDetails(
                                width: screenWidth * 0.75,
                                widthTitle: screenWidth * 0.28,
                                title: "Applied On",
                                value: convertStringToDate(DateTime.now())),
                            customRowDetails(
                                width: screenWidth * 0.75,
                                widthTitle: screenWidth * 0.28,
                                title: "Status",
                                value: widget
                                    .singleData["ReviewFirstLevelStatus"]),
                            customRowDetails(
                                width: screenWidth * 0.75,
                                widthTitle: screenWidth * 0.28,
                                title: "Loan Amount",
                                value: AllString.rs +
                                    " " +
                                    widget.singleData["LoanAmt"]),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                subtitle: Container(
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.015,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.comment + "*",
                            _commentTextEditingController,
                            4,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          MaterialButton(
                            height: screenWidth * 0.08,
                            onPressed: () {},
                            color: AllColor.lightBlack,
                            child: normalText(
                              AllString.approved,
                              color: AllColor.black,
                            ),
                            splashColor: AllColor.green,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10000),
                                side: BorderSide(color: AllColor.green)),
                          ),
                          MaterialButton(
                            height: screenWidth * 0.08,
                            color: AllColor.lightBlack,
                            onPressed: () {},
                            child: normalText(
                              AllString.rejected,
                              color: AllColor.black,
                            ),
                            splashColor: AllColor.red,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10000),
                                side: BorderSide(color: AllColor.red)),
                          ),
                          MaterialButton(
                            height: screenWidth * 0.08,
                            onPressed: () {},
                            color: AllColor.lightBlack,
                            child: normalText(
                              AllString.cancel,
                              color: AllColor.black,
                            ),
                            splashColor: AllColor.primaryColor,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10000),
                                side: BorderSide(color: AllColor.primaryColor)),
                          ),
                        ],
                      ),
                    ],
                  ),
                )),
          )),
    );
  }
}
