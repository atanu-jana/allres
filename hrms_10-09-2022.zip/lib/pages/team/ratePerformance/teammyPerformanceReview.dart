import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/myPerformance/myPerformanceReviewDetails.dart';
import 'package:hr/pages/team/ratePerformance/teammyPerformanceReviewDetails.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class TeamMyPerformanceReview extends StatefulWidget {
   final String individualId;
  const TeamMyPerformanceReview({
    Key? key,
     required this.individualId,
  }) : super(key: key);
  @override
  _TeamMyPerformanceReviewState createState() => _TeamMyPerformanceReviewState();
}

class _TeamMyPerformanceReviewState extends State<TeamMyPerformanceReview> {
  bool loading = false;
List _kraPercentageList = [];
  @override
  void initState() {
    super.initState();
    
    fetchKRApercentageData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.myPerformanceReview),
      body: LoadingOverlay(
        isLoading: loading,
   opacity: 0.5,
      color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                   decoration:customBackgroundGradient(),

          child: Stack(
            children: [
              Positioned(
                  top: 0,
                  child: Container(
                    height: screenWidth * 0.1,
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                    ),
                    decoration: BoxDecoration(
                        color: AllColor.lightBlack,
                        border:
                            Border(bottom: BorderSide(color: AllColor.black))),
                    width: screenWidth,
                    alignment: Alignment.centerLeft,
                    child: Container(
                      child: normalText(convertStringToMonthYear(DateTime.now()),
                          color: AllColor.black),
                    ),
                  )),
              Container(
                margin: EdgeInsets.only(top: screenWidth * 0.11),
                child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: _kraPercentageList.length,
                    itemBuilder: (context, index) => customPerformanceReview(_kraPercentageList[index], index)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  customPerformanceReview(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => TeamMyPerformanceReviewDetails(
                  singleData: itemData,
                  visible: false,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => TeamMyPerformanceReview(individualId: singleTeamMember["individualId"].toString())));
                  },
                )
                )
            
           
            );
      },
      child: Container(
          padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
          height: screenWidth >= 600 ? screenWidth * 0.43 : screenWidth * 0.5,
        margin: customMarginCardItem(),
        child: Container(
         
          decoration: BoxDecoration(
            color: AllColor.white,
            borderRadius: BorderRadius.circular(7),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: screenWidth * 0.008,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                width: screenWidth,
                alignment: Alignment.centerLeft,
                child: normalText(itemData["kraTemplate"].toString(), color: AllColor.primaryColor),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                width: screenWidth,
                alignment: Alignment.centerLeft,
                child:
                    normalText("Reviewed by: "+itemData["reviewBy"].toString(), color: AllColor.black),
              ),
              SizedBox(
                height: screenWidth * 0.008,
              ),
              customViewPerformanceProgress(itemData["getPercentage"].toString(), " "),
              Container(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                width: screenWidth,
                alignment: Alignment.centerRight,
                child: smallText("More details...", color: AllColor.greyColor),
              ),
              SizedBox(
                height: screenWidth * 0.008,
              ),
            ],
          ),
        ),
      ),
    );
  }


  fetchKRApercentageData() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":widget.individualId ,
        
      };
      apiPostRequestWithHeader(
              data, AllUrls.getKRApercentageList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _kraPercentageList = jsonData["kraPercentageData"];      
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customViewPerformanceProgress(String percentage, String name) {
    return Container(
      width: screenWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
              width: screenWidth * 0.3,
              child: CircularPercentIndicator(
                radius: 100.0,
                lineWidth: 20.0,
                percent: double.parse(percentage) / 100,
                center: smallText("$percentage%", color: AllColor.black),
                progressColor: AllColor.deepGreen,
                backgroundColor: AllColor.green.withOpacity(0.5),
              )),
          Container(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                child: normalText("Total Target: 100", color: AllColor.black),
              ),
              Container(
                child: normalText("Target Reached: "+ percentage.toString(), color: AllColor.black),
              ),
            ],
          )),
        ],
      ),
    );
  }
}

class SalesData {
  SalesData(this.month, this.sales);
  final String month;
  final double sales;
}
