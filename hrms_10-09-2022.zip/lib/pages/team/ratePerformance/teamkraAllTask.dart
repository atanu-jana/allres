import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customIconRowDetails.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamKraAllTasks extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  final String individualId;
  const TeamKraAllTasks(
      {Key? key,
      required this.individualId,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);

  @override
  _TeamKraAllTasksState createState() => _TeamKraAllTasksState();
}

class _TeamKraAllTasksState extends State<TeamKraAllTasks> {
  bool loading = false;
  List _loadList = [];

  @override
  void initState() {
    super.initState();
    fetchKRATaskList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.kraTasks),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                 decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Positioned(
                    top: 0,
                    child: Container(
                      height: screenWidth * 0.1,
                      padding: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.04,
                      ),
                      decoration: BoxDecoration(
                        color: AllColor.tableBackground,
                      ),
                      width: screenWidth,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            child: normalText(
                                widget.singleData["kraTemplate"].toString() +
                                    " :",
                                color: AllColor.white),
                          ),
                        ],
                      ),
                    )),
                Container(
                  margin: EdgeInsets.only(top: screenWidth * 0.11),
                  child: _loadList.isEmpty
                      ? commonNoDataFound()
                      : ListView.builder(
                          padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                          physics: BouncingScrollPhysics(),
                          itemCount: _loadList.length,
                          itemBuilder: (context, index) =>
                              customListItem(_loadList[index], index)),
                ),
              ],
            ),
          ),
        ));
  }

  fetchKRATaskList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "companyKraTemplateId":
            widget.singleData["companyKraTemplateId"].toString(),
             "employeeKraId":
            widget.singleData["employeeKraId"].toString(),
            
        "individualId": widget.individualId,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getKRATaskList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _loadList.clear();

            if (jsonData["kraTaskData"] == "") {
              _loadList = [];
            } else {
              _loadList = jsonData["kraTaskData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth >= 100 ? screenWidth * 0.14 : screenWidth * 0.16,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customIconRowDetails(
                      width: screenWidth * 0.8,
                      icon: Icons.checklist_outlined,
                      value: itemData["kpiTemplate"].toString()),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
