import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/myPerformance/myPerformanceBody.dart';
import 'package:hr/pages/team/ratePerformance/teammyPerformanceBody.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';


class TeamMyPerformance extends StatefulWidget {
  const TeamMyPerformance({Key? key}) : super(key: key);
  @override
  _TeamMyPerformanceState createState() => _TeamMyPerformanceState();
}

class _TeamMyPerformanceState extends State<TeamMyPerformance> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.ratePerformance),
        body: TeamMyPerformanceBody(individualId: singleTeamMember["individualId"].toString()));
  }
}
