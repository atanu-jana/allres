import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/myPerformance/kraAllTask.dart';
import 'package:hr/pages/myPerformance/viewPerformance.dart';
import 'package:hr/pages/team/ratePerformance/teamkraAllTask.dart';
import 'package:hr/pages/team/ratePerformance/teamviewPerformance.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

import '../teamBody.dart';

class TeamMyPerformanceBody extends StatefulWidget {
  final String individualId;
  const TeamMyPerformanceBody({
    Key? key,
    required this.individualId,
  }) : super(key: key);
  @override
  _TeamMyPerformanceBodyState createState() => _TeamMyPerformanceBodyState();
}

class _TeamMyPerformanceBodyState extends State<TeamMyPerformanceBody> {
  bool loading = false;
  List _loadList = [];

  String _totalMark = "";
  String _individualName = "";

  @override
  void initState() {
    super.initState();
    fetchKRATemplateList();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                               decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Positioned(
                top: 0,
                child: Container(
                  height: screenWidth * 0.1,
                  padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.1,
                  ),
                  decoration: BoxDecoration(
                    color: AllColor.tableBackground,
                    // border:
                    //     Border(bottom: BorderSide(color: AllColor.black))
                  ),
                  width: screenWidth,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        child: normalText(_individualName.toString(), color: AllColor.white),
                      ),
                      Container(
                        child: normalText("Total Points: "+_totalMark.toString(),
                            color: AllColor.white),
                      ),
                    ],
                  ),
                )),
            Container(
              margin: EdgeInsets.only(top: screenWidth * 0.11),
              child: _loadList.isEmpty
                  ? commonNoDataFound()
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: _loadList.length,
                      itemBuilder: (context, index) =>
                          customListItem(_loadList[index], index)),

             
            ),
            Positioned(
                bottom: 0,
                
                child: Container(
                  width: screenWidth,
                  child: button(
                    context,
                    function: () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => TeamViewPerformance(individualId: singleTeamMember["individualId"].toString())));
                    },
                  color: AllColor.primaryColor,
                    textColor: AllColor.white,
                    text: AllString.viewPerformance,
                  ),
                ))
          ],
        ),
      ),
    );
  }

  fetchKRATemplateList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": widget.individualId,
        "individualTypeId": "" ,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getKRATemplateList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _loadList.clear();

            if (jsonData["kraTemplateData"] == "") {
              _loadList = [];
            } else {
              _loadList = jsonData["kraTemplateData"]["kraDetails"];
              _totalMark = jsonData["kraTemplateData"]["totalMark"].toString();
              _individualName = jsonData["kraTemplateData"]["individualName"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }


  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => TeamKraAllTasks(
                  individualId: singleTeamMember["individualId"].toString(),
                  singleData: itemData,
                  visible: false,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => TeamMyPerformanceBody(individualId: singleTeamMember["individualId"].toString())));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth >= 100 ? screenWidth * 0.14 : screenWidth * 0.16,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.70,
                      title: itemData["kraTemplate"].toString(),
                      value: itemData["marks"].toString()),
                 
                ],
              ),
               listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }
}
