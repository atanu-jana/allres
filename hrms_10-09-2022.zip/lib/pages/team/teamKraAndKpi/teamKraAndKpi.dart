import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myPerformance/viewPerformance.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamDashboard/teamDashboard.dart';
import 'package:hr/pages/team/teamKraAndKpi/addKra.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamKRASchedule.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamkraAllTask.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/customRowTeamKraKpiDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamKraAndKpi extends StatefulWidget {
  final bool permission;
  final String kraReviewScheduleId;
  final String scheduledate;
  const TeamKraAndKpi({
    Key? key,
    required this.permission,
    required this.kraReviewScheduleId,
    required this.scheduledate,
  }) : super(key: key);
  @override
  _TeamKraAndKpiState createState() => _TeamKraAndKpiState();
}

class _TeamKraAndKpiState extends State<TeamKraAndKpi> {
  bool loading = false;
  List _loadList = [];

  String _totalMark = "";
  String _individualName = "";

  @override
  void initState() {
    super.initState();
    fetchKRATemplateList();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => TeamKRASchedule()));
        return true;
      },
      child: Scaffold(
          backgroundColor: AllColor.white,
          appBar: customAppBar(context, AllString.kraKpi, onBackPress: () {
            Navigator.of(context).push(
                CupertinoPageRoute(builder: (context) => TeamKRASchedule()));
          }, actions: [
            Center(
              child: Container(
                margin: AllMargin.customMarginCardItem(),
                padding: AllMargin.customHorizontal(),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    extraSmallText("Schedule Date", color: AllColor.black),
                    extraSmallText(
                        convertStringToDate(
                            DateTime.parse(widget.scheduledate)),
                        color: AllColor.black)
                  ],
                ),
              ),
            )
          ]),
          body: LoadingOverlay(
            isLoading: loading,
            opacity: 0.5,
            color: AllColor.black,
            progressIndicator: commonLoader(),
            child: Container(
              width: screenWidth,
              height: screenHeight,
              decoration: customBackgroundGradient(),
              child: Stack(
                children: [
                  Positioned(
                      top: 0,
                      child: Container(
                        height: screenWidth * 0.1,
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.1,
                        ),
                        decoration: BoxDecoration(
                          color: AllColor.tableBackground,
                          // border:
                          //     Border(bottom: BorderSide(color: AllColor.black))
                        ),
                        width: screenWidth,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              child: normalText(_individualName.toString(),
                                  color: AllColor.white),
                            ),
                            Container(
                              child: normalText(
                                  "Total Points: " + _totalMark.toString(),
                                  color: AllColor.white),
                            ),
                          ],
                        ),
                      )),
                  Container(
                      margin: EdgeInsets.only(top: screenWidth * 0.11),
                      child: ListView.builder(
                          padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                          physics: BouncingScrollPhysics(),
                          itemCount: _loadList.length,
                          itemBuilder: (context, index) =>
                              customListItem(_loadList[index], index))),
                  // sharedPreferences!.getString(
                  //             AllSharedPreferencesKey.individualTypeId)! ==
                  //         "16"
                  //     ?
                  Positioned(
                      bottom: screenWidth * 0.05,
                      right: screenWidth * 0.05,
                      child: FloatingActionButton(
                        onPressed: () {
                          Navigator.of(context).push(CupertinoPageRoute(
                              builder: (context) => AddKra(
                                  userKraList: _loadList,
                                  scheduledate: widget.scheduledate,
                                  permission: widget.permission,
                                  kraReviewScheduleId:
                                      widget.kraReviewScheduleId)));
                        },
                        child: normalIcon(Icons.add),
                        backgroundColor: AllColor.primaryDeepColor,
                      ))
                  // : Container(),
                ],
              ),
            ),
          )),
    );
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => TeamKraAllTasks(
                  singleData: itemData,
                  permission: widget.permission,
                  scheduledate: widget.scheduledate,
                  kraReviewScheduleId: widget.kraReviewScheduleId,
                  visible: false,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => TeamKraAndKpi(
                                scheduledate: widget.scheduledate,
                                permission: widget.permission,
                                kraReviewScheduleId:
                                    widget.kraReviewScheduleId)));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        child: Container(
          padding: AllMargin.customMarginCardItem(),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // customIconRowDetails(
                  //     width: screenWidth * 0.8,
                  //     icon: Icons.checklist_outlined,
                  //     value: itemData["kpiTemplate"].toString(),
                  //     displayFullValue: true),
                  customRowTeamKraKpiDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.70,
                      title: itemData["kraTemplate"].toString(),
                      value: itemData["marks"].toString()),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchKRATemplateList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": singleTeamMember["individualId"],
        "individualTypeId": singleTeamMember["individualTypeId"],
      };

      log(data.toString());
      apiPostRequestWithHeader(
              data, AllUrls.getKRATemplateList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _loadList.clear();

            if (jsonData["kraTemplateData"] == "") {
              _loadList = [];
            } else {
              _loadList = jsonData["kraTemplateData"]["kraDetails"];
              _totalMark = jsonData["kraTemplateData"]["totalMark"].toString();
              _individualName = jsonData["kraTemplateData"]["individualName"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
