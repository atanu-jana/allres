import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/myPerformance/viewPerformance.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamKraAndKpi/addKpi.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamKraAndKpi.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamViewKpi.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customIconRowDetails.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/customRowTeamKraKpiDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamKraAllTasks extends StatefulWidget {
  final bool permission;
  final String kraReviewScheduleId;
  final String scheduledate;
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const TeamKraAllTasks(
      {Key? key,
      required this.permission,
      required this.kraReviewScheduleId,
      required this.scheduledate,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);

  @override
  _TeamKraAllTasksState createState() => _TeamKraAllTasksState();
}

class _TeamKraAllTasksState extends State<TeamKraAllTasks> {
  bool loading = false;
  List _loadList = [];

  @override
  void initState() {
    super.initState();
    fetchKRATaskList();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) =>
                TeamKraAndKpi(permission: widget.permission,kraReviewScheduleId:widget.kraReviewScheduleId,scheduledate:widget.scheduledate)));
        return true;
      },
      child: Scaffold(
          backgroundColor: AllColor.white,
          appBar: customAppBar(context, AllString.kraTasks, onBackPress: () {
            Navigator.of(context).push(CupertinoPageRoute(
                builder: (context) =>
                    TeamKraAndKpi(permission: widget.permission,kraReviewScheduleId:widget.kraReviewScheduleId,scheduledate:widget.scheduledate)));
          },actions: [
            Center(
              child: Container(
                margin: AllMargin.customMarginCardItem(),
                padding: AllMargin.customHorizontal(),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    extraSmallText("Schedule Date", color: AllColor.black),
                    extraSmallText(
                        convertStringToDate(
                            DateTime.parse(widget.scheduledate)),
                        color: AllColor.black)
                  ],
                ),
              ),
            )
          ]),
          body: LoadingOverlay(
            isLoading: loading,
            opacity: 0.5,
            color: AllColor.black,
            progressIndicator: commonLoader(),
            child: Container(
              width: screenWidth,
              height: screenHeight,
              decoration: customBackgroundGradient(),
              child: Stack(
                children: [
                  Positioned(
                      top: 0,
                      child: Container(
                        height: screenWidth * 0.1,
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.04,
                        ),
                        decoration: BoxDecoration(
                          color: AllColor.tableBackground,
                        ),
                        width: screenWidth,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: screenWidth * 0.8,
                              child: normalText(
                                  widget.singleData["kraTemplate"].toString() +
                                      " :",
                                  color: AllColor.white,
                                  center: true),
                            ),
                          ],
                        ),
                      )),
                  Container(
                    margin: EdgeInsets.only(top: screenWidth * 0.11),
                    child: _loadList.isEmpty
                        ? commonNoDataFound()
                        : ListView.builder(
                            padding:
                                EdgeInsets.only(bottom: screenWidth * 0.03),
                            physics: BouncingScrollPhysics(),
                            itemCount: _loadList.length,
                            itemBuilder: (context, index) =>
                                customListItem(_loadList[index], index)),
                  ),
                  //  sharedPreferences!.getString(AllSharedPreferencesKey.individualTypeId)! == "16"?
                  Positioned(
                      bottom: screenWidth * 0.05,
                      right: screenWidth * 0.05,
                      child: FloatingActionButton(
                        onPressed: () {
                          Navigator.of(context).push(CupertinoPageRoute(
                              builder: (context) => AddKPI(
                                scheduledate:widget.scheduledate,
                                    permission: widget.permission,
                                    kraReviewScheduleId: widget.kraReviewScheduleId,
                                    userKpiList: _loadList,
                                    singleData: widget.singleData,
                                    parentCallBack: widget.callBack,
                                    parentSingleData: widget.singleData,
                                    parentVisible: widget.visible,
                                  )));
                        },
                        child: normalIcon(Icons.add),
                        backgroundColor: AllColor.primaryDeepColor,
                      ))
                  // :Container(),
                  // Positioned(
                  //     bottom: 0,
                  //     child: Container(
                  //       width: screenWidth,
                  //       child: button(
                  //         context,
                  //         function: () {
                  //           Navigator.push(
                  //               context,
                  //               CupertinoPageRoute(
                  //                   builder: (context) => TeamViewKpi(
                  //                         singleData: widget.singleData,
                  //                         visible: widget.visible,
                  //                         callBack: widget.callBack,
                  //                       )));
                  //         },
                  //        color: AllColor.primaryColor,
                  //         textColor: AllColor.white,
                  //         text: AllString.viewKpi,
                  //       ),
                  //     ))
                ],
              ),
            ),
          )),
    );
  }

  fetchKRATaskList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "companyKraTemplateId":
            widget.singleData["companyKraTemplateId"].toString(),
        "employeeKraId": widget.singleData["companyKraTemplateId"].toString(),
        "individualId": singleTeamMember["individualId"],
      };
      apiPostRequestWithHeader(
              data, AllUrls.getKRATaskList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _loadList.clear();

            if (jsonData["kraTaskData"] == "") {
              _loadList = [];
            } else {
              _loadList = jsonData["kraTaskData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  showDialogForApi(Map itemData) {
    TextEditingController _amountTextEditingController =
        TextEditingController();
    FocusNode _amountFocusNode = FocusNode();
    return commonAlertDialogWithCloseButtonWithWidget(
        context,
        AllColor.white,
        Container(
            child: Column(
          children: [
            Container(
              height: screenWidth * 0.1,
              alignment: Alignment.center,
              child: normalText("Add Point", color: AllColor.black),
            ),
            Container(
                child: RoundedInputField(
              controller: _amountTextEditingController,
              focusNode: _amountFocusNode,
              textInputAction: TextInputAction.next,
              textInputType: TextInputType.number,
              hintText: AllString.enterPoint,
              errorText: "",
              maxLength: 5,
              showToolTip: false,
              icon: LineIcons.handHoldingUsDollar,
              onchangeFunction: (String val) {
                  if (val.isNotEmpty && int.parse(val) >= (int.parse(itemData["kpiTarget"].toString())+1)) {
                        _amountTextEditingController.text = "";
                    
                      Navigator.pop(context);
                      showDialogForApi(itemData);
                      }
                setState(() {});
              },
            )),
            Container(
                margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.015,
                    horizontal: screenWidth * 0.03),
                child: button(
                  context,
                  width: screenWidth * 0.4,
                  function: () {
                    if (_amountTextEditingController.text.isNotEmpty) {
                      Navigator.pop(context);

                      addPoint(itemData, _amountTextEditingController.text);
                    } else {
                      Navigator.pop(context);
                    }
                  },
                  color: AllColor.primaryColor,
                  textColor: AllColor.white,
                  text: AllString.add,
                )),
          ],
        )));
  }

  addPoint(Map itemData, String point) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        // asd
        "userLoginId": loginUserId,
        "kraReviewScheduleId": widget.kraReviewScheduleId,
        "companyId": sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "employeeKpiId": itemData["employeeKpiId"],
        "employeeKraId": widget.singleData["companyKraTemplateId"].toString(),
        "point": point,
        "totalPoint": widget.singleData["marks"],
        "individualId": singleTeamMember["individualId"],
        "reviewBy":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.reviewEmployeeKpi, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.pop(context);
              fetchKRATaskList();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        // if( sharedPreferences!.getString(AllSharedPreferencesKey.individualTypeId)! == "16"){

         widget.permission &&
                                      (itemData["marksObtain"].toString() ==
                                              "" ||
                                          itemData["marksObtain"].toString() ==
                                              "null") ? showDialogForApi(itemData) : print("");
        // }
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        child: Container(
          padding: AllMargin.customMarginCardItem(),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.25,
                    title: "Kpi Template",
                    value: itemData["kpiTemplate"].toString(),
                  ),
                  customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.25,
                    title: "Target",
                    value: itemData["kpiTarget"].toString(),
                  ),
                  Container(
                    width: screenWidth * 0.8,
                    padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: screenWidth * 0.25,
                          child: Text(
                            "Marks Obtain" + " :",
                            maxLines: 1,
                            style: smallTextStyle(
                                color: AllColor.black,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.01),
                        ),
                        Container(
                          width: (screenWidth * 0.8 - screenWidth * 0.25) - 15,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                            children: [
                              Text(
                                  showValidValue(
                                      itemData["marksObtain"].toString()),
                                  maxLines: 5,
                                  overflow: TextOverflow.ellipsis,
                                  style: normalTextStyle(
                                    color: AllColor.black,
                                  )),
                              widget.permission &&
                                      (itemData["marksObtain"].toString() ==
                                              "" ||
                                          itemData["marksObtain"].toString() ==
                                              "null")
                                  ? Container(
                                      margin: AllMargin.customHorizontal(),
                                      decoration: BoxDecoration(
                                          color: AllColor.blue,
                                          borderRadius:
                                              BorderRadius.circular(5)),
                                      padding: AllMargin.customHorizontal(),
                                      child: smallText("Give Marks",
                                          color: AllColor.white),
                                    )
                                  : Container()
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
