import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonAlertDialogWithYesNo.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/myPerformance/viewPerformance.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamKraAndKpi.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamViewKpi.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customIconRowDetails.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class AddKra extends StatefulWidget {
  final bool permission;
  final String kraReviewScheduleId;
  final String scheduledate;
  final List userKraList;
  const AddKra({Key? key,
    required this.permission,
    required this.kraReviewScheduleId,
    required this.scheduledate,
  
   required this.userKraList}) : super(key: key);

  @override
  _AddKraState createState() => _AddKraState();
}

class _AddKraState extends State<AddKra> {
  bool loading = false;
  List _suggetionList = [];
  List _addSuggetionList = [];
  List _existingSuggetionList = [];
  TextEditingController _searchTextEditingController = TextEditingController();
  List _searchResult = [];
  FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    fetchKraSuggetions();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.addKra),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
            decoration: customBackgroundGradient(),
            child: ListView(
              physics: BouncingScrollPhysics(),
              children: [
                Container(
                  height: screenWidth * 0.1,
                  padding: AllMargin.customHorizontal(),
                  decoration: BoxDecoration(
                    color: AllColor.lightBlack,
                  ),
                  width: screenWidth,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        child: normalText("KRA's Suggetion",
                            color: AllColor.black),
                      ),
                      GestureDetector(
                          onTap: () {
                            suggetionDialog();
                          },
                          child: Center(
                              child: SvgPicture.asset(
                            "assets/images/addButton.svg",
                            color: AllColor.deepGreen,
                            height: screenWidth * 0.06,
                          ))),
                    ],
                  ),
                ),
                Container(
                  padding: AllMargin.customHorizontal(),
                  decoration: BoxDecoration(
                      color: AllColor.lightBlack,
                      borderRadius: BorderRadius.circular(10)),
                  margin: AllMargin.customMarginCardItemSameSmall(),
                  width: screenWidth,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        height: screenWidth * 0.1,
                        alignment: Alignment.center,
                        child: normalText("Existing KRA's List",
                            color: AllColor.black),
                      ),
                      Container(
                        child: widget.userKraList.isEmpty
                            ? commonNoDataFound()
                            : ListView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: widget.userKraList.length,
                                itemBuilder: (context, index) =>
                                    customListItemForExistingSuggetion(
                                        widget.userKraList[index], index)),
                      ),
                    ],
                  ),
                ),
                _existingSuggetionList.isEmpty
                    ? Container()
                    : Container(
                        padding: AllMargin.customHorizontal(),
                        decoration: BoxDecoration(
                            color: AllColor.lightBlack,
                            borderRadius: BorderRadius.circular(10)),
                        margin: AllMargin.customMarginCardItemSameSmall(),
                        width: screenWidth,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              height: screenWidth * 0.1,
                        alignment: Alignment.center,

                              child: normalText("KRA's List",
                                  color: AllColor.black),
                            ),
                            Container(
                              child: _existingSuggetionList.isEmpty
                                  ? commonNoDataFound()
                                  : ListView.builder(
                                      physics: NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: _existingSuggetionList.length,
                                      itemBuilder: (context, index) =>
                                          customListItemForExistingSuggetion(
                                              _existingSuggetionList[index],
                                              index)),
                            ),
                            Container(
                                margin: EdgeInsets.symmetric(
                                    vertical: screenWidth * 0.015,
                                    horizontal: screenWidth * 0.03),
                                child: button(
                                  context,
                                  width: screenWidth * 0.4,
                                  function: () {
                                    addEmployeeTemplate();
                                  },
                                  color: AllColor.primaryColor,
                                  textColor: AllColor.white,
                                  text: AllString.submit,
                                )),
                          ],
                        ),
                      )
              ],
            ),
          ),
        ));
  }

  customListItemForSuggetion(dynamic itemData, int index) {
    return GestureDetector(
      onTap: () {
        //   widget.userKraList.forEach((subElement) {
        //     if(subElement["companyKraTemplateId"]==element["companyKraTemplateId"]){
        //       _existingSuggetionList.add(element);
        //     }
        //   });
        // });
        _existingSuggetionList.contains(itemData)
            ? _existingSuggetionList.remove(itemData)
            : _existingSuggetionList.add(itemData);
        setState(() {});
        AppBuilder.of(context)!.rebuild();
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              customIconRowDetails(
                  width: screenWidth * 0.65,
                  icon: Icons.checklist_outlined,
                  value: itemData["kraTemplate"].toString(),
                  displayFullValue: true),
              Container(
                  margin: AllMargin.customHorizontalSmall(),
                  child: normalIcon(
                      _existingSuggetionList.contains(itemData)
                          ? Icons.close
                          : Icons.add,
                      color: _existingSuggetionList.contains(itemData)
                          ? AllColor.red
                          : AllColor.deepGreen))
            ],
          ),
        ),
      ),
    );
  }

  customListItemForExistingSuggetion(dynamic itemData, int index) {
    return GestureDetector(
      onTap: () {
        // _existingSuggetionList.contains(itemData)
        //     ? _existingSuggetionList.remove(itemData)
        //     : _existingSuggetionList.add(itemData);
        // setState(() {});
        // AppBuilder.of(context)!.rebuild();
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              customIconRowDetails(
                  width: screenWidth * 0.65,
                  icon: Icons.checklist_outlined,
                  value: itemData["kraTemplate"].toString(),
                  displayFullValue: true),
              
            ],
          ),
        ),
      ),
    );
  }

  suggetionDialog() {
    TextEditingController _commentTextEditingController =
        TextEditingController();

    return showDialog(
        builder: (BuildContext context) {
          return WillPopScope(
            onWillPop: () async {
              if (_existingSuggetionList.isNotEmpty) {
                commonAlertDialogWithYesNo(
                    context, AllString.warning, "Are you sure you want to KPI?",
                    yesFunction: () {
                  addEmployeeTemplate();
                }, noFunction: () {
                  _existingSuggetionList.clear();
                  Navigator.pop(context);
                  Navigator.pop(context);
                  setState(() {});
                });
              } else {
                Navigator.pop(context);
              }
              return true;
            },
            child:  Scaffold(
              appBar: customAppBar(context, "KRA's Suggetion", onBackPress: () {
                  if (_existingSuggetionList.isNotEmpty) {
                    commonAlertDialogWithYesNo(context, AllString.warning,
                        "Are you sure you want to KRA?", yesFunction: () {
                      addEmployeeTemplate();
                    }, noFunction: () {
                      _existingSuggetionList.clear();
                      Navigator.pop(context);
                      Navigator.pop(context);
                      setState(() {});
                    });
                  } else {
                    Navigator.pop(context);
                  }
                }),
              body: Container(
                child: Container(
                  child: ListView(
                    physics: BouncingScrollPhysics(),
                    children: [
                      // Container(
                      //   height: screenWidth * 0.1,
                      //   alignment: Alignment.center,
                      //   width: screenWidth,
                      //   decoration: BoxDecoration(
                      //       color: AllColor.lightBlack,
                      //       shape: BoxShape.rectangle,
                      //       borderRadius: BorderRadius.only(
                      //           topLeft: Radius.circular(16),
                      //           topRight: Radius.circular(16.0)),
                      //       boxShadow: <BoxShadow>[
                      //         BoxShadow(
                      //           color: Colors.black26,
                      //           blurRadius: 0.0,
                      //           offset: Offset(0.0, 0.0),
                      //         ),
                      //       ]),
                      //   child: normalText("KRA's Suggetion", color: AllColor.black),
                      // ),
                      Container(
                        height: screenWidth * 0.1,
                        alignment: Alignment.center,
                        width: screenWidth,
                        decoration: BoxDecoration(
                            color: AllColor.lightBlack,
                            shape: BoxShape.rectangle,
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 0.0,
                                offset: Offset(0.0, 0.0),
                              ),
                            ]),
                        child: normalText("Add Manually", color: AllColor.black),
                      ),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            "Type Here*",
                            _commentTextEditingController,
                            2,
                            100,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(
                              vertical: screenWidth * 0.015,
                              horizontal: screenWidth * 0.03),
                          child: button(
                            context,
                            width: screenWidth * 0.4,
                            function: () {
                              if (_commentTextEditingController.text.isNotEmpty) {
                                Navigator.pop(context);
          
                                addTemplate(_commentTextEditingController.text);
                              } else {
                                Navigator.pop(context);
                              }
                            },
                            color: AllColor.primaryColor,
                            textColor: AllColor.white,
                            text: AllString.add,
                          )),
                      Container(
                        width: screenWidth,
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03,
                            vertical: screenWidth * 0.015),
                        decoration: BoxDecoration(
                            color: AllColor.lightGrey,
                            borderRadius: BorderRadius.circular(10)),
                        height: screenWidth * 0.1,
                        child: Center(
                          child: TextField(
                            focusNode: _focusNode,
                            controller: _searchTextEditingController,
                            onChanged: onSearchTextChanged,
                            decoration: InputDecoration(
                                suffixIcon: _searchTextEditingController
                                        .text.isEmpty
                                    ? Container(
                                        width: screenWidth * 0,
                                      )
                                    : GestureDetector(
                                        onTap: () {
                                          _searchTextEditingController.clear();
                                          _focusNode.unfocus();
                                          onSearchTextChanged('');
                                        },
                                        child: Icon(Icons.close,
                                            color: AllColor.black),
                                      ),
                                prefixIcon: Icon(
                                  Icons.search,
                                  color: AllColor.black,
                                ),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: screenWidth * 0.03,
                                    vertical: screenWidth * 0.03),
                                isDense: true,
                                hintStyle: normalTextStyle(color: AllColor.black),
                                hintText: "Template name"),
                          ),
                        ),
                      ),
                      Container(
                          child: _searchResult.length != 0 ||
                                  _searchTextEditingController.text.isNotEmpty
                              ? ListView.builder(
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: _searchResult.length,
                                  itemBuilder: (context, index) =>
                                      customListItemForSuggetion(
                                          _searchResult[index], index))
                              : _suggetionList.isEmpty
                                  ? commonNoDataFound()
                                  : ListView.builder(
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      itemCount: _suggetionList.length,
                                      itemBuilder: (context, index) =>
                                          customListItemForSuggetion(
                                              _suggetionList[index], index))),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
        context: context);
  }

  addTemplate(String kra) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "userLoginId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "kraTemplete": kra,
        "individualId": singleTeamMember["individualId"],
      };
      apiPostRequestWithHeader(
              data, AllUrls.addKraTemplateForCompany, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.pop(context);
              fetchKraSuggetions();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  addEmployeeTemplate() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "userLoginId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": singleTeamMember["individualId"],
        "kraTempleteData": _existingSuggetionList
      };
      apiPostRequestWithHeader(
              data, AllUrls.addEmployeeKraTemplate, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.pushReplacement(context,
                  CupertinoPageRoute(builder: (context) => TeamKraAndKpi(scheduledate:widget.scheduledate, permission:widget.permission,kraReviewScheduleId:widget.kraReviewScheduleId)));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  fetchKraSuggetions() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "departmentId": "",
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": singleTeamMember["individualId"],
      };
      apiPostRequestWithHeader(
              data, AllUrls.getCompanyKraTemplate, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _suggetionList.clear();
            _addSuggetionList.clear();

            if (jsonData["kraTemplateData"] == "") {
              _suggetionList = [];
              _addSuggetionList = [];
            } else {
              _suggetionList = jsonData["kraTemplateData"];
              _addSuggetionList = jsonData["kraTemplateData"];
              Future.delayed(Duration(milliseconds: 800), () {
                setInExisting();
              });
            }

            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  setInExisting() {
    setState(() {});
    for (int i = 0; i < _addSuggetionList.length; i++) {
      for (int j = 0; j < widget.userKraList.length; j++) {
        if (widget.userKraList[j]["companyKraTemplateId"] ==
            _addSuggetionList[i]["companyKraTemplateId"]) {
          _suggetionList.removeAt(i);
          // _existingSuggetionList.add(element);
        }
      }
    }
    // _existingSuggetionList
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    _suggetionList.forEach((searchDetails) {
      if (searchDetails["kraTemplate"].toString().toLowerCase().contains(text))
        _searchResult.add(searchDetails);
      setState(() {});
      AppBuilder.of(context)!.rebuild();
    });

    setState(() {});
  }
}
