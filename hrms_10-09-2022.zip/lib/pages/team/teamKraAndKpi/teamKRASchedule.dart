import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myPerformance/viewPerformance.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamDashboard/teamDashboard.dart';
import 'package:hr/pages/team/teamKraAndKpi/addKra.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamKraAndKpi.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamkraAllTask.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customIconRowDetails.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/customRowTeamKraKpiDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamKRASchedule extends StatefulWidget {
  const TeamKRASchedule({
    Key? key,
  }) : super(key: key);
  @override
  _TeamKRAScheduleState createState() => _TeamKRAScheduleState();
}

class _TeamKRAScheduleState extends State<TeamKRASchedule> {
  bool loading = false;
  List _scheduleList = [];

  @override
  void initState() {
    super.initState();
    fetchScheduleList();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => TeamDashboard()));
        return true;
      },
      child: Scaffold(
          backgroundColor: AllColor.white,
          appBar: customAppBar(context, "KRA Schedule", onBackPress: () {
            Navigator.of(context).push(
                CupertinoPageRoute(builder: (context) => TeamDashboard()));
          }),
          body: LoadingOverlay(
            isLoading: loading,
            opacity: 0.5,
            color: AllColor.black,
            progressIndicator: commonLoader(),
            child: Container(
              width: screenWidth,
              height: screenHeight,
              decoration: customBackgroundGradient(),
              child: Stack(
                children: [
                  Positioned(
                      bottom: 0,
                      child: Container(
                        height: screenWidth * 0.1,
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.04,
                        ),
                        width: screenWidth,
                        child: Container(
                          height: screenWidth * 0.1,
                          decoration: BoxDecoration(
                              border: Border(
                                  bottom:
                                      BorderSide(color: AllColor.lightBlack))),
                          margin: AllMargin.customBottomSmall(),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                child: normalText("Index: ",
                                    color: AllColor.black),
                              ),
                              Container(
                                margin: AllMargin.customHorizontal(),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  details(
                                    Color(0xffffffff),
                                    "Only View",
                                  ),
                                  Container(
                                    margin: AllMargin.customHorizontal(),
                                  ),
                                  details(
                                    Color(0xffa5d6a7),
                                    "Editable",
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      )),
                  _scheduleList.isEmpty
                      ? commonNoDataFound()
                      : Container(
                          margin: EdgeInsets.only(bottom: screenWidth * 0.11),
                          child: ListView.builder(
                              padding:
                                  EdgeInsets.only(bottom: screenWidth * 0.03),
                              physics: BouncingScrollPhysics(),
                              itemCount: _scheduleList.length,
                              itemBuilder: (context, index) =>
                                  customListItem(_scheduleList[index], index))),
                ],
              ),
            ),
          )),
    );
  }

  details(Color color, String text) {
    return Container(
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
                border: Border.all(color: AllColor.greyColor),
                color: color,
                borderRadius: BorderRadius.circular(5)),
            width: screenWidth * 0.05,
            height: screenWidth * 0.03,
            margin: AllMargin.customRightSmall(),
          ),
          smallText(text, color: AllColor.black.withOpacity(0.6))
        ],
      ),
    );
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => TeamKraAndKpi(
                  scheduledate: itemData["scheduleDate"].toString(),
                  kraReviewScheduleId:
                      itemData["kraReviewScheduleId"].toString(),
                  permission: ((DateTime.parse(
                                      itemData["scheduleDate"].toString())
                                  .year ==
                              DateTime.now().year) &&
                          (DateTime.parse(itemData["scheduleDate"].toString())
                                  .month ==
                              DateTime.now().month) &&
                          (DateTime.parse(itemData["scheduleDate"].toString())
                                  .day ==
                              DateTime.now().day))
                      ? true
                      : false,
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        child: Container(
          padding: AllMargin.customMarginCardItem(),
          decoration: BoxDecoration(
              color:
                  ((DateTime.parse(itemData["scheduleDate"].toString()).year ==
                              DateTime.now().year) &&
                          (DateTime.parse(itemData["scheduleDate"].toString())
                                  .month ==
                              DateTime.now().month) &&
                          (DateTime.parse(itemData["scheduleDate"].toString())
                                  .day ==
                              DateTime.now().day))
                      ? Color(0xffa5d6a7)
                      : AllColor.white,
              borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customIconRowDetails(
                      width: screenWidth * 0.8,
                      icon: Icons.date_range_rounded,
                      value: convertStringToDate(
                          DateTime.parse(itemData["scheduleDate"].toString())),
                      displayFullValue: true),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchScheduleList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId": singleTeamMember["individualId"],
        "individualTypeId": singleTeamMember["individualTypeId"],
      };

      log(data.toString());
      apiPostRequestWithHeader(
              data, AllUrls.getKraSchedule, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _scheduleList.clear();

            if (jsonData["kraScheduleData"] == "") {
              _scheduleList = [];
            } else {
              _scheduleList = jsonData["kraScheduleData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
