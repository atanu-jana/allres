import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/myPerformance/myPerformanceReviewDetails.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/team/teamKraAndKpi/teamViewKpi.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamKpiReview extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final Map<String, dynamic> parentSingleData;
  final bool visible;
  final Function() callBack;
  const TeamKpiReview(
      {Key? key,
      required this.singleData,
      required this.parentSingleData,
      required this.callBack,
      required this.visible})
      : super(key: key);

  @override
  _TeamKpiReviewState createState() => _TeamKpiReviewState();
}

class _TeamKpiReviewState extends State<TeamKpiReview> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _amountTextEditingController = TextEditingController();
  FocusNode _amountFocusNode = FocusNode();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.kpiPerformanceReview),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
            width: screenWidth,
            height: screenHeight,
                                  decoration:customBackgroundGradient(),

            child: ListView(
              children: [
                Container(
                  padding: EdgeInsets.all(1),
                  decoration: customCardItemGradinet(),
                  margin: customMarginCardItem(),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.03,
                    ),
                    decoration: BoxDecoration(
                        color: AllColor.lightBlueGrey,
                        borderRadius: BorderRadius.circular(7)),
                    width: screenWidth,
                    alignment: Alignment.centerLeft,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: headingText(
                              widget.singleData["kpiTemplate"].toString(),
                              color: AllColor.primaryDeepColor),
                        ),
                        Container(
                          child: smallText(
                              "Total Marks  : " +
                                  widget.singleData["marks"].toString(),
                              color: AllColor.black),
                        ),
                        widget.singleData["reviewStatus"].toString() == "3"
                            ? Container(
                                child: smallText(
                                    "Marks Obtain  : " +
                                        widget.singleData["marksObtain"]
                                            .toString(),
                                    color: AllColor.black),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ),
                widget.singleData["reviewStatus"].toString() == "3"
                    ? Container()
                    : Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03,
                            vertical: screenWidth * 0.01),
                        alignment: Alignment.centerLeft,
                        child: normalText(AllString.scoreObtain + ": ",
                            color: AllColor.black),
                      ),
                widget.singleData["reviewStatus"].toString() == "3"
                    ? Container()
                    : Container(
                        child: RoundedInputField(
                        controller: _amountTextEditingController,
                        focusNode: _amountFocusNode,
                        textInputAction: TextInputAction.next,
                        textInputType: TextInputType.number,
                        hintText: AllString.scoreObtainHint,
                        errorText: "",
                        showToolTip: false,
                        icon: LineIcons.handHoldingUsDollar,
                        onchangeFunction: (String val) {
                          if (val.isNotEmpty &&
                              int.parse(val) > widget.singleData["marks"]) {
                            _amountTextEditingController.text = "";
                            commonAlertDialog(context, AllString.warning,
                                AllString.marksValueComment);
                          }
                          setState(() {});
                        },
                      )),
                widget.singleData["reviewStatus"].toString() == "3"
                    ? Container()
                    : Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03,
                            vertical: screenWidth * 0.01),
                        alignment: Alignment.centerLeft,
                        child: normalText(AllString.reviewComments + ": ",
                            color: AllColor.black),
                      ),
                widget.singleData["reviewStatus"].toString() == "3"
                    ? Container()
                    : Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.comment + "*",
                            _commentTextEditingController,
                            2,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                widget.singleData["reviewStatus"].toString() == "3"
                    ? Container()
                    : Container(
                        child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            alignment: Alignment.centerLeft,
                            child: button(context, function: () {
                              if (_amountTextEditingController.text.isEmpty) {
                                commonAlertDialog(context, AllString.warning,
                                    AllString.enterMarksComment);
                              } else if (_commentTextEditingController
                                  .text.isEmpty) {
                                commonAlertDialog(context, AllString.warning,
                                    AllString.enterComment);
                              } else {
                                employeeKpiReviewApi();
                              }
                            },
                             color: AllColor.primaryColor,
                                textColor: AllColor.white,
                                text: AllString.submit,
                                width: screenWidth / 2.5),
                          ),
                        ],
                      )),
              ],
            )),
      ),
    );
  }

  employeeKpiReviewApi() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });

      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "employeeKpiId": widget.singleData["employeeKpiId"].toString(),
        "marks": _amountTextEditingController.text,
        "reviewComment": _commentTextEditingController.text,
        "individualId": singleTeamMember["individualId"],
        "userLoginId": loginUserId.toString(),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getEmployeeKpiReview, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.pushReplacement(
                  context,
                  CupertinoPageRoute(
                      builder: (context) => TeamViewKpi(
                            singleData: widget.parentSingleData,
                            visible: widget.visible,
                            callBack: widget.callBack,
                          )));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
