import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpenseBody.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentBody.dart';
import 'package:hr/pages/publicHoliday/publicHolidayBody.dart';
import 'package:hr/pages/recordAttendance/myAttendanceDetails.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customCatender.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamAttendance extends StatefulWidget {
  const TeamAttendance({
    Key? key,
  }) : super(key: key);
  @override
  _TeamAttendanceState createState() => _TeamAttendanceState();
}

class _TeamAttendanceState extends State<TeamAttendance> {
  bool loading = false;
  int topMonth = DateTime.now().month - 1;
  int topYear = DateTime.now().year;
  List _attendanceList = [];
  @override
  void initState() {
    super.initState();
    fetchAttendance();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.attendance),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                        decoration:customBackgroundGradient(),
            
            child: ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Container(
                height: screenWidth * 0.1,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        if (month[topMonth] != month[0]) {
                          topMonth = topMonth - 1;
                          topYear = topYear;
                          setState(() {});
                          fetchAttendance();
                        } else {
                          topMonth = 11;

                          topYear = topYear - 1;
                          setState(() {});
                          fetchAttendance();
                        }
                      },
                      child: Container(
                          width: screenWidth * 0.05,
                          margin: EdgeInsets.only(left: screenWidth * 0.03),
                          child: smallIcon(Icons.arrow_back_ios_outlined,
                              color: AllColor.primaryColor)),
                    ),
                    Container(
                      child: Row(
                        children: [
                          normalText(month[topMonth],
                              color: AllColor.black, letterSpacing: 1.5),
                          Container(
                            width: screenWidth * 0.03,
                          ),
                          normalText(topYear.toString(), color: AllColor.black),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (topYear != DateTime.now().year ||
                            (month[topMonth] !=
                                month[DateTime.now().month - 1])) {
                          if (month[topMonth] != month[11]) {
                            topMonth = topMonth + 1;
                            topYear = topYear;
                            setState(() {});
                            fetchAttendance();
                          } else {
                            topMonth = 0;

                            topYear = topYear + 1;
                            setState(() {});
                            fetchAttendance();
                          }
                        }
                        // if ((month[(.month + 1) - 1] !=
                        //     month[(.month) - 1])) if (month[
                        //         (.month - 1) - 1] !=
                        //     month[0]) {
                        //   topMonth = month[(.month - 1) - 1];
                        //   topYear = (.year).toString();
                        //   setState(() {});
                        // } else {
                        //   topMonth = month[(.month - 1) - 1];
                        //   topYear = (.year - 1).toString();
                        //   setState(() {});
                        // }
                      },
                      child: Container(
                          width: screenWidth * 0.05,
                          margin: EdgeInsets.only(right: screenWidth * 0.03),
                          child: smallIcon(Icons.arrow_forward_ios_outlined,
                              color: month[topMonth] ==
                                          month[DateTime.now().month - 1] &&
                                      topYear == DateTime.now().year
                                  ? AllColor.greyColor
                                  : AllColor.primaryColor)),
                    ),
                  ],
                ),
              ),
              subtitle: Container(
                height: screenHeight - 100,
                child: ListView.builder(
                    padding: EdgeInsets.only(bottom: screenWidth * 0.08),
                    physics: BouncingScrollPhysics(),
                    itemCount: _attendanceList.length,
                    itemBuilder: (context, index) =>
                        customMyAttendanceItem(_attendanceList[index])),
              ),
            ),
          ),
        ));
  }

  customMyAttendanceItem(Map<String, dynamic> itemData) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => MyAttendanceDetails(
              individualId: singleTeamMember["individualId"].toString(),
                  myAddtendance: itemData,
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: customMarginCardItem(),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Container(
                width: screenWidth * 0.6,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    customRowDetails(
                        width: screenWidth * 0.6,
                        widthTitle: screenWidth * 0.28,
                        title: "Day Start",
                        value: fullTimeFormatter.format(
                            DateTime.parse(itemData["inTime"]).toLocal())),
                    customRowDetails(
                        width: screenWidth * 0.6,
                        widthTitle: screenWidth * 0.28,
                        title: "Day End",
                        value: checkApiValueValid(itemData["outTime"])
                            ? AllString.continuee
                            : fullTimeFormatter.format(
                                DateTime.parse(itemData["outTime"]).toLocal())),
                    customRowDetails(
                        width: screenWidth * 0.6,
                        widthTitle: screenWidth * 0.28,
                        title: "Working Hours",
                        value: itemData["spentHours"].toString()),
                    // customRowDetails(
                    //     width: screenWidth * 0.6,
                    //     widthTitle: screenWidth * 0.3,
                    //     title: "Break",
                    //     value: "2Hr 30Mins"),
                    // customRowDetails(
                    //     width: screenWidth * 0.6,
                    //     widthTitle: screenWidth * 0.3,
                    //     title: "Total Working Hrs",
                    //     value: "6Hr 30Mins"),
                  ],
                ),
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchAttendance() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        
         "individualName": "",
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,      
              "individualId": singleTeamMember["individualId"],

        "userId": singleTeamMember["userId"],
        "fromdate": DateTime(topYear, topMonth + 1, 01).toString(),
        "todate": DateTime(topYear, topMonth + 1, (topMonth + 1) == 1 ? 28 : 30)
            .toString()
      };

      apiPostRequestWithHeader(
              data, AllUrls.getAttendenceList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          log(jsonData.toString());
          if (checkApiResponseSuccessOrNot(jsonData)) {
           if (jsonData["attendanceData"] == "") {
              _attendanceList = [];
            } else {
              _attendanceList = jsonData["attendanceData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}
