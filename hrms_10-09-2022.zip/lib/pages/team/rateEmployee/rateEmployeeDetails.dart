import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/team/rateEmployee/shortListing.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class RateEmployeeDetails extends StatefulWidget {
  const RateEmployeeDetails({
    Key? key,
  }) : super(key: key);
  @override
  _RateEmployeeDetailsState createState() => _RateEmployeeDetailsState();
}

class _RateEmployeeDetailsState extends State<RateEmployeeDetails> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.rateEmployee),
        body: LoadingOverlay(
              isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
            child: Container(
              width: screenWidth,
              height: screenHeight,
                                     decoration:customBackgroundGradient(),

              child: ListView(
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                children: [
                  customDetailsView(
                      AllString.reimbursement, AllString.reimbursement, 4),
                  customDetailsView(
                      "Filing Procedure", "Roals & Responsibilities", 2),
                  customDetailsView(
                      AllString.attendance, "Roals & Responsibilities", 2),
                  customDetailsView(
                      "Performance Rating", "Roals & Responsibilities", 1),
                ],
              ),
            )));
  }

  customDetailsView(String text1, String text2, int totalItem) {
    return Container(
      decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: AllColor.lightGrey))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          customheader(text1),
          customColorheader(text2),
          Container(
            child: ListView.builder(
                shrinkWrap: true,
                padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                physics: BouncingScrollPhysics(),
                itemCount: totalItem,
                itemBuilder: (context, index) => customListItem(index)),
          ),
        ],
      ),
    );
  }

  customListItem(int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => ShortListing()));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        // decoration: customCardItemGradinet(),

        height: screenWidth * 0.08,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: index % 2 != 0 ? AllColor.lightBlueGrey : AllColor.white,
              borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                child: normalText("Short listing 30 Resume",
                    color: AllColor.black),
              ),
              Container(
                  child: Row(
                children: [
                  Container(
                    child: normalText("50", color: AllColor.black),
                  ),
                  Container(
                      width: screenWidth * 0.05,
                      margin: EdgeInsets.only(right: screenWidth * 0.02),
                      child: smallIcon(Icons.arrow_forward_ios,
                          color: AllColor.greyColor))
                ],
              )),
            ],
          ),
        ),
      ),
    );
  }

  customheader(String text) {
    return Container(
      height: screenWidth * 0.1,
      padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
      decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: AllColor.greyColor))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child: headingText(text, color: AllColor.primaryDeepColor),
          ),
        ],
      ),
    );
  }

  customColorheader(String text) {
    return Container(
      height: screenWidth >= 600 ? screenWidth * 0.1 : screenWidth * 0.13,
      padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
      decoration: BoxDecoration(
        color: AllColor.tableBackground,
        // border: Border(bottom: BorderSide(color: AllColor.black))
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            width: screenWidth / 2.5,
            alignment: Alignment.centerLeft,
            child: normalText(text, color: AllColor.white),
          ),
          Container(
            width: screenWidth / 2.5,
            alignment: Alignment.center,
            child: normalText("Total Points", color: AllColor.white),
          ),
        ],
      ),
    );
  }
}
