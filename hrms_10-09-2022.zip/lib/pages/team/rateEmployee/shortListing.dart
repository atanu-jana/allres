import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animation_progress_bar/flutter_animation_progress_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:syncfusion_flutter_charts/sparkcharts.dart';

class ShortListing extends StatefulWidget {
  const ShortListing({
    Key? key,
  }) : super(key: key);
  @override
  _ShortListingState createState() => _ShortListingState();
}

class _ShortListingState extends State<ShortListing> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();
  TextEditingController _pointTextEditingController = TextEditingController();
  FocusNode _pointFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.shortListing30Resume),
      body: LoadingOverlay(
            isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
        child: Container(
            width: screenWidth,
            height: screenHeight,
                                   decoration:customBackgroundGradient(),

            child: ListView(
              children: [
                Container(
                  padding: EdgeInsets.all(1),
                  decoration: customCardItemGradinet(),
                  margin: customMarginCardItem(),
                  child: Container(
                  
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.01,
                    ),
                    decoration: BoxDecoration(
                        color: AllColor.white,
                        borderRadius: BorderRadius.circular(7)),
                    width: screenWidth,
                    alignment: Alignment.centerLeft,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          child: headingText(AllString.shortListing30Resume,
                              color: AllColor.primaryDeepColor),
                        ),
                        Container(
                          child: normalText("Total Points: 10",
                              color: AllColor.black),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.01),
                  alignment: Alignment.centerLeft,
                  child: normalText(AllString.pointObtain + ": ",
                      color: AllColor.black),
                ),
                Container(
                  margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.0,
                    horizontal: screenWidth * 0.03,
                  ),
                  child: Center(
                    child: RoundedInputField(
                      controller: _pointTextEditingController,
                      errorText: '',
                      focusNode: _pointFocusNode,
                      hintText: AllString.pleaseEnterPoints,
                      icon: FontAwesomeIcons.coins,
                      onchangeFunction: (String val) {},
                      showToolTip: false,
                      textInputAction: TextInputAction.next,
                      textInputType: TextInputType.number,
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.01),
                  alignment: Alignment.centerLeft,
                  child: normalText(AllString.comments + ": ",
                      color: AllColor.black),
                ),
                Container(
                  margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.0,
                    horizontal: screenWidth * 0.03,
                  ),
                  child: Center(
                    child: textAreaField(
                      context,
                      AllString.comment + "*",
                      _commentTextEditingController,
                      2,
                      200,
                      TextInputAction.done,
                      TextInputType.text,
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.03,
                        vertical: screenWidth * 0.03),
                    alignment: Alignment.center,
                    child: Container(
                      child: button(
                        context,
                        function: () {
                          if (_pointTextEditingController.text.isEmpty) {
                            commonAlertDialog(context, AllString.warning,
                                AllString.pleaseEnterPoints);
                          } else if (_commentTextEditingController
                              .text.isEmpty) {
                            commonAlertDialog(context, AllString.warning,
                                AllString.enterComment);
                          }
                        },color: AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.submit,
                      ),
                      // child: customAnimatedButton(context, function: (_) {
                      //   if (_pointTextEditingController.text.isEmpty) {
                      //     commonAlertDialog(context, AllString.warning,
                      //         AllString.pleaseEnterPoints);
                      //   } else if (_commentTextEditingController.text.isEmpty) {
                      //     commonAlertDialog(context, AllString.warning,
                      //         AllString.enterComment);
                      //   }
                      // },
                      //     color: AllColor.primaryColor,
                      //     deepColor: AllColor.primaryDeepColor,
                      //     textColor: AllColor.white,
                      //     text: AllString.submit,
                      //     width: screenWidth),
                    )),
              ],
            )),
      ),
    );
  }
}
