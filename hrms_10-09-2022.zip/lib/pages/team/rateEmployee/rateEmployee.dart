import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/team/rateEmployee/rateEmployeeDetails.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class RateEmployee extends StatefulWidget {
  const RateEmployee({
    Key? key,
  }) : super(key: key);
  @override
  _RateEmployeeState createState() => _RateEmployeeState();
}

class _RateEmployeeState extends State<RateEmployee> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.rateEmployee),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                    decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Container(
                  child: ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: 2,
                      itemBuilder: (context, index) => customRateItem(index)),
                ),
              ],
            ),
          ),
        ));
  }

  customRateItem(int index) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => RateEmployeeDetails()));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth * 0.1,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                child: normalText(index == 0 ? "Marketing" : "Hr",
                    color: AllColor.black),
              ),
              Container(
                  child: Row(
                children: [
                  Container(
                    child:
                        normalText("Total Points: 50", color: AllColor.black),
                  ),
                  Container(
                      width: screenWidth * 0.05,
                      margin: EdgeInsets.only(right: screenWidth * 0.02),
                      child: smallIcon(Icons.arrow_forward_ios,
                          color: AllColor.greyColor))
                ],
              )),
            ],
          ),
        ),
      ),
    );
  }
}
