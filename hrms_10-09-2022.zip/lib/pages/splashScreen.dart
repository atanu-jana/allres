import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:package_info/package_info.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/authtication/signIn.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  //TODO: App Declaration Here
  AnimationController? _splashScreenController;
  Animation<double>? _animation;
  //int _duration = 7;//2
  @override
  void initState() {
    super.initState();

    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);
    getAppInfo();
    _splashScreenController = AnimationController(
      duration: const Duration(seconds: 1),//3
      vsync: this,
    )..repeat(reverse: true);
    _animation =
        CurvedAnimation(parent: _splashScreenController!, curve: Curves.easeIn);

    _splashScreenController!.forward().then((_) {
      currentScreenName = AllString.dashboard;
      setState(() {});
      // Future.delayed(Duration(milliseconds: _duration)).then((value) {
      loginUserId == "" || loginUserId == null
          ? Navigator.of(context).pushReplacement(
              CupertinoPageRoute(builder: (BuildContext context) => SignIn()))
          : Navigator.of(context).pushReplacement(
              CupertinoPageRoute(builder: (BuildContext context) => Home()));
      // });
    });
  }

  @override
  void dispose() {
    _splashScreenController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    screenWidth = MediaQuery.of(context).size.width;
    screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: AllColor.white,
      body: FadeTransition(
        opacity: _animation!,
        child: Container(
          height: screenHeight,
          width: screenWidth,
          color: AllColor.white,
          child: Stack(
            children: [
              Container(
                height: screenHeight,
                width: screenWidth,
                color: AllColor.white,
                child: Center(
                    child: sharedPreferences!
                              .getString(AllSharedPreferencesKey.companyLogo) ==
                          null ||
                      sharedPreferences!
                          .getString(AllSharedPreferencesKey.companyLogo)!
                          .isEmpty
                  ? Image.asset("assets/images/logo.png")
                  : Image.network(sharedPreferences!
                      .getString(AllSharedPreferencesKey.companyLogo)!))),
                //       Image.asset(
                //   "assets/images/logo.png",
                //   width: screenWidth * 0.8,
                //   height: screenWidth * 0.5,
                // )
              Positioned(
                bottom: 10,
                child: Container(
                  width: screenWidth,
                  child: Text(
                    AllString.versionNameWithVersion,
                    textAlign: TextAlign.center,
                    style: normalTextStyle(color: AllColor.primaryColor),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  //TODO: App methos Here
  getAppInfo() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();

    String appName = packageInfo.appName;
    String packageName = packageInfo.packageName;
    appVersion = packageInfo.version;
    String buildNumber = packageInfo.buildNumber;
    AllString.versionNameWithVersion=AllString.versionName+": "+appVersion;
    setState(() {});
    print(appName);
    print(packageName);
    print(appVersion);
    print(buildNumber);
  }
}


// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:smartcheck/main.dart';
// import 'package:smartcheck/pages/authtication/signIn.dart';
// import 'package:smartcheck/pages/dashboard/dashboard.dart';
// import 'package:smartcheck/res/allColors.dart';
// import 'package:smartcheck/res/allString.dart';

// class SplashScreen extends StatefulWidget {
//   @override
//   _SplashScreenState createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen>
//     with SingleTickerProviderStateMixin {
//   //TODO: App Declaration Here


//   AnimationController? _splashScreenController;
//   Animation? _zoomInAnimation;
//   int _duration = 2;
//   @override
//   void initState() {
//     super.initState();
//     _splashScreenController = AnimationController(
//         vsync: this, duration: Duration(seconds: _duration));
//     _zoomInAnimation = Tween<double>(begin: 60.0, end: 150.0)
//         .animate(_splashScreenController!);
//     _splashScreenController!.forward().then((_) {
//       AllString.currentPage = AllString.dashboard;
//       AllString.selectedPage = AllString.dashboard;
//       setState(() {});
//       // Future.delayed(Duration(milliseconds: _duration)).then((value) {
//       loginUserId == "" || loginUserId == null
//           ? Navigator.of(context).pushReplacement(
//               CupertinoPageRoute(builder: (BuildContext context) => SignIn()))
//           : Navigator.of(context).pushReplacement(CupertinoPageRoute(
//               builder: (BuildContext context) => DashBoard()));
//       // });
//     });
//   }

//   @override
//   void dispose() {
//     _splashScreenController!.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     screenWidth = MediaQuery.of(context).size.width;
//     screenHeight = MediaQuery.of(context).size.height;
//     // return Container(
//     // height: screenHeight,
//     // width: screenWidth,
//     // color: AllColor.white,
//     //   // child: FadeTransition(
//     //   //   opacity: _animation,
//     //   // child:  ScaleTransition(
//     //   //   scale: _animation,
//     //   // child: ScaleTransition(
//     //   //     scale: Tween(begin: 0.0, end: 2.0).animate(CurvedAnimation(
//     //   //         parent: _animationController!, curve: Curves.easeOutCirc)),
//     //   //     child: Center(
//     //   //         child: SizedBox(
//     //   //             height: screenHeight! * 0.1,
//     //   //             child: Image.asset("assets/images/logo.png")))),
//     // child:Center(
//     //         child: SizedBox(
//     //             height: screenHeight! * 0.1,
//     //             child: Image.asset("assets/images/logo.png"))),
//     // );
//     return Scaffold(
//       body: AnimatedBuilder(
//         animation: _zoomInAnimation!,
//         builder: (context, widget) {
//           return Container(
//             height: screenHeight,
//             width: screenWidth,
//             color: AllColor.white,
//             child: Stack(
//               children: [
//                 Center(
//                     child: SizedBox(
//                         height: _zoomInAnimation!.value,
//                         child: Image.asset("assets/images/appicon.png"))),
    
//                         // Positioned(
//                         //   bottom: 5,
//                         //   child:  Container(
//                         //     width: screenWidth,
//                         //     child: Text(
//                         //        AllString.versionName + ": "+"1_beta_b",
//                         //       // AllString.versionName + ": " + appVersion,
//                         //       textAlign: TextAlign.center,
//                         //       style: smallTextStyle(
//                         //         color: AllColor.deepGreen,
//                         //       ),
//                         //     ),
//                         //   ),)
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
//   //TODO: App methos Here

// }
