import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:loading_overlay/loading_overlay.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  //TODO: App Declaration Here
  int indexForBottomDetails = 0;
  Widget bottomDetailsWidget = Container();
  @override
  void initState() {
    super.initState();
    widgetBottomDetails();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.primaryDeepColor,
      appBar: customAppBarForBackHome(context, AllString.profile),
      body: WillPopScope(
        onWillPop: () async {
          return true;
        },
        child: LoadingOverlay(
          isLoading: false,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
            decoration: customBackgroundGradient(),
            child: SingleChildScrollView(
              physics: BouncingScrollPhysics(),
              child: Container(
                height: screenHeight * 1.1,
                color: AllColor.white,
                child: Column(
                  children: [
                    Container(
                        height: screenWidth * 0.47,
                        child: Stack(
                          children: [
                            Container(
                              height: screenWidth * 0.4,
                              color: AllColor.primaryDeepColor,
                            ),
                            Positioned(
                                top: screenWidth * 0.15,
                                left: 0,
                                right: 0,
                                child: Center(child: topProfileCard())),
                            Positioned(
                                top: screenWidth * 0.03,
                                child: Container(
                                  width: screenWidth,
                                  alignment: Alignment.center,
                                  child: Container(
                                      margin: EdgeInsets.symmetric(
                                          horizontal: screenWidth * 0.05),
                                      width: screenWidth * 0.22,
                                      height: screenWidth * 0.22,
                                      padding: EdgeInsets.all(7),
                                      decoration: BoxDecoration(
                                          boxShadow: [
                                            BoxShadow(
                                              color:
                                                  Colors.grey.withOpacity(0.5),
                                              spreadRadius: 2,
                                              blurRadius: 7,
                                              offset: Offset(0,
                                                  3), // changes position of shadow
                                            ),
                                          ],
                                          color: AllColor.white,
                                          borderRadius:
                                              BorderRadius.circular(1000),
                                          border: Border.all(
                                              color: AllColor.white, width: 5)),
                                      child: sharedPreferences!
                                                  .getString(
                                                      AllSharedPreferencesKey
                                                          .image)!
                                                  .isEmpty ||
                                              sharedPreferences!.getString(
                                                      AllSharedPreferencesKey
                                                          .image)! ==
                                                  "null"
                                          // ? Icon(Icons.person,
                                          //     color: AllColor.primaryColor)
                                          ?  Center(
                                                  child:   Image.asset("assets/images/defaultUser.png"),
                                                )
                                          : ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(1000),
                                              child: CachedNetworkImage(
                                                  width: screenWidth * 0.22,
                                                  height: screenWidth * 0.22,
                                                  fit: BoxFit.cover,
                                                  placeholder: (_, __) {
                                                    return Center(
                                                      child:
                                                          CircularProgressIndicator(),
                                                    );
                                                  },
                                                  errorWidget: (_, __, ___) {
                                                    return Center(
                                                      child:  Image.asset("assets/images/defaultUser.png"),
                                                    );
                                                  },
                                                  imageUrl: sharedPreferences!
                                                      .getString(
                                                          AllSharedPreferencesKey
                                                              .image)!),
                                            )),
                                )),
                          ],
                        )),
                    customTabBar(),
                    SizedBox(
                      height: screenWidth * 0.05,
                    ),
                    bottomDetailsWidget
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  //TODO: App Method Here

  customCardRowDetails(IconData icon, String title, value) {
    return Container(
      width: screenWidth * 0.6,
      margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          normalIcon(icon, color: AllColor.primaryColor),
          Container(
            margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
          ),
          normalText(value, color: AllColor.black)
        ],
      ),
    );
  }

  customTextField(
      String title,
      TextEditingController controller,
      TextInputAction textInputAction,
      TextInputType textInputType,
      int maxLength) {
    return Container(
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenWidth * 0.001),
      child: TextFormField(
        controller: controller,
        maxLength: maxLength,
        keyboardType: textInputType,
        textInputAction: textInputAction,
        decoration: InputDecoration(
          border: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(5.0)),
              borderSide:
                  BorderSide(color: AllColor.primaryColor.withOpacity(0.3))),
          filled: true,
          contentPadding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
          hintText: title,
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(5.0)),
              borderSide: BorderSide(color: AllColor.primaryColor)),
        ),
      ),
    );
  }

  widgetBottomDetails() {
    if (indexForBottomDetails == 0) {
      bottomDetailsWidget = Container(
        margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // customProfileRow(
            //   AllString.branch,
            //   sharedPreferences!
            //           .getString(AllSharedPreferencesKey.branchName)!
            //           .isEmpty
            //       ? AllString.na
            //       : sharedPreferences!
            //           .getString(AllSharedPreferencesKey.branchName)!,
            // ),
            customProfileRow(
              AllString.sponsor,
              sharedPreferences!
                      .getString(AllSharedPreferencesKey.companyName)!
                      .isEmpty
                  ? AllString.na
                  : sharedPreferences!
                      .getString(AllSharedPreferencesKey.companyName)!,
            ),
            customProfileRow(
                AllString.employeeType,
                sharedPreferences!
                        .getString(AllSharedPreferencesKey.userRoleName)!
                        .isEmpty
                    ? AllString.na
                    : sharedPreferences!
                        .getString(AllSharedPreferencesKey.userRoleName)!, ),
            customProfileRow(
                AllString.designation,
                sharedPreferences!
                        .getString(AllSharedPreferencesKey.designation)!
                        .isEmpty
                    ? AllString.na
                    : sharedPreferences!
                        .getString(AllSharedPreferencesKey.designation)!,
                bottomborder: false),
            // customProfileRow(AllString.reportedToName, "HR",
            //     bottomborder: false),
          ],
        ),
      );
    } else {
      bottomDetailsWidget = Container(
        margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            customProfileRow(
              AllString.contactNo,
              sharedPreferences!
                      .getString(AllSharedPreferencesKey.contact1)!
                      .isEmpty
                  ? AllString.na
                  : sharedPreferences!
                      .getString(AllSharedPreferencesKey.contact1)!,
            ),
            customProfileRow(
              AllString.aContactNo2,
              sharedPreferences!
                      .getString(AllSharedPreferencesKey.contact2)!
                      .isEmpty
                  ? AllString.na
                  : sharedPreferences!
                      .getString(AllSharedPreferencesKey.contact2)!,
            ),
            // customProfileRow(
            //   AllString.emergencyNumber,
            //   "9865221234",
            // ),
            customProfileRow(
              AllString.emailId,
              sharedPreferences!
                      .getString(AllSharedPreferencesKey.email)!
                      .isEmpty
                  ? AllString.na
                  : sharedPreferences!
                      .getString(AllSharedPreferencesKey.email)!,
            ),
            customProfileRow(
              AllString.dateOfBirth,
              checkApiValueValid(sharedPreferences!
                      .getString(AllSharedPreferencesKey.dob)!)
                  ? AllString.na
                  :convertStringToDate(DateTime.parse(sharedPreferences!
                      .getString(AllSharedPreferencesKey.dob)!)) ,
            ),
            // customProfileRow(
            //   AllString.gender,
            //   "Female",
            // ),
            // customProfileRow(
            //   AllString.nationality,
            //   "Indian",
            // ),
            customProfileRow(
                AllString.fullAddress,
                sharedPreferences!
                        .getString(AllSharedPreferencesKey.address)!
                        .isEmpty
                    ? AllString.na
                    : sharedPreferences!
                        .getString(AllSharedPreferencesKey.address)!,
                bottomborder: false),
          ],
        ),
      );
    }
  }

  topProfileCard() {
    return Container(
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(
                    color: AllColor.greyColor.withOpacity(0.8), width: 1))),
        padding: EdgeInsets.only(bottom: screenWidth * 0.0),
        alignment: Alignment.center,
        height: screenWidth * 0.38,
        child: Card(
          color: AllColor.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 0,
          child: Container(
            width: screenWidth * 0.75,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  height: screenWidth * 0.02,
                ),
                headingText(
                    sharedPreferences!
                            .getString(AllSharedPreferencesKey.firstName)!
                            .isEmpty
                        ? AllString.na
                        : sharedPreferences!
                            .getString(AllSharedPreferencesKey.firstName)!,
                    color: AllColor.black),
                // midNormalText(
                //     sharedPreferences!
                //             .getString(AllSharedPreferencesKey.userRoleName)!
                //             .isEmpty
                //         ? AllString.na
                //         : sharedPreferences!
                //             .getString(AllSharedPreferencesKey.userRoleName)!,
                //     color: AllColor.greyColor),
                SizedBox(
                  height: screenWidth * 0.05,
                ),
                // normalText("Team Leader", color: AllColor.black),
                // normalText(
                //     "Joining Date: ${convertStringToDate(DateTime.now())}",
                //     color: AllColor.black),
                SizedBox(
                  height: screenWidth * 0.05,
                ),
              ],
            ),
          ),
        ));
  }

  customProfileRow(String title, String text, {bool bottomborder = true}) {
    return Container(
      width: screenWidth,
      margin: EdgeInsets.symmetric(vertical: screenWidth * 0.015),
      padding: EdgeInsets.only(bottom: screenWidth * 0.02),
      decoration: bottomborder
          ? BoxDecoration(
              border: Border(
                  bottom:
                      BorderSide(color: AllColor.greyColor.withOpacity(0.45))))
          : BoxDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(right: screenWidth * 0.02),
            width: screenWidth * 0.05,
            height: screenWidth * 0.05,
            child: Icon(
              Icons.arrow_forward_ios,
              color: AllColor.greyColor,
              size: screenWidth * 0.03,
            ),
          ),
          Container(
            width: screenWidth * 0.35,
            child: smallText(title + ":", color: AllColor.greyColor),
          ),
          Container(
            width: screenWidth * 0.45,
            child: normalText(text, color: AllColor.black),
          ),
        ],
      ),
    );
  }

  customTabBar() {
    return Container(
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              indexForBottomDetails = 0;
              setState(() {});

              widgetBottomDetails();
            },
            child: Container(
              width: screenWidth / 2,
              alignment: Alignment.center,
              height: screenWidth * 0.1,
              decoration: BoxDecoration(
                  color: AllColor.white,
                  border: Border(
                      bottom: BorderSide(
                          color: indexForBottomDetails == 0
                              ? AllColor.orange
                              : AllColor.lightGrey,
                          width: 3))),
              child: normalText(AllString.workDetails, color: AllColor.black),
            ),
          ),
          GestureDetector(
            onTap: () {
              indexForBottomDetails = 1;
              setState(() {});
              widgetBottomDetails();
            },
            child: Container(
              width: screenWidth / 2,
              alignment: Alignment.center,
              height: screenWidth * 0.1,
              decoration: BoxDecoration(
                  color: AllColor.white,
                  border: Border(
                      bottom: BorderSide(
                          color: indexForBottomDetails == 1
                              ? AllColor.orange
                              : AllColor.lightGrey,
                          width: 3))),
              child:
                  normalText(AllString.contactDetails, color: AllColor.black),
            ),
          ),
        ],
      ),
    );
  }
}
