import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/requestManagement/addRequest/addRequest.dart';
import 'package:hr/pages/requestManagement/pendingRequest/pendingRequest.dart';
import 'package:hr/pages/requestManagement/viewRequest/viewRequest.dart';
import 'package:hr/pages/workPlan/collaboration/collaboration.dart';
import 'package:hr/pages/workPlan/teamReport/teamReport.dart';
import 'package:hr/pages/workPlan/workPlanDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class RequestManagementBody extends StatefulWidget {
  @override
  _RequestManagementBodyState createState() => _RequestManagementBodyState();
}

class _RequestManagementBodyState extends State<RequestManagementBody> {
  bool loading = false;
  @override
  void initState() {
    super.initState();
    fetchMemberList();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: customBackgroundGradient(),
        child: Stack(
          children: [
            Container(
              width: screenWidth,
              height: screenHeight,
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                // crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // height: screenWidth * 0.45,

                  customCard("Add Request", Icons.add, () {
                    Navigator.of(context).push(
                        CupertinoPageRoute(builder: (context) => AddRequest()));
                  }, Colors.red, "assets/images/add.png"),
                  customCard("View Request", Icons.view_array, () {
                    Navigator.of(context).push(CupertinoPageRoute(
                        builder: (context) => ViewRequest()));
                  }, Colors.red, "assets/images/view.png"),
                  ((sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() ==
                              "17") ||
                          (sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() ==
                              "16") ||
                          (sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() ==
                              "19"))
                      ? customCard("Waiting for Approval", Icons.pending, () {
                          Navigator.of(context).push(CupertinoPageRoute(
                              builder: (context) => PendingRequest()));
                        }, Colors.red, "assets/images/wait.png")
                      : Container(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  customCard(String title, IconData icon, Function() onTap, Color color,
      String image) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: AllMargin.customMarginCardItem(),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
          elevation: 3,
          margin: AllMargin.customMarginCardItem(),
          child: Container(
            padding: AllMargin.customMarginCardItem(),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: screenWidth * 0.2,
                      width: screenWidth * 0.2,
                      child: Container(
                        margin: AllMargin.customVertical(),
                        height: screenWidth * 0.15,
                        width: screenWidth * 0.15,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(7)),
                        padding: AllMargin.customHorizontalSmall(),
                        child: Image.asset(
                          image,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Container(
                      margin: AllMargin.customHorizontal(),
                      child: headingText(title,
                          color: AllColor.black,
                          center: true,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                Container(
                  height: screenWidth * 0.1,
                  width: screenWidth * 0.1,
                  alignment: Alignment.center,
                  margin: AllMargin.customVertical(),
                  child: Icon(
                    Icons.arrow_circle_right_outlined,
                    color: AllColor.green,
                    size: screenWidth * 0.1,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      // child: Card(
      //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      //     color: color.withOpacity(0.3),
      //     elevation: 2,
      //     margin: EdgeInsets.symmetric(
      //         horizontal: screenWidth * 0.03, vertical: screenWidth * 0.03),

      //     child: Container(
      //       decoration: BoxDecoration(
      //           color: AllColor.black.withOpacity(0.1),
      //           image: DecorationImage(
      //               fit: BoxFit.cover,
      //               colorFilter: ColorFilter.mode(
      //                   AllColor.white.withOpacity(0.2), BlendMode.dstATop),
      //               image: AssetImage(image)),
      //           borderRadius: BorderRadius.circular(10)),
      //       padding: AllMargin.customMarginCardItem(),
      //       child: Column(
      //       crossAxisAlignment: CrossAxisAlignment.center,
      //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //       children: [
      // Column(
      //   mainAxisAlignment: MainAxisAlignment.start,
      //   crossAxisAlignment: CrossAxisAlignment.center,
      //   children: [
      //     Container(
      //       margin: AllMargin.customVertical(),
      //       height: screenWidth * 0.2,
      //       width: screenWidth * 0.2,
      //       decoration: BoxDecoration(
      //           color: color,
      //           borderRadius: BorderRadius.circular(7)),
      //       padding: AllMargin.customHorizontalSmall(),
      //       child: Icon(
      //         icon,
      //         color: AllColor.white,
      //         size: screenWidth * 0.1,
      //       ),
      //     ),
      //     Divider(),
      //     Container(
      //       margin: AllMargin.customHorizontal(),
      //       child: headingText(title,
      //           color: AllColor.black,
      //           center: true,
      //           fontWeight: FontWeight.bold),
      //     ),
      //   ],
      // ),
      // Container(
      //   height: screenWidth * 0.1,
      //   width: screenWidth * 0.1,
      //   alignment: Alignment.center,
      //   margin: AllMargin.customVertical(),
      //   child: Icon(
      //     Icons.arrow_circle_right_outlined,
      //     color: AllColor.green,
      //     size: screenWidth * 0.1,
      //   ),
      // ),
      //       ],
      //     ),
      //     ),
      //   ),

      // child: Container(
      //   width: screenWidth,
      //   margin: AllMargin.customMarginCardItemSame(),
      //   padding: AllMargin.customMarginCardItemSame(),
      //   alignment: Alignment.center,
      //   decoration: BoxDecoration(
      //       color: AllColor.white,
      //       boxShadow: [
      //         BoxShadow(
      //           color: Colors.grey.withOpacity(0.5),
      //           spreadRadius: 5,
      //           blurRadius: 7,
      //           offset: Offset(0, 3), // changes position of shadow
      //         ),
      //       ],
      //       border: Border.all(width: 0, color: AllColor.white),
      //       borderRadius: BorderRadius.circular(15)),
      // child: Column(
      //   crossAxisAlignment: CrossAxisAlignment.center,
      //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //   children: [
      //     Column(
      //       mainAxisAlignment: MainAxisAlignment.start,
      //       crossAxisAlignment: CrossAxisAlignment.center,
      //       children: [
      //         Container(
      //           margin: AllMargin.customVertical(),
      //           height: screenWidth * 0.2,
      //           width: screenWidth * 0.2,
      //           decoration: BoxDecoration(
      //               color: AllColor.primaryColor,
      //               borderRadius: BorderRadius.circular(7)),
      //           padding: AllMargin.customHorizontalSmall(),
      //           child: Icon(
      //             icon,
      //             color: AllColor.white,
      //             size: screenWidth * 0.1,
      //           ),
      //         ),
      //         Divider(),
      //         Container(
      //           margin: AllMargin.customHorizontal(),
      //           child: headingText(title,
      //               color: AllColor.black,
      //               center: true,
      //               fontWeight: FontWeight.bold),
      //         ),
      //       ],
      //     ),
      //     Container(
      //       height: screenWidth * 0.1,
      //       width: screenWidth * 0.1,
      //       alignment: Alignment.center,
      //       margin: AllMargin.customVertical(),
      //       child: Icon(
      //         Icons.arrow_circle_right_outlined,
      //         color: AllColor.green,
      //         size: screenWidth * 0.1,
      //       ),
      //     ),
      //   ],
      // ),
      // ),
    );
  }

  fetchMemberList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(data, AllUrls.memberList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          teamMemberList.clear();
          allTeamMemberList.clear();
          teamMemberList.add(AllString.select);
          allTeamMemberList.add(AllString.select);
          setState(() {
            loading = false;
          });
          if (jsonData["data"]["particularMember"].toString().isEmpty ||
              jsonData["data"]["particularMember"].toString() == "") {
            teamMemberList.clear();
          } else {
            List _tempList = jsonData["data"]["particularMember"];
            _tempList.forEach((element) {
              teamMemberList.add(element["individualName"].toString() +
                  AllString.splitText +
                  element["individualId"].toString());
            });
          }
          // * All Team Members
          if (jsonData["data"]["allMembers"].toString().isEmpty ||
              jsonData["data"]["allMembers"].toString() == "") {
            allTeamMemberList.clear();
          } else {
            List _tempList = jsonData["data"]["allMembers"];
            _tempList.forEach((element) {
              allTeamMemberList.add(element["individualName"].toString() +
                  AllString.splitText +
                  element["individualId"].toString());
            });
            // log("firstName: "+ sharedPreferences!
            //         .getString(AllSharedPreferencesKey.firstName)!);
            // allTeamMemberList.remove(sharedPreferences!
            //         .getString(AllSharedPreferencesKey.firstName)! +
            //     AllString.splitText +
            //     sharedPreferences!
            //         .getString(AllSharedPreferencesKey.individualId)!);
          }
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}

String checkAndDisplayTaskStatus(Map<String, dynamic> itemData) {
  if (itemData["approvalStatus"].toString() == "0") {
    return "Pending";
  } else if (itemData["approvalStatus"].toString() == "1") {
    return "Approved";
  } else if (itemData["approvalStatus"].toString() == "2") {
    return "Rejected";
  } else {
    return "Unknown";
  }
}

String checkAndSiaplayStatus(Map<String, dynamic> itemData) {
  if (itemData["approvalLevel"].toString() == "1") {
    if (itemData["firstLevelApproveStatus"].toString() == "0") {
      return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
      return "Rejected By " + showValidValue(itemData["firstLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "1") {
      return "Approved By " + showValidValue(itemData["firstLevelApprovalBy"]);
    } else {
      return "Unknown";
    }
  } else if (itemData["approvalLevel"].toString() == "2") {
    if (itemData["firstLevelApproveStatus"].toString() == "0" &&
        itemData["secondLevelApproveStatus"].toString() == "0") {
      return "Pending By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "1" &&
        itemData["secondLevelApproveStatus"].toString() == "1") {
      return "Approved By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "2" &&
        itemData["secondLevelApproveStatus"].toString() == "2") {
      return "Rejected By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "1" &&
        itemData["secondLevelApproveStatus"].toString() == "2") {
      return "Approved By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          "Rejected By " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "2" &&
        itemData["secondLevelApproveStatus"].toString() == "1") {
      return "Rejected By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          "Approved By " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "0" &&
        itemData["secondLevelApproveStatus"].toString() == "1") {
      return "Pending By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          "Approved By " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "1" &&
        itemData["secondLevelApproveStatus"].toString() == "0") {
      return "Approved By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          "Pending By " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "0" &&
        itemData["secondLevelApproveStatus"].toString() == "2") {
      return "Pending By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          "Rejected By " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "2" &&
        itemData["secondLevelApproveStatus"].toString() == "0") {
      return "Rejected By " +
          showValidValue(itemData["firstLevelApprovalBy"]) +
          ", " +
          "Pending By " +
          showValidValue(itemData["secondLevelApprovalBy"]);
    }
    //  else if (itemData["firstLevelApproveStatus"].toString() == "2" ||
    //     itemData["secondLevelApproveStatus"].toString() == "2") {
    //   return itemData["firstLevelApprovalBy"].toString() == "null" ||
    //           itemData["firstLevelApprovalBy"].toString().isEmpty
    //       ? "Rejected By " + showValidValue(itemData["secondLevelApprovalBy"])
    //       : "Rejected By " + showValidValue(itemData["firstLevelApprovalBy"]);
    // } else if (itemData["firstLevelApproveStatus"].toString() == "1" ||
    //     itemData["secondLevelApproveStatus"].toString() == "1") {
    //   return itemData["firstLevelApprovalBy"].toString() == "null" ||
    //           itemData["firstLevelApprovalBy"].toString().isEmpty
    //       ? "Approved By " + showValidValue(itemData["secondLevelApprovalBy"])
    //       : "Approved By " + showValidValue(itemData["firstLevelApprovalBy"]);
    // }
    else {
      return "Unknown";
    }
  } else {
    if (itemData["firstLevelApproveStatus"].toString() == "0") {
      return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
    } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
      return "Rejected By " + showValidValue(itemData["firstLevelApprovalBy"]);
    } else {
      if (itemData["secondLevelApproveStatus"].toString() == "0") {
        return "Pending By " +
            showValidValue(itemData["secondLevelApprovalBy"]);
      } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
        return "Approved By " +
            showValidValue(itemData["secondLevelApprovalBy"]);
      } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
        return "Rejected By " +
            showValidValue(itemData["secondLevelApprovalBy"]);
      } else {
        return "Unknown";
      }
    }
  }
}

bool checkForAprovedAndReject(Map<String, dynamic> itemData) {
  if ((sharedPreferences!
              .getString(AllSharedPreferencesKey.individualTypeId)
              .toString() ==
          "17") ||
      (sharedPreferences!
              .getString(AllSharedPreferencesKey.individualTypeId)
              .toString() ==
          "16") ||
      (sharedPreferences!
              .getString(AllSharedPreferencesKey.individualTypeId)
              .toString() ==
          "19")) {
    //! approval Level 1 only first level

    if (itemData["approvalLevel"].toString() == "1" &&
        (itemData["firstLevelApproveStatus"].toString() == "0" &&
            (itemData["firstLevelIndividualId"].toString() ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)
                    .toString()))) {
      if (itemData["firstLevelApproveStatus"].toString() == "0") {
        //! 0 pending
        return true;
      } else if (itemData["firstLevelApproveStatus"].toString() == "2" ||
          itemData["firstLevelApproveStatus"].toString() == "1") {
        //! 1 arroved and 2 reject
        return false;
      } else {
        return false;
      }
    }
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================

    //! approval Level 2 2nd level but no hierarchical
    else if (itemData["approvalLevel"].toString() == "2") {
      if ((itemData["firstLevelApproveStatus"].toString() == "0" &&
              (itemData["firstLevelIndividualId"].toString() ==
                  sharedPreferences!
                      .getString(AllSharedPreferencesKey.individualId)
                      .toString())) &&
          (itemData["secondLevelApproveStatus"].toString() == "0" &&
              (itemData["secondLevelIndividualId"].toString() ==
                  sharedPreferences!
                      .getString(AllSharedPreferencesKey.individualId)
                      .toString()))) {
        return true;
      } else if (((itemData["firstLevelApproveStatus"].toString() == "1" ||
              itemData["firstLevelApproveStatus"].toString() == "2") &&
          (itemData["firstLevelIndividualId"].toString() ==
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
                  .toString()))) {
        return false;
      } else if (((itemData["secondLevelApproveStatus"].toString() == "1" ||
              itemData["secondLevelApproveStatus"].toString() == "2") &&
          (itemData["secondLevelIndividualId"].toString() ==
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
                  .toString()))) {
        return false;
      } else {
        return true;
      }
    }
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================
    // =======================================================

    //! approval Level 3 hierarchical

    else if (itemData["approvalLevel"].toString() == "3" &&
            (itemData["firstLevelIndividualId"].toString() ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)
                    .toString()) ||
        (itemData["secondLevelIndividualId"].toString() ==
            sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId)
                .toString())) {
      /**
                     * 
                     */

      if (itemData["firstLevelApproveStatus"].toString() == "0") {
        //! pending
        return true;
      } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
        //! reject
        return false;
      } else {
        //! approved
        if (itemData["secondLevelApproveStatus"].toString() == "0") {
          return true;
        } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
          return false;
        } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
          return false;
        } else {
          return false;
        }
      }
    } else {
      return false;
    }
  } else {
    return false;
  }
}

// import 'dart:convert';
// import 'dart:developer';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/leaveBalance/applyLeave.dart';
// import 'package:hr/pages/leaveBalance/leave.dart';
// import 'package:hr/pages/myExpense/applyExpense.dart';
// import 'package:hr/pages/myExpense/myExpenseDetails.dart';
// import 'package:hr/pages/myLoan/applyLoan.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/widget/customCatender.dart';
// import 'package:hr/widget/customRowDetails.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/dashboard/dashboard.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allString.dart';

// class MyExpenseBody extends StatefulWidget {
//   @override
//   _MyExpenseBodyState createState() => _MyExpenseBodyState();
// }

// class _MyExpenseBodyState extends State<MyExpenseBody> {
//   bool loading = false;
//   List _myExpenseList = [];
//   @override
//   void initState() {
//     super.initState();
//     fetchExpense();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return LoadingOverlay(
//       isLoading: loading,
//       opacity: 0.1,
//       color: AllColor.primaryColor,
//       progressIndicator: loaderWaveOrange(),
//       child: Container(
//         width: screenWidth,
//         height: screenHeight,
//                                decoration:customBackgroundGradient(),

//         child: Stack(
//           children: [
//             ListView.builder(
//                 padding: EdgeInsets.only(bottom: screenWidth * 0.03),
//                 physics: BouncingScrollPhysics(),
//                 itemCount: _myExpenseList.length,
//                 itemBuilder: (context, index) =>
//                     customMyLoanItem(_myExpenseList[index], index)),
//             Positioned(
//                 bottom: screenWidth * 0.05,
//                 right: screenWidth * 0.05,
//                 child: FloatingActionButton(
//                   onPressed: () {
//                     Navigator.of(context).push(CupertinoPageRoute(
//                         builder: (context) => ApplyExpense()));
//                   },
//                   child: normalIcon(Icons.add),
//                   backgroundColor: AllColor.primaryDeepColor,
//                 )),
//           ],
//         ),
//       ),
//     );
//   }

//   customMyLoanItem(Map<String, dynamic> itemData, int index) {
//     return GestureDetector(
//       onTap: () {
//         if (itemData["Status"] == "Reimbursment") {
//           Navigator.push(context,
//               CupertinoPageRoute(builder: (context) => MyExpenseDetails()));
//         }
//       },
//       child: Container(
//         padding: EdgeInsets.all(1),
//         decoration: customCardItemGradinet(),
//         height: screenWidth >= 600 ? screenWidth * 0.23 : screenWidth * 0.27,
//         margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
//         child: Container(
//           decoration: BoxDecoration(
//               color: AllColor.white, borderRadius: BorderRadius.circular(10)),
//           width: screenWidth,
//           child: Row(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               customCatender(
//                   screenWidth * 0.23,
//                   screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
//                   screenWidth * 0.18,
//                   index),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Amount",
//                       value: AllString.rs + " " + itemData["ExpenseAmount"]),
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Remark",
//                       value: itemData["ExpenseApplyRemarks"].toString()),
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Status",
//                       value: itemData["Status"]),
//                 ],
//               ),
//               itemData["Status"] == "Reimbursment"
//                   ? Container(
//                       margin: EdgeInsets.only(right: screenWidth * 0.02),
//                       child: normalIcon(Icons.arrow_forward_ios,
//                           color: AllColor.greyColor))
//                   : Container()
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   fetchExpense() async {
//     var jsonData = json.decode(
//         await rootBundle.loadString('assets/json/ExpenseListData.json'));
//     log(jsonData.toString());
//     _myExpenseList = jsonData["ExpenseListData"];
//     setState(() {});
//   }
// }
