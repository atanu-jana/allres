import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/requestManagement/requestManagement.dart';
import 'package:hr/pages/requestManagement/requestManagementBody.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class AddRequest extends StatefulWidget {
  const AddRequest({
    Key? key,
  }) : super(key: key);
  @override
  _AddRequestState createState() => _AddRequestState();
}

class _AddRequestState extends State<AddRequest> {
  bool loading = false;
  PickedFile? _attatchmentImageFile2;
  PickedFile? _attatchmentImageFile1;
  TextEditingController commentTextEditingController = TextEditingController();
  String selectedRequested = AllString.select;
  List<String> _requestList = [];

  @override
  void initState() {
    super.initState();

    fetchRequestTypeList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, "Add Request"),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
            width: screenWidth,
            height: screenHeight,
                                  decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Container(
                    width: screenWidth,
                    height: screenHeight,
                    child: ListView(
                      physics: BouncingScrollPhysics(),
                      children: [
                        textFieldHeader("Request For *",
                            fontWeight: FontWeight.bold),
                        Container(
                          child: DropdownButtonWithSearch(
                            icon: LineIcons.sortAmountDown,
                            selectedValue: selectedRequested,
                            dropdownList: _requestList,
                            onChanged: onRequestChanged,
                          ),
                        ),
                        textFieldHeader("Comment *",
                            fontWeight: FontWeight.bold),
                        Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.typeHere,
                              commentTextEditingController,
                              4,
                              200,
                              TextInputAction.newline,
                              TextInputType.multiline,
                            ),
                          ),
                        ),
                        attatchmentCard(),
                        Container(
                            margin: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.015,
                                horizontal: screenWidth * 0.03),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                    child: button(context, function: () {
                                  if (validateAndProceed()) {
                                    addDailyPlan();
                                  }
                                },
                                        color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                                        textColor: AllColor.white,
                                        text: AllString.request,
                                        width: screenWidth * 0.3))
                              ],
                            )),
                      ],
                    ))
              ],
            )),
      ),
    );
  }

  addDailyPlan() {
    String attachment1 = "";
    String attachment2 = "";
    if (_attatchmentImageFile1 != null) {
      File imageFile = new File(_attatchmentImageFile1!.path);
      List<int> imageBytes = imageFile.readAsBytesSync();
      attachment1 = base64Encode(imageBytes);
    }
    if (_attatchmentImageFile2 != null) {
      File imageFile = new File(_attatchmentImageFile1!.path);
      List<int> imageBytes = imageFile.readAsBytesSync();
      attachment2 = base64Encode(imageBytes);
    }
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "requestTypeId": selectedRequested.split(AllString.splitText).last,
      "comment": commentTextEditingController.text,
      "image1": attachment1,
      "image2": attachment2,
      "firstLevelApproveStatus": "0",
      "secondLevelApproveStatus": "0",
      "userLoginId":
          sharedPreferences!.getString(AllSharedPreferencesKey.userId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.addEmployeeRequest, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              Navigator.of(context).push(CupertinoPageRoute(
                  builder: (context) => RequestManagement()));
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  onRequestChanged(String? value) {
    selectedRequested = value!;
    setState(() {});
  }

  bool validateAndProceed() {
    if (selectedRequested == AllString.select) {
      return false;
    } else if (commentTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }

  attatchmentCard() {
    return Container(
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                extraSmallText(AllString.attachment + " 1",
                    fontWeight: FontWeight.bold, color: AllColor.black),
                Container(
                  margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.0,
                  ),
                  child: Row(
                    children: [
                      Container(
                        child: GestureDetector(
                          onTap: () {
                            pickImageOption(ImageSource.camera,
                                paymentImage: false,
                                attatchmentImage1: true,
                                attatchmentImage2: false);
                            // pickImageOption();
                          },
                          child: Stack(
                            children: [
                              Container(
                                width: screenWidth * 0.2,
                                height: screenWidth * 0.2,
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  color: AllColor.greyColor.withOpacity(0.5),
                                ),
                                child: Material(
                                  color: AllColor.lightBlack.withOpacity(0.5),
                                  //display new updated image here
                                  child: _attatchmentImageFile1 == null
                                      ? mediumIcon(Icons.attach_file,
                                          color: AllColor.black)
                                      : Image.file(
                                          File(_attatchmentImageFile1!.path),
                                          fit: BoxFit.cover,
                                        ),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  clipBehavior: Clip.hardEdge,
                                ),
                              ),
                              _attatchmentImageFile1 == null
                                  ? Container()
                                  : Positioned(
                                      top: screenWidth * 0.01,
                                      right: screenWidth * 0.01,
                                      child: GestureDetector(
                                        onTap: () {
                                          _attatchmentImageFile1 = null;
                                          setState(() {});
                                        },
                                        child: Container(
                                          child: normalIcon(Icons.close),
                                        ),
                                      ))
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              width: screenWidth * 0.05,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                extraSmallText(AllString.attachment + " 2",
                    fontWeight: FontWeight.bold, color: AllColor.black),
                Container(
                  margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.0,
                  ),
                  child: Row(
                    children: [
                      Container(
                        child: GestureDetector(
                          onTap: () {
                            pickImageOption(ImageSource.camera,
                                paymentImage: false,
                                attatchmentImage1: false,
                                attatchmentImage2: true);
                            // pickImageOption();
                          },
                          child: Stack(
                            children: [
                              Container(
                                width: screenWidth * 0.2,
                                height: screenWidth * 0.2,
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  color: AllColor.greyColor.withOpacity(0.5),
                                ),
                                child: Material(
                                  color: AllColor.lightBlack.withOpacity(0.5),
                                  //display new updated image here
                                  child: _attatchmentImageFile2 == null
                                      ? mediumIcon(Icons.attach_file,
                                          color: AllColor.black)
                                      : Image.file(
                                          File(_attatchmentImageFile2!.path),
                                          fit: BoxFit.cover,
                                        ),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  clipBehavior: Clip.hardEdge,
                                ),
                              ),
                              _attatchmentImageFile2 == null
                                  ? Container()
                                  : Positioned(
                                      top: screenWidth * 0.01,
                                      right: screenWidth * 0.01,
                                      child: GestureDetector(
                                        onTap: () {
                                          _attatchmentImageFile2 = null;
                                          setState(() {});
                                        },
                                        child: Container(
                                          child: normalIcon(Icons.close),
                                        ),
                                      ))
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )
          ]),
    );
  }

  pickImageOption(ImageSource source,
      {required bool paymentImage,
      required bool attatchmentImage1,
      required bool attatchmentImage2}) {
    return showDialog(
        // barrierDismissible: false,
        context: context,
        builder: (context) {
          return SimpleDialog(
            backgroundColor: AllColor.white,
            contentPadding: EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0)),
            elevation: 0.0,
            title: normalText(AllString.selectImageFrom + ":",
                color: AllColor.black),
            children: [
              Container(
                margin: EdgeInsets.only(top: screenWidth * 0.03),
                decoration: BoxDecoration(
                    border: Border(top: BorderSide(color: Colors.grey))),
              ),
              SimpleDialogOption(
                  padding: EdgeInsets.all(0),
                  child: ListTile(
                    contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
                    leading: normalIcon(Icons.camera_alt,
                        color: AllColor.primaryColor),
                    title: normalText(AllString.camera, color: AllColor.black),
                  ),
                  onPressed: () {
                    _onImageButtonPressed(ImageSource.camera,
                        paymentImage: paymentImage,
                        attatchmentImage1: attatchmentImage1,
                        attatchmentImage2: attatchmentImage2);
                    Navigator.pop(context);
                  }),
              SimpleDialogOption(
                  padding: EdgeInsets.all(0),
                  child: ListTile(
                    contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
                    leading: normalIcon(Icons.photo_library,
                        color: AllColor.primaryColor),
                    title: normalText(AllString.gallery, color: AllColor.black),
                  ),
                  onPressed: () {
                    _onImageButtonPressed(ImageSource.gallery,
                        paymentImage: paymentImage,
                        attatchmentImage1: attatchmentImage1,
                        attatchmentImage2: attatchmentImage2);
                    Navigator.pop(context);
                  }),
            ],
          );
        });
  }

  _onImageButtonPressed(ImageSource source,
      {required bool paymentImage,
      required bool attatchmentImage1,
      required bool attatchmentImage2}) async {
    try {
      final pickedFile = await imagePickerQuality(source);
      

      final bytes = File(pickedFile!.path).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      final mb = kb / 1024;
      log("kb: " + kb.toString());
      log("mb: " + mb.toString());
      if (attatchmentImage1) {
        _attatchmentImageFile1 = pickedFile;
        setState(() {});
      } else if (attatchmentImage2) {
        _attatchmentImageFile2 = pickedFile;
        setState(() {});
      }

      setState(() {
        loading = false;
      });
    } catch (e) {}
  }

  fetchRequestTypeList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.requestTypeList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _requestList.clear();
          _requestList.add(AllString.select);

          if (jsonData["requestTypeData"].isEmpty ||
              jsonData["requestTypeData"].toString() == "") {
            _requestList.clear();
          } else {
            List _tempList = jsonData["requestTypeData"];
            _tempList.forEach((element) {
              _requestList.add(element["requestTypeName"].toString() +
                  AllString.splitText +
                  element["requestTypeId"].toString());
            });
          }

          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}
