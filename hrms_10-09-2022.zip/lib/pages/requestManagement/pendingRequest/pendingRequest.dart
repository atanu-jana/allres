import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/requestManagement/pendingRequest/pendingRequestDetails.dart';
import 'package:hr/pages/requestManagement/requestManagement.dart';
import 'package:hr/pages/requestManagement/requestManagementBody.dart';
import 'package:hr/pages/requestManagement/viewRequest/viewRequestDetails.dart';
import 'package:hr/pages/workPlan/daily/daily.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class PendingRequest extends StatefulWidget {
  const PendingRequest({
    Key? key,
  }) : super(key: key);
  @override
  _PendingRequestState createState() => _PendingRequestState();
}

class _PendingRequestState extends State<PendingRequest> {
  bool loading = false;
  String selectTeamMember = AllString.select;
  List _requestedList = [];
  List<String> _filterList = [];
  String selectedFilter = AllString.select;

  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    if (teamMemberList.length > 1) {
      selectTeamMember = teamMemberList[1];
      setState(() {});
    }
    fetchStatusList();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).push(
            CupertinoPageRoute(builder: (context) => RequestManagement()));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(
          context,
          "Waiting for Approval",
          onBackPress: () {
            Navigator.of(context).push(
                CupertinoPageRoute(builder: (context) => RequestManagement()));
          },
        ),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
                                    decoration:customBackgroundGradient(),

              child: Stack(
                children: [
                  Container(
                    margin: EdgeInsets.only(
                        top:
                            // sharedPreferences!
                            //                 .getString(AllSharedPreferencesKey
                            //                     .individualTypeId)
                            //                 .toString() !=
                            //             "16" &&
                            //         sharedPreferences!
                            //                 .getString(AllSharedPreferencesKey
                            //                     .individualTypeId)
                            //                 .toString() !=
                            //             "17"
                            //     ?
                            screenWidth * 0.22
                        // : screenWidth * 0.37
                        ),
                    child: _requestedList.isEmpty
                        ? commonNoDataFound()
                        : ListView.builder(
                            padding:
                                EdgeInsets.only(bottom: screenWidth * 0.03),
                            physics: BouncingScrollPhysics(),
                            itemCount: _requestedList.length,
                            itemBuilder: (context, index) =>
                                customTile(_requestedList[index], index)),
                  ),
                  Positioned(
                      left: 0,
                      right: 0,
                      top: screenWidth * 0.01,
                      child: Container(
                        height:
                            //  sharedPreferences!
                            //                 .getString(AllSharedPreferencesKey
                            //                     .individualTypeId)
                            //                 .toString() !=
                            //             "16" &&
                            //         sharedPreferences!
                            //                 .getString(AllSharedPreferencesKey
                            //                     .individualTypeId)
                            //                 .toString() !=
                            //             "17"
                            //     ?
                            screenWidth * 0.2
                        // : screenWidth * 0.35
                        ,
                        color: AllColor.white,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // sharedPreferences!
                            //                 .getString(AllSharedPreferencesKey
                            //                     .individualTypeId)
                            //                 .toString() !=
                            //             "16" &&
                            //         sharedPreferences!
                            //                 .getString(AllSharedPreferencesKey
                            //                     .individualTypeId)
                            //                 .toString() !=
                            //             "17"
                            //     ? Container()
                            //     : Container(
                            //         child: Column(children: [
                            //           // dateSelectDisplay(),
                            //           Container(
                            //             child: Column(
                            //               children: [
                            //                 textFieldHeader(
                            //                     AllString.selectMember,
                            //                     fontWeight: FontWeight.bold,
                            //                     center: true),
                            //                 Container(
                            //                   width: screenWidth,
                            //                   child: Container(
                            //                     child: DropdownButtonWithSearch(
                            //                       icon:
                            //                           LineIcons.sortAmountDown,
                            //                       selectedValue:
                            //                           selectTeamMember,
                            //                       dropdownList: teamMemberList,
                            //                       onChanged:
                            //                           onTeamMemberChanged,
                            //                     ),
                            //                   ),
                            //                   // child: dropdownButton(teamMemberList,
                            //                   //     onTeamMemberChanged, selectTeamMember)),
                            //                 ),
                            //               ],
                            //             ),
                            //           ),
                            //         ]),
                            //       ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  width: screenWidth / 2.2,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      textFieldHeader(AllString.selectDate,
                                          fontWeight: FontWeight.bold),
                                      datePickerButton(context, _selectedDate,
                                          Icons.calendar_today, () {
                                        selectDate(context, _selectedDate)
                                            .then((value) {
                                          _selectedDate = value;
                                          setState(() {});
                                          log(_selectedDate.toString());
                                          fetchRequestedList();
                                        });
                                      }, dense: true),
                                    ],
                                  ),
                                ),
                                _filterList.isEmpty
                                    ? Container()
                                    : Container(
                                        width: screenWidth / 2.2,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            textFieldHeader(AllString.status,
                                                fontWeight: FontWeight.bold),
                                            dropdownButton(
                                                _filterList,
                                                onDropdownChange,
                                                selectedFilter),
                                          ],
                                        ),
                                      )
                              ],
                            ),
                          ],
                        ),
                      )),
                ],
              )),
        ),
      ),
    );
  }

  onDropdownChange(String? value) {
    selectedFilter = value!;
    setState(() {});
    if (selectedFilter == AllString.select) {
      _requestedList = [];
      setState(() {});
    } else {
      fetchRequestedList();
    }
  }

  fetchStatusList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.requestStatus, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _filterList.clear();
          _filterList.add(AllString.select);

          if (jsonData["requestStatusList"].toString() == "") {
            _filterList.clear();
          } else {
            List _tempList = jsonData["requestStatusList"];
            _tempList.forEach((element) {
              _filterList.add(element["requestStatusName"].toString() +
                  AllString.splitText +
                  element["requestStatusId"].toString());
            });
          }
          if (_filterList.length > 1) {
            selectedFilter = _filterList[1];
            setState(() {});
          }
          fetchRequestedList();
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  onTeamMemberChanged(String? value) {
    selectTeamMember = value!;
    setState(() {});
    fetchRequestedList();
  }

  fetchRequestedList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          // sharedPreferences!
          //                 .getString(AllSharedPreferencesKey.individualTypeId)
          //                 .toString() !=
          //             "16" &&
          //         sharedPreferences!
          //                 .getString(AllSharedPreferencesKey.individualTypeId)
          //                 .toString() !=
          //             "17"
          //     ?
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId)
      // : selectTeamMember.split(AllString.splitText).last
      ,
      "requestStatusId": selectedFilter.split(AllString.splitText).last,
      "date": formatterForRequest.format(DateTime.now()).toString(),
    };
    apiPostRequestWithHeader(
            data, AllUrls.employeePendingRequest, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _requestedList.clear();
          if (jsonData["pendingRequsetList"].toString() == "") {
            _requestedList.clear();
          } else {
            _requestedList = jsonData["pendingRequsetList"];
          }
          setState(() {
            loading = false;
          });
        } else {
          _requestedList.clear();

          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  customTile(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => PendingRequestDetails(
                  singleData: itemData,
                  visible: true,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => PendingRequest()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth >= 600 ? screenWidth * 0.23 : screenWidth * 0.3,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  // DateTime.parse(itemData["createdDate"]
                  _selectedDate),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Req. Type",
                      value: showValidValue(
                          itemData["requestTypeName"].toString())),

                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Comment",
                      value: showValidValue(itemData["comment"])),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.18,
                      title: "Status",
                      value: checkAndSiaplayStatus(itemData)),
                  // customRowDetails(
                  //     width: screenWidth * 0.6,
                  //     widthTitle: screenWidth * 0.15,
                  //     title: "Status",
                  //     value: itemData["Status"]),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  // String checkAndSiaplayStatus(Map<String, dynamic> itemData) {
  //   if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //     return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
  //   } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //     return "Rejected By " + showValidValue(itemData["firstLevelApprovalBy"]);
  //   } else {
  //     if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " +
  //           showValidValue(itemData["secondLevelApprovalBy"]);
  //     } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //       return "Approved By " +
  //           showValidValue(itemData["secondLevelApprovalBy"]);
  //     } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " +
  //           showValidValue(itemData["secondLevelApprovalBy"]);
  //     } else {
  //       return "Unknown";
  //     }
  //   }

  //   // return itemData["reviewStatus"].toString() == "0"
  //   //                       // ? "Pending ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
  //   //                       ? " Team Manager"
  //   //                       : itemData["reviewStatus"].toString() == "1"
  //   //                           // ? "Rejected ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
  //   //                           ? "Rejected By Team Manager"
  //   //                           : itemData["reviewStatus"].toString() == "2"
  //   //                               // ? "Approved ${sharedPreferences!.getString(AllSharedPreferencesKey.reportingManager)!}"
  //   //                               ? "Approved By Team Manager"
  //   //                               : itemData["reviewStatus"].toString() == "3"
  //   //                                   ? "Rejected By HR"
  //   //                                   : itemData["reviewStatus"].toString() ==
  //   //                                           "4"
  //   //                                       ? "Approved By HR"
  //   //                                       : ""
  // }

}
