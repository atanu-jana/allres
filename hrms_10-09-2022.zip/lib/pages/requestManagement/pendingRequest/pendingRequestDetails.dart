import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/requestManagement/requestManagementBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class PendingRequestDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const PendingRequestDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);
  @override
  _PendingRequestDetailsState createState() => _PendingRequestDetailsState();
}

class _PendingRequestDetailsState extends State<PendingRequestDetails> {
  bool loading = false;
  TextEditingController _commentTextEditingController = TextEditingController();
  @override
  void initState() {
    super.initState();
    log(widget.singleData.toString());
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.individualId)
        .toString());
    log(sharedPreferences!
        .getString(AllSharedPreferencesKey.individualTypeId)
        .toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, "View Request Details"),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                 decoration:customBackgroundGradient(),

          child: ListView(
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: AllColor.black))),
                padding: EdgeInsets.all(1),
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                child: Container(
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10)),
                  width: screenWidth,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Req. Type",
                              value: showValidValue(widget
                                  .singleData["requestTypeName"]
                                  .toString())),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Comment",
                              value: showValidValue(
                                  widget.singleData["comment"].toString())),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.18,
                              title: "Status",
                              value: checkAndSiaplayStatus(widget.singleData)),
                          widget.singleData["firstLevelComment"]
                                      .toString()
                                      .isEmpty ||
                                  widget.singleData["firstLevelComment"]
                                          .toString() ==
                                      "null"
                              ? Container()
                              : customRowDetails(
                                  width: screenWidth - 50,
                                  widthTitle: screenWidth * 0.3,
                                  title: "Comment",
                                  value: widget.singleData["firstLevelComment"]
                                      .toString()),
                          widget.singleData["secondLevelComment"]
                                      .toString()
                                      .isEmpty ||
                                  widget.singleData["secondLevelComment"]
                                          .toString() ==
                                      "null"
                              ? Container()
                              : customRowDetails(
                                  width: screenWidth - 50,
                                  widthTitle: screenWidth * 0.3,
                                  title: "Comment",
                                  value: widget.singleData["secondLevelComment"]
                                      .toString()),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                margin: AllMargin.customMarginCardItem(),
                child: Row(
                  children: [
                    widget.singleData["image1"].toString().isEmpty ||
                            widget.singleData["image1"].toString() == "null"
                        ? Container()
                        : GestureDetector(
                            onTap: () {
                              Navigator.of(context)
                                  .push(CupertinoPageRoute(builder: (context) {
                                return NetworkImageView(
                                  url: widget.singleData["image1"].toString(),
                                );
                              }));
                            },
                            child: Center(
                              child: Container(
                                margin: customVertical(),
                                width: screenWidth * 0.3,
                                height: screenWidth * 0.3,
                                decoration: BoxDecoration(
                                    color: AllColor.white,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        width: 2, color: AllColor.black)),
                                child: Center(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: CachedNetworkImage(
                                    width: screenWidth * 0.3,
                                    height: screenWidth * 0.3,
                                    fit: BoxFit.cover,
                                        placeholder: (_, __) {
                                          return Center(
                                            child: CircularProgressIndicator(),
                                          );
                                        },
                                        errorWidget: (_, __, ___) {
                                          return Center(
                                            child: Image.asset(
                                                "assets/images/appLogo.png"),
                                          );
                                        },
                                        imageUrl: widget
                                            .singleData["image1"]
                                            .toString()),
                                    // child: Image.memory(
                                    //   Base64Decoder().convert(base64.normalize(
                                    //       widget.singleData["image1"]
                                    //           .toString()
                                    //           .trim())),
                                    //   width: screenWidth * 0.3,
                                    //   height: screenWidth * 0.3,
                                    //   fit: BoxFit.cover,
                                    // ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                    widget.singleData["image2"].toString().isEmpty ||
                            widget.singleData["image2"].toString() == "null"
                        ? Container()
                        : GestureDetector(
                            onTap: () {
                              Navigator.of(context)
                                  .push(CupertinoPageRoute(builder: (context) {
                                return NetworkImageView(
                                  url: widget.singleData["image2"].toString(),
                                );
                              }));
                            },
                            child: Center(
                              child: Container(
                                margin: AllMargin.customMarginCardItem(),
                                width: screenWidth * 0.3,
                                height: screenWidth * 0.3,
                                decoration: BoxDecoration(
                                    color: AllColor.white,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        width: 2, color: AllColor.black)),
                                child: Center(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    // child: Image.memory(
                                    //   Base64Decoder().convert(base64.normalize(
                                    //       widget.singleData["image2"]
                                    //           .toString()
                                    //           .trim())),
                                    //   width: screenWidth * 0.3,
                                    //   height: screenWidth * 0.3,
                                    //   fit: BoxFit.cover,
                                    // ),
                                    child:  CachedNetworkImage(
                                    width: screenWidth * 0.3,
                                    height: screenWidth * 0.3,
                                    fit: BoxFit.cover,
                                        placeholder: (_, __) {
                                          return Center(
                                            child: CircularProgressIndicator(),
                                          );
                                        },
                                        errorWidget: (_, __, ___) {
                                          return Center(
                                            child: Image.asset(
                                                "assets/images/appLogo.png"),
                                          );
                                        },
                                        imageUrl: widget
                                            .singleData["image2"]
                                            .toString()),
                                    
                                  ),
                                ),
                              ),
                            ),
                          ),
                  ],
                ),
              ),
              widget.visible
                  ? !checkForAprovedAndReject(widget.singleData)
                      ? Container()
                      : textFieldHeader(AllString.remark,
                          fontWeight: FontWeight.bold)
                  : Container(),
              widget.visible
                  ? !checkForAprovedAndReject(widget.singleData)
                      ? Container()
                      : Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.enterRemark,
                              _commentTextEditingController,
                              4,
                              200,
                              TextInputAction.done,
                              TextInputType.text,
                            ),
                          ),
                        )
                  : Container(),
              SizedBox(
                height: screenWidth * 0.03,
              ),
              widget.visible
                  ? !checkForAprovedAndReject(widget.singleData)
                      ? Container()
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              child: button(context,
                              color:AllColor.red,
 
                                  text: AllString.reject,
                                  textColor: AllColor.white,
                                  width: screenWidth * 0.35, function: () {
                                approvedAndRejectCall(widget.singleData, true);
                              },
                                  enable:
                                      _commentTextEditingController.text.isEmpty
                                          ? false
                                          : true),
                            ),
                            Container(
                              child: button(context,
                              color:AllColor.deepGreen,
                              text: AllString.approved,
                                  width: screenWidth * 0.35,
                                  enable:
                                      _commentTextEditingController.text.isEmpty
                                          ? false
                                          : true,
                                  textColor: AllColor.white, function: () {
                                approvedAndRejectCall(widget.singleData, false);
                              }),
                            ),
                          ],
                        )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  approvedAndRejectCall(Map<String, dynamic> itemData, bool reject) async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "firstLevelApproveStatus":
            itemData["firstLevelIndividualId"].toString() ==
                    sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualId)
                        .toString()
                ? reject
                    ? 2
                    : 1
                : "",
        "secondLevelApproveStatus":
            itemData["secondLevelIndividualId"].toString() ==
                    sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualId)
                        .toString()
                ? reject
                    ? 2
                    : 1
                : "",
        "firstLevelComment": itemData["firstLevelIndividualId"].toString() ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)
                    .toString()
            ? _commentTextEditingController.text
            : "",
        "secondLevelComment": itemData["secondLevelIndividualId"].toString() ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)
                    .toString()
            ? _commentTextEditingController.text
            : "",
        "employeeRequestDetailId": widget.singleData["employeeRequestDetailId"],
        "userLoginId": loginUserId,
        "individualTypeId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId)
            .toString(),
        "companyId": sharedPreferences!
            .getString(AllSharedPreferencesKey.companyId)
            .toString(),
        "individualId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualId)
            .toString(),
      };

      apiPostRequestWithHeader(
              data, AllUrls.updateEmployeeRequest, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () {
              widget.callBack();
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  // customCardRowDetails(String title, value) {
  //   return Container(
  //     width: screenWidth,
  //     padding: EdgeInsets.symmetric(
  //         vertical: screenWidth * 0.01, horizontal: screenWidth * 0.03),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.start,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         Container(
  //           width: screenWidth * 0.33,
  //           child: smallText(title + " :", color: AllColor.greyColor),
  //         ),
  //         Container(
  //           margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
  //         ),
  //         normalText(value,
  //             color: value == "Approved" ? AllColor.green : AllColor.black)
  //       ],
  //     ),
  //   );
  // }

  // String checkAndSiaplayStatus(Map<String, dynamic> itemData) {
  //   if (itemData["approvalLevel"].toString() == "1") {
  //     if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //       return "Approved By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else {
  //       return "Unknown";
  //     }
  //   } else if (itemData["approvalLevel"].toString() == "2") {
  //     if (itemData["firstLevelApproveStatus"].toString() == "0" &&
  //         itemData["secondLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]) +
  //           ", " +
  //           showValidValue(itemData["secondLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2" ||
  //         itemData["secondLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " + itemData["firstLevelApprovalBy"].toString() ==
  //                   "null" ||
  //               itemData["firstLevelApprovalBy"].isEmpty
  //           ? showValidValue(itemData["secondLevelApprovalBy"])
  //           : showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "1" ||
  //         itemData["secondLevelApproveStatus"].toString() == "1") {
  //       return "Approved By " + itemData["firstLevelApprovalBy"].toString() ==
  //                   "null" ||
  //               itemData["firstLevelApprovalBy"].isEmpty
  //           ? showValidValue(itemData["secondLevelApprovalBy"])
  //           : showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else {
  //       return "Unknown";
  //     }
  //   } else {
  //     if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //       return "Pending By " + showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //       return "Rejected By " +
  //           showValidValue(itemData["firstLevelApprovalBy"]);
  //     } else {
  //       if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //         return "Pending By " +
  //             showValidValue(itemData["secondLevelApprovalBy"]);
  //       } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //         return "Approved By " +
  //             showValidValue(itemData["secondLevelApprovalBy"]);
  //       } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //         return "Rejected By " +
  //             showValidValue(itemData["secondLevelApprovalBy"]);
  //       } else {
  //         return "Unknown";
  //       }
  //     }
  //   }
  // }

  // bool checkForAprovedAndReject(Map<String, dynamic> itemData) {
  //   if ((sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "17") ||
  //       (sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "16") ||
  //       (sharedPreferences!
  //               .getString(AllSharedPreferencesKey.individualTypeId)
  //               .toString() ==
  //           "19")) {
  //     if (itemData["approvalLevel"].toString() == "2" &&
  //         (itemData["firstLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString() ||
  //             itemData["secondLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString())) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "0" &&
  //         (itemData["firstLevelIndividualId"].toString() ==
  //             sharedPreferences!
  //                 .getString(AllSharedPreferencesKey.individualId)
  //                 .toString())) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "1" &&
  //         (itemData["firstLevelApproveStatus"].toString() == "0" &&
  //             (itemData["firstLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString()))) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else if (itemData["approvalLevel"].toString() == "1" &&
  //         (itemData["firstLevelApproveStatus"].toString() == "1" &&
  //             itemData["secondLevelApproveStatus"].toString() == "0" &&
  //             (itemData["secondLevelIndividualId"].toString() ==
  //                 sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.individualId)
  //                     .toString()))) {
  //       /**
  //                    *
  //                    */

  //       if (itemData["firstLevelApproveStatus"].toString() == "0") {
  //         //! pending
  //         return true;
  //       } else if (itemData["firstLevelApproveStatus"].toString() == "2") {
  //         //! reject
  //         return false;
  //       } else {
  //         //! approved
  //         if (itemData["secondLevelApproveStatus"].toString() == "0") {
  //           return true;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "1") {
  //           return false;
  //         } else if (itemData["secondLevelApproveStatus"].toString() == "2") {
  //           return false;
  //         } else {
  //           return false;
  //         }
  //       }
  //       /*
  //                    */

  //     } else {
  //       return false;
  //     }

  //     // if (status == "1") {
  //     //   return false;
  //     // } else if (status == "3" ||status == "4") {
  //     //   return false;
  //     // } else if (status == "0" &&
  //     //     (sharedPreferences!
  //     //             .getString(AllSharedPreferencesKey.individualTypeId)
  //     //             .toString() ==
  //     //         "17")) {
  //     //   return true;
  //     // } else if (int.parse(status) > 0 &&
  //     //     (sharedPreferences!
  //     //             .getString(AllSharedPreferencesKey.individualTypeId)
  //     //             .toString() ==
  //     //         "16")) {
  //     //   return true;
  //     // } else {
  //     //   return false;
  //     // }
  //   } else {
  //     return false;
  //   }
  // }
}
