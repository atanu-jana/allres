import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:connectivity/connectivity.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/services.dart';
import 'package:hr/common/commonAlertDialogForBackPressToClose.dart';
import 'package:hr/common/commonAlertDialogWithYesNo.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/about/aboutBody.dart';
import 'package:hr/pages/authtication/signIn.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/pages/fileView/fileView.dart';
import 'package:hr/pages/fileView/fileViewBody.dart';
import 'package:hr/pages/leaveBalance/leaveBalanceBody.dart';
import 'package:hr/pages/more/more.dart';
import 'package:hr/pages/myExpense/myExpenseBody.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/myPerformance/myPerformanceBody.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentBody.dart';
import 'package:hr/pages/mySuggetion/mySuggetionBody.dart';
import 'package:hr/pages/profile/profile.dart';
import 'package:hr/pages/publicHoliday/publicHolidayBody.dart';
import 'package:hr/pages/recordAttendance/myAttendanceBody.dart';
import 'package:hr/pages/requestManagement/requestManagementBody.dart';
import 'package:hr/pages/serviceList/serviceList.dart';
import 'package:hr/pages/serviceList/serviceListBody.dart';
import 'package:hr/pages/taskManagement/taskManagementBody.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/pages/visitHistory/visitHistory.dart';
import 'package:hr/pages/visitHistory/visitHistoryBody.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/res/allUrls.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/clearAllSharePrefrerenceValue.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/showOnlineSnakbar.dart';
import 'package:hr/widget/drawerTile.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';

bool isDrawerOpen = false;
String currentScreenName = "";
Widget currentScreen = Container();

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _isDrawerOpen = false;
  DateTime backButtonPressTime = DateTime.now();
  bool showInternetConnectivity = false;
  static const snackBarDuration = Duration(seconds: 3);
  final snackBar = SnackBar(
    content: Text('Press back again to leave'),
    duration: snackBarDuration,
  );
  @override
  void initState() {
    super.initState();

    bool showInternetConnectivity = false;
    // initConnectivity();
    // _connectivitySubscription =
    //     _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
    SystemChrome.setEnabledSystemUIOverlays(
        [SystemUiOverlay.top, SystemUiOverlay.bottom]);
    Future.delayed(Duration(milliseconds: 300), () {
      replaceScreenForDashboard(AllString.dashboard);
    });
    _animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 300));
  }

  @override
  void dispose() {
    _animationController.dispose();

    super.dispose();
  }

  late AnimationController _animationController;
  bool isPlaying = false;
  @override
  Widget build(BuildContext context) {
    screenHeight = MediaQuery.of(context).size.height;
    screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AllColor.primaryColor,
      primary: true,
      appBar: AppBar(
        iconTheme: IconThemeData(color: AllColor.black),
        automaticallyImplyLeading: false,
        centerTitle: true,
        // backgroundColor: AllColor.primaryColor,
        backgroundColor: AllColor.white,
        // shadowColor: Color(0xff292E49),
        elevation: 0,
        // flexibleSpace: Container(
        //     decoration: BoxDecoration(
        //   gradient: LinearGradient(
        //       begin: Alignment(-5, 1),
        //       end: Alignment(0, 0),
        //       colors: [
        //         // Color(0xff005C97),
        //         // Color(0xff363795)
        //         Color(0xff536976),
        //         Color(0xff292E49)
        //         // Color.fromRGBO(2, 0, 36, 0.8)
        //         // Color.fromRGBO(2, 0, 36, 1),
        //         // Color.fromRGBO(9, 9, 121, 1),
        //         // Color.fromRGBO(9, 9, 121, 1),
        //         // Color.fromRGBO(0, 212, 255, 1)
        //       ]),
        // )),
        title: currentScreenName == AllString.dashboard
            ? Container(
                width: screenWidth * 0.3,
                // width: screenWidth * 0.15,
                height: screenWidth * 0.1,
                padding: EdgeInsets.all(3),
                decoration: BoxDecoration(
                    // boxShadow: [
                    //   BoxShadow(
                    //     color: Colors.grey.withOpacity(0.5),
                    //     spreadRadius: 2,
                    //     blurRadius: 7,
                    //     offset: Offset(0, 3), // changes position of shadow
                    //   ),
                    // ],
                    color: AllColor.white,
                    borderRadius: BorderRadius.circular(1000),
                    border: Border.all(color: AllColor.white, width: 5)),
                child: CachedNetworkImage(
                    placeholder: (_, __) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    },
                    fit: BoxFit.fill,
                    errorWidget: (_, __, ___) {
                      return Center(
                        child: Image.asset("assets/images/logo.png"),
                      );
                    },
                    imageUrl: sharedPreferences!
                        .getString(AllSharedPreferencesKey.companyLogo)!))
            : headingText(currentScreenName, color: AllColor.black),
        leading: IconButton(
          icon: AnimatedIcon(
              icon: AnimatedIcons.menu_arrow, progress: _animationController),
          onPressed: () {
            if (!_isDrawerOpen) {
              _key.currentState!.openDrawer();
            } else {
              // if (Navigator.canPop(context)) {
              //   Navigator.pop(context);
              // } else {
              replaceScreenForDashboard(AllString.dashboard);
              // }
            }
            setState(() {
              _isDrawerOpen = !_isDrawerOpen;
            });
            _handleOnPressed();
          },
        ),
      ),
      onDrawerChanged: (onDrawerChanged) {
        debugPrint('onDrawerChanged? $onDrawerChanged');
        // onDrawerChanged is called on changes in drawer direction
        // true - gesture that the Drawer is being opened
        // false - gesture that the Drawer is being closed
        onDrawerChanged
            ? _animationController.forward()
            : _animationController.reverse();
      },
      body: WillPopScope(
        onWillPop: () => handleWillPop(context),
        child: Scaffold(
          key: _key,
          drawer: GestureDetector(
            onTap: () {
              if (!_isDrawerOpen) {
                _key.currentState!.openDrawer();
              } else {
                if (Navigator.canPop(context)) {
                  Navigator.pop(context);
                } else {
                  replaceScreenForDashboard(AllString.dashboard);
                }
              }
              setState(() {
                _isDrawerOpen = !_isDrawerOpen;
              });
              _handleOnPressed();
            },
            child: Container(
              width: screenWidth,
              color: AllColor.transparentColor,
              alignment: Alignment.centerLeft,
              child: Container(
                width: screenWidth * 0.7,
                color: AllColor.white,
                child: ListView(
                  physics: BouncingScrollPhysics(),
                  children: [
                    Container(
                      height: 5,
                      color: AllColor.white,
                    ),

                    customDrawerTile(
                      context,
                      // EvaIcons.info,
                      Ionicons.home_outline,
                      AllString.dashboard,
                      true,
                      () {
                        currentScreenName = AllString.dashboard;
                        replaceScreenForDashboard(AllString.dashboard);
                      },
                    ),
                    customDrawerTile(
                      context,
                      // EvaIcons.info,
                      Icons.view_list,
                      AllString.visitHistory,
                      true,
                      () {
                        currentScreenName = AllString.visitHistory;
                        replaceScreenForDashboard(AllString.visitHistory);
                      },
                    ),

                    customDrawerTile(
                      context,
                      Icons.list_alt_outlined,
                      AllString.viewServiceList,
                      true,
                      () {
                        currentScreenName = AllString.viewServiceList;
                        replaceScreenForDashboard(AllString.viewServiceList);
                      },
                    ),
                    // customDrawerTile(
                    //   context,
                    //   // EvaIcons.info,
                    //   Icons.person,
                    //   AllString.profile,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.profile;
                    //     replaceScreenForDashboard(AllString.profile);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   // EvaIcons.info,
                    //   Ionicons.calendar_outline,
                    //   AllString.myAttendance,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.myAttendance;
                    //     replaceScreenForDashboard(AllString.myAttendance);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   LineIcons.moneyBill,
                    //   AllString.leaveBalance,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.leaveBalance;
                    //     replaceScreenForDashboard(AllString.leaveBalance);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   LineIcons.handHolding,
                    //   AllString.myLoan,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.myLoan;
                    //     replaceScreenForDashboard(AllString.myLoan);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   LineIcons.signLanguage,
                    //   AllString.mySuggestion,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.mySuggestion;
                    //     replaceScreenForDashboard(AllString.mySuggestion);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   LineIcons.arrowDown,
                    //   AllString.myExpense,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.myExpense;
                    //     replaceScreenForDashboard(AllString.myExpense);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   LineIcons.revIo,
                    //   AllString.myReimbursement,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.myReimbursement;
                    //     replaceScreenForDashboard(AllString.myReimbursement);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   LineIcons.cardboardVr,
                    //   AllString.myPerformance,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.myPerformance;
                    //     replaceScreenForDashboard(AllString.myPerformance);
                    //   },
                    // ),
                    // sharedPreferences!.getString(
                    //             AllSharedPreferencesKey.userConfigSetting) ==
                    //         "OnlySalesManApp"
                    //     ? Container()
                    //     :
                    (sharedPreferences!
                                    .getString(AllSharedPreferencesKey
                                        .individualTypeId)
                                    .toString() ==
                                "17") ||
                            (sharedPreferences!
                                    .getString(AllSharedPreferencesKey
                                        .individualTypeId)
                                    .toString() ==
                                "16")
                        ? customDrawerTile(
                            context,
                            Icons.group_outlined,
                            AllString.teamMembers,
                            true,
                            () {
                              currentScreenName = AllString.teamMembers;
                              replaceScreenForDashboard(AllString.teamMembers);
                            },
                          )
                        : Container(),
                    // customDrawerTile(
                    //   context,
                    //   Icons.holiday_village_outlined,
                    //   AllString.publicHolidays,
                    //   true,
                    //   () {
                    // currentScreenName = AllString.publicHolidays;
                    // replaceScreenForDashboard(AllString.publicHolidays);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   Icons.folder_open_outlined,
                    //   AllString.files,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.files;
                    //     replaceScreenForDashboard(AllString.files);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   Icons.more_horiz_outlined,
                    //   AllString.more,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.more;
                    //     replaceScreenForDashboard(AllString.more);
                    //   },
                    // ),
                    // customDrawerTile(
                    //   context,
                    //   // EvaIcons.info,
                    //   Ionicons.information_circle_outline,
                    //   AllString.aboutApp,
                    //   true,
                    //   () {
                    //     currentScreenName = AllString.aboutApp;
                    //     replaceScreenForDashboard(AllString.aboutApp);
                    //   },
                    // ),
                    tgtsAvailable ?customDrawerTile(
                      context,
                      // EvaIcons.info,
                      Icons.paste_outlined,
                      AllString.tGTS,
                      false,
                      () {
                        currentScreenName = AllString.tGTS;
                        replaceScreenForDashboard(AllString.tGTS);
                      },
                    ):Container(),
                    requestAvailable? customDrawerTile(
                      context,
                      // EvaIcons.info,
                      Icons.request_page,
                      AllString.requestManagement,
                      false,
                      () {
                        currentScreenName = AllString.requestManagement;
                        replaceScreenForDashboard(AllString.requestManagement);
                      },
                    ):Container(),
                   taskAvailable? customDrawerTile(
                      context,
                      // EvaIcons.info,
                      Icons.task,
                      AllString.taskManagement,
                      false,
                      () {
                        currentScreenName = AllString.taskManagement;
                        replaceScreenForDashboard(AllString.taskManagement);
                      },
                    ):Container(),
                    customDrawerTile(
                      context,
                      Icons.info_outline,
                      AllString.aboutApp,
                      false,
                      () {
                        currentScreenName = AllString.aboutApp;
                        replaceScreenForDashboard(AllString.aboutApp);
                      },
                    ),
                    customDrawerTile(
                      context,
                      // EvaIcons.info,
                      Ionicons.log_out_outline,
                      AllString.logout,
                      false,
                      () {
                        commonAlertDialogWithYesNo(
                            context, AllString.areYouSureYouWantToLogout, "",
                            yesFunction: () {
                          currentScreenName = AllString.logout;
                          replaceScreenForDashboard(AllString.logout);
                        });
                      },
                    ),

                    SizedBox(
                      height: screenWidth * 0.03,
                    ),
                    // ! *** For App Version Display
                    Container(
                      width: screenWidth,
                      height: screenWidth * 0.2,
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          Image.asset(
                            "assets/images/logo.png",
                            height: screenHeight * 0.05,
                          ),
                          Text(
                            AllString.versionNameWithVersion,
                            style: TextStyle(
                                color: AllColor.greyColor,
                                fontSize: screenWidth * 0.022),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),

                    // GestureDetector(
                    //   onTap: () {
                    //     sharedPreferences!
                    //         .setString(AllSharedPreferencesKey.userId, "");
                    //     loginPatientUserId = "";
                    //     Navigator.push(
                    //         context,
                    //         CupertinoPageRoute(
                    //             builder: (context) => SplashScreen()));
                    //   },
                    //   child: customDrawerTile(
                    //     context,
                    //     Icons.logout,
                    //     AllString.logout,
                    //   ),
                    // ),
                    SizedBox(
                      height: screenWidth * 0.05,
                    )
                  ],
                ),
              ),
            ),
          ),
          body: Container(
            child: currentScreen,
            // child: CustomButton(),
          ),
        ),
      ),
    );
  }

  // TODO: specific class methods

  void _handleOnPressed() {
    setState(() {
      isPlaying = !isPlaying;
      isPlaying
          ? _animationController.forward()
          : _animationController.reverse();
    });
  }

  replaceScreenForDashboard(String screenName) {
    // if (currentScreenName == "") {
    //   currentScreen = Dashboard();
    //   currentScreenName = screenName;
    //   setState(() {});
    // } else if (currentScreenName == AllString.dashboard) {
    //   if (!_isDrawerOpen) {
    //     _key.currentState!.openDrawer();
    //   } else {
    //     if (Navigator.canPop(context)) {
    //       Navigator.pop(context);
    //     } else {
    //       replaceScreenForDashboard(AllString.dashboard);
    //     }
    //   }
    //   setState(() {
    //     _isDrawerOpen = !_isDrawerOpen;
    //   });
    //   _handleOnPressed();
    // } else

    if (screenName == AllString.dashboard) {
      currentScreen = Dashboard();
      currentScreenName = screenName;
      setState(() {});
      _key.currentState!.openEndDrawer();
      _animationController.reverse();
    } else if (screenName == AllString.myAttendance) {
      currentScreen = MyAttendanceBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.profile) {
      Navigator.of(context)
          .push(CupertinoPageRoute(builder: (context) => Profile()));
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.leaveBalance) {
      currentScreen = LeaveBalanceBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.aboutApp) {
      currentScreen = AboutBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.myLoan) {
      currentScreen = MyLoanBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.myExpense) {
      currentScreen = MyExpenseBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.myReimbursement) {
      currentScreen = MyReimbursmentBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.publicHolidays) {
      currentScreen = PublicHolidayBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.myPerformance) {
      currentScreen = MyPerformanceBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.teamMembers) {
      currentScreen = TeamBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.visitHistory) {
      currentScreen = VisitHistoryBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.mySuggestion) {
      currentScreen = MySuggetionBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.files) {
      currentScreen = FileViewBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.more) {
      currentScreen = More();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.viewServiceList) {
      currentScreen = ServiceListBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.tGTS) {
      currentScreen = WorkPlanBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.requestManagement) {
      currentScreen = RequestManagementBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.taskManagement) {
      currentScreen = TaskManagementBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.aboutApp) {
      currentScreen = AboutBody();
      currentScreenName = screenName;
      _key.currentState!.openEndDrawer();
      setState(() {});
    } else if (screenName == AllString.logout) {
      clearAllSharePrefrerenceValue();
      currentScreenName = AllString.dashboard;
      currentScreen = Container();
      setState(() {});

      Navigator.of(context)
          .pushReplacement(CupertinoPageRoute(builder: (context) => SignIn()));
    }
  }

  Future<bool> handleWillPop(BuildContext context) async {
    if (currentScreenName == AllString.dashboard) {
      commonAlertDialogForBackPressToClose(context);

      return false;
    } else {
      if (!_isDrawerOpen) {
        _key.currentState!.openDrawer();
      } else {
        if (Navigator.canPop(context)) {
          // Navigator.pop(context);
          replaceScreenForDashboard(AllString.dashboard);
        } else {
          replaceScreenForDashboard(AllString.dashboard);
        }
      }
      setState(() {
        _isDrawerOpen = !_isDrawerOpen;
      });
      _handleOnPressed();
      return false;
    }
  }
}
