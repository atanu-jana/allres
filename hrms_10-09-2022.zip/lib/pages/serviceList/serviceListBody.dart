import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/myLoan/myLoanDetails.dart';
import 'package:hr/pages/serviceList/serviceDetails.dart';
import 'package:hr/pages/serviceList/serviceList.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';

class ServiceListBody extends StatefulWidget {
  @override
  _ServiceListBodyState createState() => _ServiceListBodyState();
}

class _ServiceListBodyState extends State<ServiceListBody> {
  bool loading = false;
  bool firstTimeLoading = true;
  TextEditingController _searchTextEditingController = TextEditingController();
  FocusNode _focusNode = FocusNode();
  List _loadList = [];
  List _searchResult = [];
  @override
  void initState() {
    super.initState();
    fetchServiceList();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                              decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Container(
                  width: screenWidth,
                  margin: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.015),
                  decoration: BoxDecoration(
                      color: AllColor.lightGrey,
                      borderRadius: BorderRadius.circular(10)),
                  height: screenWidth * 0.1,
                  child: Center(
                    child: TextField(
                      focusNode: _focusNode,
                      controller: _searchTextEditingController,
                      onChanged: onSearchTextChanged,
                      decoration: InputDecoration(
                          suffixIcon: _searchTextEditingController.text.isEmpty
                              ? Container(
                                  width: screenWidth * 0,
                                )
                              : GestureDetector(
                                  onTap: () {
                                    _searchTextEditingController.clear();
                                    _focusNode.unfocus();
                                    onSearchTextChanged('');
                                  },
                                  child:
                                      Icon(Icons.close, color: AllColor.black),
                                ),
                          prefixIcon: Icon(
                            Icons.search,
                            color: AllColor.black,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.03,
                              vertical: screenWidth * 0.03),
                          isDense: true,
                          hintStyle: normalTextStyle(color: AllColor.black),
                          hintText:
                              AllString.jonNo + ", " + AllString.customerName),
                    ),
                  ),
                )),
            Container(
              margin: EdgeInsets.only(
                top: screenWidth * 0.14,
              ),
              child: Container(
                child: _searchResult.length != 0 ||
                        _searchTextEditingController.text.isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                        itemCount: _searchResult.length,
                        itemBuilder: (context, index) =>
                            customListItem(_searchResult[index], index))
                    : _loadList.isEmpty
                        ? commonNoDataFound()
                        : ListView.builder(
                            padding:
                                EdgeInsets.only(bottom: screenWidth * 0.03),
                            physics: BouncingScrollPhysics(),
                            itemCount: _loadList.length,
                            itemBuilder: (context, index) =>
                                customListItem(_loadList[index], index)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  fetchServiceList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "searchJobValue": "",
        "branchId": "",
        "serviceStatusId": "",
        "jobNo": "",
        "productModelId": "",
        "divisionId": "",
        "customerName": "",
        "customerContact": "",
        "callTypeId": "",
        "asmId": "",
        "customerId": "",
        "employeeId": "",
        "userLoginId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "userTypeId": sharedPreferences!
            .getString(AllSharedPreferencesKey.individualTypeId),
      };
      apiPostRequestWithHeader(
              data, AllUrls.getServiceList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _loadList.clear();

            if (jsonData["serviceData"] == "") {
              _loadList = [];
            } else {
              _loadList = jsonData["serviceData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => ServiceDetails(
                  singleData: itemData,
                  visible: false,
                  callBack: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => ServiceList()));
                  },
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        height: screenWidth >= 600 ? screenWidth * 0.23 : screenWidth * 0.26,
        margin: customMarginCardItem(),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.25,
                      title: "Job No.",
                      value: itemData["jobNo"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.25,
                      title: "Client Name",
                      value: itemData["customerName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.8,
                      widthTitle: screenWidth * 0.25,
                      title: "Client Contact",
                      value: itemData["customerContactNo1"].toString()),

                  // customRowDetails(
                  //     width: screenWidth * 0.8,
                  //     widthTitle: screenWidth * 0.25,
                  //     title: AllString.remark,
                  //     value: checkApiValueValid(itemData["loanComment"])
                  //         ? AllString.na
                  //         : itemData["loanComment"]),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    _loadList.forEach((searchDetails) {
      if (searchDetails["jobNo"].toString().toLowerCase().contains(text) ||
          searchDetails["customerName"]
              .toString()
              .toLowerCase()
              .contains(text) ||
          searchDetails["customerContactNo1"]
              .toString()
              .toLowerCase()
              .contains(text)) _searchResult.add(searchDetails);
      setState(() {});
    });
    firstTimeLoading = false;

    setState(() {});
  }
}
