import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/team/teamBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class ServiceDetails extends StatefulWidget {
  final Map<String, dynamic> singleData;
  final bool visible;
  final Function() callBack;
  const ServiceDetails(
      {Key? key,
      required this.singleData,
      required this.callBack,
      required this.visible})
      : super(key: key);
  @override
  _ServiceDetailsState createState() => _ServiceDetailsState();
}

class _ServiceDetailsState extends State<ServiceDetails> {
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, AllString.serviceListDetails),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
          width: screenWidth,
          height: screenHeight,
                                decoration:customBackgroundGradient(),

          child: ListView(
            padding: EdgeInsets.only(bottom: screenWidth * 0.03),
            physics: BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: AllColor.black))),
                padding: EdgeInsets.all(1),
                margin: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.03,
                    vertical: screenWidth * 0.01),
                child: Container(
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10)),
                  width: screenWidth,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Job No.",
                              value: widget.singleData["jobNo"].toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Request Date",
                              value: convertStringToDate(DateTime.parse(
                                      widget.singleData["jobDate"]))
                                  .toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Client Name",
                              value:
                                  widget.singleData["customerName"].toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "ContactNo.",
                              value: widget.singleData["customerContactNo1"]
                                  .toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Brand Name",
                              value: widget.singleData["brandName"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Model No.",
                              value: widget.singleData["productModelNo"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Serial No.",
                              value: widget.singleData["serialNo"].toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Purchase Date",
                              value: convertStringToDate(DateTime.parse(
                                      widget.singleData["purchaseDate"]))
                                  .toString()),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Call Type",
                              value: widget.singleData["callTypeName"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Warranty Type",
                              value: widget.singleData["warrantyTypeName"]),
                          customRowDetails(
                              width: screenWidth - 50,
                              widthTitle: screenWidth * 0.28,
                              title: "Job Closed Date",
                              value: checkApiValueValid(
                                      widget.singleData["jobClosingDate"])
                                  ? AllString.na
                                  : convertStringToDate(DateTime.parse(
                                          widget.singleData["jobClosingDate"]))
                                      .toString()),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: screenWidth * 0.03,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
