import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:math' as math;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButton.dart';
import 'package:hr/common/commonFluttertoast.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/conveyance/conveyance.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/leaveBalance.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/myLoan/myLoan.dart';
import 'package:hr/pages/myPerformance/myPerformance.dart';
import 'package:hr/pages/myReimbursment/myReimbursment.dart';
import 'package:hr/pages/mySuggetion/mySuggetion.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/payment/payment.dart';
import 'package:hr/pages/payslip/paySlip.dart';
import 'package:hr/pages/profile/profile.dart';
import 'package:hr/pages/publicHoliday/publicHoliday.dart';
import 'package:hr/pages/recordAttendance/myAttendance.dart';
import 'package:hr/pages/recordAttendance/recordAttendance.dart';
import 'package:hr/pages/visitInOut/visitInOut.dart';
import 'package:hr/pages/workPlan/workPlan.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/res/allUrls.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:permission_handler/permission_handler.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  List<Color> color = [
    Color(0xffcfd8dc),
    Color(0xffd7ccc8),
    Color(0xffffccbc),
    Color(0xffffecb3),
    Color(0xffc8e6c9),
    Color(0xffb2ebf2),
    Color(0xffbbdefb),
    Color(0xffc5cae9),
    Color(0xffd1c4e9),
    Color(0xffe1bee7),
    Color(0xfff8bbd0),
    Color(0xffffcdd2),
  ];
  math.Random random = new math.Random();
  bool loading = false;
  List _loadList = [];
  String _configSetting = "";
  double distance = 0.0;
  String distanceForDisplay = "";
  String startLatLong = "";
  String endLatLong = "";
  @override
  void initState() {
    super.initState();
    try {
      FocusScope.of(context).unfocus();
    } catch (e) {}
    fetchVersionForUpdateCheck();

    fetchAndSetAllIdSettingConfig(this.context);
    // createRequestBodyAndHit();
    fetchMemberList();

    positionConfigForHitLocation();
    // fetchAllProduct();
// offlineTrackingSendLocationFetch();
    fetchConfigData();

    Future.delayed(Duration(milliseconds: 300), () {
      checkAndFetchAllDetails();
    });
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        height: screenHeight,
        width: screenWidth,
        decoration: customBackgroundGradient(),
        child: Stack(
          children: [
            Container(
              height: screenHeight - 100,
              padding: AllMargin.customBottom(),
              child: ListView(
                physics: BouncingScrollPhysics(),
                children: [
                  profileCard(),
                  sharedPreferences!.getString(
                              AllSharedPreferencesKey.userConfigSetting) ==
                          "null"
                      ? Container()
                      : sharedPreferences!.getString(
                                  AllSharedPreferencesKey.userConfigSetting) ==
                              "Both"
                          ? bothConfigView()
                          : sharedPreferences!.getString(AllSharedPreferencesKey
                                      .userConfigSetting) ==
                                  "OnlyHrModuleWithKra"
                              ? onlyHrModuleWithKra()
                              : sharedPreferences!.getString(
                                          AllSharedPreferencesKey
                                              .userConfigSetting) ==
                                      "OnlyHrModuleWithOutKra"
                                  ? onlyHrModuleWithOutKra()
                                  : sharedPreferences!.getString(
                                              AllSharedPreferencesKey
                                                  .userConfigSetting) ==
                                          "OnlySalesManApp"
                                      ? onlySalesManConfigView()
                                      : Container(),
                  //         Center(
                  //   child: GestureDetector(
                  //     onTap: () {
                  //       Navigator.of(context).push(
                  //           CupertinoPageRoute(builder: (context) => WorkPlan()));
                  //     },
                  //     child: Container(
                  //       margin: EdgeInsets.only(top: screenWidth * 0.1),
                  //       width: screenWidth * 0.8,
                  //       height: screenWidth * 0.45,
                  //       decoration: BoxDecoration(
                  //         color: AllColor.white,
                  //         // color: Color(0xffb4ffff),
                  //         boxShadow: [
                  //           BoxShadow(
                  //             color: Colors.grey.withOpacity(0.5),
                  //             spreadRadius: 2,
                  //             blurRadius: 7,
                  //             offset: Offset(0, 3), // changes position of shadow
                  //           ),
                  //         ],
                  //         borderRadius: BorderRadius.all(Radius.circular(10)),
                  //         border: Border.all(color: AllColor.black.withOpacity(0.1)),
                  //       ),
                  //       child: ClipRRect(
                  //         borderRadius: BorderRadius.all(Radius.circular(10)),
                  //         child: Stack(
                  //           children: [
                  //             Container(
                  //               width: screenWidth * 0.8,
                  //               height: screenWidth * 0.45,
                  //               decoration: BoxDecoration(
                  //                 color: AllColor.white,
                  //         // color: Color(0xffb4ffff),

                  //               ),
                  //               padding: AllMargin.customMarginCardItem(),
                  //               child: Column(
                  //                 mainAxisSize: MainAxisSize.min,
                  //                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  //                 crossAxisAlignment: CrossAxisAlignment.center,
                  //                 children: [
                  //                   Center(
                  //                     child: Container(
                  //                       width: screenWidth * 0.2,
                  //                       height: screenWidth * 0.15,
                  //                       alignment: Alignment.center,
                  //                       decoration: BoxDecoration(
                  //                           color: AllColor.blue,
                  //                           border: Border.all(
                  //                               color: AllColor.blue, width: 5),
                  //                           borderRadius: BorderRadius.circular(7)),
                  //                       child: headingText(AllString.tGTS,
                  //                           color: AllColor.white,
                  //                           center: true,
                  //                           fontWeight: FontWeight.bold),
                  //                     ),
                  //                   ),
                  //                   Divider(),
                  //                   Container(
                  //                     child: normalText(" Team Goal Tracking System ",
                  //                         center: true, color: AllColor.greyColor),
                  //                   )
                  //                 ],
                  //               ),
                  //             ),
                  //             Positioned(
                  //               bottom: -screenWidth * 0.33,
                  //               right: -screenWidth * 0.33,
                  //               child: Container(
                  //                 height: screenWidth * 0.7,
                  //                 width: screenWidth * 0.7,
                  //                 decoration: BoxDecoration(
                  //                     color: AllColor.primaryColor.withOpacity(0.1),
                  //                     borderRadius: BorderRadius.circular(10000)),
                  //               ),
                  //             ),
                  //             Positioned(
                  //               bottom: -screenWidth * 0.7,
                  //               right: -screenWidth * 0.1,
                  //               child: Container(
                  //                 height: screenWidth * 0.9,
                  //                 width: screenWidth * 0.9,
                  //                 decoration: BoxDecoration(
                  //                     color: AllColor.blue.withOpacity(0.1),
                  //                     borderRadius: BorderRadius.circular(10000)),
                  //               ),
                  //             ),
                  //             Positioned(
                  //               top: -screenWidth * 0.05,
                  //               left: -screenWidth * 0.05,
                  //               child: Container(
                  //                 height: screenWidth * 0.15,
                  //                 width: screenWidth * 0.15,
                  //                 decoration: BoxDecoration(
                  //                     border:
                  //                         Border.all

                  //                         (
                  //                           // color: AllColor.blue,
                  //                     color: AllColor.primaryColor.withOpacity(0.8),

                  //                           width: 3),
                  //                     borderRadius: BorderRadius.circular(10000)),
                  //               ),
                  //             ),
                  //             Positioned(
                  //               top: -screenWidth * 0.08,
                  //               left: -screenWidth * 0.08,
                  //               child: Container(
                  //                 height: screenWidth * 0.15,
                  //                 width: screenWidth * 0.15,
                  //                 decoration: BoxDecoration(
                  //                     // color: AllColor.blue,
                  //                     color: AllColor.primaryColor.withOpacity(0.9) ,
                  //                     borderRadius: BorderRadius.circular(10000)),
                  //               ),
                  //             )
                  //           ],
                  //         ),
                  //       ),
                  //     ),
                  //   ),
                  // )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  bothConfigView() {
    return ListView(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.profile, FontAwesomeIcons.userAlt, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Profile()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.recordAttendance, Icons.touch_app_outlined,
                        () {
                      Navigator.of(context).push(CupertinoPageRoute(
                          builder: (context) => RecordAttendance()));
                    }, color[random.nextInt(12)]),
                    // customDashboardButton(AllString.myAttendance,
                    //     Ionicons.calendar_outline, () {
                    //   Navigator.push(
                    //       context,
                    //       CupertinoPageRoute(
                    //           builder: (context) => MyAttendance(
                    //                 fromRecordAttendance: false,
                    //               )));
                    // }, color[random.nextInt(12)]),
                    customDashboardButton(
                      sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption) ==
                                  null ||
                              sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption) ==
                                  ""
                          ? AllString.visitIn
                          : AllString.visitOut,
                      Ionicons.locate_outline,
                      () {
                        if (sharedPreferences!.getString(
                                    AllSharedPreferencesKey.punchInId) ==
                                null ||
                            sharedPreferences!.getString(
                                    AllSharedPreferencesKey.punchInId) ==
                                "" ||
                            sharedPreferences!.getString(
                                    AllSharedPreferencesKey.attendanceStatus) ==
                                "1") {
                          commonAlertDialog(context, AllString.alert,
                              AllString.pleasePunchInBeforeVisitIn,
                              function: () {
                            Navigator.pop(context);
                            Navigator.of(context).push(CupertinoPageRoute(
                                builder: (context) => RecordAttendance()));
                          });
                        } else {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => VisitInOut()));
                        }
                      },
                      color[random.nextInt(12)],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.order, FontAwesomeIcons.handHolding, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Order()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.payment, FontAwesomeIcons.moneyBill, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Payment()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.expense, LineIcons.arrowDown, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => MyExpense()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(AllString.publicHolidays,
                        Icons.holiday_village_outlined, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => PublicHoliday()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.leaveBalance, LineIcons.moneyBill, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => LeaveBalance()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.myLoan, LineIcons.handHolding, () {
                      Navigator.push(context,
                          CupertinoPageRoute(builder: (context) => MyLoan()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.mySuggestion, LineIcons.signLanguage, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => MySuggetion()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.myPerformance, LineIcons.cardboardVr, () {
                      Navigator.of(context).push(CupertinoPageRoute(
                          builder: (context) => MyPerformance()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(AllString.paySlip, Icons.note_rounded,
                        () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Payslip()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  onlySalesManConfigView() {
    return ListView(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.profile, FontAwesomeIcons.userAlt, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Profile()));
                      // showPaymentDialog({});
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.recordAttendance, Icons.touch_app_outlined,
                        () {
                      Navigator.of(context).push(CupertinoPageRoute(
                          builder: (context) => RecordAttendance()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                      sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption) ==
                                  null ||
                              sharedPreferences!.getString(
                                      AllSharedPreferencesKey.checkInOption) ==
                                  ""
                          ? AllString.visitIn
                          : AllString.visitOut,
                      Ionicons.locate_outline,
                      () {
                        if (sharedPreferences!.getString(
                                    AllSharedPreferencesKey.punchInId) ==
                                null ||
                            sharedPreferences!.getString(
                                    AllSharedPreferencesKey.punchInId) ==
                                "" ||
                            sharedPreferences!.getString(
                                    AllSharedPreferencesKey.attendanceStatus) ==
                                "1") {
                          commonAlertDialog(context, AllString.alert,
                              AllString.pleasePunchInBeforeVisitIn,
                              function: () {
                            Navigator.pop(context);
                            Navigator.of(context).push(CupertinoPageRoute(
                                builder: (context) => RecordAttendance()));
                          });
                        } else {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => VisitInOut()));
                        }
                      },
                      color[random.nextInt(12)],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.order, FontAwesomeIcons.handHolding, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Order()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.payment, FontAwesomeIcons.moneyBill, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Payment()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.expense, LineIcons.arrowDown, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => MyExpense()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(AllString.publicHolidays,
                        Icons.holiday_village_outlined, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => PublicHoliday()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  onlyHrModuleWithOutKra() {
    return ListView(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.profile, FontAwesomeIcons.userAlt, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Profile()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.recordAttendance, Icons.touch_app_outlined,
                        () {
                      Navigator.of(context).push(CupertinoPageRoute(
                          builder: (context) => RecordAttendance()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.leaveBalance, LineIcons.moneyBill, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => LeaveBalance()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.myLoan, LineIcons.handHolding, () {
                      Navigator.push(context,
                          CupertinoPageRoute(builder: (context) => MyLoan()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.mySuggestion, LineIcons.signLanguage, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => MySuggetion()));
                    }, color[random.nextInt(12)]),
                    // customDashboardButton(
                    //     AllString.myPerformance, LineIcons.cardboardVr, () {
                    //   Navigator.of(context).push(CupertinoPageRoute(
                    //       builder: (context) => MyPerformance()));
                    // }, color[random.nextInt(12)]),
                    customDashboardButton(AllString.publicHolidays,
                        Icons.holiday_village_outlined, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => PublicHoliday()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        // Container(
        //   width: screenWidth,
        //   child: Column(
        //     mainAxisSize: MainAxisSize.min,
        //     children: [
        //       Container(
        //         margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
        //         child: Row(
        //           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        //           crossAxisAlignment: CrossAxisAlignment.center,
        //           children: [
        //             customDashboardButton(AllString.publicHolidays,
        //                 Icons.holiday_village_outlined, () {
        //               Navigator.push(
        //                   context,
        //                   CupertinoPageRoute(
        //                       builder: (context) => PublicHoliday()));
        //             }, color[random.nextInt(12)]),
        //           ],
        //         ),
        //       ),
        //     ],
        //   ),
        // ),
      ],
    );
  }

  onlyHrModuleWithKra() {
    return ListView(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.profile, FontAwesomeIcons.userAlt, () {
                      Navigator.of(context).push(
                          CupertinoPageRoute(builder: (context) => Profile()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.recordAttendance, Icons.touch_app_outlined,
                        () {
                      Navigator.of(context).push(CupertinoPageRoute(
                          builder: (context) => RecordAttendance()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.leaveBalance, LineIcons.moneyBill, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => LeaveBalance()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(
                        AllString.myLoan, LineIcons.handHolding, () {
                      Navigator.push(context,
                          CupertinoPageRoute(builder: (context) => MyLoan()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.mySuggestion, LineIcons.signLanguage, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => MySuggetion()));
                    }, color[random.nextInt(12)]),
                    customDashboardButton(
                        AllString.myPerformance, LineIcons.cardboardVr, () {
                      Navigator.of(context).push(CupertinoPageRoute(
                          builder: (context) => MyPerformance()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: screenWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    customDashboardButton(AllString.publicHolidays,
                        Icons.holiday_village_outlined, () {
                      Navigator.push(
                          context,
                          CupertinoPageRoute(
                              builder: (context) => PublicHoliday()));
                    }, color[random.nextInt(12)]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  customDashboardButton(
      String name, IconData icon, Function() onTap, Color color,
      {bool enable = true}) {
    return GestureDetector(
      onTap: enable ? onTap : () {},
      child: Container(
        width: screenWidth * 0.33,
        child: Container(
          child: Center(
            child: Container(
              decoration: customCardItemGradinet(),
              child: Container(
                // width: screenWidth >= 600
                //     ? screenWidth * 0.25
                //     : screenWidth > 450
                //         ? screenWidth * 0.26
                //         : screenWidth * 0.28,
                // height: screenWidth >= 600
                //     ? screenWidth * 0.22
                //     : screenWidth > 450
                //         ? screenWidth * 0.23
                //         : screenWidth * 0.25,
                width: screenWidth * 0.25,
                height: screenWidth * 0.25,
                margin: EdgeInsets.all(1),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: enable ? AllColor.white : AllColor.white),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      child: Center(
                        child: Container(
                          child: Container(
                            child: mediumIcon(icon,
                                color: enable
                                    // ? Color(0xff1C8D73)
                                    ? AllColor.primaryColor
                                    : AllColor.white),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      padding: AllMargin.customHorizontalSmall(),
                      child: Text(
                        name.split(" ").length > 1
                            ? name.split(" ").first +
                                "\n" +
                                name.split(" ").last
                            : name,
                        textAlign: TextAlign.center,
                        style: smallTextStyle(
                            color: enable ? AllColor.black : AllColor.greyColor,
                            fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  profileCard() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => Profile()));
      },
      child: Container(
        width: screenWidth,
        decoration: BoxDecoration(color: AllColor.primaryColor),
        // height: screenWidth * 0.37,
        alignment: Alignment.center,
        margin: EdgeInsets.only(
          bottom: screenWidth * 0.02,
        ),
        padding: AllMargin.customVerticalLarge(),
        child: Container(
          margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.05,
          ),
          child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.03,
              vertical: screenWidth >= 600
                  ? screenWidth * 0.02
                  : screenWidth > 450
                      ? screenWidth * 0.02
                      : screenWidth * 0.02,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: screenWidth >= 600
                      ? screenWidth * 0.18
                      : screenWidth > 450
                          ? screenWidth * 0.2
                          : screenWidth * 0.22,
                  height: screenWidth >= 600
                      ? screenWidth * 0.18
                      : screenWidth > 450
                          ? screenWidth * 0.2
                          : screenWidth * 0.22,
                  decoration: BoxDecoration(
                      color: AllColor.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(width: 2, color: AllColor.black)),
                  child: Center(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: sharedPreferences!
                                  .getString(AllSharedPreferencesKey.image)!
                                  .isEmpty ||
                              sharedPreferences!.getString(
                                      AllSharedPreferencesKey.image)! ==
                                  "null"
                          ? Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Image.asset(
                                    "assets/images/defaultUser.png"),
                              ),
                            )
                          : CachedNetworkImage(
                              width: screenWidth >= 600
                                  ? screenWidth * 0.16
                                  : screenWidth > 450
                                      ? screenWidth * 0.18
                                      : screenWidth * 0.2,
                              height: screenWidth >= 600
                                  ? screenWidth * 0.16
                                  : screenWidth > 450
                                      ? screenWidth * 0.18
                                      : screenWidth * 0.2,
                              fit: BoxFit.cover,
                              placeholder: (_, __) {
                                return Center(
                                  child: CircularProgressIndicator(),
                                );
                              },
                              errorWidget: (_, __, ___) {
                                return Center(
                                  child: Image.asset(
                                      "assets/images/defaultUser.png"),
                                );
                              },
                              imageUrl: sharedPreferences!
                                  .getString(AllSharedPreferencesKey.image)!),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(
                      // left: screenWidth * 0.05,
                      top: screenWidth * 0.03),
                  width: screenWidth,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        // sharedPreferences!.getString(
                        //                 AllSharedPreferencesKey.image)!,
                        sharedPreferences!
                            .getString(AllSharedPreferencesKey.companyName)!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: screenWidth >= 600
                                ? screenWidth * 0.042
                                : screenWidth * 0.055,
                            letterSpacing: 1.5,
                            color: AllColor.white,
                            fontWeight: FontWeight.bold),
                      ),
                      normalText(
                          sharedPreferences!
                              .getString(AllSharedPreferencesKey.firstName)!,
                          color: AllColor.white),
                      normalText(
                          showValidValue(sharedPreferences!.getString(
                                  AllSharedPreferencesKey.designation) ??
                              ""),
                          color: AllColor.white),
                      // normalText(
                      //     "( " +
                      //         sharedPreferences!.getString(
                      //             AllSharedPreferencesKey.designation)! +
                      //         " )",
                      //     color: AllColor.white),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  fetchDealer() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.getEmployeeDealer, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          sharedPreferences!.setString(
              AllSharedPreferencesKey.allDealerJson, response.toString());
          dealerList.clear();
          dealerList.add(AllString.select);
          List _tempList = jsonData["dealerData"];
          _tempList.forEach((element) {
            dealerList.add(element["dealerName"].toString() +
                AllString.splitText +
                element["dealerId"].toString());
          });
          setState(() {});
          setState(() {
            loading = false;
          });
          // fetchCategory();
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  // fetchCategory() {
  //   setState(() {
  //     loading = true;
  //   });
  //   Map data = {
  //     "divisionId": "",
  //     "companyId":
  //         sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
  //     "status": ""
  //   };
  //   apiPostRequestWithHeader(
  //           data, AllUrls.productDivisionListPost, this.context, loginToken)
  //       .then((response) {
  //     if (response == null) {
  //       loading = false;
  //       setState(() {});
  //       commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
  //     } else {
  //       Map<String, dynamic> jsonData = json.decode(response);
  //       if (checkApiResponseSuccessOrNot(jsonData)) {
  //         sharedPreferences!.setString(
  //             AllSharedPreferencesKey.allCategoryJson, response.toString());
  //         List _tempList = [];
  //         if (jsonData["divisionData"] == "" ||
  //             jsonData["divisionData"] == []) {
  //           _tempList = [];
  //         } else {
  //           _tempList = jsonData["divisionData"];
  //         }
  //         categoryList.clear();
  //         _tempList.forEach((element) {
  //           categoryList.add(element["divisionName"].toString() +
  //               AllString.splitText +
  //               element["divisionId"].toString());
  //         });

  //         setState(() {});
  //         fetchExpenseType();
  //       } else {
  //         setState(() {
  //           loading = false;
  //         });
  //         commonAlertDialog(context, jsonData["status"], jsonData["message"]);
  //       }
  //     }
  //   });
  // }

  // fetchExpenseType() {
  //   loading = true;
  //   setState(() {});
  //   Map data = {};
  //   apiPostRequestWithHeader(
  //           data, AllUrls.reimbursementMasterDataPost, this.context, loginToken)
  //       .then((response) {
  //     if (response == null) {
  //       loading = false;
  //       setState(() {});
  //       commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
  //     } else {
  //       Map<String, dynamic> jsonData = json.decode(response);
  //       if (checkApiResponseSuccessOrNot(jsonData)) {
  //         setState(() {
  //           loading = false;
  //         });
  //         sharedPreferences!.setString(
  //             AllSharedPreferencesKey.allExpenseTypeJson, response.toString());
  //         expenseTypeList.clear();

  //         List _tempList = jsonData["data"];
  //         _tempList.forEach((element) {
  //           expenseTypeList.add(element["reimbursementType"].toString() +
  //               AllString.splitText +
  //               element["reimbursementTypeId"].toString());
  //         });
  //         setState(() {});
  //         fetchAllProduct();
  //       } else {
  //         setState(() {
  //           loading = false;
  //         });
  //         commonAlertDialog(context, jsonData["status"], jsonData["message"]);
  //       }
  //     }
  //   });
  // }

  // fetchAllProduct() {
  //   loading = true;
  //   setState(() {});
  //   Map data = {
  //     "companyId":
  //         sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
  //     "divisionId": ""
  //   };
  //   apiPostRequestWithHeader(
  //           data, AllUrls.getModelByDivision, this.context, loginToken)
  //       .then((response) {
  //     if (response == null) {
  //       loading = false;
  //       setState(() {});
  //       commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
  //     } else {
  //       Map<String, dynamic> jsonData = json.decode(response);
  //       if (checkApiResponseSuccessOrNot(jsonData)) {
  //         setState(() {
  //           loading = false;
  //         });
  //         sharedPreferences!.setString(
  //             AllSharedPreferencesKey.allProductJson, response.toString());
  //         AppBuilder.of(context)!.rebuild();
  //         log("""sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.allProductJson: """ +
  //             sharedPreferences!
  //                 .getString(AllSharedPreferencesKey.allProductJson)!);
  //         sharedPreferences!.setString(
  //             AllSharedPreferencesKey.allProductJson, response.toString());
  //         // List _tempList = jsonData["data"];
  //         if (sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.allProductJson) ==
  //                 null ||
  //             sharedPreferences!
  //                     .getString(AllSharedPreferencesKey.allProductJson) ==
  //                 "null" ||
  //             sharedPreferences!
  //                 .getString(AllSharedPreferencesKey.allProductJson)!
  //                 .isEmpty) {
  //           fetchAllProduct();
  //         }
  //         setState(() {
  //           loading = false;
  //         });
  //       } else {
  //         setState(() {
  //           loading = false;
  //         });
  //         commonAlertDialog(context, jsonData["status"], jsonData["message"]);
  //       }
  //     }
  //   });
  // }

  fetchMemberList() {
    // setState(() {
    //   loading = true;
    // });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(data, AllUrls.memberList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        log("teamMemberL: " + jsonData.toString());
        fetchProfileOtherDetails();

        if (checkApiResponseSuccessOrNot(jsonData)) {
          teamMemberList.clear();
          allTeamMemberList.clear();
          teamMemberList.add(AllString.select);
          allTeamMemberList.add(AllString.select);

          if (jsonData["data"]["particularMember"].isEmpty ||
              jsonData["data"]["particularMember"].toString() == "") {
            teamMemberList.clear();
          } else {
            List _tempList = jsonData["data"]["particularMember"];
            _tempList.forEach((element) {
              teamMemberList.add(element["individualName"].toString() +
                  AllString.splitText +
                  element["individualId"].toString());
            });
          }
          // * All Team Members
          if (jsonData["data"]["allMembers"].isEmpty ||
              jsonData["data"]["allMembers"].toString() == "") {
            allTeamMemberList.clear();
          } else {
            List _tempList = jsonData["data"]["allMembers"];
            _tempList.forEach((element) {
              allTeamMemberList.add(element["individualName"].toString() +
                  AllString.splitText +
                  element["individualId"].toString());
            });
            // log("firstName: "+ sharedPreferences!
            //         .getString(AllSharedPreferencesKey.firstName)!);
            // allTeamMemberList.remove(sharedPreferences!
            //         .getString(AllSharedPreferencesKey.firstName)! +
            //     AllString.splitText +
            //     sharedPreferences!
            //         .getString(AllSharedPreferencesKey.individualId)!);
          }
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchConfigData() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "configParameterName": "hrmsFeaturesConfig" // will be static always
      };
      apiPostRequestWithHeader(
              data, AllUrls.getConfigData, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          log("otherConfiguration: " + jsonData.toString());
          if (checkApiResponseSuccessOrNot(jsonData)) {
            if (jsonData["configarationData"] == "") {
              _configSetting = "";
            } else {
              _configSetting =
                  jsonData["configarationData"][0]["option"].toString();
              log("_configSetting: " + _configSetting);
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.userConfigSetting, _configSetting);
            }
            log(_configSetting.toString());
            fetchOtherConfigConfigData();
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  fetchOtherConfigConfigData() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "configParameterName": [
          "tgtsConfig",
          "requestMangementConfig",
          "taskManagementConfig",
          "visitPurpose"
        ],
      };
      apiPostRequestWithHeader(
              data, AllUrls.hrmsMenuAccess, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          log("configarationDataaaa: " + jsonData.toString());
          if (checkApiResponseSuccessOrNot(jsonData)) {
            if (jsonData["configarationData"] == "") {
              _configSetting = "";
            } else {
              tgtsAvailable =
                  jsonData["configarationData"][0]["option"].toString() == "1"
                      ? true
                      : false;
              requestAvailable =
                  jsonData["configarationData"][1]["option"].toString() == "1"
                      ? true
                      : false;
              taskAvailable =
                  jsonData["configarationData"][2]["option"].toString() == "1"
                      ? true
                      : false;
              checkForExpenseAndVisitPurpose =
                  jsonData["configarationData"][3]["option"].toString() == "1"
                      ? true
                      : false;
              log("checkForExpenseAndVisitPurpose " +
                  checkForExpenseAndVisitPurpose.toString());
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  fetchProfileOtherDetails() async {
    log("Profile Call");
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
        "userId": loginUserId,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getEmployeeProfileDetails, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          setState(() {
            loading = false;
          });
          Map<String, dynamic> jsonDataForDetails = json.decode(response);
          log("designation " +
              jsonDataForDetails["employeeData"]["employeeDetails"][0]
                      ["designation"]
                  .toString());
          log("getEmployeeProfileDetails: " + jsonDataForDetails.toString());
          log("getEmployeeProfileDetailss: " +
              jsonDataForDetails["employeeData"]["employeeDetails"][0]
                      ["reportingManager"]
                  .toString());
          if (checkApiResponseSuccessOrNot(jsonDataForDetails)) {
            sharedPreferences!.setString(
                AllSharedPreferencesKey.reportingManager,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                    ["reportingManager"]
                                .toString() ==
                            "null" ||
                        jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                    ["reportingManager"]
                                .toString() ==
                            ""
                    ? AllString.na
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["reportingManager"]
                        .toString());

            if (jsonDataForDetails["employeeData"]["visitDetails"] == "" ||
                jsonDataForDetails["employeeData"]["visitDetails"].isEmpty) {
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.checkInOptionNameWithId, "");
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.checkInOptionName, "");
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.checkInOption, "");
            } else {
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.checkInOptionNameWithId,
                  jsonDataForDetails["employeeData"]["visitDetails"][0]
                                      ["dealerId"]
                                  .toString() ==
                              "null" ||
                          jsonDataForDetails["employeeData"]["visitDetails"][0]
                                      ["dealerId"]
                                  .toString() ==
                              "0"
                      ? ""
                      : jsonDataForDetails["employeeData"]["visitDetails"][0]
                              ["dealerId"]
                          .toString());
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.checkInOptionName,
                  jsonDataForDetails["employeeData"]["visitDetails"][0]
                                  ["visitTypeName"]
                              .toString() ==
                          "null"
                      ? ""
                      : jsonDataForDetails["employeeData"]["visitDetails"][0]
                              ["visitTypeName"]
                          .toString());

              sharedPreferences!.setString(
                  AllSharedPreferencesKey.checkInOption,
                  jsonDataForDetails["employeeData"]["visitDetails"][0]
                                      ["visitType"]
                                  .toString() ==
                              "null" ||
                          jsonDataForDetails["employeeData"]["visitDetails"][0]
                                      ["visitType"]
                                  .toString() ==
                              "0"
                      ? ""
                      : jsonDataForDetails["employeeData"]["visitDetails"][0]
                                      ["visitType"]
                                  .toString() ==
                              "1"
                          ? AllString.dealer
                          : jsonDataForDetails["employeeData"]["visitDetails"]
                                          [0]["visitType"]
                                      .toString() ==
                                  "2"
                              ? AllString.office
                              : jsonDataForDetails["employeeData"]
                                              ["visitDetails"][0]["visitType"]
                                          .toString() ==
                                      "3"
                                  ? AllString.others
                                  : "");
            }

            if (jsonDataForDetails["employeeData"]["employeeLastDistance"]
                        .toString() ==
                    "null" ||
                jsonDataForDetails["employeeData"]["employeeLastDistance"]
                        .toString() ==
                    "") {
              sharedPreferences!
                  .setDouble(AllSharedPreferencesKey.positionForSend, 0.0);
            } else {
              sharedPreferences!.setDouble(
                  AllSharedPreferencesKey.positionForSend,
                  double.parse(jsonDataForDetails["employeeData"]
                          ["employeeLastDistance"]
                      .toString()));
            }
            sharedPreferences!.setString(
                AllSharedPreferencesKey.sendLatitude,
                jsonDataForDetails["employeeData"]["checkInLatitude"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["checkInLatitude"]
                        .toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.sendLongitude,
                jsonDataForDetails["employeeData"]["checkInLongitude"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["checkInLongitude"]
                        .toString());

            // sharedPreferences!
            //     .setString(AllSharedPreferencesKey.attendanceStatus, "1");

            //

            sharedPreferences!.setString(
                AllSharedPreferencesKey.userRoleName,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["individualType"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["individualType"]
                        .toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.designation,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["designation"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["designation"]
                        .toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.individualId,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["individualId"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["individualId"]
                        .toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.individualTypeId,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["individualTypeId"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["individualTypeId"]
                        .toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.image,
                jsonDataForDetails["employeeData"]["employeeImage"][0]["url"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeImage"][0]
                            ["url"]
                        .toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.address,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["individualAddress"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["individualAddress"]
                        .toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.contact1,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["individualContactNo1"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["individualContactNo1"]
                        .toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.contact2,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["individualContactNo2"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["individualContactNo2"]
                        .toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.dob,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["dateOfBirth"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["dateOfBirth"]
                        .toString());

            sharedPreferences!.setString(
                AllSharedPreferencesKey.email,
                jsonDataForDetails["employeeData"]["employeeDetails"][0]
                                ["personalEmail"]
                            .toString() ==
                        "null"
                    ? ""
                    : jsonDataForDetails["employeeData"]["employeeDetails"][0]
                            ["personalEmail"]
                        .toString());

            loginToken = sharedPreferences!.getString(
                  AllSharedPreferencesKey.token,
                ) ??
                "";

            loginUserId = sharedPreferences!.getString(
                  AllSharedPreferencesKey.userId,
                ) ??
                "";
            loginIndivisualId = sharedPreferences!.getString(
                  AllSharedPreferencesKey.individualTypeId,
                ) ??
                "";
            AppBuilder.of(context)!.rebuild();

            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonDataForDetails["status"],
                jsonDataForDetails["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }

  checkAndFetchAllDetails() async {
    // //  log("allProductJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
    // log("allDealerJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allDealerJson)!);
    // log("allDealerJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allCommonDataJson)!);
    //     log("allCategoryJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allCategoryJson)!);
    //     log("allExpenseTypeJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allExpenseTypeJson)!);
    if ((dealerList.isEmpty || dealerList.length == 1) ||
        (expenseTypeList.isEmpty || expenseTypeList.length == 1)
        //  ||
        // (categoryList.isEmpty || categoryList.length == 1)
        ) {
      if (await internetCheck()) {
        fetchDealer();

        Future.delayed(Duration(milliseconds: 300), () {
          fetchCommonList();
        });
      } else {
        dealerList.clear();
        leaveTypeDetailsData.clear();
        leaveTypeDetailsData.clear();
        loanTypeDetailsData.clear();
        suggestionTypeDetails.clear();
        departmentDetails.clear();
        // categoryList.clear();
        expenseTypeList.clear();
        brandList.clear();
        // expenseTypeList.clear();
        // categoryList.clear();
        // dealerList.add(AllString.select);
        // expenseTypeList.add(AllString.select);
        // categoryList.add(AllString.select);
        // setState(() {
        //   loading = true;
        // });

        // // ! Product Data fetch from local

        // if (sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allProductJson) ==
        //         null ||
        //     sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allProductJson) ==
        //         "") {
        //   sharedPreferences!
        //       .setString(AllSharedPreferencesKey.allProductJson, "");
        // }
        // ! Dealer Data fetch from local
        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allDealerJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allDealerJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allDealerJson, "");
        } else {
          Map<String, dynamic> jsonDataForDealerList = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allDealerJson)!);

          List _tempList = jsonDataForDealerList["dealerData"];
          dealerList.clear();
          dealerList.add(AllString.select);
          _tempList.forEach((element) {
            dealerList.add(element["dealerName"].toString() +
                AllString.splitText +
                element["dealerId"].toString());
          });
        }
        // ! leaveTypeName Data fetch from local
        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        } else {
          Map<String, dynamic> jsonDataForCommon = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCommonDataJson)!);

          List _tempList =
              jsonDataForCommon["commonData"]["leaveTypeDetailsData"];
          leaveTypeDetailsData.clear();
          leaveTypeDetailsData.add(AllString.select);
          _tempList.forEach((element) {
            leaveTypeDetailsData.add(element["leaveTypeName"].toString() +
                AllString.splitText +
                element["leaveTypeId"].toString());
          });
        }

        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        } else {
          Map<String, dynamic> jsonDataForCommon = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCommonDataJson)!);

          List _tempList =
              jsonDataForCommon["commonData"]["loanTypeDetailsData"];
          loanTypeDetailsData.clear();
          loanTypeDetailsData.add(AllString.select);
          _tempList.forEach((element) {
            loanTypeDetailsData.add(element["loanTypeName"].toString() +
                AllString.splitText +
                element["loanTypeId"].toString());
          });
        }
        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        } else {
          Map<String, dynamic> jsonDataForCommon = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCommonDataJson)!);

          List _tempList =
              jsonDataForCommon["commonData"]["suggestionTypeDetails"];
          suggestionTypeDetails.clear();
          suggestionTypeDetails.add(AllString.select);
          _tempList.forEach((element) {
            suggestionTypeDetails.add(element["suggestionTypeName"].toString() +
                AllString.splitText +
                element["suggestionTypeId"].toString());
          });
        }
        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        } else {
          Map<String, dynamic> jsonDataForCommon = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCommonDataJson)!);

          List _tempList = jsonDataForCommon["commonData"]["departmentDetails"];
          departmentDetails.clear();
          departmentDetails.add(AllString.select);
          _tempList.forEach((element) {
            departmentDetails.add(element["departmentName"].toString() +
                AllString.splitText +
                element["departmentId"].toString());
          });
        }
        // if (sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allCommonDataJson) ==
        //         null ||
        //     sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allCommonDataJson) ==
        //         "") {
        //   sharedPreferences!
        //       .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        // } else {
        //   Map<String, dynamic> jsonDataForCommon = json.decode(
        //       sharedPreferences!
        //           .getString(AllSharedPreferencesKey.allCommonDataJson)!);

        //   List _tempList = jsonDataForCommon["commonData"]["divisionDetails"];
        //   categoryList.clear();
        //   categoryList.add(AllString.select);
        //   _tempList.forEach((element) {
        //     categoryList.add(element["productCategoryName"].toString() +
        //         AllString.splitText +
        //         element["productCategoryId"].toString());
        //   });
        // }
        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        } else {
          Map<String, dynamic> jsonDataForCommon = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCommonDataJson)!);

          List _tempList = jsonDataForCommon["commonData"]["reimburstmentData"];
          expenseTypeList.clear();
          expenseTypeList.add(AllString.select);
          _tempList.forEach((element) {
            expenseTypeList.add(element["reimbursementType"].toString() +
                AllString.splitText +
                element["reimbursementTypeId"].toString());
          });
        }
        if (sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                null ||
            sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson) ==
                "") {
          sharedPreferences!
              .setString(AllSharedPreferencesKey.allCommonDataJson, "");
        } else {
          Map<String, dynamic> jsonDataForCommon = json.decode(
              sharedPreferences!
                  .getString(AllSharedPreferencesKey.allCommonDataJson)!);

          List _tempList = jsonDataForCommon["commonData"]["brandDetails"];
          brandList.clear();
          brandList.add(AllString.select);
          _tempList.forEach((element) {
            brandList.add(element["brandName"].toString() +
                AllString.splitText +
                element["brandId"].toString());
          });
        }
        // // ! Category Data fetch from local
        // if (sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allCategoryJson) ==
        //         null ||
        //     sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allCategoryJson) ==
        //         "") {
        //   sharedPreferences!
        //       .setString(AllSharedPreferencesKey.allCategoryJson, "");
        // } else {
        //   Map<String, dynamic> jsonDataForCategoryList = json.decode(
        //       sharedPreferences!
        //           .getString(AllSharedPreferencesKey.allCategoryJson)!);
        //   List _tempList = jsonDataForCategoryList["divisionData"];
        //   _tempList.forEach((element) {
        //     categoryList.add(element["divisionName"].toString() +
        //         AllString.splitText +
        //         element["divisionId"].toString());
        //   });
        // }
        // // ! ExpenseType Data fetch from local
        // if (sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allExpenseTypeJson) ==
        //         null ||
        //     sharedPreferences!
        //             .getString(AllSharedPreferencesKey.allExpenseTypeJson) ==
        //         "") {
        //   sharedPreferences!
        //       .setString(AllSharedPreferencesKey.allExpenseTypeJson, "");
        // } else {
        //   Map<String, dynamic> jsonDataForExpenseTypeList = json.decode(
        //       sharedPreferences!
        //           .getString(AllSharedPreferencesKey.allExpenseTypeJson)!);
        //   List _tempList = jsonDataForExpenseTypeList["data"];
        //   _tempList.forEach((element) {
        //     expenseTypeList.add(element["reimbursementType"].toString() +
        //         AllString.splitText +
        //         element["reimbursementTypeId"].toString());
        //   });
        // }

        setState(() {
          loading = false;
        });
        showOfflineSnakbar(context);
      }
    }
  }

  apiHitForSendLocation() {
    if (sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude)! ==
            "") {
    } else {
      if (sharedPreferences!.getString(AllSharedPreferencesKey.allowance) ==
          "1") {
        // Timer.periodic(
        //     Duration(
        //         seconds: int.parse(sharedPreferences!
        //             .getString(AllSharedPreferencesKey.timeinterval)!)),
        //     (Timer t) {
        Permission.location.request().then((value) async {
          var status = await Permission.location.status;
          log(status.toString());
          if (await Permission.location.isRestricted) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForRestrictedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            if (status.isDenied) {
              commonAlertDialog(
                  context, AllString.error, AllString.msgForDeniedLocation,
                  function: () {
                Navigator.of(context).pushReplacement(
                    CupertinoPageRoute(builder: (context) => Home()));
              });
            } else {
              Position position = await Geolocator.getCurrentPosition(
                  desiredAccuracy: LocationAccuracy.high);

              setState(() {});

              startLatLong = sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLatitude)! +
                  " ||| " +
                  sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLongitude)!;
              endLatLong = position.latitude.toString() +
                  " ||| " +
                  position.longitude.toString();
              setState(() {});

              List<Placemark> placemarks = await placemarkFromCoordinates(
                  position.latitude, position.longitude);
              if (placemarks.isNotEmpty) {
                Placemark placeMark = placemarks[0];
                setState(() {});
                log(placeMark.toString());
                String location = placeMark.locality! +
                    ", " +
                    placeMark.subLocality! +
                    " " +
                    placeMark.name! +
                    ", Street: " +
                    placeMark.street! +
                    ", " +
                    placeMark.administrativeArea! +
                    " " +
                    placeMark.subAdministrativeArea! +
                    ", Pincode: " +
                    placeMark.postalCode! +
                    ", " +
                    placeMark.country!;
                sharedPreferences!
                    .setString(AllSharedPreferencesKey.location, location);
                distance = Geolocator.distanceBetween(
                    double.parse(sharedPreferences!
                        .getString(AllSharedPreferencesKey.sendLatitude)!),
                    double.parse(sharedPreferences!
                        .getString(AllSharedPreferencesKey.sendLongitude)!),
                    position.latitude,
                    position.longitude);
                distanceForDisplay =
                    (' ${distance != null ? distance > 1000 ? (distance / 1000).toStringAsFixed(2) : distance.toStringAsFixed(2) : 0} ${distance != null ? distance > 1000 ? 'KM' : 'm' : 0}');
// commonFluttertoast(msg:"Distance: "+ int.parse(distance.toStringAsFixed(0).toString()).toString());
                if (int.parse(distance.toStringAsFixed(0).toString()) > 1) {
                  sharedPreferences!.setString(
                      AllSharedPreferencesKey.sendLatitude,
                      position.latitude.toString());
                  sharedPreferences!.setString(
                      AllSharedPreferencesKey.sendLongitude,
                      position.longitude.toString());
                  sharedPreferences!.setDouble(
                      AllSharedPreferencesKey.positionForSend,
                      (sharedPreferences!.getDouble(
                              AllSharedPreferencesKey.positionForSend)! +
                          distance));
                  Map dataForSend = {
                    "companyId": sharedPreferences!
                        .getString(AllSharedPreferencesKey.companyId),
                    "individualId": sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualId),
                    "latitude": sharedPreferences!
                        .getString(AllSharedPreferencesKey.sendLatitude),
                    "longitude": sharedPreferences!
                        .getString(AllSharedPreferencesKey.sendLongitude),
                    "location": sharedPreferences!
                        .getString(AllSharedPreferencesKey.location),
                    "distance": sharedPreferences!
                        .getDouble(AllSharedPreferencesKey.positionForSend)!
                        .toStringAsFixed(2)
                  };
                  // commonFluttertoast(msg:dataForSend.toString());
                  apiPostRequestWithHeader(dataForSend,
                          AllUrls.addEmployeePosition, this.context, loginToken)
                      .then((response) {
                    if (response == null) {
                      commonAlertDialog(context, AllString.warning,
                          AllString.connectionFailure);
                    } else {
                      Map<String, dynamic> jsonDataForSend =
                          json.decode(response);
                      // commonFluttertoast(msg:jsonDataForSend.toString());

                      // commonFluttertoast(msg: "Send Location Resopnse "+jsonDataForSend.toString());

                      if (checkApiResponseSuccessOrNot(jsonDataForSend)) {
                        log(jsonDataForSend.toString());
                      } else {
                        commonAlertDialog(context, jsonDataForSend["status"],
                            jsonDataForSend["message"]);
                      }
                    }
                  });
                }
              }
              setState(() {});
            }
          }
        });
        // });
      }
    }
  }

  positionConfigForHitLocation() async {
    if (await internetCheck()) {
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)
      };
      apiPostRequestWithHeader(
              data, AllUrls.getLocationTrakingDetails, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            log(jsonData.toString());
            sharedPreferences!.setString(AllSharedPreferencesKey.timeinterval,
                jsonData["locationData"][0]["timeInterval"].toString());
            sharedPreferences!.setString(AllSharedPreferencesKey.allowance,
                jsonData["locationData"][0]["isAllowed"].toString());
            apiHitForSendLocation();

            setState(() {});
          } else {
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      offlineSentLocationTracking();
      // apiHitForSendLocation();
    }
  }

  offlineSentLocationTracking() {
    if (sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude) ==
            null ||
        sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude)! ==
            "") {
      log("offlineSentLocationTracking IF");
    } else {
      log("offlineSentLocationTracking ELSE");

      if (sharedPreferences!.getString(AllSharedPreferencesKey.allowance) ==
          "1") {
        log("offlineSentLocationTracking Allow");

        // Timer.periodic(
        //     Duration(
        //         seconds: int.parse(sharedPreferences!
        //             .getString(AllSharedPreferencesKey.timeinterval)!)),
        //     (Timer t) {
        Permission.location.request().then((value) async {
          var status = await Permission.location.status;
          log(status.toString());
          if (await Permission.location.isRestricted) {
            commonAlertDialog(
                context, AllString.error, AllString.msgForRestrictedLocation,
                function: () {
              Navigator.of(context).pushReplacement(
                  CupertinoPageRoute(builder: (context) => Home()));
            });
          } else {
            if (status.isDenied) {
              commonAlertDialog(
                  context, AllString.error, AllString.msgForDeniedLocation,
                  function: () {
                Navigator.of(context).pushReplacement(
                    CupertinoPageRoute(builder: (context) => Home()));
              });
            } else {
              Position position = await Geolocator.getCurrentPosition(
                  desiredAccuracy: LocationAccuracy.high);

              setState(() {});

              startLatLong = sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLatitude)! +
                  " ||| " +
                  sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLongitude)!;
              endLatLong = position.latitude.toString() +
                  " ||| " +
                  position.longitude.toString();
              setState(() {});

              sharedPreferences!.setString(
                  AllSharedPreferencesKey.location,
                  sharedPreferences!
                      .getString(AllSharedPreferencesKey.location)!);
              distance = Geolocator.distanceBetween(
                  double.parse(sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLatitude)!),
                  double.parse(sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLongitude)!),
                  position.latitude,
                  position.longitude);
              distanceForDisplay =
                  (' ${distance != null ? distance > 1000 ? (distance / 1000).toStringAsFixed(2) : distance.toStringAsFixed(2) : 0} ${distance != null ? distance > 1000 ? 'KM' : 'm' : 0}');
// commonFluttertoast(msg:"Distance: "+ int.parse(distance.toStringAsFixed(0).toString()).toString());
              if (int.parse(distance.toStringAsFixed(0).toString()) > 1) {
                sharedPreferences!.setString(
                    AllSharedPreferencesKey.sendLatitude,
                    position.latitude.toString());
                sharedPreferences!.setString(
                    AllSharedPreferencesKey.sendLongitude,
                    position.longitude.toString());
                sharedPreferences!.setDouble(
                    AllSharedPreferencesKey.positionForSend,
                    (sharedPreferences!.getDouble(
                            AllSharedPreferencesKey.positionForSend)! +
                        distance));

                Map<String, dynamic> data = {
                  Databasehelper.distance: sharedPreferences!
                      .getDouble(AllSharedPreferencesKey.positionForSend)!
                      .toStringAsFixed(2),
                  Databasehelper.latitude: sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLatitude),
                  Databasehelper.longitude: sharedPreferences!
                      .getString(AllSharedPreferencesKey.sendLongitude),
                  Databasehelper.location: sharedPreferences!
                      .getString(AllSharedPreferencesKey.location),
                };
                final id = await dbhelper.insertTrackingLocation(data);
                var allrows = await dbhelper.fetchAllTrackingLocation();
                log(allrows.toString());
              }
              setState(() {});
            }
          }
        });
        // });
      }
    }
  }

  fetchCommonList() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)
      };
      apiPostRequestWithHeader(
              data, AllUrls.getCommonData, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            leaveTypeDetailsData.clear();
            leaveTypeDetailsData.clear();
            loanTypeDetailsData.clear();
            suggestionTypeDetails.clear();
            departmentDetails.clear();
            // categoryList.clear();
            expenseTypeList.clear();
            brandList.clear();
            sharedPreferences!.setString(
                AllSharedPreferencesKey.allCommonDataJson, response.toString());
            log("oooo " +
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.allCommonDataJson)!
                    .toString());
            List _tempList = [];
            if (jsonData["commonData"] == "" || jsonData["commonData"] == []) {
              _tempList = [];
              setState(() {
                loading = false;
              });
            } else {
              // if (jsonData["commonData"]["dealerData"] == "" ||
              //     jsonData["commonData"]["dealerData"] == []) {
              //   sharedPreferences!
              //       .setString(AllSharedPreferencesKey.allDealerJson, "");
              // } else {
              //   sharedPreferences!.setString(
              //       AllSharedPreferencesKey.allDealerJson,
              //       jsonData["commonData"]["dealerData"].toString());

              //   _tempList = jsonData["commonData"]["dealerData"];
              //   _tempList.forEach((element) {
              //     dealerList.add(element["dealerName"].toString() +
              //         AllString.splitText +
              //         element["dealerId"].toString());
              //   });
              // }

              // if (jsonData["commonData"]["dealerData"] == "" ||
              //     jsonData["commonData"]["dealerData"] == []) {
              //   sharedPreferences!
              //       .setString(AllSharedPreferencesKey.allDealerJson, "");
              // } else {
              //   sharedPreferences!.setString(
              //       AllSharedPreferencesKey.allDealerJson,
              //       jsonData["commonData"]["dealerData"].toString());

              //   _tempList = jsonData["commonData"]["dealerData"];
              //   _tempList.forEach((element) {
              //     dealerList.add(element["dealerName"].toString() +
              //         AllString.splitText +
              //         element["dealerId"].toString());
              //   });
              // }

              if (jsonData["commonData"]["leaveTypeDetailsData"] == "" ||
                  jsonData["commonData"]["leaveTypeDetailsData"] == []) {
              } else {
                _tempList = jsonData["commonData"]["leaveTypeDetailsData"];
                leaveTypeDetailsData.clear();
                leaveTypeDetailsData.add(AllString.select);
                _tempList.forEach((element) {
                  leaveTypeDetailsData.add(element["leaveTypeName"].toString() +
                      AllString.splitText +
                      element["leaveTypeId"].toString());
                });
              }

              if (jsonData["commonData"]["loanTypeDetailsData"] == "" ||
                  jsonData["commonData"]["loanTypeDetailsData"] == []) {
              } else {
                _tempList = jsonData["commonData"]["loanTypeDetailsData"];
                loanTypeDetailsData.clear();
                loanTypeDetailsData.add(AllString.select);
                _tempList.forEach((element) {
                  loanTypeDetailsData.add(element["loanTypeName"].toString() +
                      AllString.splitText +
                      element["loanTypeId"].toString());
                });
              }

              if (jsonData["commonData"]["suggestionTypeDetails"] == "" ||
                  jsonData["commonData"]["suggestionTypeDetails"] == []) {
              } else {
                _tempList = jsonData["commonData"]["suggestionTypeDetails"];
                suggestionTypeDetails.clear();
                suggestionTypeDetails.add(AllString.select);
                _tempList.forEach((element) {
                  suggestionTypeDetails.add(
                      element["suggestionTypeName"].toString() +
                          AllString.splitText +
                          element["suggestionTypeId"].toString());
                });
              }

              if (jsonData["commonData"]["departmentDetails"] == "" ||
                  jsonData["commonData"]["departmentDetails"] == []) {
              } else {
                _tempList = jsonData["commonData"]["departmentDetails"];
                departmentDetails.clear();
                departmentDetails.add(AllString.select);
                _tempList.forEach((element) {
                  departmentDetails.add(element["departmentName"].toString() +
                      AllString.splitText +
                      element["departmentId"].toString());
                });
              }

              // if (jsonData["commonData"]["divisionDetails"] == "" ||
              //     jsonData["commonData"]["divisionDetails"] == []) {
              // } else {
              //   categoryList.clear();
              //   categoryList.clear();
              //   categoryList.add(AllString.select);
              //   _tempList = jsonData["commonData"]["divisionDetails"];
              //   _tempList.forEach((element) {
              //     categoryList.add(element["productCategoryName"].toString() +
              //         AllString.splitText +
              //         element["productCategoryId"].toString());
              //   });
              // }
              if (jsonData["commonData"]["reimburstmentData"] == "" ||
                  jsonData["commonData"]["reimburstmentData"] == []) {
              } else {
                expenseTypeList.clear();
                expenseTypeList.add(AllString.select);
                _tempList = jsonData["commonData"]["reimburstmentData"];
                _tempList.forEach((element) {
                  expenseTypeList.add(element["reimbursementType"].toString() +
                      AllString.splitText +
                      element["reimbursementTypeId"].toString());
                });
              }
              if (jsonData["commonData"]["brandDetails"] == "" ||
                  jsonData["commonData"]["brandDetails"] == []) {
                brandList = [];
              } else {
                brandList.clear();
                brandList.add(AllString.select);
                _tempList = jsonData["commonData"]["brandDetails"];
                _tempList.forEach((element) {
                  brandList.add(element["brandName"].toString() +
                      AllString.splitText +
                      element["brandId"].toString());
                });
              }
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      apiHitForSendLocation();
    }
  }

  offlineTrackingSendLocationFetch() async {
    setState(() {
      loading = true;
    });
    if (await internetCheck()) {
      var allrows = await dbhelper.fetchAllTrackingLocation();
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
        "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
        "trackingData": allrows,
      };
      log(data.toString());
      apiPostRequestWithHeader(
              data, AllUrls.addEmployeePosition, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(
              context, AllString.warning, AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            setState(() {
              loading = false;
            });

            commonAlertDialog(context, jsonData["status"], jsonData["message"],
                function: () async {
              List allSendLocationList = allrows;
              allSendLocationList.forEach((element) {
                dbhelper.deleteTrackingLocation(element["id"]);
              });

              var allrowsss = await dbhelper.fetchAllTrackingLocation();
              log(allrowsss.toString());
              setState(() {});
              Navigator.pop(context);
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    }
  }

  createRequestBodyAndHit() async {
    if (await internetCheck()) {
      // log("\n\nFetch All Tracking Location ====================================================\n\n");
      // allrows = await dbhelper.fetchAllTrackingLocation();
      // data = {
      //   "companyId":
      //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      //   "individualId":
      //       sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      //   "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
      //   "trackingData": allrows,
      // };
      // log(json.encode(data));
      log("\n\nFetch All Day Start Day End ====================================================\n\n");

      var allAttendanceRowsList = await dbhelper.fetchAllDayStartDayEnd();
      List allAttendanceRows = [];
      allAttendanceRowsList.forEach((element) {
        allAttendanceRows.add({
          "inTime": element["punchInTime"],
          "outTime": element["punchOutTime"],
          "checkInLocation": element["checkInLocation"],
          "checkInLatitude": element["checkInLatitude"],
          "checkInLongitude": element["checkInLongitude"],
          "checkOutLocation": element["checkOutLocation"],
          "checkOutLongitude": element["checkOutLongitude"],
          "checkOutLatitude": element["checkOutLatitude"]
        });
      });
      Future.delayed(Duration(milliseconds: 300), () {
        if (allAttendanceRows.isNotEmpty) {
          Map attendanceData = {
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "userLoginId":
                sharedPreferences!.getString(AllSharedPreferencesKey.userId),
            "attendanceData": allAttendanceRows,
          };
          // commonFluttertoast(msg: "Attendance Hit");

          apiPostRequestWithHeader(attendanceData,
                  AllUrls.addEmployeeAttendance, this.context, loginToken)
              .then((response) {
            if (response == null) {
              log("Null Response");
            } else {
              Map<String, dynamic> attendanceResponse = json.decode(response);
              log("Attendance Response: " + attendanceResponse.toString());
              if (checkApiResponseSuccessOrNot(attendanceResponse)) {
                allAttendanceRowsList.forEach((element) {
                  dbhelper.deleteDayStartDayEnd(element["id"]);
                });
                callAllOfflineBreakForUpdate();
              } else {}
            }
          });
        }
      });

      log("\n\nFetch All Check In ====================================================\n\n");
      var allCheckInRowsList = await dbhelper.fetchAllCheckIn();
      List allCheckInRowsForRequest = [];
      allCheckInRowsList.forEach((element) {
        allCheckInRowsForRequest.add({
          "officeName": element["checkInofficeName"],
          "officeType": element["checkInofficeType"],
          "dealerId": element["checkIndealerId"],
          "visitTypeName": element["checkInvisitTypeName"],
          "visitType": element["checkInvisitType"],
          "location": element["checkInlocation"],
          "latitude": element["checkInlatitude"],
          "longitude": element["checkInlongitude"],
          "checkInTime": element["checkInTime"],
        });
      });

      Future.delayed(Duration(milliseconds: 300), () {
        if (allCheckInRowsForRequest.isNotEmpty) {
          Map checkInData = {
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "userLoginId":
                sharedPreferences!.getString(AllSharedPreferencesKey.userId),
            "checkInData": allCheckInRowsForRequest,
          };
          log(json.encode(checkInData));
          // commonFluttertoast(msg: "Check In Hit");
          log("checkInResponse: " + checkInData.toString());

          apiPostRequestWithHeader(checkInData, AllUrls.employeeVisitIn,
                  this.context, loginToken)
              .then((response) {
            if (response == null) {
              log("Null Response");
            } else {
              Map<String, dynamic> checkInResponse = json.decode(response);
              // commonFluttertoast(
              //     msg: "Check In Response: " + checkInResponse.toString());
              // commonAlertDialog(
              //     context, "Check In Response", checkInResponse.toString());

              if (checkApiResponseSuccessOrNot(checkInResponse)) {
                allCheckInRowsList.forEach((element) {
                  dbhelper.deleteCheckIn(element["id"]);
                });
                callOfflineCheckOut();
              } else {}
            }
          });
        }
      });

      log("\n\nFetch All Order ====================================================\n\n");

      var allOrderRowsList = await dbhelper.fetchAllOrder();
      List allOrderRows = [];
      List allOrderRowsFinalList = [];
      Future.forEach(allOrderRowsList, (Map element) async {
        allOrderRows = await dbhelper
            .fetchAllOrderSubList(element["id"].toString().trim() + "_Order");

        allOrderRowsFinalList.add({
          "dealerId": element["dealerId"],
          "visitType": element["visitType"],
          "visitTypeName": element["visitTypeName"],
          "remarks": element["remarks"],
          "orderData": allOrderRows
        });
      });

      Future.delayed(Duration(milliseconds: 300), () {
        if (allOrderRowsFinalList.isNotEmpty) {
          Map orderData = {
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "userLoginId":
                sharedPreferences!.getString(AllSharedPreferencesKey.userId),
            "orderDetails": allOrderRowsFinalList,
          };
          // commonFluttertoast(msg: "Add Order Hit");

          apiPostRequestWithHeader(
                  orderData, AllUrls.addOrder, this.context, loginToken)
              .then((response) {
            if (response == null) {
              log("Null Response");
            } else {
              Map<String, dynamic> orderResponse = json.decode(response);
              log("Order Response: " + orderResponse.toString());
              if (checkApiResponseSuccessOrNot(orderResponse)) {
                Future.forEach(allOrderRowsList, (Map element) async {
                  allOrderRows = await dbhelper.fetchAllOrderSubList(
                      element["id"].toString().trim() + "_Order");
                  Future.forEach(allOrderRowsList, (Map subElement) async {
                    dbhelper.deleteOrderSubList(subElement["id"]);
                  });
                }).whenComplete(() {
                  Future.forEach(allOrderRowsList, (Map element) async {
                    dbhelper.deleteOrder(element["id"]);
                  });
                });
              } else {}
            }
          });
        }
      });

      log("\n\nFetch All Payment ====================================================\n\n");

      var allPaymentRowsList = await dbhelper.fetchAllApplyPayment();
      var allrowsPaymentImages = await dbhelper.fetchAllPaymentImage();
      List<Map<String, dynamic>> paymentResponList = [];

      Future.forEach(allPaymentRowsList, (Map expenseEle) {
        Map<String, dynamic> tempData = {
          "id": expenseEle["id"],
          "dealerId": expenseEle["dealerId"],
          "amount": expenseEle["amount"],
          "comment": expenseEle["comment"],
          "visitTypeName": expenseEle["visitTypeName"],
          "visitTypeId": expenseEle["visitTypeId"],
          "paymentUniqueId": expenseEle["paymentUniqueId"],
          "paymentImage": "",
        };
        paymentResponList.add(tempData);
      });

      Future.forEach(paymentResponList, (Map<String, dynamic> elementJson) {
        Future.forEach(allrowsPaymentImages, (Map<String, dynamic> ele) {
          if (ele["paymentId"].toString() == elementJson["id"].toString()) {
            elementJson["paymentImage"] =
                ele["paymentPaymentImage"].toString().isNotEmpty
                    // ? ele["paymentPaymentImage"].toString().substring(0, 15)
                    ? ele["paymentPaymentImage"].toString()
                    : "";
          }
        });
      });

      Future.delayed(Duration(milliseconds: 300), () {
        if (allPaymentRowsList.isNotEmpty) {
          Map expenseData = {
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "userLoginId":
                sharedPreferences!.getString(AllSharedPreferencesKey.userId),
            "paymentData": paymentResponList,
          };
          // commonFluttertoast(msg: "Add Payment Hit");

          apiPostRequestWithHeader(
                  expenseData, AllUrls.addPaymentPost, this.context, loginToken)
              .then((response) {
            if (response == null) {
              log("Null Response");
            } else {
              Map<String, dynamic> attendanceResponse = json.decode(response);
              // commonAlertDialog(
              //     context, "Payment Response", attendanceResponse.toString());
              if (checkApiResponseSuccessOrNot(attendanceResponse)) {
                allPaymentRowsList.forEach((element) {
                  dbhelper.deleteApplyPayment(element["id"]);
                });
                allrowsPaymentImages.forEach((element) {
                  dbhelper.deletePaymentImage(element["id"]);
                });
              } else {}
            }
          });
        }
      });

      log("\n\nFetch All Expense ====================================================\n\n");

      var allExpenseRowsList = await dbhelper.fetchAllExpense();
      var allrowsExpenseImages = await dbhelper.fetchAllExpenseImage();
      List<Map<String, dynamic>> expenseResponList = [];
      List<Map<String, dynamic>> expenseResponListFinal = [];

      Future.forEach(allExpenseRowsList, (Map expenseEle) {
        Map<String, dynamic> tempData = {
          "id": expenseEle["id"],
          "expenceTypeId": expenseEle["expenceTypeId"],
          "visitId": expenseEle["visitId"],
          "amount": expenseEle["amount"],
          "comment": expenseEle["comment"],
          "attchment1": "",
          "attchment2": ""
        };
        expenseResponList.add(tempData);
      });

      Future.forEach(expenseResponList, (Map<String, dynamic> elementJson) {
        Future.forEach(allrowsExpenseImages, (Map<String, dynamic> ele) {
          if (ele["expenseId"].toString() == elementJson["id"].toString()) {
            elementJson["attchment1"] =
                ele["expenseAttchment1"].toString().isNotEmpty
                    // ? ele["expenseAttchment1"].toString().substring(0, 15)
                    ? ele["expenseAttchment1"].toString()
                    : "";
          }
        });
      });

      Future.delayed(Duration(milliseconds: 300), () {
        if (allExpenseRowsList.isNotEmpty) {
          Map expenseData = {
            "companyId":
                sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
            "individualId": sharedPreferences!
                .getString(AllSharedPreferencesKey.individualId),
            "userLoginId":
                sharedPreferences!.getString(AllSharedPreferencesKey.userId),
            "expenseData": expenseResponList,
          };
          // commonFluttertoast(msg: "Add Expense Hit");

          apiPostRequestWithHeader(expenseData, AllUrls.addEmployeeExpence,
                  this.context, loginToken)
              .then((response) {
            if (response == null) {
              log("Null Response");
            } else {
              Map<String, dynamic> attendanceResponse = json.decode(response);
              // commonAlertDialog(
              //     context, "Expense Response", attendanceResponse.toString());
              if (checkApiResponseSuccessOrNot(attendanceResponse)) {
                allExpenseRowsList.forEach((element) {
                  dbhelper.deleteExpense(element["id"]);
                });
                allrowsExpenseImages.forEach((element) {
                  dbhelper.deleteExpenseImage(element["id"]);
                });
              } else {}
            }
          });
        }
      });
    }
  }

  callOfflineCheckOut() async {
    log("\n\nFetch All Check Out ====================================================\n\n");

    var allCheckOutRowsList = await dbhelper.fetchAllCheckOut();
    List<Map<String, dynamic>> allrowsCheckOutImages =
        await dbhelper.fetchAllCheckOutImage();
    List<Map<String, dynamic>> checkOutResponList = [];

    allCheckOutRowsList.forEach((element) {
      checkOutResponList.add({
        "id": element["id"],
        "location": element["checkOutlocation"],
        "latitude": element["checkOutlatitude"],
        "longitude": element["checkOutlongitude"],
        "officeName": element["checkOutofficeName"],
        "dealerId": element["checkOutDealerId"],
        "visitType": element["checkOutvisitType"],
        "visitTypeName": element["checkOutvisitTypeName"],
        "checkInId": element["checkInIdForCheckOut"],
        "attatchmentImageFile1": "",
        "attatchmentImageFile2": "",
        "checkOutTime": element["checkOutcheckOutTime"],
        "payment": {
          "amount": element["checkOutpaymentAmount"] ?? "",
          "remarks": element["checkOutpaymentRemark"] ?? "",
        },
        "conveyance": {
          "amount": element["checkOutconveyanceAmount"] ?? "",
          "remarks": element["checkOutconveyanceRemark"] ?? ""
        }
      });
    });

    Future.forEach(checkOutResponList, (Map<String, dynamic> elementJson) {
      Future.forEach(allrowsCheckOutImages, (Map<String, dynamic> ele) {
        if (ele["orderId"].toString() == elementJson["id"].toString()) {
          elementJson["checkOutAttatchmentImageFile1"] =
              ele["checkOutAttatchmentImageFile1"].toString().isNotEmpty
                  // ? ele["checkOutAttatchmentImageFile1"]
                  //     .toString()
                  //     .substring(0, 15)
                  ? ele["checkOutAttatchmentImageFile1"].toString()
                  : "";
          elementJson["checkOutAttatchmentImageFile2"] =
              ele["checkOutAttatchmentImageFile2"].toString().isNotEmpty
                  // ? ele["checkOutAttatchmentImageFile2"]
                  //     .toString()
                  //     .substring(0, 15)
                  ? ele["checkOutAttatchmentImageFile2"].toString()
                  : "";
          elementJson["checkOutPaymentImage"] =
              ele["checkOutPaymentImage"].toString().isNotEmpty
                  // ? ele["checkOutPaymentImage"].toString().substring(0, 15)
                  ? ele["checkOutPaymentImage"].toString()
                  : "";
        }
      });
    });
    Future.forEach(checkOutResponList, (Map<String, dynamic> elementJson) {
      List<Map<String, dynamic>> allOrderRows = [];
      dbhelper
          .fetchAllOrderSubList(
              elementJson["id"].toString().trim() + "_CheckOut")
          .then((value) {
        Future.delayed(Duration(milliseconds: 600), () {
          List<Map<String, dynamic>> allOrderRowsFinalList = [];

          allOrderRows = value;
          Future.forEach(allOrderRows, (Map<String, dynamic> eleeee) {
            allOrderRowsFinalList.add({
              "productCategoryId": eleeee["productCategoryId"],
              "productId": eleeee["productId"],
              "brandId": eleeee["brandId"],
              "quantity": eleeee["quantity"]
            });
            elementJson["orders"] = allOrderRowsFinalList;
          });
        });
      });
    });

    // List allrowsCheckOutOrder = [];
    // allrows.forEach((element) async {
    //   allrowsCheckOutOrder = await dbhelper
    //       .fetchAllOrderSubList(element["id"].toString() + "_CheckOut");
    // });
    Future.delayed(Duration(seconds: 3), () {
      if (checkOutResponList.isNotEmpty) {
        Map checkOutData = {
          "companyId":
              sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
          "individualId": sharedPreferences!
              .getString(AllSharedPreferencesKey.individualId),
          "userId":
              sharedPreferences!.getString(AllSharedPreferencesKey.userId),
          "checkOutData": checkOutResponList,
        };
        // commonFluttertoast(msg: "Check Out Hit");
        log("checkOutData: " + checkOutData.toString());
        apiPostRequestWithHeader(checkOutData, AllUrls.employeeVisitOut,
                this.context, loginToken)
            .then((response) {
          if (response == null) {
            log("Null Response");
          } else {
            Map<String, dynamic> checkOutResponse = json.decode(response);
            commonFluttertoast(
                msg: "Check Out Response: " + checkOutResponse.toString());
            // commonAlertDialog(
            //     context, "Check Out Response", checkOutResponse.toString());
            if (checkApiResponseSuccessOrNot(checkOutResponse)) {
              // allCheckOutRowsList.forEach((element) {
              //   dbhelper.deleteCheckOut(element["id"]);
              // });
              allrowsCheckOutImages.forEach((element) {
                dbhelper.deleteCheckOutImage(element["id"]);
              });
              Future.forEach(checkOutResponList,
                  (Map<String, dynamic> elementJson) {
                dbhelper.fetchAllOrderSubList(
                    elementJson["id"].toString().trim() + "_CheckOut");
                Future.forEach(checkOutResponList, (Map subElement) async {
                  dbhelper.deleteOrderSubList(subElement["id"]);
                });
              }).whenComplete(() {
                Future.forEach(checkOutResponList, (Map element) async {
                  log("checkOutResponList: " + element["id"].toString());
                  dbhelper.deleteCheckOut(element["id"]);
                });
              });
            } else {}
          }
        });
      }
    });
  }

  callAllOfflineBreakForUpdate() async {
    log("\n\n Fetch All Break Start Break End ==================================================== \n\n");

    var allBreakRowsList = await dbhelper.fetchAllBreakStartAndBreakEnd();
    List allBreakRows = [];
    allBreakRowsList.forEach((element) {
      allBreakRows.add({
        "attendanceId": element["attendanceId"],
        "breakPunchId": element["breakPunchId"],
        "inTime": element["breakStartTime"],
        "outTime": element["breakEndTime"],
      });
    });
    Future.delayed(Duration(milliseconds: 300), () {
      if (allBreakRowsList.isNotEmpty) {
        Map breakData = {
          "companyId":
              sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
          "individualId": sharedPreferences!
              .getString(AllSharedPreferencesKey.individualId),
          "userLoginId":
              sharedPreferences!.getString(AllSharedPreferencesKey.userId),
          "breakData": allBreakRows,
        };
        // commonFluttertoast(msg: "Break Hit");

        apiPostRequestWithHeader(
                breakData, AllUrls.breakStartEnd, this.context, loginToken)
            .then((response) {
          if (response == null) {
            log("Null Response");
          } else {
            Map<String, dynamic> attendanceResponse = json.decode(response);
            log("Attendance Response: " + attendanceResponse.toString());
            if (checkApiResponseSuccessOrNot(attendanceResponse)) {
              allBreakRowsList.forEach((element) {
                dbhelper.deleteBreakStartBreakEnd(element["id"]);
              });
            } else {}
          }
        });
      }
    });
  }

  fetchVersionForUpdateCheck() {
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "appVersion": appVersion
    };
    apiPostRequestWithHeader(
            data, AllUrls.updateAppVersion, this.context, loginToken)
        .then((response) {
      if (response == null) {
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure,
            function: () {
          Navigator.pop(context);
        });
      } else {
        Map<String, dynamic> versionJson = json.decode(response);
        log("versionJson: " + versionJson.toString());
        if (checkApiResponseSuccessOrNot(versionJson)) {
          if (versionJson["versionData"]["flag"]) {
            showUpdateDialog(versionJson);
          } else {
            checkPaymentStatus();
          }
        } else {
          checkPaymentStatus();
        }
      }
    });
  }

  checkPaymentStatus() {
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "configParameterName": "paymentChasingPopUpForHrms"
    };
    apiPostRequestWithHeader(
            data, AllUrls.companyPayment, this.context, loginToken)
        .then((response) {
      if (response == null) {
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure,
            function: () {
          Navigator.pop(context);
        });
      } else {
        Map<String, dynamic> versionJson = json.decode(response);
        log("paymentJsonnn: " + versionJson.toString());
        if (checkApiResponseSuccessOrNot(versionJson)) {
          if (versionJson["configarationData"].isEmpty) {
          } else if (versionJson["configarationData"][0]["option"].toString() ==
              "1") {
            showPaymentDialog(versionJson);
          } else if (versionJson["configarationData"][0]["option"].toString() ==
              "2") {
            showPaymentDialog(versionJson);
          }
        } else {}
      }
    });
  }

  showUpdateDialog(Map versionJson) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => WillPopScope(
              onWillPop: () async => false,
              child: Dialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0)),
                elevation: 0.0,
                backgroundColor: Colors.transparent,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16.0),
                  child: Container(
                    margin: EdgeInsets.only(left: 0.0, right: 0.0),
                    child: Stack(
                      children: <Widget>[
                        Container(
                          // padding: EdgeInsets.only(
                          //   top: 18.0,
                          // ),
                          // margin: EdgeInsets.only(top: 13.0, right: 8.0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(16.0),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 0.0,
                                  offset: Offset(0.0, 0.0),
                                ),
                              ]),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              Container(
                                  height: screenWidth * 0.55,
                                  alignment: Alignment.center,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        top: -screenWidth * 0.5,
                                        left: -screenWidth * 0.1,
                                        right: -screenWidth * 0.1,
                                        child: SvgPicture.asset(
                                          "assets/images/cloud.svg",
                                          color: Color(0xffffca28),
                                          width: screenWidth * 5,
                                          height: screenWidth * 0.9,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Positioned(
                                        top: screenWidth * 0.1,
                                        left: screenWidth * 0.1,
                                        child: Column(
                                          children: [
                                            Text(
                                              "Upgrade",
                                              textAlign: TextAlign.center,
                                              style: headingTextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xff870000)),
                                            ),
                                            Text(
                                              "New Version",
                                              textAlign: TextAlign.center,
                                              style: normalTextStyle(
                                                  color: Color(0xfff57c00)),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Positioned(
                                        top: screenWidth * 0.05,
                                        right: screenWidth * 0.1,
                                        child: SvgPicture.asset(
                                          "assets/images/rocket.svg",
                                          // color: Color(0xffffca28),
                                          // width: screenWidth * 5,
                                          height: screenWidth * 0.35,
                                          fit: BoxFit.cover,
                                        ),
                                      )
                                    ],
                                  )),
                              Container(
                                width: screenWidth,
                                padding: EdgeInsets.symmetric(
                                    horizontal: screenWidth * 0.02,
                                    vertical: screenWidth * 0.0),
                                alignment: Alignment.center,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: screenWidth,
                                      child: Text(
                                        "Dear " +
                                            sharedPreferences!.getString(
                                                AllSharedPreferencesKey
                                                    .firstName)!,
                                        textAlign: TextAlign.start,
                                        style: headingTextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: AllColor.black),
                                      ),
                                    ),
                                    SizedBox(
                                      height: screenWidth * 0.02,
                                    ),
                                    Container(
                                      width: screenWidth,
                                      child: Text(
                                        // "App updates are great for both app users and apps – updates mean that developers are always working on improving the app, keeping in mind a better customer experience with each update",
                                        versionJson["message"].toString(),
                                        textAlign: TextAlign.justify,
                                        style: normalTextStyle(
                                            color: AllColor.black
                                                .withOpacity(0.5)),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.symmetric(
                                    vertical: screenWidth * 0.03,
                                  ),
                                  child: Divider()),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: screenWidth * 0.3,
                                    alignment: Alignment.center,
                                    padding: EdgeInsets.symmetric(
                                        vertical: screenWidth * 0.01,
                                        horizontal: screenWidth * 0.0),
                                    child: Center(
                                      child: CupertinoButton(
                                        padding: EdgeInsets.symmetric(
                                            vertical: screenWidth * 0.01,
                                            horizontal: screenWidth * 0.03),
                                        color: AllColor.transparentColor,
                                        child: Text(
                                          "Ignore",
                                          style: normalTextStyle(
                                            color: Color(0xffffca28),
                                          ),
                                        ),
                                        disabledColor: AllColor.greyColor,
                                        onPressed: () {
                                          SystemNavigator.pop();
                                        },
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: screenWidth * 0.3,
                                    alignment: Alignment.center,
                                    padding: EdgeInsets.symmetric(
                                        vertical: screenWidth * 0.01,
                                        horizontal: screenWidth * 0.0),
                                    child: Center(
                                      child: CupertinoButton(
                                        padding: EdgeInsets.symmetric(
                                            vertical: screenWidth * 0.01,
                                            horizontal: screenWidth * 0.03),

                                        child: Text(
                                          "Update",
                                          style: normalTextStyle(
                                              color: AllColor.white),
                                        ),
                                        disabledColor: AllColor.greyColor,
                                        // onPressed: enable ? function! : null,
                                        color: Color(0xffffca28),
                                        onPressed: () {
                                          launchURL(versionJson["versionData"]
                                              ["driveLink"]);
                                        },
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              )
                            ],
                          ),
                        ),
                        // Positioned(
                        //   right: 0.0,
                        //   child: GestureDetector(
                        //     onTap: () {
                        //       // SystemNavigator.pop();
                        //       Navigator.pop(context);
                        //     },
                        //     child: Align(
                        //       alignment: Alignment.topRight,
                        //       child: CircleAvatar(
                        //           radius: 14.0,
                        //           backgroundColor: Colors.white,
                        //           child: normalIcon(Icons.close,
                        //               color: AllColor.greyColor)),
                        //     ),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ),
              ),
            ));
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => WillPopScope(
              onWillPop: () async {
                return false;
              },
              child: SimpleDialog(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0)),
                  elevation: 0.0,
                  backgroundColor: AllColor.white,
                  title: Container(
                    width: screenWidth,
                    color: AllColor.white,
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.03,
                      horizontal: screenWidth * 0.0,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      AllString.newViesionAvailable,
                      textAlign: TextAlign.left,
                      style: headingTextStyle(
                          fontWeight: FontWeight.bold, color: AllColor.black),
                    ),
                  ),
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.02,
                      ),
                      width: screenWidth,
                      alignment: Alignment.center,
                      child: Text(
                        versionJson["message"].toString(),
                        textAlign: TextAlign.center,
                        style: headingTextStyle(color: AllColor.black),
                      ),
                    ),
                    SizedBox(height: screenWidth * 0.02),
                    Container(
                      width: screenWidth,
                      margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.02,
                      ),
                      alignment: Alignment.centerRight,
                      child: button(
                        context,
                        function: () {
                          Navigator.pop(context);
                          launchURL(versionJson["versionData"]["driveLink"]);
                        },
                        color: Color(0xff536976),
                        textColor: AllColor.white,
                        text: AllString.update,
                      ),
                    ),
                  ]),
            ));
  }

  showPaymentDialog(Map versionJson) {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) => WillPopScope(
              onWillPop: () async => false,
              child: Dialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16.0)),
                elevation: 0.0,
                backgroundColor: Colors.transparent,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16.0),
                  child: Container(
                    margin: EdgeInsets.only(left: 0.0, right: 0.0),
                    child: Stack(
                      children: <Widget>[
                        Container(
                          // padding: EdgeInsets.only(
                          //   top: 18.0,
                          // ),
                          // margin: EdgeInsets.only(top: 13.0, right: 8.0),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(16.0),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 0.0,
                                  offset: Offset(0.0, 0.0),
                                ),
                              ]),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              Container(
                                width: screenWidth,
                                padding: EdgeInsets.symmetric(
                                    horizontal: screenWidth * 0.02,
                                    vertical: screenWidth * 0.0),
                                alignment: Alignment.center,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: screenWidth,
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.symmetric(
                                          vertical: screenWidth * 0.03),
                                      child: Icon(
                                        Icons.warning_amber_rounded,
                                        color: versionJson["configarationData"]
                                                        [0]["option"]
                                                    .toString() ==
                                                "1"
                                            ? AllColor.yellow
                                            : AllColor.red,
                                        size: screenWidth * 0.23,
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.symmetric(
                                          vertical: screenWidth * 0.01),
                                      width: screenWidth,
                                      child: Text(
                                        "Something went wrong",
                                        textAlign: TextAlign.center,
                                        style: headingTextStyle(
                                          fontWeight: FontWeight.bold,
                                          color:
                                              versionJson["configarationData"]
                                                              [0]["option"]
                                                          .toString() ==
                                                      "1"
                                                  ? AllColor.yellow
                                                  : AllColor.red,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: screenWidth * 0.02,
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      width: screenWidth,
                                      child: Text(
                                        versionJson["message"].toString(),
                                        textAlign: TextAlign.center,
                                        style: normalTextStyle(
                                            color: AllColor.black
                                                .withOpacity(0.5)),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.symmetric(
                                    vertical: screenWidth * 0.03,
                                  ),
                                  child: Divider()),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: screenWidth * 0.4,
                                    alignment: Alignment.center,
                                    padding: EdgeInsets.symmetric(
                                        vertical: screenWidth * 0.01,
                                        horizontal: screenWidth * 0.0),
                                    child: Center(
                                      child: CupertinoButton(
                                        padding: EdgeInsets.symmetric(
                                            vertical: screenWidth * 0.01,
                                            horizontal: screenWidth * 0.03),
                                        child: Text(
                                          "Close",
                                          style: normalTextStyle(
                                              color: AllColor.white),
                                        ),
                                        disabledColor: AllColor.greyColor,
                                        // onPressed: enable ? function! : null,
                                        color: versionJson["configarationData"]
                                                        [0]["option"]
                                                    .toString() ==
                                                "1"
                                            ? AllColor.yellow
                                            : AllColor.red,
                                        onPressed: () {
                                          versionJson["configarationData"][0]
                                                          ["option"]
                                                      .toString() ==
                                                  "1"
                                              ? Navigator.pop(context)
                                              :
                                              //  Navigator.pop(context);
                                              SystemNavigator.pop();
                                        },
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              )
                            ],
                          ),
                        ),
                        // Positioned(
                        //   right: 0.0,
                        //   child: GestureDetector(
                        //     onTap: () {
                        //       // SystemNavigator.pop();
                        //       Navigator.pop(context);
                        //     },
                        //     child: Align(
                        //       alignment: Alignment.topRight,
                        //       child: CircleAvatar(
                        //           radius: 14.0,
                        //           backgroundColor: Colors.white,
                        //           child: normalIcon(Icons.close,
                        //               color: AllColor.greyColor)),
                        //     ),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ),
              ),
            ));
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => WillPopScope(
              onWillPop: () async {
                return false;
              },
              child: SimpleDialog(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0)),
                  elevation: 0.0,
                  backgroundColor: AllColor.white,
                  title: Container(
                    width: screenWidth,
                    color: AllColor.white,
                    margin: EdgeInsets.symmetric(
                      vertical: screenWidth * 0.03,
                      horizontal: screenWidth * 0.0,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      AllString.newViesionAvailable,
                      textAlign: TextAlign.left,
                      style: headingTextStyle(
                          fontWeight: FontWeight.bold, color: AllColor.black),
                    ),
                  ),
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.02,
                      ),
                      width: screenWidth,
                      alignment: Alignment.center,
                      child: Text(
                        versionJson["message"].toString(),
                        textAlign: TextAlign.center,
                        style: headingTextStyle(color: AllColor.black),
                      ),
                    ),
                    SizedBox(height: screenWidth * 0.02),
                    Container(
                      width: screenWidth,
                      margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.02,
                      ),
                      alignment: Alignment.centerRight,
                      child: button(
                        context,
                        function: () {
                          Navigator.pop(context);
                          launchURL(versionJson["versionData"]["driveLink"]);
                        },
                        color: Color(0xff536976),
                        textColor: AllColor.white,
                        text: AllString.update,
                      ),
                    ),
                  ]),
            ));
  }
}

class CustomShape extends CustomClipper<Path> {
  @override
  getClip(Size size) {
    double height = size.height;
    double width = size.width;
    var path = Path();
    path.lineTo(0, height - 50);
    path.quadraticBezierTo(width / 2, height, width, height - 54);
    path.lineTo(width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper oldClipper) {
    return true;
  }
}

// import 'dart:math';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/rendering.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/leaveBalance/leaveBalance.dart';
// import 'package:hr/pages/myExpense/myExpense.dart';
// import 'package:hr/pages/myLoan/myLoan.dart';
// import 'package:hr/pages/myPerformance/myPerformance.dart';
// import 'package:hr/pages/myReimbursment/myReimbursment.dart';
// import 'package:hr/pages/mySuggetion/mySuggetion.dart';
// import 'package:hr/pages/profile/profile.dart';
// import 'package:hr/pages/publicHoliday/publicHoliday.dart';
// import 'package:hr/pages/recordAttendance/myAttendance.dart';
// import 'package:hr/pages/recordAttendance/recordAttendance.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allSharePreferencesKey.dart';
// import 'package:hr/res/allString.dart';
// import 'package:hr/res/allUrls.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/allText.dart';
// import 'package:hr/util/allTextStyle.dart';
// import 'package:ionicons/ionicons.dart';
// import 'package:line_icons/line_icons.dart';

// class Dashboard extends StatefulWidget {
//   const Dashboard({Key? key}) : super(key: key);

//   @override
//   _DashboardState createState() => _DashboardState();
// }

// class _DashboardState extends State<Dashboard> {
//   List<Color> color = [
//     Color(0xffcfd8dc),
//     Color(0xffd7ccc8),
//     Color(0xffffccbc),
//     Color(0xffffecb3),
//     Color(0xffc8e6c9),
//     Color(0xffb2ebf2),
//     Color(0xffbbdefb),
//     Color(0xffc5cae9),
//     Color(0xffd1c4e9),
//     Color(0xffe1bee7),
//     Color(0xfff8bbd0),
//     Color(0xffffcdd2),
//   ];
//   Random random = new Random();

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       height: screenHeight,
//       width: screenWidth,
//              decoration:customBackgroundGradient(),

//       child: Stack(
//         children: [
//           ClipPath(
//             clipper:
//                 CustomShape(), // this is my own class which extendsCustomClipper
//             child: Container(
//                 // height: screenWidth * 0.555,
//                 height: screenHeight / 2.7,
//                 decoration: BoxDecoration(
//                     gradient: LinearGradient(
//                         begin: Alignment(-5, 1),
//                         end: Alignment(0, 0),
//                         colors: [
//                       Color.fromRGBO(0, 212, 255, 1),
//                       Color.fromRGBO(2, 0, 36, 1)
//                       // Color.fromRGBO(9, 9, 121, 1),
//                       // Color.fromRGBO(9, 9, 121, 1),
//                       // Color.fromRGBO(0, 212, 255, 1)
//                     ]))),
//           ),
//           Positioned(
//             top: screenWidth * 0.03,
//             child: profileCard(),
//           ),
//           Positioned(
//             bottom: 0,
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 Container(
//                   width: screenWidth,
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Container(
//                         margin:
//                             EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             customDashboardButton(AllString.recordAttendance,
//                                 Icons.touch_app_outlined, () {
//                               Navigator.of(context).push(CupertinoPageRoute(
//                                   builder: (context) => RecordAttendance()));
//                             }, color[random.nextInt(12)]),
//                             customDashboardButton(AllString.myAttendance,
//                                 Ionicons.calendar_outline, () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => MyAttendance()));
//                             }, color[random.nextInt(12)]),
//                             customDashboardButton(
//                                 AllString.leaveBalance, LineIcons.moneyBill,
//                                 () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => LeaveBalance()));
//                             }, color[random.nextInt(12)]),
//                           ],
//                         ),
//                       ),
//                       Container(
//                         margin:
//                             EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             customDashboardButton(
//                                 AllString.myLoan, LineIcons.handHolding, () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => MyLoan()));
//                             }, color[random.nextInt(12)]),
//                             customDashboardButton(
//                                 AllString.mySuggestion, LineIcons.signLanguage,
//                                 () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => MySuggetion()));
//                             }, color[random.nextInt(12)]),
//                             customDashboardButton(
//                                 AllString.myExpense, LineIcons.arrowDown, () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => MyExpense()));
//                             }, color[random.nextInt(12)]),
//                           ],
//                         ),
//                       ),
//                       Container(
//                         margin:
//                             EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             customDashboardButton(
//                                 AllString.myReimbursement, LineIcons.revIo, () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => MyReimbursment()));
//                             }, color[random.nextInt(12)]),
//                             customDashboardButton(
//                                 AllString.myPerformance, LineIcons.cardboardVr,
//                                 () {
//                               Navigator.of(context).push(CupertinoPageRoute(
//                                   builder: (context) => MyPerformance()));
//                             }, color[random.nextInt(12)]),
//                             customDashboardButton(AllString.publicHolidays,
//                                 Icons.holiday_village_outlined, () {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => PublicHoliday()));
//                             }, color[random.nextInt(12)]),
//                           ],
//                         ),
//                       )
//                     ],
//                   ),
//                 )
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   customDashboardButton(
//       String name, IconData icon, Function() onTap, Color color) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         width: screenWidth * 0.33,
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             Container(
//               width: screenWidth >= 600
//                   ? screenWidth * 0.15
//                   : screenWidth > 450
//                       ? screenWidth * 0.17
//                       : screenWidth * 0.19,
//               height: screenWidth >= 600
//                   ? screenWidth * 0.15
//                   : screenWidth > 450
//                       ? screenWidth * 0.17
//                       : screenWidth * 0.19,
//               decoration: BoxDecoration(
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.grey.withOpacity(0.5),
//                     spreadRadius: 5,
//                     blurRadius: 7,
//                     offset: Offset(0, 3), // changes position of shadow
//                   ),
//                 ],
//                 borderRadius: BorderRadius.circular(10),
//                 gradient: LinearGradient(
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                     // begin: Alignment(-5, 1),
//                     // end: Alignment(0, 0),
//                     colors: [
//                       Color(0xff59C173),
//                       Color(0xffa17fe0),
//                       Color(0xff5D26C1),
//                       // Color.fromRGBO(0, 212, 255, 1),
//                       // Color.fromRGBO(2, 0, 36, 1)
//                     ]),
//               ),
//               child: Center(
//                 child: Container(
//                   width: screenWidth >= 600
//                       ? screenWidth * 0.15
//                       : screenWidth > 450
//                           ? screenWidth * 0.16
//                           : screenWidth * 0.18,
//                   height: screenWidth >= 600
//                       ? screenWidth * 0.15
//                       : screenWidth > 450
//                           ? screenWidth * 0.16
//                           : screenWidth * 0.18,
//                   decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(10),
//                       color: AllColor.white
//                       // gradient: LinearGradient(
//                       //     begin: FractionalOffset(0.0, 0.0),
//                       //     end: FractionalOffset(1.0, 0.0),
//                       //     stops: [0.0, 1.0],
//                       //     tileMode: TileMode.clamp,
//                       //     colors: [color, color.withOpacity(0.8)])

//                       ),
//                   child: Container(
//                     // child: mediumIcon(icon, color: AllColor.primaryDeepColor),
//                     child: mediumIcon(icon, color: Color(0xff1C8D73)),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(
//               height: screenWidth * 0.02,
//             ),
//             Container(
//               child: Text(
//                 name,
//                 textAlign: TextAlign.center,
//                 style: smallTextStyle(
//                     color: AllColor.black, fontWeight: FontWeight.bold),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }

//   profileCard() {
//     return GestureDetector(
//       onTap: () {
//         Navigator.of(context)
//             .push(CupertinoPageRoute(builder: (context) => Profile()));
//       },
//       child: Container(
//         width: screenWidth,
//         // height: screenWidth * 0.37,
//         height: screenHeight / 3.5,
//         alignment: Alignment.center,
//         margin: EdgeInsets.symmetric(
//           vertical: screenWidth * 0.05,
//         ),
//         child: Container(
//           margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.05,
//           ),
//           // decoration: BoxDecoration(
//           //   color: AllColor.primaryColor,
//           //   borderRadius: BorderRadius.circular(15),
//           //   boxShadow: [
//           //     BoxShadow(
//           //       color: Colors.grey.withOpacity(0.5),
//           //       spreadRadius: 5,
//           //       blurRadius: 7,
//           //       offset: Offset(0, 3), // changes position of shadow
//           //     ),
//           //   ],
//           // ),
//           child: Container(
//             margin: EdgeInsets.symmetric(
//               horizontal: screenWidth * 0.03,
//               vertical: screenWidth >= 600
//                   ? screenWidth * 0.02
//                   : screenWidth > 450
//                       ? screenWidth * 0.02
//                       : screenWidth * 0.02,
//             ),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Container(
//                   width: screenWidth >= 600
//                       ? screenWidth * 0.18
//                       : screenWidth > 450
//                           ? screenWidth * 0.2
//                           : screenWidth * 0.22,
//                   height: screenWidth >= 600
//                       ? screenWidth * 0.18
//                       : screenWidth > 450
//                           ? screenWidth * 0.2
//                           : screenWidth * 0.22,
//                   decoration: BoxDecoration(
//                       color: AllColor.white,
//                       borderRadius: BorderRadius.circular(10),
//                       border: Border.all(width: 2, color: AllColor.black)),
//                   child: Center(
//                     child: ClipRRect(
//                       borderRadius: BorderRadius.circular(10),
//                       child: sharedPreferences!
//                                   .getString(AllSharedPreferencesKey.image)!
//                                   .isEmpty ||
//                               sharedPreferences!.getString(
//                                       AllSharedPreferencesKey.image)! ==
//                                   "null"
//                           ? Icon(Icons.person, color: AllColor.primaryColor)
//                           : CachedNetworkImage(
//                               width: screenWidth >= 600
//                                   ? screenWidth * 0.16
//                                   : screenWidth > 450
//                                       ? screenWidth * 0.18
//                                       : screenWidth * 0.2,
//                               height: screenWidth >= 600
//                                   ? screenWidth * 0.16
//                                   : screenWidth > 450
//                                       ? screenWidth * 0.18
//                                       : screenWidth * 0.2,
//                               fit: BoxFit.cover,
//                               placeholder: (_, __) {
//                                 return Center(
//                                   child: CircularProgressIndicator(),
//                                 );
//                               },
//                               errorWidget: (_, __, ___) {
//                                 return Center(
//                                   child: Image.asset("assets/images/logo.png"),
//                                 );
//                               },
//                               imageUrl: sharedPreferences!
//                                   .getString(AllSharedPreferencesKey.image)!),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   margin: EdgeInsets.only(
//                       left: screenWidth * 0.05, top: screenWidth * 0.03),
//                   width: screenWidth,
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     children: [
//                       Text(
//                         sharedPreferences!
//                             .getString(AllSharedPreferencesKey.companyName)!,
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                             fontSize: screenWidth >= 600
//                                 ? screenWidth * 0.042
//                                 : screenWidth * 0.055,
//                             letterSpacing: 1.5,
//                             color: AllColor.white,
//                             fontWeight: FontWeight.bold),
//                       ),
//                       normalText(
//                           sharedPreferences!.getString(
//                               AllSharedPreferencesKey.companyContactNo)!,
//                           color: AllColor.white),
//                       normalText(
//                           "${sharedPreferences!.getString(AllSharedPreferencesKey.companyEmailId)!}",
//                           color: AllColor.white),
//                     ],
//                   ),
//                 )
//               ],
//             ),
//             // child: Column(
//             //   mainAxisAlignment: MainAxisAlignment.center,
//             //   crossAxisAlignment: CrossAxisAlignment.center,
//             //   mainAxisSize: MainAxisSize.min,
//             //   children: [
//             //     Container(
//             //         child: Row(
//             //       mainAxisAlignment: MainAxisAlignment.start,
//             //       crossAxisAlignment: CrossAxisAlignment.start,
//             //       children: [
//             //         Container(
//             //           width: screenWidth >= 600
//             //               ? screenWidth * 0.18
//             //               : screenWidth > 450
//             //                   ? screenWidth * 0.2
//             //                   : screenWidth * 0.22,
//             //           height: screenWidth >= 600
//             //               ? screenWidth * 0.18
//             //               : screenWidth > 450
//             //                   ? screenWidth * 0.2
//             //                   : screenWidth * 0.22,
//             //           decoration: BoxDecoration(
//             //               color: AllColor.white,
//             //               borderRadius: BorderRadius.circular(1000),
//             //               border: Border.all(width: 2, color: AllColor.black)),
//             //           child: Center(
//             //             child: ClipRRect(
//             //               borderRadius: BorderRadius.circular(1000),
//             //               child: CachedNetworkImage(
//             //                   width: screenWidth >= 600
//             //                       ? screenWidth * 0.16
//             //                       : screenWidth > 450
//             //                           ? screenWidth * 0.18
//             //                           : screenWidth * 0.2,
//             //                   height: screenWidth >= 600
//             //                       ? screenWidth * 0.16
//             //                       : screenWidth > 450
//             //                           ? screenWidth * 0.18
//             //                           : screenWidth * 0.2,
//             //                   fit: BoxFit.cover,
//             //                   placeholder: (_, __) {
//             //                     return Center(
//             //                       child: CircularProgressIndicator(),
//             //                     );
//             //                   },
//             //                   errorWidget: (_, __, ___) {
//             //                     return Center(
//             //                       child: Image.asset("assets/images/logo.png"),
//             //                     );
//             //                   },
//             //                   imageUrl: sharedPreferences!.getString(
//             //                       AllSharedPreferencesKey.userImage)!),
//             //             ),
//             //           ),
//             //         ),
//             //         Container(
//             //           margin: EdgeInsets.only(left: screenWidth * 0.05),
//             //           height: screenWidth * 0.18,
//             //           child: Column(
//             //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             //             crossAxisAlignment: CrossAxisAlignment.start,
//             //             mainAxisSize: MainAxisSize.min,
//             //             children: [
//             //               headingText(
//             //                   sharedPreferences!
//             //                       .getString(AllSharedPreferencesKey.name)!,
//             //                   color: AllColor.black),
//             //               midNormalText(
//             //                   sharedPreferences!
//             //                       .getString(AllSharedPreferencesKey.code)!,
//             //                   color: AllColor.black),
//             //               midNormalText(
//             //                   "Designation: ${sharedPreferences!.getString(AllSharedPreferencesKey.designation)!}",
//             //                   color: AllColor.black),
//             //             ],
//             //           ),
//             //         )
//             //       ],
//             //     )),
//             //     SizedBox(
//             //       height: screenWidth * 0.02,
//             //     ),
//             //     Container(
//             //       width: screenWidth,
//             //       margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
//             //       child: Column(
//             //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//             //         crossAxisAlignment: CrossAxisAlignment.start,
//             //         children: [
//             //           midNormalText(
//             //               "Department:  ${sharedPreferences!.getString(AllSharedPreferencesKey.department)!}",
//             //               color: AllColor.black),
//             //           midNormalText(
//             //               "Grade: ${sharedPreferences!.getString(AllSharedPreferencesKey.grade)!}",
//             //               color: AllColor.black),
//             //           midNormalText(
//             //               "Date Of Joining: ${convertStringToDate(DateTime.now())}",
//             //               color: AllColor.black),
//             //         ],
//             //       ),
//             //     )
//             //   ],
//             // ),
//           ),
//         ),
//       ),
//     );
//     // return GestureDetector(
//     //   onTap: () {
//     //     Navigator.of(context)
//     //         .push(CupertinoPageRoute(builder: (context) => Profile()));
//     //   },
//     //   child: Container(
//     //     width: screenWidth,
//     //     // height: screenWidth * 0.37,
//     //     height: screenHeight / 3,
//     //     alignment: Alignment.center,
//     //     margin: EdgeInsets.symmetric(
//     //       vertical: screenWidth * 0.05,
//     //     ),
//     //     child: Container(
//     //       margin: EdgeInsets.symmetric(
//     //         horizontal: screenWidth * 0.05,
//     //       ),
//     //       // decoration: BoxDecoration(
//     //       //   color: AllColor.primaryColor,
//     //       //   borderRadius: BorderRadius.circular(15),
//     //       //   boxShadow: [
//     //       //     BoxShadow(
//     //       //       color: Colors.grey.withOpacity(0.5),
//     //       //       spreadRadius: 5,
//     //       //       blurRadius: 7,
//     //       //       offset: Offset(0, 3), // changes position of shadow
//     //       //     ),
//     //       //   ],
//     //       // ),
//     //       child: Container(
//     //         margin: EdgeInsets.symmetric(
//     //           horizontal: screenWidth * 0.03,
//     //           vertical: screenWidth >= 600
//     //               ? screenWidth * 0.02
//     //               : screenWidth > 450
//     //                   ? screenWidth * 0.02
//     //                   : screenWidth * 0.02,
//     //         ),
//     //         child: Column(
//     //           mainAxisAlignment: MainAxisAlignment.center,
//     //           crossAxisAlignment: CrossAxisAlignment.center,
//     //           mainAxisSize: MainAxisSize.min,
//     //           children: [
//     //             Container(
//     //                 child: Row(
//     //               mainAxisAlignment: MainAxisAlignment.start,
//     //               crossAxisAlignment: CrossAxisAlignment.start,
//     //               children: [
//     //                 Container(
//     //                   width: screenWidth >= 600
//     //                       ? screenWidth * 0.18
//     //                       : screenWidth > 450
//     //                           ? screenWidth * 0.2
//     //                           : screenWidth * 0.22,
//     //                   height: screenWidth >= 600
//     //                       ? screenWidth * 0.18
//     //                       : screenWidth > 450
//     //                           ? screenWidth * 0.2
//     //                           : screenWidth * 0.22,
//     //                   decoration: BoxDecoration(
//     //                       color: AllColor.white,
//     //                       borderRadius: BorderRadius.circular(1000),
//     //                       border: Border.all(width: 2, color: AllColor.black)),
//     //                   child: Center(
//     //                     child: ClipRRect(
//     //                       borderRadius: BorderRadius.circular(1000),
//     //                       child: CachedNetworkImage(
//     //                           width: screenWidth >= 600
//     //                               ? screenWidth * 0.16
//     //                               : screenWidth > 450
//     //                                   ? screenWidth * 0.18
//     //                                   : screenWidth * 0.2,
//     //                           height: screenWidth >= 600
//     //                               ? screenWidth * 0.16
//     //                               : screenWidth > 450
//     //                                   ? screenWidth * 0.18
//     //                                   : screenWidth * 0.2,
//     //                           fit: BoxFit.cover,
//     //                           placeholder: (_, __) {
//     //                             return Center(
//     //                               child: CircularProgressIndicator(),
//     //                             );
//     //                           },
//     //                           errorWidget: (_, __, ___) {
//     //                             return Center(
//     //                               child: Image.asset("assets/images/logo.png"),
//     //                             );
//     //                           },
//     //                           imageUrl: sharedPreferences!.getString(
//     //                               AllSharedPreferencesKey.userImage)!),
//     //                     ),
//     //                   ),
//     //                 ),
//     //                 Container(
//     //                   margin: EdgeInsets.only(left: screenWidth * 0.05),
//     //                   height: screenWidth >= 600
//     //                       ? screenWidth * 0.18
//     //                       : screenWidth > 450
//     //                           ? screenWidth * 0.2
//     //                           : screenWidth * 0.22,
//     //                   child: Column(
//     //                     mainAxisAlignment: MainAxisAlignment.center,
//     //                     crossAxisAlignment: CrossAxisAlignment.start,
//     //                     mainAxisSize: MainAxisSize.min,
//     //                     children: [
//     //                       headingText(
//     //                           sharedPreferences!
//     //                               .getString(AllSharedPreferencesKey.name)!,
//     //                           color: AllColor.white),
//     //                       midNormalText(
//     //                           sharedPreferences!
//     //                               .getString(AllSharedPreferencesKey.code)!,
//     //                           color: AllColor.white),
//     //                       midNormalText(
//     //                           "Designation: ${sharedPreferences!.getString(AllSharedPreferencesKey.designation)!}",
//     //                           color: AllColor.white),
//     //                     ],
//     //                   ),
//     //                 )
//     //               ],
//     //             )),
//     //             SizedBox(
//     //               height: screenWidth * 0.02,
//     //             ),
//     //           ],
//     //         ),
//     //         // child: Column(
//     //         //   mainAxisAlignment: MainAxisAlignment.center,
//     //         //   crossAxisAlignment: CrossAxisAlignment.center,
//     //         //   mainAxisSize: MainAxisSize.min,
//     //         //   children: [
//     //         //     Container(
//     //         //         child: Row(
//     //         //       mainAxisAlignment: MainAxisAlignment.start,
//     //         //       crossAxisAlignment: CrossAxisAlignment.start,
//     //         //       children: [
//     //         //         Container(
//     //         //           width: screenWidth >= 600
//     //         //               ? screenWidth * 0.18
//     //         //               : screenWidth > 450
//     //         //                   ? screenWidth * 0.2
//     //         //                   : screenWidth * 0.22,
//     //         //           height: screenWidth >= 600
//     //         //               ? screenWidth * 0.18
//     //         //               : screenWidth > 450
//     //         //                   ? screenWidth * 0.2
//     //         //                   : screenWidth * 0.22,
//     //         //           decoration: BoxDecoration(
//     //         //               color: AllColor.white,
//     //         //               borderRadius: BorderRadius.circular(1000),
//     //         //               border: Border.all(width: 2, color: AllColor.black)),
//     //         //           child: Center(
//     //         //             child: ClipRRect(
//     //         //               borderRadius: BorderRadius.circular(1000),
//     //         //               child: CachedNetworkImage(
//     //         //                   width: screenWidth >= 600
//     //         //                       ? screenWidth * 0.16
//     //         //                       : screenWidth > 450
//     //         //                           ? screenWidth * 0.18
//     //         //                           : screenWidth * 0.2,
//     //         //                   height: screenWidth >= 600
//     //         //                       ? screenWidth * 0.16
//     //         //                       : screenWidth > 450
//     //         //                           ? screenWidth * 0.18
//     //         //                           : screenWidth * 0.2,
//     //         //                   fit: BoxFit.cover,
//     //         //                   placeholder: (_, __) {
//     //         //                     return Center(
//     //         //                       child: CircularProgressIndicator(),
//     //         //                     );
//     //         //                   },
//     //         //                   errorWidget: (_, __, ___) {
//     //         //                     return Center(
//     //         //                       child: Image.asset("assets/images/logo.png"),
//     //         //                     );
//     //         //                   },
//     //         //                   imageUrl: sharedPreferences!.getString(
//     //         //                       AllSharedPreferencesKey.userImage)!),
//     //         //             ),
//     //         //           ),
//     //         //         ),
//     //         //         Container(
//     //         //           margin: EdgeInsets.only(left: screenWidth * 0.05),
//     //         //           height: screenWidth * 0.18,
//     //         //           child: Column(
//     //         //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//     //         //             crossAxisAlignment: CrossAxisAlignment.start,
//     //         //             mainAxisSize: MainAxisSize.min,
//     //         //             children: [
//     //         //               headingText(
//     //         //                   sharedPreferences!
//     //         //                       .getString(AllSharedPreferencesKey.name)!,
//     //         //                   color: AllColor.black),
//     //         //               midNormalText(
//     //         //                   sharedPreferences!
//     //         //                       .getString(AllSharedPreferencesKey.code)!,
//     //         //                   color: AllColor.black),
//     //         //               midNormalText(
//     //         //                   "Designation: ${sharedPreferences!.getString(AllSharedPreferencesKey.designation)!}",
//     //         //                   color: AllColor.black),
//     //         //             ],
//     //         //           ),
//     //         //         )
//     //         //       ],
//     //         //     )),
//     //         //     SizedBox(
//     //         //       height: screenWidth * 0.02,
//     //         //     ),
//     //         //     Container(
//     //         //       width: screenWidth,
//     //         //       margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
//     //         //       child: Column(
//     //         //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//     //         //         crossAxisAlignment: CrossAxisAlignment.start,
//     //         //         children: [
//     //         //           midNormalText(
//     //         //               "Department:  ${sharedPreferences!.getString(AllSharedPreferencesKey.department)!}",
//     //         //               color: AllColor.black),
//     //         //           midNormalText(
//     //         //               "Grade: ${sharedPreferences!.getString(AllSharedPreferencesKey.grade)!}",
//     //         //               color: AllColor.black),
//     //         //           midNormalText(
//     //         //               "Date Of Joining: ${convertStringToDate(DateTime.now())}",
//     //         //               color: AllColor.black),
//     //         //         ],
//     //         //       ),
//     //         //     )
//     //         //   ],
//     //         // ),
//     //       ),
//     //     ),
//     //   ),
//     // );
//   }
// }

// class CustomShape extends CustomClipper<Path> {
//   @override
//   getClip(Size size) {
//     double height = size.height;
//     double width = size.width;
//     var path = Path();
//     path.lineTo(0, height - 50);
//     path.quadraticBezierTo(width / 2, height, width, height - 54);
//     path.lineTo(width, 0);
//     path.close();

//     return path;
//   }

//   @override
//   bool shouldReclip(CustomClipper oldClipper) {
//     return true;
//   }
// }

fetchAndSetAllIdSettingConfig(BuildContext context) async {
  if (await internetCheck()) {
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
      "userId": loginUserId,
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(data, AllUrls.userConfigData, context, loginToken)
        .then((response) {
      if (response == null) {
        commonAlertDialog(
            context, AllString.warning, AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonDataForDetails = json.decode(response);
        log(":jsonDataForDetailsssss " + jsonDataForDetails.toString());
        if (checkApiResponseSuccessOrNot(jsonDataForDetails)) {
          if (jsonDataForDetails["data"].isEmpty) {
            sharedPreferences!.setString(AllSharedPreferencesKey.checkInId, "");
            sharedPreferences!
                .setString(AllSharedPreferencesKey.attendanceStatus, "");
            sharedPreferences!.setString(AllSharedPreferencesKey.punchInId, "");
            sharedPreferences!
                .setString(AllSharedPreferencesKey.breakPunchId, "");
          } else {
            sharedPreferences!.setString(
                AllSharedPreferencesKey.checkInId,
                jsonDataForDetails["data"]["checkInId"].toString() == "null" ||
                        jsonDataForDetails["data"]["checkInId"].toString() ==
                            "0" ||
                        jsonDataForDetails["data"]["checkInId"].toString() == ""
                    ? ""
                    : jsonDataForDetails["data"]["checkInId"].toString());
            if (sharedPreferences!
                .getString(AllSharedPreferencesKey.checkInId)!
                .isEmpty) {
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.checkInOption, "");
              sharedPreferences!
                  .setString(AllSharedPreferencesKey.checkInOptionName, "");
              sharedPreferences!.setString(
                  AllSharedPreferencesKey.checkInOptionNameWithId, "");
            }
            sharedPreferences!.setString(
                AllSharedPreferencesKey.attendanceStatus,
                jsonDataForDetails["data"]["attendanceStatus"].toString() == "0"
                    ? ""
                    : jsonDataForDetails["data"]["attendanceStatus"]
                        .toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.punchInId,
                jsonDataForDetails["data"]["punchInId"].toString() == "0"
                    ? ""
                    : jsonDataForDetails["data"]["punchInId"].toString());
            sharedPreferences!.setString(
                AllSharedPreferencesKey.breakPunchId,
                jsonDataForDetails["data"]["breakId"].toString() == "0"
                    ? ""
                    : jsonDataForDetails["data"]["breakId"].toString());
          }

          AppBuilder.of(context)!.rebuild();
        } else {
          commonAlertDialog(context, jsonDataForDetails["status"],
              jsonDataForDetails["message"]);
        }
      }
    });
  } else {
    showOfflineSnakbar(context);
  }
}
// import 'dart:async';
// import 'dart:convert';
// import 'dart:developer';
// import 'dart:math' as math;

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/rendering.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:geocoding/geocoding.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:hr/api/apiPostRequestWithHeader.dart';
// import 'package:hr/common/commonAlertDialog.dart';
// import 'package:hr/common/commonAlertDialogWithCloseButton.dart';
// import 'package:hr/common/commonFluttertoast.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/db/handler.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/conveyance/conveyance.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/leaveBalance/leaveBalance.dart';
// import 'package:hr/pages/myExpense/myExpense.dart';
// import 'package:hr/pages/myLoan/myLoan.dart';
// import 'package:hr/pages/myPerformance/myPerformance.dart';
// import 'package:hr/pages/myReimbursment/myReimbursment.dart';
// import 'package:hr/pages/mySuggetion/mySuggetion.dart';
// import 'package:hr/pages/order/order.dart';
// import 'package:hr/pages/payment/payment.dart';
// import 'package:hr/pages/payslip/paySlip.dart';
// import 'package:hr/pages/profile/profile.dart';
// import 'package:hr/pages/publicHoliday/publicHoliday.dart';
// import 'package:hr/pages/recordAttendance/myAttendance.dart';
// import 'package:hr/pages/recordAttendance/recordAttendance.dart';
// import 'package:hr/pages/visitInOut/visitInOut.dart';
// import 'package:hr/pages/workPlan/workPlan.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allSharePreferencesKey.dart';
// import 'package:hr/res/allString.dart';
// import 'package:hr/res/allUrls.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/allMargin.dart';
// import 'package:hr/util/allText.dart';
// import 'package:hr/util/allTextStyle.dart';
// import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/util/internetCheck.dart';
// import 'package:hr/util/otherUtils.dart';
// import 'package:hr/util/showOfflineSnakbar.dart';
// import 'package:hr/widget/button.dart';
// import 'package:ionicons/ionicons.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:permission_handler/permission_handler.dart';

// class Dashboard extends StatefulWidget {
//   const Dashboard({Key? key}) : super(key: key);

//   @override
//   _DashboardState createState() => _DashboardState();
// }

// class _DashboardState extends State<Dashboard> {
//   List<Color> color = [
//     Color(0xffcfd8dc),
//     Color(0xffd7ccc8),
//     Color(0xffffccbc),
//     Color(0xffffecb3),
//     Color(0xffc8e6c9),
//     Color(0xffb2ebf2),
//     Color(0xffbbdefb),
//     Color(0xffc5cae9),
//     Color(0xffd1c4e9),
//     Color(0xffe1bee7),
//     Color(0xfff8bbd0),
//     Color(0xffffcdd2),
//   ];
//   math.Random random = new math.Random();
//   bool loading = false;
//   List _loadList = [];
//   String _configSetting = "";
//   double distance = 0.0;
//   String distanceForDisplay = "";
//   String startLatLong = "";
//   String endLatLong = "";
//   @override
//   void initState() {
//     super.initState();
//     try {
//       FocusScope.of(context).unfocus();
//     } catch (e) {}
//     fetchVersionForUpdateCheck();

//     fetchAndSetAllIdSettingConfig(this.context);
//     // createRequestBodyAndHit();
//     fetchMemberList();

//     positionConfigForHitLocation();
//     // fetchAllProduct();
// // offlineTrackingSendLocationFetch();
//     fetchConfigData();

//     Future.delayed(Duration(milliseconds: 300), () {
//       checkAndFetchAllDetails();
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return LoadingOverlay(
//       isLoading: loading,
//       opacity: 0.5,
//       color: AllColor.black,
//       progressIndicator: commonLoader(),
//       child: Container(
//         height: screenHeight,
//         width: screenWidth,
//                decoration:customBackgroundGradient(),

//         child: Stack(
//           children: [
//             // Row(
//             //   children: [
//             //     // IconButton(
//             //     //     onPressed: () {
//             //     //       createRequestBody();
//             //     //     },
//             //     //     icon: Icon(Icons.refresh)),
//             //     IconButton(
//             //         onPressed: () {
//             // Navigator.push(context,
//             //     CupertinoPageRoute(builder: (context) => WorkPlan()));
//             //         },
//             //         icon: Icon(Icons.paste_outlined)),
//             //   ],
//             // ),

//             ClipPath(
//               clipper:
//                   CustomShape(), // this is my own class which extendsCustomClipper
//               child: Container(
//                   // height: screenWidth * 0.555,
//                   height: screenHeight / 3.4,
//                   decoration: BoxDecoration(
//                       gradient: LinearGradient(
//                           begin: Alignment(-5, 1),
//                           end: Alignment(0, 0),
//                           colors: [
//                         Color.fromRGBO(0, 212, 255, 1),
//                         Color.fromRGBO(2, 0, 36, 1)
//                         // Color.fromRGBO(9, 9, 121, 1),
//                         // Color.fromRGBO(9, 9, 121, 1),
//                         // Color.fromRGBO(0, 212, 255, 1)
//                       ]))),
//             ),
//             Positioned(
//               top: screenWidth * 0.0,
//               child: profileCard(),
//             ),
//             // Row(
//             //   children: [
//             //     // IconButton(
//             //     //     onPressed: () {
//             //     //       createRequestBody();
//             //     //     },
//             //     //     icon: Icon(Icons.refresh)),
//             //     IconButton(
//             //         onPressed: () {
//             //           Navigator.push(context,
//             //               CupertinoPageRoute(builder: (context) => WorkPlan()));
//             //         },
//             //         icon: Icon(Icons.paste_outlined)),
//             //   ],
//             // ),
//             // bothConfigView()
//             // onlyHRConfigView()
//             // onlySalesManConfigView()
//             sharedPreferences!
//                         .getString(AllSharedPreferencesKey.userConfigSetting) ==
//                     "null"
//                 ? Container()
//                 : sharedPreferences!.getString(
//                             AllSharedPreferencesKey.userConfigSetting) ==
//                         "Both"
//                     ? bothConfigView()
//                     : sharedPreferences!.getString(
//                                 AllSharedPreferencesKey.userConfigSetting) ==
//                             "OnlyHrModule"
//                         ? onlyHRConfigView()
//                         : sharedPreferences!.getString(AllSharedPreferencesKey
//                                     .userConfigSetting) ==
//                                 "OnlySalesManApp"
//                             ? onlySalesManConfigView()
//                             : Container(),
//           ],
//         ),
//       ),
//     );
//   }

//   bothConfigView() {
//     return Positioned(
//         top: screenWidth * 0.72,
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.profile, FontAwesomeIcons.userAlt, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Profile()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(AllString.recordAttendance,
//                             Icons.touch_app_outlined, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => RecordAttendance()));
//                         }, color[random.nextInt(12)]),
//                         // customDashboardButton(AllString.myAttendance,
//                         //     Ionicons.calendar_outline, () {
//                         //   Navigator.push(
//                         //       context,
//                         //       CupertinoPageRoute(
//                         //           builder: (context) => MyAttendance(
//                         //                 fromRecordAttendance: false,
//                         //               )));
//                         // }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                           sharedPreferences!.getString(AllSharedPreferencesKey
//                                           .checkInOption) ==
//                                       null ||
//                                   sharedPreferences!.getString(
//                                           AllSharedPreferencesKey
//                                               .checkInOption) ==
//                                       ""
//                               ? AllString.visitIn
//                               : AllString.visitOut,
//                           Ionicons.locate_outline,
//                           () {
//                             if (sharedPreferences!.getString(
//                                         AllSharedPreferencesKey.punchInId) ==
//                                     null ||
//                                 sharedPreferences!.getString(
//                                         AllSharedPreferencesKey.punchInId) ==
//                                     "" ||
//                                 sharedPreferences!.getString(
//                                         AllSharedPreferencesKey
//                                             .attendanceStatus) ==
//                                     "1") {
//                               commonAlertDialog(context, AllString.alert,
//                                   AllString.pleasePunchInBeforeVisitIn,
//                                   function: () {
//                                 Navigator.pop(context);
//                                 Navigator.of(context).push(CupertinoPageRoute(
//                                     builder: (context) => RecordAttendance()));
//                               });
//                             } else {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => VisitInOut()));
//                             }
//                           },
//                           color[random.nextInt(12)],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.order, FontAwesomeIcons.handHolding, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Order()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.payment, FontAwesomeIcons.moneyBill, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Payment()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.expense, LineIcons.arrowDown, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => MyExpense()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(AllString.publicHolidays,
//                             Icons.holiday_village_outlined, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => PublicHoliday()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.leaveBalance, LineIcons.moneyBill, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => LeaveBalance()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.myLoan, LineIcons.handHolding, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => MyLoan()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.mySuggestion, LineIcons.signLanguage, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => MySuggetion()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.myPerformance, LineIcons.cardboardVr, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => MyPerformance()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.paySlip, Icons.note_rounded, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Payslip()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ));
//   }

//   onlySalesManConfigView() {
//     return Positioned(
//         top: screenWidth * 0.72,
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.profile, FontAwesomeIcons.userAlt, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Profile()));
//                           // showPaymentDialog({});
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(AllString.recordAttendance,
//                             Icons.touch_app_outlined, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => RecordAttendance()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                           sharedPreferences!.getString(AllSharedPreferencesKey
//                                           .checkInOption) ==
//                                       null ||
//                                   sharedPreferences!.getString(
//                                           AllSharedPreferencesKey
//                                               .checkInOption) ==
//                                       ""
//                               ? AllString.visitIn
//                               : AllString.visitOut,
//                           Ionicons.locate_outline,
//                           () {
//                             if (sharedPreferences!.getString(
//                                         AllSharedPreferencesKey.punchInId) ==
//                                     null ||
//                                 sharedPreferences!.getString(
//                                         AllSharedPreferencesKey.punchInId) ==
//                                     "" ||
//                                 sharedPreferences!.getString(
//                                         AllSharedPreferencesKey
//                                             .attendanceStatus) ==
//                                     "1") {
//                               commonAlertDialog(context, AllString.alert,
//                                   AllString.pleasePunchInBeforeVisitIn,
//                                   function: () {
//                                 Navigator.pop(context);
//                                 Navigator.of(context).push(CupertinoPageRoute(
//                                     builder: (context) => RecordAttendance()));
//                               });
//                             } else {
//                               Navigator.push(
//                                   context,
//                                   CupertinoPageRoute(
//                                       builder: (context) => VisitInOut()));
//                             }
//                           },
//                           color[random.nextInt(12)],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.order, FontAwesomeIcons.handHolding, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Order()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.payment, FontAwesomeIcons.moneyBill, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Payment()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.expense, LineIcons.arrowDown, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => MyExpense()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(AllString.publicHolidays,
//                             Icons.holiday_village_outlined, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => PublicHoliday()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ));
//   }

//   onlyHRConfigView() {
//     return Positioned(
//         top: screenWidth * 0.72,
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.profile, FontAwesomeIcons.userAlt, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => Profile()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(AllString.recordAttendance,
//                             Icons.touch_app_outlined, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => RecordAttendance()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.leaveBalance, LineIcons.moneyBill, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => LeaveBalance()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(
//                             AllString.myLoan, LineIcons.handHolding, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => MyLoan()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.mySuggestion, LineIcons.signLanguage, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => MySuggetion()));
//                         }, color[random.nextInt(12)]),
//                         customDashboardButton(
//                             AllString.myPerformance, LineIcons.cardboardVr, () {
//                           Navigator.of(context).push(CupertinoPageRoute(
//                               builder: (context) => MyPerformance()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               width: screenWidth,
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Container(
//                     margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         customDashboardButton(AllString.publicHolidays,
//                             Icons.holiday_village_outlined, () {
//                           Navigator.push(
//                               context,
//                               CupertinoPageRoute(
//                                   builder: (context) => PublicHoliday()));
//                         }, color[random.nextInt(12)]),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ));
//   }

//   customDashboardButton(
//       String name, IconData icon, Function() onTap, Color color,
//       {bool enable = true}) {
//     return GestureDetector(
//       onTap: enable ? onTap : () {},
//       child: Container(
//         width: screenWidth * 0.33,
//         child: Center(
//           child: Container(
//             width: screenWidth >= 600
//                 ? screenWidth * 0.25
//                 : screenWidth > 450
//                     ? screenWidth * 0.26
//                     : screenWidth * 0.28,
//             height: screenWidth >= 600
//                 ? screenWidth * 0.22
//                 : screenWidth > 450
//                     ? screenWidth * 0.23
//                     : screenWidth * 0.25,
//             decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(10),
//                 color: enable
//                     ? AllColor.transparentColor
//                     : AllColor.transparentColor),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 Container(
//                   child: Center(
//                     child: Container(
//                       child: Container(
//                         child: mediumIcon(icon,
//                             color: enable ? Color(0xff1C8D73) : AllColor.white),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   child: Text(
//                     name,
//                     textAlign: TextAlign.center,
//                     style: smallTextStyle(
//                         color: enable ? AllColor.black : AllColor.greyColor,
//                         fontWeight: FontWeight.bold),
//                   ),
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   profileCard() {
//     return GestureDetector(
//       onTap: () {
//         Navigator.of(context)
//             .push(CupertinoPageRoute(builder: (context) => Profile()));
//       },
//       child: Container(
//         width: screenWidth,
//         // height: screenWidth * 0.37,
//         height: screenHeight / 4,
//         alignment: Alignment.center,
//         margin: EdgeInsets.symmetric(
//           vertical: screenWidth * 0.03,
//         ),
//         child: Container(
//           margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.05,
//           ),
//           child: Container(
//             margin: EdgeInsets.symmetric(
//               horizontal: screenWidth * 0.03,
//               vertical: screenWidth >= 600
//                   ? screenWidth * 0.02
//                   : screenWidth > 450
//                       ? screenWidth * 0.02
//                       : screenWidth * 0.02,
//             ),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Container(
//                   width: screenWidth >= 600
//                       ? screenWidth * 0.18
//                       : screenWidth > 450
//                           ? screenWidth * 0.2
//                           : screenWidth * 0.22,
//                   height: screenWidth >= 600
//                       ? screenWidth * 0.18
//                       : screenWidth > 450
//                           ? screenWidth * 0.2
//                           : screenWidth * 0.22,
//                   decoration: BoxDecoration(
//                       color: AllColor.white,
//                       borderRadius: BorderRadius.circular(10),
//                       border: Border.all(width: 2, color: AllColor.black)),
//                   child: Center(
//                     child: ClipRRect(
//                       borderRadius: BorderRadius.circular(10),
//                       child: sharedPreferences!
//                                   .getString(AllSharedPreferencesKey.image)!
//                                   .isEmpty ||
//                               sharedPreferences!.getString(
//                                       AllSharedPreferencesKey.image)! ==
//                                   "null"
//                           ? Center(
//                               child: Padding(
//                                 padding: const EdgeInsets.all(8.0),
//                                 child: Image.asset(
//                                     "assets/images/defaultUser.png"),
//                               ),
//                             )
//                           : CachedNetworkImage(
//                               width: screenWidth >= 600
//                                   ? screenWidth * 0.16
//                                   : screenWidth > 450
//                                       ? screenWidth * 0.18
//                                       : screenWidth * 0.2,
//                               height: screenWidth >= 600
//                                   ? screenWidth * 0.16
//                                   : screenWidth > 450
//                                       ? screenWidth * 0.18
//                                       : screenWidth * 0.2,
//                               fit: BoxFit.cover,
//                               placeholder: (_, __) {
//                                 return Center(
//                                   child: CircularProgressIndicator(),
//                                 );
//                               },
//                               errorWidget: (_, __, ___) {
//                                 return Center(
//                                   child: Image.asset(
//                                       "assets/images/defaultUser.png"),
//                                 );
//                               },
//                               imageUrl: sharedPreferences!
//                                   .getString(AllSharedPreferencesKey.image)!),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   margin: EdgeInsets.only(
//                       // left: screenWidth * 0.05,
//                       top: screenWidth * 0.03),
//                   width: screenWidth,
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     children: [
//                       Text(
//                         // sharedPreferences!.getString(
//                         //                 AllSharedPreferencesKey.image)!,
//                         sharedPreferences!
//                             .getString(AllSharedPreferencesKey.companyName)!,
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                             fontSize: screenWidth >= 600
//                                 ? screenWidth * 0.042
//                                 : screenWidth * 0.055,
//                             letterSpacing: 1.5,
//                             color: AllColor.white,
//                             fontWeight: FontWeight.bold),
//                       ),
//                       normalText(
//                           sharedPreferences!
//                               .getString(AllSharedPreferencesKey.firstName)!,
//                           color: AllColor.white),
//                       normalText(
//                           "${sharedPreferences!.getString(AllSharedPreferencesKey.userRoleName)!}",
//                           color: AllColor.white),
//                     ],
//                   ),
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   fetchDealer() {
//     setState(() {
//       loading = true;
//     });
//     Map data = {
//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//       "individualId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//     };
//     apiPostRequestWithHeader(
//             data, AllUrls.getEmployeeDealer, this.context, loginToken)
//         .then((response) {
//       if (response == null) {
//         loading = false;
//         setState(() {});
//         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//       } else {
//         Map<String, dynamic> jsonData = json.decode(response);
//         if (checkApiResponseSuccessOrNot(jsonData)) {
//           sharedPreferences!.setString(
//               AllSharedPreferencesKey.allDealerJson, response.toString());
//           dealerList.clear();
//           dealerList.add(AllString.select);
//           List _tempList = jsonData["dealerData"];
//           _tempList.forEach((element) {
//             dealerList.add(element["dealerName"].toString() +
//                 AllString.splitText +
//                 element["dealerId"].toString());
//           });
//           setState(() {});
//            setState(() {
//           loading = false;
//         });
//           // fetchCategory();
//         } else {
//           setState(() {
//             loading = false;
//           });
//           commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//         }
//       }
//     });
//   }

//   // fetchCategory() {
//   //   setState(() {
//   //     loading = true;
//   //   });
//   //   Map data = {
//   //     "divisionId": "",
//   //     "companyId":
//   //         sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//   //     "status": ""
//   //   };
//   //   apiPostRequestWithHeader(
//   //           data, AllUrls.productDivisionListPost, this.context, loginToken)
//   //       .then((response) {
//   //     if (response == null) {
//   //       loading = false;
//   //       setState(() {});
//   //       commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//   //     } else {
//   //       Map<String, dynamic> jsonData = json.decode(response);
//   //       if (checkApiResponseSuccessOrNot(jsonData)) {
//   //         sharedPreferences!.setString(
//   //             AllSharedPreferencesKey.allCategoryJson, response.toString());
//   //         List _tempList = [];
//   //         if (jsonData["divisionData"] == "" ||
//   //             jsonData["divisionData"] == []) {
//   //           _tempList = [];
//   //         } else {
//   //           _tempList = jsonData["divisionData"];
//   //         }
//   //         categoryList.clear();
//   //         _tempList.forEach((element) {
//   //           categoryList.add(element["divisionName"].toString() +
//   //               AllString.splitText +
//   //               element["divisionId"].toString());
//   //         });

//   //         setState(() {});
//   //         fetchExpenseType();
//   //       } else {
//   //         setState(() {
//   //           loading = false;
//   //         });
//   //         commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//   //       }
//   //     }
//   //   });
//   // }

//   // fetchExpenseType() {
//   //   loading = true;
//   //   setState(() {});
//   //   Map data = {};
//   //   apiPostRequestWithHeader(
//   //           data, AllUrls.reimbursementMasterDataPost, this.context, loginToken)
//   //       .then((response) {
//   //     if (response == null) {
//   //       loading = false;
//   //       setState(() {});
//   //       commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//   //     } else {
//   //       Map<String, dynamic> jsonData = json.decode(response);
//   //       if (checkApiResponseSuccessOrNot(jsonData)) {
//   //         setState(() {
//   //           loading = false;
//   //         });
//   //         sharedPreferences!.setString(
//   //             AllSharedPreferencesKey.allExpenseTypeJson, response.toString());
//   //         expenseTypeList.clear();

//   //         List _tempList = jsonData["data"];
//   //         _tempList.forEach((element) {
//   //           expenseTypeList.add(element["reimbursementType"].toString() +
//   //               AllString.splitText +
//   //               element["reimbursementTypeId"].toString());
//   //         });
//   //         setState(() {});
//   //         fetchAllProduct();
//   //       } else {
//   //         setState(() {
//   //           loading = false;
//   //         });
//   //         commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//   //       }
//   //     }
//   //   });
//   // }

//   // fetchAllProduct() {
//   //   loading = true;
//   //   setState(() {});
//   //   Map data = {
//   //     "companyId":
//   //         sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
//   //     "divisionId": ""
//   //   };
//   //   apiPostRequestWithHeader(
//   //           data, AllUrls.getModelByDivision, this.context, loginToken)
//   //       .then((response) {
//   //     if (response == null) {
//   //       loading = false;
//   //       setState(() {});
//   //       commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//   //     } else {
//   //       Map<String, dynamic> jsonData = json.decode(response);
//   //       if (checkApiResponseSuccessOrNot(jsonData)) {
//   //         setState(() {
//   //           loading = false;
//   //         });
//   //         sharedPreferences!.setString(
//   //             AllSharedPreferencesKey.allProductJson, response.toString());
//   //         AppBuilder.of(context)!.rebuild();
//   //         log("""sharedPreferences!
//   //                     .getString(AllSharedPreferencesKey.allProductJson: """ +
//   //             sharedPreferences!
//   //                 .getString(AllSharedPreferencesKey.allProductJson)!);
//   //         sharedPreferences!.setString(
//   //             AllSharedPreferencesKey.allProductJson, response.toString());
//   //         // List _tempList = jsonData["data"];
//   //         if (sharedPreferences!
//   //                     .getString(AllSharedPreferencesKey.allProductJson) ==
//   //                 null ||
//   //             sharedPreferences!
//   //                     .getString(AllSharedPreferencesKey.allProductJson) ==
//   //                 "null" ||
//   //             sharedPreferences!
//   //                 .getString(AllSharedPreferencesKey.allProductJson)!
//   //                 .isEmpty) {
//   //           fetchAllProduct();
//   //         }
//   //         setState(() {
//   //           loading = false;
//   //         });
//   //       } else {
//   //         setState(() {
//   //           loading = false;
//   //         });
//   //         commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//   //       }
//   //     }
//   //   });
//   // }

//   fetchMemberList() {
//     // setState(() {
//     //   loading = true;
//     // });
//     Map data = {
//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//       "individualId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//       "individualTypeId": sharedPreferences!
//           .getString(AllSharedPreferencesKey.individualTypeId),
//     };
//     apiPostRequestWithHeader(data, AllUrls.memberList, this.context, loginToken)
//         .then((response) {
//       if (response == null) {
//         loading = false;
//         setState(() {});
//         // commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//       } else {
//         Map<String, dynamic> jsonData = json.decode(response);
//         if (checkApiResponseSuccessOrNot(jsonData)) {
//           teamMemberList.clear();
//           allTeamMemberList.clear();
//           teamMemberList.add(AllString.select);
//           allTeamMemberList.add(AllString.select);

//           if (jsonData["data"]["particularMember"].isEmpty ||
//               jsonData["data"]["particularMember"].toString() == "") {
//             teamMemberList.clear();
//           } else {
//             List _tempList = jsonData["data"]["particularMember"];
//             _tempList.forEach((element) {
//               teamMemberList.add(element["individualName"].toString() +
//                   AllString.splitText +
//                   element["individualId"].toString());
//             });
//           }
//           // * All Team Members
//           if (jsonData["data"]["allMembers"].isEmpty ||
//               jsonData["data"]["allMembers"].toString() == "") {
//             allTeamMemberList.clear();
//           } else {
//             List _tempList = jsonData["data"]["allMembers"];
//             _tempList.forEach((element) {
//               allTeamMemberList.add(element["individualName"].toString() +
//                   AllString.splitText +
//                   element["individualId"].toString());
//             });
//             // log("firstName: "+ sharedPreferences!
//             //         .getString(AllSharedPreferencesKey.firstName)!);
//             // allTeamMemberList.remove(sharedPreferences!
//             //         .getString(AllSharedPreferencesKey.firstName)! +
//             //     AllString.splitText +
//             //     sharedPreferences!
//             //         .getString(AllSharedPreferencesKey.individualId)!);
//           }
//     fetchProfileOtherDetails();

//         } else {
//           setState(() {
//             loading = false;
//           });
//           commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//         }
//       }
//     });
//   }

//   fetchConfigData() async {
//     if (await internetCheck()) {
//       setState(() {
//         loading = true;
//       });
//       Map data = {
//         "companyId":
//             sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//         "configParameterName": "hrmsFeaturesConfig" // will be static always
//       };
//       apiPostRequestWithHeader(
//               data, AllUrls.getConfigDataSetting, this.context, loginToken)
//           .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//         } else {
//           Map<String, dynamic> jsonData = json.decode(response);
//           log("configarationData: " + jsonData.toString());
//           if (checkApiResponseSuccessOrNot(jsonData)) {
//             if (jsonData["configarationData"] == "") {
//               _configSetting = "";
//             } else {
//               _configSetting =
//                   jsonData["configarationData"][0]["option"].toString();
//               log("_configSetting: " + _configSetting);
//               sharedPreferences!.setString(
//                   AllSharedPreferencesKey.userConfigSetting, _configSetting);

//               //_configSetting ="Both";
//             }
//             log(_configSetting.toString());
//             setState(() {
//               loading = false;
//             });
//           } else {
//             setState(() {
//               loading = false;
//             });
//             commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//           }
//         }
//       });
//     } else {
//       showOfflineSnakbar(context);
//     }
//   }

//   fetchProfileOtherDetails() async {
//     if (await internetCheck()) {
//       setState(() {
//         loading = true;
//       });
//       Map data = {
//         "companyId":
//             sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
//         "userId": loginUserId,
//       };
//       apiPostRequestWithHeader(
//               data, AllUrls.getEmployeeProfileDetails, this.context, loginToken)
//           .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//         } else {
//               setState(() {
//               loading = false;
//             });
//           Map<String, dynamic> jsonDataForDetails = json.decode(response);
//           log("getEmployeeProfileDetails: " + jsonDataForDetails.toString());
//           log("getEmployeeProfileDetailss: " +
//               jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                       ["reportingManager"]
//                   .toString());
//           if (checkApiResponseSuccessOrNot(jsonDataForDetails)) {
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.reportingManager,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                     ["reportingManager"]
//                                 .toString() ==
//                             "null" ||
//                         jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                     ["reportingManager"]
//                                 .toString() ==
//                             ""
//                     ? AllString.na
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["reportingManager"]
//                         .toString());

//             if (jsonDataForDetails["employeeData"]["visitDetails"] == "" ||
//                 jsonDataForDetails["employeeData"]["visitDetails"].isEmpty) {
//               sharedPreferences!.setString(
//                   AllSharedPreferencesKey.checkInOptionNameWithId, "");
//               sharedPreferences!
//                   .setString(AllSharedPreferencesKey.checkInOptionName, "");
//               sharedPreferences!
//                   .setString(AllSharedPreferencesKey.checkInOption, "");
//             } else {
//               sharedPreferences!.setString(
//                   AllSharedPreferencesKey.checkInOptionNameWithId,
//                   jsonDataForDetails["employeeData"]["visitDetails"][0]
//                                       ["dealerId"]
//                                   .toString() ==
//                               "null" ||
//                           jsonDataForDetails["employeeData"]["visitDetails"][0]
//                                       ["dealerId"]
//                                   .toString() ==
//                               "0"
//                       ? ""
//                       : jsonDataForDetails["employeeData"]["visitDetails"][0]
//                               ["dealerId"]
//                           .toString());
//               sharedPreferences!.setString(
//                   AllSharedPreferencesKey.checkInOptionName,
//                   jsonDataForDetails["employeeData"]["visitDetails"][0]
//                                   ["visitTypeName"]
//                               .toString() ==
//                           "null"
//                       ? ""
//                       : jsonDataForDetails["employeeData"]["visitDetails"][0]
//                               ["visitTypeName"]
//                           .toString());

//               sharedPreferences!.setString(
//                   AllSharedPreferencesKey.checkInOption,
//                   jsonDataForDetails["employeeData"]["visitDetails"][0]
//                                       ["visitType"]
//                                   .toString() ==
//                               "null" ||
//                           jsonDataForDetails["employeeData"]["visitDetails"][0]
//                                       ["visitType"]
//                                   .toString() ==
//                               "0"
//                       ? ""
//                       : jsonDataForDetails["employeeData"]["visitDetails"][0]
//                                       ["visitType"]
//                                   .toString() ==
//                               "1"
//                           ? AllString.dealer
//                           : jsonDataForDetails["employeeData"]["visitDetails"]
//                                           [0]["visitType"]
//                                       .toString() ==
//                                   "2"
//                               ? AllString.office
//                               : jsonDataForDetails["employeeData"]
//                                               ["visitDetails"][0]["visitType"]
//                                           .toString() ==
//                                       "3"
//                                   ? AllString.others
//                                   : "");
//             }

//             if (jsonDataForDetails["employeeData"]["employeeLastDistance"]
//                         .toString() ==
//                     "null" ||
//                 jsonDataForDetails["employeeData"]["employeeLastDistance"]
//                         .toString() ==
//                     "") {
//               sharedPreferences!
//                   .setDouble(AllSharedPreferencesKey.positionForSend, 0.0);
//             } else {
//               sharedPreferences!.setDouble(
//                   AllSharedPreferencesKey.positionForSend,
//                   double.parse(jsonDataForDetails["employeeData"]
//                           ["employeeLastDistance"]
//                       .toString()));
//             }
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.sendLatitude,
//                 jsonDataForDetails["employeeData"]["checkInLatitude"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["checkInLatitude"]
//                         .toString());

//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.sendLongitude,
//                 jsonDataForDetails["employeeData"]["checkInLongitude"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["checkInLongitude"]
//                         .toString());

//             // sharedPreferences!
//             //     .setString(AllSharedPreferencesKey.attendanceStatus, "1");

//             //

//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.userRoleName,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["individualType"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["individualType"]
//                         .toString());

//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.individualId,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["individualId"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["individualId"]
//                         .toString());

//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.individualTypeId,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["individualTypeId"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["individualTypeId"]
//                         .toString());

//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.image,
//                 jsonDataForDetails["employeeData"]["employeeImage"][0]["url"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeImage"][0]
//                             ["url"]
//                         .toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.address,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["individualAddress"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["individualAddress"]
//                         .toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.contact1,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["individualContactNo1"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["individualContactNo1"]
//                         .toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.contact2,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["individualContactNo2"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["individualContactNo2"]
//                         .toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.dob,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["dateOfBirth"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["dateOfBirth"]
//                         .toString());

//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.email,
//                 jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                                 ["personalEmail"]
//                             .toString() ==
//                         "null"
//                     ? ""
//                     : jsonDataForDetails["employeeData"]["employeeDetails"][0]
//                             ["personalEmail"]
//                         .toString());

//             loginToken = sharedPreferences!.getString(
//                   AllSharedPreferencesKey.token,
//                 ) ??
//                 "";

//             loginUserId = sharedPreferences!.getString(
//                   AllSharedPreferencesKey.userId,
//                 ) ??
//                 "";
//             loginIndivisualId = sharedPreferences!.getString(
//                   AllSharedPreferencesKey.individualTypeId,
//                 ) ??
//                 "";
//             AppBuilder.of(context)!.rebuild();

//             setState(() {
//               loading = false;
//             });
//           } else {
//             setState(() {
//               loading = false;
//             });
//             commonAlertDialog(context, jsonDataForDetails["status"],
//                 jsonDataForDetails["message"]);
//           }
//         }
//       });
//     } else {
//       showOfflineSnakbar(context);
//     }
//   }

//   checkAndFetchAllDetails() async {
//     // //  log("allProductJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allProductJson)!);
//     // log("allDealerJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allDealerJson)!);
//     // log("allDealerJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allCommonDataJson)!);
//     //     log("allCategoryJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allCategoryJson)!);
//     //     log("allExpenseTypeJson: "+ sharedPreferences!.getString(AllSharedPreferencesKey.allExpenseTypeJson)!);
//     if ((dealerList.isEmpty || dealerList.length == 1) ||
//         (expenseTypeList.isEmpty || expenseTypeList.length == 1) ||
//         (categoryList.isEmpty || categoryList.length == 1)) {
//       if (await internetCheck()) {
//         fetchDealer();
        
//         Future.delayed(Duration(milliseconds: 300), () {
//           fetchCommonList();
//         });
//       } else {
//         dealerList.clear();
//         leaveTypeDetailsData.clear();
//         leaveTypeDetailsData.clear();
//         loanTypeDetailsData.clear();
//         suggestionTypeDetails.clear();
//         departmentDetails.clear();
//         categoryList.clear();
//         expenseTypeList.clear();
//         brandList.clear();
//         // expenseTypeList.clear();
//         // categoryList.clear();
//         // dealerList.add(AllString.select);
//         // expenseTypeList.add(AllString.select);
//         // categoryList.add(AllString.select);
//         // setState(() {
//         //   loading = true;
//         // });

//         // // ! Product Data fetch from local

//         // if (sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.allProductJson) ==
//         //         null ||
//         //     sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.allProductJson) ==
//         //         "") {
//         //   sharedPreferences!
//         //       .setString(AllSharedPreferencesKey.allProductJson, "");
//         // }
//         // ! Dealer Data fetch from local
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allDealerJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allDealerJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allDealerJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForDealerList = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allDealerJson)!);

//           List _tempList = jsonDataForDealerList["dealerData"];
//           dealerList.clear();
//           dealerList.add(AllString.select);
//           _tempList.forEach((element) {
//             dealerList.add(element["dealerName"].toString() +
//                 AllString.splitText +
//                 element["dealerId"].toString());
//           });
//         }
//         // ! leaveTypeName Data fetch from local
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList =
//               jsonDataForCommon["commonData"]["leaveTypeDetailsData"];
//           leaveTypeDetailsData.clear();
//           leaveTypeDetailsData.add(AllString.select);
//           _tempList.forEach((element) {
//             leaveTypeDetailsData.add(element["leaveTypeName"].toString() +
//                 AllString.splitText +
//                 element["leaveTypeId"].toString());
//           });
//         }

//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList =
//               jsonDataForCommon["commonData"]["loanTypeDetailsData"];
//           loanTypeDetailsData.clear();
//           loanTypeDetailsData.add(AllString.select);
//           _tempList.forEach((element) {
//             loanTypeDetailsData.add(element["loanTypeName"].toString() +
//                 AllString.splitText +
//                 element["loanTypeId"].toString());
//           });
//         }
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList =
//               jsonDataForCommon["commonData"]["suggestionTypeDetails"];
//           suggestionTypeDetails.clear();
//           suggestionTypeDetails.add(AllString.select);
//           _tempList.forEach((element) {
//             suggestionTypeDetails.add(element["suggestionTypeName"].toString() +
//                 AllString.splitText +
//                 element["suggestionTypeId"].toString());
//           });
//         }
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList = jsonDataForCommon["commonData"]["departmentDetails"];
//           departmentDetails.clear();
//           departmentDetails.add(AllString.select);
//           _tempList.forEach((element) {
//             departmentDetails.add(element["departmentName"].toString() +
//                 AllString.splitText +
//                 element["departmentId"].toString());
//           });
//         }
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList = jsonDataForCommon["commonData"]["divisionDetails"];
//           categoryList.clear();
//           categoryList.add(AllString.select);
//           _tempList.forEach((element) {
//             categoryList.add(element["productCategoryName"].toString() +
//                 AllString.splitText +
//                 element["productCategoryId"].toString());
//           });
//         }
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList = jsonDataForCommon["commonData"]["reimburstmentData"];
//           expenseTypeList.clear();
//           expenseTypeList.add(AllString.select);
//           _tempList.forEach((element) {
//             expenseTypeList.add(element["reimbursementType"].toString() +
//                 AllString.splitText +
//                 element["reimbursementTypeId"].toString());
//           });
//         }
//         if (sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 null ||
//             sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson) ==
//                 "") {
//           sharedPreferences!
//               .setString(AllSharedPreferencesKey.allCommonDataJson, "");
//         } else {
//           Map<String, dynamic> jsonDataForCommon = json.decode(
//               sharedPreferences!
//                   .getString(AllSharedPreferencesKey.allCommonDataJson)!);

//           List _tempList = jsonDataForCommon["commonData"]["brandDetails"];
//           brandList.clear();
//           brandList.add(AllString.select);
//           _tempList.forEach((element) {
//             brandList.add(element["brandName"].toString() +
//                 AllString.splitText +
//                 element["brandId"].toString());
//           });
//         }
//         // // ! Category Data fetch from local
//         // if (sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.allCategoryJson) ==
//         //         null ||
//         //     sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.allCategoryJson) ==
//         //         "") {
//         //   sharedPreferences!
//         //       .setString(AllSharedPreferencesKey.allCategoryJson, "");
//         // } else {
//         //   Map<String, dynamic> jsonDataForCategoryList = json.decode(
//         //       sharedPreferences!
//         //           .getString(AllSharedPreferencesKey.allCategoryJson)!);
//         //   List _tempList = jsonDataForCategoryList["divisionData"];
//         //   _tempList.forEach((element) {
//         //     categoryList.add(element["divisionName"].toString() +
//         //         AllString.splitText +
//         //         element["divisionId"].toString());
//         //   });
//         // }
//         // // ! ExpenseType Data fetch from local
//         // if (sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.allExpenseTypeJson) ==
//         //         null ||
//         //     sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.allExpenseTypeJson) ==
//         //         "") {
//         //   sharedPreferences!
//         //       .setString(AllSharedPreferencesKey.allExpenseTypeJson, "");
//         // } else {
//         //   Map<String, dynamic> jsonDataForExpenseTypeList = json.decode(
//         //       sharedPreferences!
//         //           .getString(AllSharedPreferencesKey.allExpenseTypeJson)!);
//         //   List _tempList = jsonDataForExpenseTypeList["data"];
//         //   _tempList.forEach((element) {
//         //     expenseTypeList.add(element["reimbursementType"].toString() +
//         //         AllString.splitText +
//         //         element["reimbursementTypeId"].toString());
//         //   });
//         // }

//         setState(() {
//           loading = false;
//         });
//         showOfflineSnakbar(context);
//       }
//     }
//   }

//   apiHitForSendLocation() {
//     if (sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude) ==
//             null ||
//         sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude)! ==
//             "") {
//     } else {
//       if (sharedPreferences!.getString(AllSharedPreferencesKey.allowance) ==
//           "1") {
//         // Timer.periodic(
//         //     Duration(
//         //         seconds: int.parse(sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.timeinterval)!)),
//         //     (Timer t) {
//         Permission.location.request().then((value) async {
//           var status = await Permission.location.status;
//           log(status.toString());
//           if (await Permission.location.isRestricted) {
//             commonAlertDialog(
//                 context, AllString.error, AllString.msgForRestrictedLocation,
//                 function: () {
//               Navigator.of(context).pushReplacement(
//                   CupertinoPageRoute(builder: (context) => Home()));
//             });
//           } else {
//             if (status.isDenied) {
//               commonAlertDialog(
//                   context, AllString.error, AllString.msgForDeniedLocation,
//                   function: () {
//                 Navigator.of(context).pushReplacement(
//                     CupertinoPageRoute(builder: (context) => Home()));
//               });
//             } else {
//               Position position = await Geolocator.getCurrentPosition(
//                   desiredAccuracy: LocationAccuracy.high);

//               setState(() {});

//               startLatLong = sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLatitude)! +
//                   " ||| " +
//                   sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLongitude)!;
//               endLatLong = position.latitude.toString() +
//                   " ||| " +
//                   position.longitude.toString();
//               setState(() {});

//               List<Placemark> placemarks = await placemarkFromCoordinates(
//                   position.latitude, position.longitude);
//               if (placemarks.isNotEmpty) {
//                 Placemark placeMark = placemarks[0];
//                 setState(() {});
//                 log(placeMark.toString());
//                 String location = placeMark.locality! +
//                     ", " +
//                     placeMark.subLocality! +
//                     " " +
//                     placeMark.name! +
//                     ", Street: " +
//                     placeMark.street! +
//                     ", " +
//                     placeMark.administrativeArea! +
//                     " " +
//                     placeMark.subAdministrativeArea! +
//                     ", Pincode: " +
//                     placeMark.postalCode! +
//                     ", " +
//                     placeMark.country!;
//                 sharedPreferences!
//                     .setString(AllSharedPreferencesKey.location, location);
//                 distance = Geolocator.distanceBetween(
//                     double.parse(sharedPreferences!
//                         .getString(AllSharedPreferencesKey.sendLatitude)!),
//                     double.parse(sharedPreferences!
//                         .getString(AllSharedPreferencesKey.sendLongitude)!),
//                     position.latitude,
//                     position.longitude);
//                 distanceForDisplay =
//                     (' ${distance != null ? distance > 1000 ? (distance / 1000).toStringAsFixed(2) : distance.toStringAsFixed(2) : 0} ${distance != null ? distance > 1000 ? 'KM' : 'm' : 0}');
// // commonFluttertoast(msg:"Distance: "+ int.parse(distance.toStringAsFixed(0).toString()).toString());
//                 if (int.parse(distance.toStringAsFixed(0).toString()) > 1) {
//                   sharedPreferences!.setString(
//                       AllSharedPreferencesKey.sendLatitude,
//                       position.latitude.toString());
//                   sharedPreferences!.setString(
//                       AllSharedPreferencesKey.sendLongitude,
//                       position.longitude.toString());
//                   sharedPreferences!.setDouble(
//                       AllSharedPreferencesKey.positionForSend,
//                       (sharedPreferences!.getDouble(
//                               AllSharedPreferencesKey.positionForSend)! +
//                           distance));
//                   Map dataForSend = {
//                     "companyId": sharedPreferences!
//                         .getString(AllSharedPreferencesKey.companyId),
//                     "individualId": sharedPreferences!
//                         .getString(AllSharedPreferencesKey.individualId),
//                     "latitude": sharedPreferences!
//                         .getString(AllSharedPreferencesKey.sendLatitude),
//                     "longitude": sharedPreferences!
//                         .getString(AllSharedPreferencesKey.sendLongitude),
//                     "location": sharedPreferences!
//                         .getString(AllSharedPreferencesKey.location),
//                     "distance": sharedPreferences!
//                         .getDouble(AllSharedPreferencesKey.positionForSend)!
//                         .toStringAsFixed(2)
//                   };
//                   // commonFluttertoast(msg:dataForSend.toString());
//                   apiPostRequestWithHeader(dataForSend,
//                           AllUrls.addEmployeePosition, this.context, loginToken)
//                       .then((response) {
//                     if (response == null) {
//                       commonAlertDialog(
//                           context, AllString.warning ,AllString.connectionFailure);
//                     } else {
//                       Map<String, dynamic> jsonDataForSend =
//                           json.decode(response);
//                       // commonFluttertoast(msg:jsonDataForSend.toString());

//                       // commonFluttertoast(msg: "Send Location Resopnse "+jsonDataForSend.toString());

//                       if (checkApiResponseSuccessOrNot(jsonDataForSend)) {
//                         log(jsonDataForSend.toString());
//                       } else {
//                         commonAlertDialog(context, jsonDataForSend["status"],
//                             jsonDataForSend["message"]);
//                       }
//                     }
//                   });
//                 }
//               }
//               setState(() {});
//             }
//           }
//         });
//         // });
//       }
//     }
//   }

//   positionConfigForHitLocation() async {
//     if (await internetCheck()) {
//       Map data = {
//         "companyId":
//             sharedPreferences!.getString(AllSharedPreferencesKey.companyId)
//       };
//       apiPostRequestWithHeader(
//               data, AllUrls.getLocationTrakingDetails, this.context, loginToken)
//           .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//         } else {
//           Map<String, dynamic> jsonData = json.decode(response);
//           if (checkApiResponseSuccessOrNot(jsonData)) {
//             log(jsonData.toString());
//             sharedPreferences!.setString(AllSharedPreferencesKey.timeinterval,
//                 jsonData["locationData"][0]["timeInterval"].toString());
//             sharedPreferences!.setString(AllSharedPreferencesKey.allowance,
//                 jsonData["locationData"][0]["isAllowed"].toString());
//             apiHitForSendLocation();

//             setState(() {});
//           } else {
//             commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//           }
//         }
//       });
//     } else {
//       offlineSentLocationTracking();
//       // apiHitForSendLocation();
//     }
//   }

//   offlineSentLocationTracking() {
//     if (sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude) ==
//             null ||
//         sharedPreferences!.getString(AllSharedPreferencesKey.sendLatitude)! ==
//             "") {
//       log("offlineSentLocationTracking IF");
//     } else {
//       log("offlineSentLocationTracking ELSE");

//       if (sharedPreferences!.getString(AllSharedPreferencesKey.allowance) ==
//           "1") {
//         log("offlineSentLocationTracking Allow");

//         // Timer.periodic(
//         //     Duration(
//         //         seconds: int.parse(sharedPreferences!
//         //             .getString(AllSharedPreferencesKey.timeinterval)!)),
//         //     (Timer t) {
//         Permission.location.request().then((value) async {
//           var status = await Permission.location.status;
//           log(status.toString());
//           if (await Permission.location.isRestricted) {
//             commonAlertDialog(
//                 context, AllString.error, AllString.msgForRestrictedLocation,
//                 function: () {
//               Navigator.of(context).pushReplacement(
//                   CupertinoPageRoute(builder: (context) => Home()));
//             });
//           } else {
//             if (status.isDenied) {
//               commonAlertDialog(
//                   context, AllString.error, AllString.msgForDeniedLocation,
//                   function: () {
//                 Navigator.of(context).pushReplacement(
//                     CupertinoPageRoute(builder: (context) => Home()));
//               });
//             } else {
//               Position position = await Geolocator.getCurrentPosition(
//                   desiredAccuracy: LocationAccuracy.high);

//               setState(() {});

//               startLatLong = sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLatitude)! +
//                   " ||| " +
//                   sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLongitude)!;
//               endLatLong = position.latitude.toString() +
//                   " ||| " +
//                   position.longitude.toString();
//               setState(() {});

//               sharedPreferences!.setString(
//                   AllSharedPreferencesKey.location,
//                   sharedPreferences!
//                       .getString(AllSharedPreferencesKey.location)!);
//               distance = Geolocator.distanceBetween(
//                   double.parse(sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLatitude)!),
//                   double.parse(sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLongitude)!),
//                   position.latitude,
//                   position.longitude);
//               distanceForDisplay =
//                   (' ${distance != null ? distance > 1000 ? (distance / 1000).toStringAsFixed(2) : distance.toStringAsFixed(2) : 0} ${distance != null ? distance > 1000 ? 'KM' : 'm' : 0}');
// // commonFluttertoast(msg:"Distance: "+ int.parse(distance.toStringAsFixed(0).toString()).toString());
//               if (int.parse(distance.toStringAsFixed(0).toString()) > 1) {
//                 sharedPreferences!.setString(
//                     AllSharedPreferencesKey.sendLatitude,
//                     position.latitude.toString());
//                 sharedPreferences!.setString(
//                     AllSharedPreferencesKey.sendLongitude,
//                     position.longitude.toString());
//                 sharedPreferences!.setDouble(
//                     AllSharedPreferencesKey.positionForSend,
//                     (sharedPreferences!.getDouble(
//                             AllSharedPreferencesKey.positionForSend)! +
//                         distance));

//                 Map<String, dynamic> data = {
//                   Databasehelper.distance: sharedPreferences!
//                       .getDouble(AllSharedPreferencesKey.positionForSend)!
//                       .toStringAsFixed(2),
//                   Databasehelper.latitude: sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLatitude),
//                   Databasehelper.longitude: sharedPreferences!
//                       .getString(AllSharedPreferencesKey.sendLongitude),
//                   Databasehelper.location: sharedPreferences!
//                       .getString(AllSharedPreferencesKey.location),
//                 };
//                 final id = await dbhelper.insertTrackingLocation(data);
//                 var allrows = await dbhelper.fetchAllTrackingLocation();
//                 log(allrows.toString());
//               }
//               setState(() {});
//             }
//           }
//         });
//         // });
//       }
//     }
//   }

//   fetchCommonList() async {
//     if (await internetCheck()) {
//       setState(() {
//         loading = true;
//       });
//       Map data = {
//         "companyId":
//             sharedPreferences!.getString(AllSharedPreferencesKey.companyId)
//       };
//       apiPostRequestWithHeader(
//               data, AllUrls.getCommonData, this.context, loginToken)
//           .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//         } else {
//           Map<String, dynamic> jsonData = json.decode(response);
//           if (checkApiResponseSuccessOrNot(jsonData)) {
//             leaveTypeDetailsData.clear();
//             leaveTypeDetailsData.clear();
//             loanTypeDetailsData.clear();
//             suggestionTypeDetails.clear();
//             departmentDetails.clear();
//             categoryList.clear();
//             expenseTypeList.clear();
//             brandList.clear();
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.allCommonDataJson, response.toString());
//             log("oooo " +
//                 sharedPreferences!
//                     .getString(AllSharedPreferencesKey.allCommonDataJson)!
//                     .toString());
//             List _tempList = [];
//             if (jsonData["commonData"] == "" || jsonData["commonData"] == []) {
//               _tempList = [];
//               setState(() {
//                 loading = false;
//               });
//             } else {
//               // if (jsonData["commonData"]["dealerData"] == "" ||
//               //     jsonData["commonData"]["dealerData"] == []) {
//               //   sharedPreferences!
//               //       .setString(AllSharedPreferencesKey.allDealerJson, "");
//               // } else {
//               //   sharedPreferences!.setString(
//               //       AllSharedPreferencesKey.allDealerJson,
//               //       jsonData["commonData"]["dealerData"].toString());

//               //   _tempList = jsonData["commonData"]["dealerData"];
//               //   _tempList.forEach((element) {
//               //     dealerList.add(element["dealerName"].toString() +
//               //         AllString.splitText +
//               //         element["dealerId"].toString());
//               //   });
//               // }

//               // if (jsonData["commonData"]["dealerData"] == "" ||
//               //     jsonData["commonData"]["dealerData"] == []) {
//               //   sharedPreferences!
//               //       .setString(AllSharedPreferencesKey.allDealerJson, "");
//               // } else {
//               //   sharedPreferences!.setString(
//               //       AllSharedPreferencesKey.allDealerJson,
//               //       jsonData["commonData"]["dealerData"].toString());

//               //   _tempList = jsonData["commonData"]["dealerData"];
//               //   _tempList.forEach((element) {
//               //     dealerList.add(element["dealerName"].toString() +
//               //         AllString.splitText +
//               //         element["dealerId"].toString());
//               //   });
//               // }

//               if (jsonData["commonData"]["leaveTypeDetailsData"] == "" ||
//                   jsonData["commonData"]["leaveTypeDetailsData"] == []) {
//               } else {
//                 _tempList = jsonData["commonData"]["leaveTypeDetailsData"];
//                 leaveTypeDetailsData.clear();
//                 leaveTypeDetailsData.add(AllString.select);
//                 _tempList.forEach((element) {
//                   leaveTypeDetailsData.add(element["leaveTypeName"].toString() +
//                       AllString.splitText +
//                       element["leaveTypeId"].toString());
//                 });
//               }

//               if (jsonData["commonData"]["loanTypeDetailsData"] == "" ||
//                   jsonData["commonData"]["loanTypeDetailsData"] == []) {
//               } else {
//                 _tempList = jsonData["commonData"]["loanTypeDetailsData"];
//                 loanTypeDetailsData.clear();
//                 loanTypeDetailsData.add(AllString.select);
//                 _tempList.forEach((element) {
//                   loanTypeDetailsData.add(element["loanTypeName"].toString() +
//                       AllString.splitText +
//                       element["loanTypeId"].toString());
//                 });
//               }

//               if (jsonData["commonData"]["suggestionTypeDetails"] == "" ||
//                   jsonData["commonData"]["suggestionTypeDetails"] == []) {
//               } else {
//                 _tempList = jsonData["commonData"]["suggestionTypeDetails"];
//                 suggestionTypeDetails.clear();
//                 suggestionTypeDetails.add(AllString.select);
//                 _tempList.forEach((element) {
//                   suggestionTypeDetails.add(
//                       element["suggestionTypeName"].toString() +
//                           AllString.splitText +
//                           element["suggestionTypeId"].toString());
//                 });
//               }

//               if (jsonData["commonData"]["departmentDetails"] == "" ||
//                   jsonData["commonData"]["departmentDetails"] == []) {
//               } else {
//                 _tempList = jsonData["commonData"]["departmentDetails"];
//                 departmentDetails.clear();
//                 departmentDetails.add(AllString.select);
//                 _tempList.forEach((element) {
//                   departmentDetails.add(element["departmentName"].toString() +
//                       AllString.splitText +
//                       element["departmentId"].toString());
//                 });
//               }

//               if (jsonData["commonData"]["divisionDetails"] == "" ||
//                   jsonData["commonData"]["divisionDetails"] == []) {
//               } else {
//                 categoryList.clear();
//                 categoryList.clear();
//                 categoryList.add(AllString.select);
//                 _tempList = jsonData["commonData"]["divisionDetails"];
//                 _tempList.forEach((element) {
//                   categoryList.add(element["productCategoryName"].toString() +
//                       AllString.splitText +
//                       element["productCategoryId"].toString());
//                 });
//               }
//               if (jsonData["commonData"]["reimburstmentData"] == "" ||
//                   jsonData["commonData"]["reimburstmentData"] == []) {
//               } else {
//                 expenseTypeList.clear();
//                 expenseTypeList.add(AllString.select);
//                 _tempList = jsonData["commonData"]["reimburstmentData"];
//                 _tempList.forEach((element) {
//                   expenseTypeList.add(element["reimbursementType"].toString() +
//                       AllString.splitText +
//                       element["reimbursementTypeId"].toString());
//                 });
//               }
//               if (jsonData["commonData"]["brandDetails"] == "" ||
//                   jsonData["commonData"]["brandDetails"] == []) {
//                 brandList = [];
//               } else {
//                 brandList.clear();
//                 brandList.add(AllString.select);
//                 _tempList = jsonData["commonData"]["brandDetails"];
//                 _tempList.forEach((element) {
//                   brandList.add(element["brandName"].toString() +
//                       AllString.splitText +
//                       element["brandId"].toString());
//                 });
//               }
//             }
//             setState(() {
//               loading = false;
//             });
//           } else {
//             setState(() {
//               loading = false;
//             });
//             commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//           }
//         }
//       });
//     } else {
//       apiHitForSendLocation();
//     }
//   }

//   offlineTrackingSendLocationFetch() async {
//     setState(() {
//       loading = true;
//     });
//     if (await internetCheck()) {
//       var allrows = await dbhelper.fetchAllTrackingLocation();
//       Map data = {
//         "companyId":
//             sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//         "individualId":
//             sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//         "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//         "trackingData": allrows,
//       };
//       log(data.toString());
//       apiPostRequestWithHeader(
//               data, AllUrls.addEmployeePosition, this.context, loginToken)
//           .then((response) {
//         if (response == null) {
//           loading = false;
//           setState(() {});
//           commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//         } else {
//           Map<String, dynamic> jsonData = json.decode(response);
//           if (checkApiResponseSuccessOrNot(jsonData)) {
//             setState(() {
//               loading = false;
//             });

//             commonAlertDialog(context, jsonData["status"], jsonData["message"],
//                 function: () async {
//               List allSendLocationList = allrows;
//               allSendLocationList.forEach((element) {
//                 dbhelper.deleteTrackingLocation(element["id"]);
//               });

//               var allrowsss = await dbhelper.fetchAllTrackingLocation();
//               log(allrowsss.toString());
//               setState(() {});
//               Navigator.pop(context);
//             });
//           } else {
//             setState(() {
//               loading = false;
//             });
//             commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//           }
//         }
//       });
//     }
//   }

//   createRequestBodyAndHit() async {
//     if (await internetCheck()) {
//       // log("\n\nFetch All Tracking Location ====================================================\n\n");
//       // allrows = await dbhelper.fetchAllTrackingLocation();
//       // data = {
//       //   "companyId":
//       //       sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//       //   "individualId":
//       //       sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//       //   "userId": sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//       //   "trackingData": allrows,
//       // };
//       // log(json.encode(data));
//       log("\n\nFetch All Day Start Day End ====================================================\n\n");

//       var allAttendanceRowsList = await dbhelper.fetchAllDayStartDayEnd();
//       List allAttendanceRows = [];
//       allAttendanceRowsList.forEach((element) {
//         allAttendanceRows.add({
//           "inTime": element["punchInTime"],
//           "outTime": element["punchOutTime"],
//           "checkInLocation": element["checkInLocation"],
//           "checkInLatitude": element["checkInLatitude"],
//           "checkInLongitude": element["checkInLongitude"],
//           "checkOutLocation": element["checkOutLocation"],
//           "checkOutLongitude": element["checkOutLongitude"],
//           "checkOutLatitude": element["checkOutLatitude"]
//         });
//       });
//       Future.delayed(Duration(milliseconds: 300), () {
//         if (allAttendanceRows.isNotEmpty) {
//           Map attendanceData = {
//             "companyId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//             "individualId": sharedPreferences!
//                 .getString(AllSharedPreferencesKey.individualId),
//             "userLoginId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//             "attendanceData": allAttendanceRows,
//           };
//           // commonFluttertoast(msg: "Attendance Hit");

//           apiPostRequestWithHeader(attendanceData,
//                   AllUrls.addEmployeeAttendance, this.context, loginToken)
//               .then((response) {
//             if (response == null) {
//               log("Null Response");
//             } else {
//               Map<String, dynamic> attendanceResponse = json.decode(response);
//               log("Attendance Response: " + attendanceResponse.toString());
//               if (checkApiResponseSuccessOrNot(attendanceResponse)) {
//                 allAttendanceRowsList.forEach((element) {
//                   dbhelper.deleteDayStartDayEnd(element["id"]);
//                 });
//                 callAllOfflineBreakForUpdate();
//               } else {}
//             }
//           });
//         }
//       });

//       log("\n\nFetch All Check In ====================================================\n\n");
//       var allCheckInRowsList = await dbhelper.fetchAllCheckIn();
//       List allCheckInRowsForRequest = [];
//       allCheckInRowsList.forEach((element) {
//         allCheckInRowsForRequest.add({
//           "officeName": element["checkInofficeName"],
//           "officeType": element["checkInofficeType"],
//           "dealerId": element["checkIndealerId"],
//           "visitTypeName": element["checkInvisitTypeName"],
//           "visitType": element["checkInvisitType"],
//           "location": element["checkInlocation"],
//           "latitude": element["checkInlatitude"],
//           "longitude": element["checkInlongitude"],
//           "checkInTime": element["checkInTime"],
//         });
//       });

//       Future.delayed(Duration(milliseconds: 300), () {
//         if (allCheckInRowsForRequest.isNotEmpty) {
//           Map checkInData = {
//             "companyId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//             "individualId": sharedPreferences!
//                 .getString(AllSharedPreferencesKey.individualId),
//             "userLoginId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//             "checkInData": allCheckInRowsForRequest,
//           };
//           log(json.encode(checkInData));
//           // commonFluttertoast(msg: "Check In Hit");
//           log("checkInResponse: " + checkInData.toString());

//           apiPostRequestWithHeader(checkInData, AllUrls.employeeVisitIn,
//                   this.context, loginToken)
//               .then((response) {
//             if (response == null) {
//               log("Null Response");
//             } else {
//               Map<String, dynamic> checkInResponse = json.decode(response);
//               // commonFluttertoast(
//               //     msg: "Check In Response: " + checkInResponse.toString());
//               // commonAlertDialog(
//               //     context, "Check In Response", checkInResponse.toString());

//               if (checkApiResponseSuccessOrNot(checkInResponse)) {
//                 allCheckInRowsList.forEach((element) {
//                   dbhelper.deleteCheckIn(element["id"]);
//                 });
//                 callOfflineCheckOut();
//               } else {}
//             }
//           });
//         }
//       });

//       log("\n\nFetch All Order ====================================================\n\n");

//       var allOrderRowsList = await dbhelper.fetchAllOrder();
//       List allOrderRows = [];
//       List allOrderRowsFinalList = [];
//       Future.forEach(allOrderRowsList, (Map element) async {
//         allOrderRows = await dbhelper
//             .fetchAllOrderSubList(element["id"].toString().trim() + "_Order");

//         allOrderRowsFinalList.add({
//           "dealerId": element["dealerId"],
//           "visitType": element["visitType"],
//           "visitTypeName": element["visitTypeName"],
//           "remarks": element["remarks"],
//           "orderData": allOrderRows
//         });
//       });

//       Future.delayed(Duration(milliseconds: 300), () {
//         if (allOrderRowsFinalList.isNotEmpty) {
//           Map orderData = {
//             "companyId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//             "individualId": sharedPreferences!
//                 .getString(AllSharedPreferencesKey.individualId),
//             "userLoginId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//             "orderDetails": allOrderRowsFinalList,
//           };
//           // commonFluttertoast(msg: "Add Order Hit");

//           apiPostRequestWithHeader(
//                   orderData, AllUrls.addOrder, this.context, loginToken)
//               .then((response) {
//             if (response == null) {
//               log("Null Response");
//             } else {
//               Map<String, dynamic> orderResponse = json.decode(response);
//               log("Order Response: " + orderResponse.toString());
//               if (checkApiResponseSuccessOrNot(orderResponse)) {
//                 Future.forEach(allOrderRowsList, (Map element) async {
//                   allOrderRows = await dbhelper.fetchAllOrderSubList(
//                       element["id"].toString().trim() + "_Order");
//                   Future.forEach(allOrderRowsList, (Map subElement) async {
//                     dbhelper.deleteOrderSubList(subElement["id"]);
//                   });
//                 }).whenComplete(() {
//                   Future.forEach(allOrderRowsList, (Map element) async {
//                     dbhelper.deleteOrder(element["id"]);
//                   });
//                 });
//               } else {}
//             }
//           });
//         }
//       });

//       log("\n\nFetch All Payment ====================================================\n\n");

//       var allPaymentRowsList = await dbhelper.fetchAllApplyPayment();
//       var allrowsPaymentImages = await dbhelper.fetchAllPaymentImage();
//       List<Map<String, dynamic>> paymentResponList = [];

//       Future.forEach(allPaymentRowsList, (Map expenseEle) {
//         Map<String, dynamic> tempData = {
//           "id": expenseEle["id"],
//           "dealerId": expenseEle["dealerId"],
//           "amount": expenseEle["amount"],
//           "comment": expenseEle["comment"],
//           "visitTypeName": expenseEle["visitTypeName"],
//           "visitTypeId": expenseEle["visitTypeId"],
//           "paymentUniqueId": expenseEle["paymentUniqueId"],
//           "paymentImage": "",
//         };
//         paymentResponList.add(tempData);
//       });

//       Future.forEach(paymentResponList, (Map<String, dynamic> elementJson) {
//         Future.forEach(allrowsPaymentImages, (Map<String, dynamic> ele) {
//           if (ele["paymentId"].toString() == elementJson["id"].toString()) {
//             elementJson["paymentImage"] =
//                 ele["paymentPaymentImage"].toString().isNotEmpty
//                     // ? ele["paymentPaymentImage"].toString().substring(0, 15)
//                     ? ele["paymentPaymentImage"].toString()
//                     : "";
//           }
//         });
//       });

//       Future.delayed(Duration(milliseconds: 300), () {
//         if (allPaymentRowsList.isNotEmpty) {
//           Map expenseData = {
//             "companyId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//             "individualId": sharedPreferences!
//                 .getString(AllSharedPreferencesKey.individualId),
//             "userLoginId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//             "paymentData": paymentResponList,
//           };
//           // commonFluttertoast(msg: "Add Payment Hit");

//           apiPostRequestWithHeader(
//                   expenseData, AllUrls.addPaymentPost, this.context, loginToken)
//               .then((response) {
//             if (response == null) {
//               log("Null Response");
//             } else {
//               Map<String, dynamic> attendanceResponse = json.decode(response);
//               // commonAlertDialog(
//               //     context, "Payment Response", attendanceResponse.toString());
//               if (checkApiResponseSuccessOrNot(attendanceResponse)) {
//                 allPaymentRowsList.forEach((element) {
//                   dbhelper.deleteApplyPayment(element["id"]);
//                 });
//                 allrowsPaymentImages.forEach((element) {
//                   dbhelper.deletePaymentImage(element["id"]);
//                 });
//               } else {}
//             }
//           });
//         }
//       });

//       log("\n\nFetch All Expense ====================================================\n\n");

//       var allExpenseRowsList = await dbhelper.fetchAllExpense();
//       var allrowsExpenseImages = await dbhelper.fetchAllExpenseImage();
//       List<Map<String, dynamic>> expenseResponList = [];
//       List<Map<String, dynamic>> expenseResponListFinal = [];

//       Future.forEach(allExpenseRowsList, (Map expenseEle) {
//         Map<String, dynamic> tempData = {
//           "id": expenseEle["id"],
//           "expenceTypeId": expenseEle["expenceTypeId"],
//           "visitId": expenseEle["visitId"],
//           "amount": expenseEle["amount"],
//           "comment": expenseEle["comment"],
//           "attchment1": "",
//           "attchment2": ""
//         };
//         expenseResponList.add(tempData);
//       });

//       Future.forEach(expenseResponList, (Map<String, dynamic> elementJson) {
//         Future.forEach(allrowsExpenseImages, (Map<String, dynamic> ele) {
//           if (ele["expenseId"].toString() == elementJson["id"].toString()) {
//             elementJson["attchment1"] =
//                 ele["expenseAttchment1"].toString().isNotEmpty
//                     // ? ele["expenseAttchment1"].toString().substring(0, 15)
//                     ? ele["expenseAttchment1"].toString()
//                     : "";
//           }
//         });
//       });

//       Future.delayed(Duration(milliseconds: 300), () {
//         if (allExpenseRowsList.isNotEmpty) {
//           Map expenseData = {
//             "companyId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//             "individualId": sharedPreferences!
//                 .getString(AllSharedPreferencesKey.individualId),
//             "userLoginId":
//                 sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//             "expenseData": expenseResponList,
//           };
//           // commonFluttertoast(msg: "Add Expense Hit");

//           apiPostRequestWithHeader(expenseData, AllUrls.addEmployeeExpence,
//                   this.context, loginToken)
//               .then((response) {
//             if (response == null) {
//               log("Null Response");
//             } else {
//               Map<String, dynamic> attendanceResponse = json.decode(response);
//               // commonAlertDialog(
//               //     context, "Expense Response", attendanceResponse.toString());
//               if (checkApiResponseSuccessOrNot(attendanceResponse)) {
//                 allExpenseRowsList.forEach((element) {
//                   dbhelper.deleteExpense(element["id"]);
//                 });
//                 allrowsExpenseImages.forEach((element) {
//                   dbhelper.deleteExpenseImage(element["id"]);
//                 });
//               } else {}
//             }
//           });
//         }
//       });
//     }
//   }

//   callOfflineCheckOut() async {
//     log("\n\nFetch All Check Out ====================================================\n\n");

//     var allCheckOutRowsList = await dbhelper.fetchAllCheckOut();
//     List<Map<String, dynamic>> allrowsCheckOutImages =
//         await dbhelper.fetchAllCheckOutImage();
//     List<Map<String, dynamic>> checkOutResponList = [];

//     allCheckOutRowsList.forEach((element) {
//       checkOutResponList.add({
//         "id": element["id"],
//         "location": element["checkOutlocation"],
//         "latitude": element["checkOutlatitude"],
//         "longitude": element["checkOutlongitude"],
//         "officeName": element["checkOutofficeName"],
//         "dealerId": element["checkOutDealerId"],
//         "visitType": element["checkOutvisitType"],
//         "visitTypeName": element["checkOutvisitTypeName"],
//         "checkInId": element["checkInIdForCheckOut"],
//         "attatchmentImageFile1": "",
//         "attatchmentImageFile2": "",
//         "checkOutTime": element["checkOutcheckOutTime"],
//         "payment": {
//           "amount": element["checkOutpaymentAmount"] ?? "",
//           "remarks": element["checkOutpaymentRemark"] ?? "",
//         },
//         "conveyance": {
//           "amount": element["checkOutconveyanceAmount"] ?? "",
//           "remarks": element["checkOutconveyanceRemark"] ?? ""
//         }
//       });
//     });

//     Future.forEach(checkOutResponList, (Map<String, dynamic> elementJson) {
//       Future.forEach(allrowsCheckOutImages, (Map<String, dynamic> ele) {
//         if (ele["orderId"].toString() == elementJson["id"].toString()) {
//           elementJson["checkOutAttatchmentImageFile1"] =
//               ele["checkOutAttatchmentImageFile1"].toString().isNotEmpty
//                   // ? ele["checkOutAttatchmentImageFile1"]
//                   //     .toString()
//                   //     .substring(0, 15)
//                   ? ele["checkOutAttatchmentImageFile1"].toString()
//                   : "";
//           elementJson["checkOutAttatchmentImageFile2"] =
//               ele["checkOutAttatchmentImageFile2"].toString().isNotEmpty
//                   // ? ele["checkOutAttatchmentImageFile2"]
//                   //     .toString()
//                   //     .substring(0, 15)
//                   ? ele["checkOutAttatchmentImageFile2"].toString()
//                   : "";
//           elementJson["checkOutPaymentImage"] =
//               ele["checkOutPaymentImage"].toString().isNotEmpty
//                   // ? ele["checkOutPaymentImage"].toString().substring(0, 15)
//                   ? ele["checkOutPaymentImage"].toString()
//                   : "";
//         }
//       });
//     });
//     Future.forEach(checkOutResponList, (Map<String, dynamic> elementJson) {
//       List<Map<String, dynamic>> allOrderRows = [];
//       dbhelper
//           .fetchAllOrderSubList(
//               elementJson["id"].toString().trim() + "_CheckOut")
//           .then((value) {
//         Future.delayed(Duration(milliseconds: 600), () {
//           List<Map<String, dynamic>> allOrderRowsFinalList = [];

//           allOrderRows = value;
//           Future.forEach(allOrderRows, (Map<String, dynamic> eleeee) {
//             allOrderRowsFinalList.add({
//               "productCategoryId": eleeee["productCategoryId"],
//               "productId": eleeee["productId"],
//               "brandId": eleeee["brandId"],
//               "quantity": eleeee["quantity"]
//             });
//             elementJson["orders"] = allOrderRowsFinalList;
//           });
//         });
//       });
//     });

//     // List allrowsCheckOutOrder = [];
//     // allrows.forEach((element) async {
//     //   allrowsCheckOutOrder = await dbhelper
//     //       .fetchAllOrderSubList(element["id"].toString() + "_CheckOut");
//     // });
//     Future.delayed(Duration(seconds: 3), () {
//       if (checkOutResponList.isNotEmpty) {
//         Map checkOutData = {
//           "companyId":
//               sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//           "individualId": sharedPreferences!
//               .getString(AllSharedPreferencesKey.individualId),
//           "userId":
//               sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//           "checkOutData": checkOutResponList,
//         };
//         // commonFluttertoast(msg: "Check Out Hit");
//         log("checkOutData: " + checkOutData.toString());
//         apiPostRequestWithHeader(checkOutData, AllUrls.employeeVisitOut,
//                 this.context, loginToken)
//             .then((response) {
//           if (response == null) {
//             log("Null Response");
//           } else {
//             Map<String, dynamic> checkOutResponse = json.decode(response);
//             commonFluttertoast(
//                 msg: "Check Out Response: " + checkOutResponse.toString());
//             // commonAlertDialog(
//             //     context, "Check Out Response", checkOutResponse.toString());
//             if (checkApiResponseSuccessOrNot(checkOutResponse)) {
//               // allCheckOutRowsList.forEach((element) {
//               //   dbhelper.deleteCheckOut(element["id"]);
//               // });
//               allrowsCheckOutImages.forEach((element) {
//                 dbhelper.deleteCheckOutImage(element["id"]);
//               });
//               Future.forEach(checkOutResponList,
//                   (Map<String, dynamic> elementJson) {
//                 dbhelper.fetchAllOrderSubList(
//                     elementJson["id"].toString().trim() + "_CheckOut");
//                 Future.forEach(checkOutResponList, (Map subElement) async {
//                   dbhelper.deleteOrderSubList(subElement["id"]);
//                 });
//               }).whenComplete(() {
//                 Future.forEach(checkOutResponList, (Map element) async {
//                   log("checkOutResponList: " + element["id"].toString());
//                   dbhelper.deleteCheckOut(element["id"]);
//                 });
//               });
//             } else {}
//           }
//         });
//       }
//     });
//   }

//   callAllOfflineBreakForUpdate() async {
//     log("\n\n Fetch All Break Start Break End ==================================================== \n\n");

//     var allBreakRowsList = await dbhelper.fetchAllBreakStartAndBreakEnd();
//     List allBreakRows = [];
//     allBreakRowsList.forEach((element) {
//       allBreakRows.add({
//         "attendanceId": element["attendanceId"],
//         "breakPunchId": element["breakPunchId"],
//         "inTime": element["breakStartTime"],
//         "outTime": element["breakEndTime"],
//       });
//     });
//     Future.delayed(Duration(milliseconds: 300), () {
//       if (allBreakRowsList.isNotEmpty) {
//         Map breakData = {
//           "companyId":
//               sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//           "individualId": sharedPreferences!
//               .getString(AllSharedPreferencesKey.individualId),
//           "userLoginId":
//               sharedPreferences!.getString(AllSharedPreferencesKey.userId),
//           "breakData": allBreakRows,
//         };
//         // commonFluttertoast(msg: "Break Hit");

//         apiPostRequestWithHeader(
//                 breakData, AllUrls.breakStartEnd, this.context, loginToken)
//             .then((response) {
//           if (response == null) {
//             log("Null Response");
//           } else {
//             Map<String, dynamic> attendanceResponse = json.decode(response);
//             log("Attendance Response: " + attendanceResponse.toString());
//             if (checkApiResponseSuccessOrNot(attendanceResponse)) {
//               allBreakRowsList.forEach((element) {
//                 dbhelper.deleteBreakStartBreakEnd(element["id"]);
//               });
//             } else {}
//           }
//         });
//       }
//     });
//   }

//   fetchVersionForUpdateCheck() {
//     Map data = {
//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//       "individualId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//       "appVersion": appVersion
//     };
//     apiPostRequestWithHeader(
//             data, AllUrls.updateAppVersion, this.context, loginToken)
//         .then((response) {
//       if (response == null) {
//         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure,
//             function: () {
//           Navigator.pop(context);
//         });
//       } else {
//         Map<String, dynamic> versionJson = json.decode(response);
//         log("versionJson: " + versionJson.toString());
//         if (checkApiResponseSuccessOrNot(versionJson)) {
//           if (versionJson["versionData"]["flag"]) {
//             showUpdateDialog(versionJson);
//           } else {
//             checkPaymentStatus();
//           }
//         } else {
//           checkPaymentStatus();
//         }
//       }
//     });
//   }

//   checkPaymentStatus() {
//     Map data = {
//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//       "individualId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//       "configParameterName": "paymentChasingPopUpForHrms"
//     };
//     apiPostRequestWithHeader(
//             data, AllUrls.companyPayment, this.context, loginToken)
//         .then((response) {
//       if (response == null) {
//         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure,
//             function: () {
//           Navigator.pop(context);
//         });
//       } else {
//         Map<String, dynamic> versionJson = json.decode(response);
//         log("paymentJsonnn: " + versionJson.toString());
//         if (checkApiResponseSuccessOrNot(versionJson)) {
//           if (versionJson["configarationData"].isEmpty) {
//           } else if (versionJson["configarationData"][0]["option"].toString() ==
//               "1") {
//             showPaymentDialog(versionJson);
//           } else if (versionJson["configarationData"][0]["option"].toString() ==
//               "2") {
//             showPaymentDialog(versionJson);
//           }
//         } else {}
//       }
//     });
//   }

//   showUpdateDialog(Map versionJson) {
//     return showDialog(
//         barrierDismissible: false,
//         context: context,
//         builder: (BuildContext context) => WillPopScope(
//               onWillPop: () async => false,
//               child: Dialog(
//                 shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16.0)),
//                 elevation: 0.0,
//                 backgroundColor: Colors.transparent,
//                 child: ClipRRect(
//                   borderRadius: BorderRadius.circular(16.0),
//                   child: Container(
//                     margin: EdgeInsets.only(left: 0.0, right: 0.0),
//                     child: Stack(
//                       children: <Widget>[
//                         Container(
//                           // padding: EdgeInsets.only(
//                           //   top: 18.0,
//                           // ),
//                           // margin: EdgeInsets.only(top: 13.0, right: 8.0),
//                           decoration: BoxDecoration(
//                               color: Colors.white,
//                               shape: BoxShape.rectangle,
//                               borderRadius: BorderRadius.circular(16.0),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: Colors.black26,
//                                   blurRadius: 0.0,
//                                   offset: Offset(0.0, 0.0),
//                                 ),
//                               ]),
//                           child: Column(
//                             mainAxisSize: MainAxisSize.min,
//                             crossAxisAlignment: CrossAxisAlignment.stretch,
//                             children: <Widget>[
//                               Container(
//                                   height: screenWidth * 0.55,
//                                   alignment: Alignment.center,
//                                   child: Stack(
//                                     children: [
//                                       Positioned(
//                                         top: -screenWidth * 0.5,
//                                         left: -screenWidth * 0.1,
//                                         right: -screenWidth * 0.1,
//                                         child: SvgPicture.asset(
//                                           "assets/images/cloud.svg",
//                                           color: Color(0xffffca28),
//                                           width: screenWidth * 5,
//                                           height: screenWidth * 0.9,
//                                           fit: BoxFit.cover,
//                                         ),
//                                       ),
//                                       Positioned(
//                                         top: screenWidth * 0.1,
//                                         left: screenWidth * 0.1,
//                                         child: Column(
//                                           children: [
//                                             Text(
//                                               "Upgrade",
//                                               textAlign: TextAlign.center,
//                                               style: headingTextStyle(
//                                                   fontWeight: FontWeight.bold,
//                                                   color: Color(0xff870000)),
//                                             ),
//                                             Text(
//                                               "New Version",
//                                               textAlign: TextAlign.center,
//                                               style: normalTextStyle(
//                                                   color: Color(0xfff57c00)),
//                                             ),
//                                           ],
//                                         ),
//                                       ),
//                                       Positioned(
//                                         top: screenWidth * 0.05,
//                                         right: screenWidth * 0.1,
//                                         child: SvgPicture.asset(
//                                           "assets/images/rocket.svg",
//                                           // color: Color(0xffffca28),
//                                           // width: screenWidth * 5,
//                                           height: screenWidth * 0.35,
//                                           fit: BoxFit.cover,
//                                         ),
//                                       )
//                                     ],
//                                   )),
//                               Container(
//                                 width: screenWidth,
//                                 padding: EdgeInsets.symmetric(
//                                     horizontal: screenWidth * 0.02,
//                                     vertical: screenWidth * 0.0),
//                                 alignment: Alignment.center,
//                                 child: Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     Container(
//                                       width: screenWidth,
//                                       child: Text(
//                                         "Dear " +
//                                             sharedPreferences!.getString(
//                                                 AllSharedPreferencesKey
//                                                     .firstName)!,
//                                         textAlign: TextAlign.start,
//                                         style: headingTextStyle(
//                                             fontWeight: FontWeight.bold,
//                                             color: AllColor.black),
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       height: screenWidth * 0.02,
//                                     ),
//                                     Container(
//                                       width: screenWidth,
//                                       child: Text(
//                                         // "App updates are great for both app users and apps – updates mean that developers are always working on improving the app, keeping in mind a better customer experience with each update",
//                                         versionJson["message"].toString(),
//                                         textAlign: TextAlign.justify,
//                                         style: normalTextStyle(
//                                             color: AllColor.black
//                                                 .withOpacity(0.5)),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               Container(
//                                   margin: EdgeInsets.symmetric(
//                                     vertical: screenWidth * 0.03,
//                                   ),
//                                   child: Divider()),
//                               Row(
//                                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                                 crossAxisAlignment: CrossAxisAlignment.center,
//                                 children: [
//                                   Container(
//                                     width: screenWidth *0.3,
                                    
                                    
//                                     alignment: Alignment.center,
//                                     padding: EdgeInsets.symmetric(
//                                         vertical: screenWidth * 0.01,
//                                         horizontal: screenWidth * 0.0),
//                                     child: Center(
//                                       child: CupertinoButton(  padding: EdgeInsets.symmetric(
//                                         vertical: screenWidth * 0.01,
//                                         horizontal: screenWidth * 0.03),
//                                         color: AllColor.transparentColor,
//                                         child: Text(
//                                           "Ignore",
//                                           style: normalTextStyle(
//                                             color: Color(0xffffca28),
//                                           ),
//                                         ),
//                                         disabledColor: AllColor.greyColor,
//                                         onPressed: () {
//                                           SystemNavigator.pop();
//                                         },
//                                       ),
//                                     ),
//                                   ),
//                                   Container(
//                                     width: screenWidth *0.3,
                                    
//                                     alignment: Alignment.center,
//                                     padding: EdgeInsets.symmetric(
//                                         vertical: screenWidth * 0.01,
//                                         horizontal: screenWidth * 0.0),
//                                     child: Center(
//                                       child: CupertinoButton(padding: EdgeInsets.symmetric(
//                                         vertical: screenWidth * 0.01,
//                                         horizontal: screenWidth * 0.03),
                                        

//                                         child: Text(
//                                           "Update",
//                                           style: normalTextStyle(
//                                               color: AllColor.white),
//                                         ),
//                                         disabledColor: AllColor.greyColor,
//                                         // onPressed: enable ? function! : null,
//                                         color: Color(0xffffca28),
//                                         onPressed: () {
//                                           launchURL(versionJson["versionData"]
//                                               ["driveLink"]);
//                                         },
//                                       ),
//                                     ),
//                                   )
//                                 ],
//                               ),
//                               SizedBox(
//                                 height: 10,
//                               )
//                             ],
//                           ),
//                         ),
//                         // Positioned(
//                         //   right: 0.0,
//                         //   child: GestureDetector(
//                         //     onTap: () {
//                         //       // SystemNavigator.pop();
//                         //       Navigator.pop(context);
//                         //     },
//                         //     child: Align(
//                         //       alignment: Alignment.topRight,
//                         //       child: CircleAvatar(
//                         //           radius: 14.0,
//                         //           backgroundColor: Colors.white,
//                         //           child: normalIcon(Icons.close,
//                         //               color: AllColor.greyColor)),
//                         //     ),
//                         //   ),
//                         // ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ));
//     showDialog(
//         barrierDismissible: false,
//         context: context,
//         builder: (context) => WillPopScope(
//               onWillPop: () async {
//                 return false;
//               },
//               child: SimpleDialog(
//                   shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(16.0)),
//                   elevation: 0.0,
//                   backgroundColor: AllColor.white,
//                   title: Container(
//                     width: screenWidth,
//                     color: AllColor.white,
//                     margin: EdgeInsets.symmetric(
//                       vertical: screenWidth * 0.03,
//                       horizontal: screenWidth * 0.0,
//                     ),
//                     alignment: Alignment.center,
//                     child: Text(
//                       AllString.newViesionAvailable,
//                       textAlign: TextAlign.left,
//                       style: headingTextStyle(
//                           fontWeight: FontWeight.bold, color: AllColor.black),
//                     ),
//                   ),
//                   children: [
//                     Container(
//                       margin: EdgeInsets.symmetric(
//                         horizontal: screenWidth * 0.02,
//                       ),
//                       width: screenWidth,
//                       alignment: Alignment.center,
//                       child: Text(
//                         versionJson["message"].toString(),
//                         textAlign: TextAlign.center,
//                         style: headingTextStyle(color: AllColor.black),
//                       ),
//                     ),
//                     SizedBox(height: screenWidth * 0.02),
//                     Container(
//                       width: screenWidth,
//                       margin: EdgeInsets.symmetric(
//                         horizontal: screenWidth * 0.02,
//                       ),
//                       alignment: Alignment.centerRight,
//                       child: button(
//                         context,
//                         function: () {
//                           Navigator.pop(context);
//                           launchURL(versionJson["versionData"]["driveLink"]);
//                         },
//                         color1: Color(0xff536976),
//                         color2: Color(0xff292E49),
//                         textColor: AllColor.white,
//                         text: AllString.update,
//                       ),
//                     ),
//                   ]),
//             ));
//   }

//   showPaymentDialog(Map versionJson) {
//     return showDialog(
//         barrierDismissible: false,
//         context: context,
//         builder: (BuildContext context) => WillPopScope(
//               onWillPop: () async => false,
//               child: Dialog(
//                 shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(16.0)),
//                 elevation: 0.0,
//                 backgroundColor: Colors.transparent,
//                 child: ClipRRect(
//                   borderRadius: BorderRadius.circular(16.0),
//                   child: Container(
//                     margin: EdgeInsets.only(left: 0.0, right: 0.0),
//                     child: Stack(
//                       children: <Widget>[
//                         Container(
//                           // padding: EdgeInsets.only(
//                           //   top: 18.0,
//                           // ),
//                           // margin: EdgeInsets.only(top: 13.0, right: 8.0),
//                           decoration: BoxDecoration(
//                               color: Colors.white,
//                               shape: BoxShape.rectangle,
//                               borderRadius: BorderRadius.circular(16.0),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: Colors.black26,
//                                   blurRadius: 0.0,
//                                   offset: Offset(0.0, 0.0),
//                                 ),
//                               ]),
//                           child: Column(
//                             mainAxisSize: MainAxisSize.min,
//                             crossAxisAlignment: CrossAxisAlignment.stretch,
//                             children: <Widget>[
//                               Container(
//                                 width: screenWidth,
//                                 padding: EdgeInsets.symmetric(
//                                     horizontal: screenWidth * 0.02,
//                                     vertical: screenWidth * 0.0),
//                                 alignment: Alignment.center,
//                                 child: Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     Container(
//                                       width: screenWidth,
//                                       alignment: Alignment.center,
//                                       margin: EdgeInsets.symmetric(
//                                           vertical: screenWidth * 0.03),
//                                       child: Icon(
//                                         Icons.warning_amber_rounded,
//                                         color: versionJson["configarationData"]
//                                                         [0]["option"]
//                                                     .toString() ==
//                                                 "1"
//                                             ? AllColor.yellow
//                                             : AllColor.red,
//                                         size: screenWidth * 0.23,
//                                       ),
//                                     ),
//                                     Container(
//                                       alignment: Alignment.center,
//                                       margin: EdgeInsets.symmetric(
//                                           vertical: screenWidth * 0.01),
//                                       width: screenWidth,
//                                       child: Text(
//                                         "Something went wrong",
//                                         textAlign: TextAlign.center,
//                                         style: headingTextStyle(
//                                           fontWeight: FontWeight.bold,
//                                           color:
//                                               versionJson["configarationData"]
//                                                               [0]["option"]
//                                                           .toString() ==
//                                                       "1"
//                                                   ? AllColor.yellow
//                                                   : AllColor.red,
//                                         ),
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       height: screenWidth * 0.02,
//                                     ),
//                                     Container(
//                                       alignment: Alignment.center,
//                                       width: screenWidth,
//                                       child: Text(
//                                         versionJson["message"].toString(),
//                                         textAlign: TextAlign.center,
//                                         style: normalTextStyle(
//                                             color: AllColor.black
//                                                 .withOpacity(0.5)),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               Container(
//                                   margin: EdgeInsets.symmetric(
//                                     vertical: screenWidth * 0.03,
//                                   ),
//                                   child: Divider()),
//                               Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 crossAxisAlignment: CrossAxisAlignment.center,
//                                 children: [
//                                   Container(
//                                     width: screenWidth * 0.4,
//                                     alignment: Alignment.center,
//                                     padding: EdgeInsets.symmetric(
//                                         vertical: screenWidth * 0.01,
//                                         horizontal: screenWidth * 0.0),
//                                     child: Center(
//                                       child: CupertinoButton(
//                                         padding: EdgeInsets.symmetric(
//                                         vertical: screenWidth * 0.01,
//                                         horizontal: screenWidth * 0.03),
//                                         child: Text(
//                                           "Close",
//                                           style: normalTextStyle(
//                                               color: AllColor.white),
//                                         ),
//                                         disabledColor: AllColor.greyColor,
//                                         // onPressed: enable ? function! : null,
//                                         color: versionJson["configarationData"]
//                                                         [0]["option"]
//                                                     .toString() ==
//                                                 "1"
//                                             ? AllColor.yellow
//                                             : AllColor.red,
//                                         onPressed: () {
//                                           versionJson["configarationData"][0]
//                                                           ["option"]
//                                                       .toString() ==
//                                                   "1"
//                                               ? Navigator.pop(context)
//                                               :
//                                               //  Navigator.pop(context);
//                                               SystemNavigator.pop();
//                                         },
//                                       ),
//                                     ),
//                                   )
//                                 ],
//                               ),
//                               SizedBox(
//                                 height: 10,
//                               )
//                             ],
//                           ),
//                         ),
//                         // Positioned(
//                         //   right: 0.0,
//                         //   child: GestureDetector(
//                         //     onTap: () {
//                         //       // SystemNavigator.pop();
//                         //       Navigator.pop(context);
//                         //     },
//                         //     child: Align(
//                         //       alignment: Alignment.topRight,
//                         //       child: CircleAvatar(
//                         //           radius: 14.0,
//                         //           backgroundColor: Colors.white,
//                         //           child: normalIcon(Icons.close,
//                         //               color: AllColor.greyColor)),
//                         //     ),
//                         //   ),
//                         // ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ));
//     showDialog(
//         barrierDismissible: false,
//         context: context,
//         builder: (context) => WillPopScope(
//               onWillPop: () async {
//                 return false;
//               },
//               child: SimpleDialog(
//                   shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(16.0)),
//                   elevation: 0.0,
//                   backgroundColor: AllColor.white,
//                   title: Container(
//                     width: screenWidth,
//                     color: AllColor.white,
//                     margin: EdgeInsets.symmetric(
//                       vertical: screenWidth * 0.03,
//                       horizontal: screenWidth * 0.0,
//                     ),
//                     alignment: Alignment.center,
//                     child: Text(
//                       AllString.newViesionAvailable,
//                       textAlign: TextAlign.left,
//                       style: headingTextStyle(
//                           fontWeight: FontWeight.bold, color: AllColor.black),
//                     ),
//                   ),
//                   children: [
//                     Container(
//                       margin: EdgeInsets.symmetric(
//                         horizontal: screenWidth * 0.02,
//                       ),
//                       width: screenWidth,
//                       alignment: Alignment.center,
//                       child: Text(
//                         versionJson["message"].toString(),
//                         textAlign: TextAlign.center,
//                         style: headingTextStyle(color: AllColor.black),
//                       ),
//                     ),
//                     SizedBox(height: screenWidth * 0.02),
//                     Container(
//                       width: screenWidth,
//                       margin: EdgeInsets.symmetric(
//                         horizontal: screenWidth * 0.02,
//                       ),
//                       alignment: Alignment.centerRight,
//                       child: button(
//                         context,
//                         function: () {
//                           Navigator.pop(context);
//                           launchURL(versionJson["versionData"]["driveLink"]);
//                         },
//                         color1: Color(0xff536976),
//                         color2: Color(0xff292E49),
//                         textColor: AllColor.white,
//                         text: AllString.update,
//                       ),
//                     ),
//                   ]),
//             ));
//   }
// }

// class CustomShape extends CustomClipper<Path> {
//   @override
//   getClip(Size size) {
//     double height = size.height;
//     double width = size.width;
//     var path = Path();
//     path.lineTo(0, height - 50);
//     path.quadraticBezierTo(width / 2, height, width, height - 54);
//     path.lineTo(width, 0);
//     path.close();

//     return path;
//   }

//   @override
//   bool shouldReclip(CustomClipper oldClipper) {
//     return true;
//   }
// }

// // import 'dart:math';

// // import 'package:cached_network_image/cached_network_image.dart';
// // import 'package:flutter/rendering.dart';
// // import 'package:hr/main.dart';
// // import 'package:hr/pages/home/home.dart';
// // import 'package:hr/pages/leaveBalance/leaveBalance.dart';
// // import 'package:hr/pages/myExpense/myExpense.dart';
// // import 'package:hr/pages/myLoan/myLoan.dart';
// // import 'package:hr/pages/myPerformance/myPerformance.dart';
// // import 'package:hr/pages/myReimbursment/myReimbursment.dart';
// // import 'package:hr/pages/mySuggetion/mySuggetion.dart';
// // import 'package:hr/pages/profile/profile.dart';
// // import 'package:hr/pages/publicHoliday/publicHoliday.dart';
// // import 'package:hr/pages/recordAttendance/myAttendance.dart';
// // import 'package:hr/pages/recordAttendance/recordAttendance.dart';
// // import 'package:hr/res/allColors.dart';
// // import 'package:hr/res/allSharePreferencesKey.dart';
// // import 'package:hr/res/allString.dart';
// // import 'package:hr/res/allUrls.dart';
// // import 'package:flutter/cupertino.dart';
// // import 'package:flutter/material.dart';
// // import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// // import 'package:hr/util/allIcon.dart';
// // import 'package:hr/util/allText.dart';
// // import 'package:hr/util/allTextStyle.dart';
// // import 'package:ionicons/ionicons.dart';
// // import 'package:line_icons/line_icons.dart';

// // class Dashboard extends StatefulWidget {
// //   const Dashboard({Key? key}) : super(key: key);

// //   @override
// //   _DashboardState createState() => _DashboardState();
// // }

// // class _DashboardState extends State<Dashboard> {
// //   List<Color> color = [
// //     Color(0xffcfd8dc),
// //     Color(0xffd7ccc8),
// //     Color(0xffffccbc),
// //     Color(0xffffecb3),
// //     Color(0xffc8e6c9),
// //     Color(0xffb2ebf2),
// //     Color(0xffbbdefb),
// //     Color(0xffc5cae9),
// //     Color(0xffd1c4e9),
// //     Color(0xffe1bee7),
// //     Color(0xfff8bbd0),
// //     Color(0xffffcdd2),
// //   ];
// //   Random random = new Random();

// //   @override
// //   Widget build(BuildContext context) {
// //     return Container(
// //       height: screenHeight,
// //       width: screenWidth,
// //              decoration:customBackgroundGradient(),

// //       child: Stack(
// //         children: [
// //           ClipPath(
// //             clipper:
// //                 CustomShape(), // this is my own class which extendsCustomClipper
// //             child: Container(
// //                 // height: screenWidth * 0.555,
// //                 height: screenHeight / 2.7,
// //                 decoration: BoxDecoration(
// //                     gradient: LinearGradient(
// //                         begin: Alignment(-5, 1),
// //                         end: Alignment(0, 0),
// //                         colors: [
// //                       Color.fromRGBO(0, 212, 255, 1),
// //                       Color.fromRGBO(2, 0, 36, 1)
// //                       // Color.fromRGBO(9, 9, 121, 1),
// //                       // Color.fromRGBO(9, 9, 121, 1),
// //                       // Color.fromRGBO(0, 212, 255, 1)
// //                     ]))),
// //           ),
// //           Positioned(
// //             top: screenWidth * 0.03,
// //             child: profileCard(),
// //           ),
// //           Positioned(
// //             bottom: 0,
// //             child: Column(
// //               mainAxisSize: MainAxisSize.min,
// //               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //               children: [
// //                 Container(
// //                   width: screenWidth,
// //                   child: Column(
// //                     mainAxisSize: MainAxisSize.min,
// //                     children: [
// //                       Container(
// //                         margin:
// //                             EdgeInsets.symmetric(vertical: screenWidth * 0.03),
// //                         child: Row(
// //                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //                           crossAxisAlignment: CrossAxisAlignment.center,
// //                           children: [
// //                             customDashboardButton(AllString.recordAttendance,
// //                                 Icons.touch_app_outlined, () {
// //                               Navigator.of(context).push(CupertinoPageRoute(
// //                                   builder: (context) => RecordAttendance()));
// //                             }, color[random.nextInt(12)]),
// //                             customDashboardButton(AllString.myAttendance,
// //                                 Ionicons.calendar_outline, () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => MyAttendance()));
// //                             }, color[random.nextInt(12)]),
// //                             customDashboardButton(
// //                                 AllString.leaveBalance, LineIcons.moneyBill,
// //                                 () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => LeaveBalance()));
// //                             }, color[random.nextInt(12)]),
// //                           ],
// //                         ),
// //                       ),
// //                       Container(
// //                         margin:
// //                             EdgeInsets.symmetric(vertical: screenWidth * 0.03),
// //                         child: Row(
// //                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //                           crossAxisAlignment: CrossAxisAlignment.center,
// //                           children: [
// //                             customDashboardButton(
// //                                 AllString.myLoan, LineIcons.handHolding, () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => MyLoan()));
// //                             }, color[random.nextInt(12)]),
// //                             customDashboardButton(
// //                                 AllString.mySuggestion, LineIcons.signLanguage,
// //                                 () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => MySuggetion()));
// //                             }, color[random.nextInt(12)]),
// //                             customDashboardButton(
// //                                 AllString.myExpense, LineIcons.arrowDown, () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => MyExpense()));
// //                             }, color[random.nextInt(12)]),
// //                           ],
// //                         ),
// //                       ),
// //                       Container(
// //                         margin:
// //                             EdgeInsets.symmetric(vertical: screenWidth * 0.03),
// //                         child: Row(
// //                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //                           crossAxisAlignment: CrossAxisAlignment.center,
// //                           children: [
// //                             customDashboardButton(
// //                                 AllString.myReimbursement, LineIcons.revIo, () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => MyReimbursment()));
// //                             }, color[random.nextInt(12)]),
// //                             customDashboardButton(
// //                                 AllString.myPerformance, LineIcons.cardboardVr,
// //                                 () {
// //                               Navigator.of(context).push(CupertinoPageRoute(
// //                                   builder: (context) => MyPerformance()));
// //                             }, color[random.nextInt(12)]),
// //                             customDashboardButton(AllString.publicHolidays,
// //                                 Icons.holiday_village_outlined, () {
// //                               Navigator.push(
// //                                   context,
// //                                   CupertinoPageRoute(
// //                                       builder: (context) => PublicHoliday()));
// //                             }, color[random.nextInt(12)]),
// //                           ],
// //                         ),
// //                       )
// //                     ],
// //                   ),
// //                 )
// //               ],
// //             ),
// //           ),
// //         ],
// //       ),
// //     );
// //   }

// //   customDashboardButton(
// //       String name, IconData icon, Function() onTap, Color color) {
// //     return GestureDetector(
// //       onTap: onTap,
// //       child: Container(
// //         width: screenWidth * 0.33,
// //         child: Column(
// //           mainAxisSize: MainAxisSize.min,
// //           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //           crossAxisAlignment: CrossAxisAlignment.center,
// //           children: [
// //             Container(
// //               width: screenWidth >= 600
// //                   ? screenWidth * 0.15
// //                   : screenWidth > 450
// //                       ? screenWidth * 0.17
// //                       : screenWidth * 0.19,
// //               height: screenWidth >= 600
// //                   ? screenWidth * 0.15
// //                   : screenWidth > 450
// //                       ? screenWidth * 0.17
// //                       : screenWidth * 0.19,
// //               decoration: BoxDecoration(
// //                 boxShadow: [
// //                   BoxShadow(
// //                     color: Colors.grey.withOpacity(0.5),
// //                     spreadRadius: 5,
// //                     blurRadius: 7,
// //                     offset: Offset(0, 3), // changes position of shadow
// //                   ),
// //                 ],
// //                 borderRadius: BorderRadius.circular(10),
// //                 gradient: LinearGradient(
// //                     begin: Alignment.topLeft,
// //                     end: Alignment.bottomRight,
// //                     // begin: Alignment(-5, 1),
// //                     // end: Alignment(0, 0),
// //                     colors: [
// //                       Color(0xff59C173),
// //                       Color(0xffa17fe0),
// //                       Color(0xff5D26C1),
// //                       // Color.fromRGBO(0, 212, 255, 1),
// //                       // Color.fromRGBO(2, 0, 36, 1)
// //                     ]),
// //               ),
// //               child: Center(
// //                 child: Container(
// //                   width: screenWidth >= 600
// //                       ? screenWidth * 0.15
// //                       : screenWidth > 450
// //                           ? screenWidth * 0.16
// //                           : screenWidth * 0.18,
// //                   height: screenWidth >= 600
// //                       ? screenWidth * 0.15
// //                       : screenWidth > 450
// //                           ? screenWidth * 0.16
// //                           : screenWidth * 0.18,
// //                   decoration: BoxDecoration(
// //                       borderRadius: BorderRadius.circular(10),
// //                       color: AllColor.white
// //                       // gradient: LinearGradient(
// //                       //     begin: FractionalOffset(0.0, 0.0),
// //                       //     end: FractionalOffset(1.0, 0.0),
// //                       //     stops: [0.0, 1.0],
// //                       //     tileMode: TileMode.clamp,
// //                       //     colors: [color, color.withOpacity(0.8)])

// //                       ),
// //                   child: Container(
// //                     // child: mediumIcon(icon, color: AllColor.primaryDeepColor),
// //                     child: mediumIcon(icon, color: Color(0xff1C8D73)),
// //                   ),
// //                 ),
// //               ),
// //             ),
// //             SizedBox(
// //               height: screenWidth * 0.02,
// //             ),
// //             Container(
// //               child: Text(
// //                 name,
// //                 textAlign: TextAlign.center,
// //                 style: smallTextStyle(
// //                     color: AllColor.black, fontWeight: FontWeight.bold),
// //               ),
// //             )
// //           ],
// //         ),
// //       ),
// //     );
// //   }

// //   profileCard() {
// //     return GestureDetector(
// //       onTap: () {
// //         Navigator.of(context)
// //             .push(CupertinoPageRoute(builder: (context) => Profile()));
// //       },
// //       child: Container(
// //         width: screenWidth,
// //         // height: screenWidth * 0.37,
// //         height: screenHeight / 3.5,
// //         alignment: Alignment.center,
// //         margin: EdgeInsets.symmetric(
// //           vertical: screenWidth * 0.05,
// //         ),
// //         child: Container(
// //           margin: EdgeInsets.symmetric(
// //             horizontal: screenWidth * 0.05,
// //           ),
// //           // decoration: BoxDecoration(
// //           //   color: AllColor.primaryColor,
// //           //   borderRadius: BorderRadius.circular(15),
// //           //   boxShadow: [
// //           //     BoxShadow(
// //           //       color: Colors.grey.withOpacity(0.5),
// //           //       spreadRadius: 5,
// //           //       blurRadius: 7,
// //           //       offset: Offset(0, 3), // changes position of shadow
// //           //     ),
// //           //   ],
// //           // ),
// //           child: Container(
// //             margin: EdgeInsets.symmetric(
// //               horizontal: screenWidth * 0.03,
// //               vertical: screenWidth >= 600
// //                   ? screenWidth * 0.02
// //                   : screenWidth > 450
// //                       ? screenWidth * 0.02
// //                       : screenWidth * 0.02,
// //             ),
// //             child: Column(
// //               mainAxisAlignment: MainAxisAlignment.center,
// //               crossAxisAlignment: CrossAxisAlignment.center,
// //               mainAxisSize: MainAxisSize.min,
// //               children: [
// //                 Container(
// //                   width: screenWidth >= 600
// //                       ? screenWidth * 0.18
// //                       : screenWidth > 450
// //                           ? screenWidth * 0.2
// //                           : screenWidth * 0.22,
// //                   height: screenWidth >= 600
// //                       ? screenWidth * 0.18
// //                       : screenWidth > 450
// //                           ? screenWidth * 0.2
// //                           : screenWidth * 0.22,
// //                   decoration: BoxDecoration(
// //                       color: AllColor.white,
// //                       borderRadius: BorderRadius.circular(10),
// //                       border: Border.all(width: 2, color: AllColor.black)),
// //                   child: Center(
// //                     child: ClipRRect(
// //                       borderRadius: BorderRadius.circular(10),
// //                       child: sharedPreferences!
// //                                   .getString(AllSharedPreferencesKey.image)!
// //                                   .isEmpty ||
// //                               sharedPreferences!.getString(
// //                                       AllSharedPreferencesKey.image)! ==
// //                                   "null"
// //                           ? Icon(Icons.person, color: AllColor.primaryColor)
// //                           : CachedNetworkImage(
// //                               width: screenWidth >= 600
// //                                   ? screenWidth * 0.16
// //                                   : screenWidth > 450
// //                                       ? screenWidth * 0.18
// //                                       : screenWidth * 0.2,
// //                               height: screenWidth >= 600
// //                                   ? screenWidth * 0.16
// //                                   : screenWidth > 450
// //                                       ? screenWidth * 0.18
// //                                       : screenWidth * 0.2,
// //                               fit: BoxFit.cover,
// //                               placeholder: (_, __) {
// //                                 return Center(
// //                                   child: CircularProgressIndicator(),
// //                                 );
// //                               },
// //                               errorWidget: (_, __, ___) {
// //                                 return Center(
// //                                   child: Image.asset("assets/images/logo.png"),
// //                                 );
// //                               },
// //                               imageUrl: sharedPreferences!
// //                                   .getString(AllSharedPreferencesKey.image)!),
// //                     ),
// //                   ),
// //                 ),
// //                 Container(
// //                   margin: EdgeInsets.only(
// //                       left: screenWidth * 0.05, top: screenWidth * 0.03),
// //                   width: screenWidth,
// //                   child: Column(
// //                     mainAxisAlignment: MainAxisAlignment.center,
// //                     crossAxisAlignment: CrossAxisAlignment.center,
// //                     children: [
// //                       Text(
// //                         sharedPreferences!
// //                             .getString(AllSharedPreferencesKey.companyName)!,
// //                         textAlign: TextAlign.center,
// //                         style: TextStyle(
// //                             fontSize: screenWidth >= 600
// //                                 ? screenWidth * 0.042
// //                                 : screenWidth * 0.055,
// //                             letterSpacing: 1.5,
// //                             color: AllColor.white,
// //                             fontWeight: FontWeight.bold),
// //                       ),
// //                       normalText(
// //                           sharedPreferences!.getString(
// //                               AllSharedPreferencesKey.companyContactNo)!,
// //                           color: AllColor.white),
// //                       normalText(
// //                           "${sharedPreferences!.getString(AllSharedPreferencesKey.companyEmailId)!}",
// //                           color: AllColor.white),
// //                     ],
// //                   ),
// //                 )
// //               ],
// //             ),
// //             // child: Column(
// //             //   mainAxisAlignment: MainAxisAlignment.center,
// //             //   crossAxisAlignment: CrossAxisAlignment.center,
// //             //   mainAxisSize: MainAxisSize.min,
// //             //   children: [
// //             //     Container(
// //             //         child: Row(
// //             //       mainAxisAlignment: MainAxisAlignment.start,
// //             //       crossAxisAlignment: CrossAxisAlignment.start,
// //             //       children: [
// //             //         Container(
// //             //           width: screenWidth >= 600
// //             //               ? screenWidth * 0.18
// //             //               : screenWidth > 450
// //             //                   ? screenWidth * 0.2
// //             //                   : screenWidth * 0.22,
// //             //           height: screenWidth >= 600
// //             //               ? screenWidth * 0.18
// //             //               : screenWidth > 450
// //             //                   ? screenWidth * 0.2
// //             //                   : screenWidth * 0.22,
// //             //           decoration: BoxDecoration(
// //             //               color: AllColor.white,
// //             //               borderRadius: BorderRadius.circular(1000),
// //             //               border: Border.all(width: 2, color: AllColor.black)),
// //             //           child: Center(
// //             //             child: ClipRRect(
// //             //               borderRadius: BorderRadius.circular(1000),
// //             //               child: CachedNetworkImage(
// //             //                   width: screenWidth >= 600
// //             //                       ? screenWidth * 0.16
// //             //                       : screenWidth > 450
// //             //                           ? screenWidth * 0.18
// //             //                           : screenWidth * 0.2,
// //             //                   height: screenWidth >= 600
// //             //                       ? screenWidth * 0.16
// //             //                       : screenWidth > 450
// //             //                           ? screenWidth * 0.18
// //             //                           : screenWidth * 0.2,
// //             //                   fit: BoxFit.cover,
// //             //                   placeholder: (_, __) {
// //             //                     return Center(
// //             //                       child: CircularProgressIndicator(),
// //             //                     );
// //             //                   },
// //             //                   errorWidget: (_, __, ___) {
// //             //                     return Center(
// //             //                       child: Image.asset("assets/images/logo.png"),
// //             //                     );
// //             //                   },
// //             //                   imageUrl: sharedPreferences!.getString(
// //             //                       AllSharedPreferencesKey.userImage)!),
// //             //             ),
// //             //           ),
// //             //         ),
// //             //         Container(
// //             //           margin: EdgeInsets.only(left: screenWidth * 0.05),
// //             //           height: screenWidth * 0.18,
// //             //           child: Column(
// //             //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //             //             crossAxisAlignment: CrossAxisAlignment.start,
// //             //             mainAxisSize: MainAxisSize.min,
// //             //             children: [
// //             //               headingText(
// //             //                   sharedPreferences!
// //             //                       .getString(AllSharedPreferencesKey.name)!,
// //             //                   color: AllColor.black),
// //             //               midNormalText(
// //             //                   sharedPreferences!
// //             //                       .getString(AllSharedPreferencesKey.code)!,
// //             //                   color: AllColor.black),
// //             //               midNormalText(
// //             //                   "Designation: ${sharedPreferences!.getString(AllSharedPreferencesKey.designation)!}",
// //             //                   color: AllColor.black),
// //             //             ],
// //             //           ),
// //             //         )
// //             //       ],
// //             //     )),
// //             //     SizedBox(
// //             //       height: screenWidth * 0.02,
// //             //     ),
// //             //     Container(
// //             //       width: screenWidth,
// //             //       margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
// //             //       child: Column(
// //             //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //             //         crossAxisAlignment: CrossAxisAlignment.start,
// //             //         children: [
// //             //           midNormalText(
// //             //               "Department:  ${sharedPreferences!.getString(AllSharedPreferencesKey.department)!}",
// //             //               color: AllColor.black),
// //             //           midNormalText(
// //             //               "Grade: ${sharedPreferences!.getString(AllSharedPreferencesKey.grade)!}",
// //             //               color: AllColor.black),
// //             //           midNormalText(
// //             //               "Date Of Joining: ${convertStringToDate(DateTime.now())}",
// //             //               color: AllColor.black),
// //             //         ],
// //             //       ),
// //             //     )
// //             //   ],
// //             // ),
// //           ),
// //         ),
// //       ),
// //     );
// //     // return GestureDetector(
// //     //   onTap: () {
// //     //     Navigator.of(context)
// //     //         .push(CupertinoPageRoute(builder: (context) => Profile()));
// //     //   },
// //     //   child: Container(
// //     //     width: screenWidth,
// //     //     // height: screenWidth * 0.37,
// //     //     height: screenHeight / 3,
// //     //     alignment: Alignment.center,
// //     //     margin: EdgeInsets.symmetric(
// //     //       vertical: screenWidth * 0.05,
// //     //     ),
// //     //     child: Container(
// //     //       margin: EdgeInsets.symmetric(
// //     //         horizontal: screenWidth * 0.05,
// //     //       ),
// //     //       // decoration: BoxDecoration(
// //     //       //   color: AllColor.primaryColor,
// //     //       //   borderRadius: BorderRadius.circular(15),
// //     //       //   boxShadow: [
// //     //       //     BoxShadow(
// //     //       //       color: Colors.grey.withOpacity(0.5),
// //     //       //       spreadRadius: 5,
// //     //       //       blurRadius: 7,
// //     //       //       offset: Offset(0, 3), // changes position of shadow
// //     //       //     ),
// //     //       //   ],
// //     //       // ),
// //     //       child: Container(
// //     //         margin: EdgeInsets.symmetric(
// //     //           horizontal: screenWidth * 0.03,
// //     //           vertical: screenWidth >= 600
// //     //               ? screenWidth * 0.02
// //     //               : screenWidth > 450
// //     //                   ? screenWidth * 0.02
// //     //                   : screenWidth * 0.02,
// //     //         ),
// //     //         child: Column(
// //     //           mainAxisAlignment: MainAxisAlignment.center,
// //     //           crossAxisAlignment: CrossAxisAlignment.center,
// //     //           mainAxisSize: MainAxisSize.min,
// //     //           children: [
// //     //             Container(
// //     //                 child: Row(
// //     //               mainAxisAlignment: MainAxisAlignment.start,
// //     //               crossAxisAlignment: CrossAxisAlignment.start,
// //     //               children: [
// //     //                 Container(
// //     //                   width: screenWidth >= 600
// //     //                       ? screenWidth * 0.18
// //     //                       : screenWidth > 450
// //     //                           ? screenWidth * 0.2
// //     //                           : screenWidth * 0.22,
// //     //                   height: screenWidth >= 600
// //     //                       ? screenWidth * 0.18
// //     //                       : screenWidth > 450
// //     //                           ? screenWidth * 0.2
// //     //                           : screenWidth * 0.22,
// //     //                   decoration: BoxDecoration(
// //     //                       color: AllColor.white,
// //     //                       borderRadius: BorderRadius.circular(1000),
// //     //                       border: Border.all(width: 2, color: AllColor.black)),
// //     //                   child: Center(
// //     //                     child: ClipRRect(
// //     //                       borderRadius: BorderRadius.circular(1000),
// //     //                       child: CachedNetworkImage(
// //     //                           width: screenWidth >= 600
// //     //                               ? screenWidth * 0.16
// //     //                               : screenWidth > 450
// //     //                                   ? screenWidth * 0.18
// //     //                                   : screenWidth * 0.2,
// //     //                           height: screenWidth >= 600
// //     //                               ? screenWidth * 0.16
// //     //                               : screenWidth > 450
// //     //                                   ? screenWidth * 0.18
// //     //                                   : screenWidth * 0.2,
// //     //                           fit: BoxFit.cover,
// //     //                           placeholder: (_, __) {
// //     //                             return Center(
// //     //                               child: CircularProgressIndicator(),
// //     //                             );
// //     //                           },
// //     //                           errorWidget: (_, __, ___) {
// //     //                             return Center(
// //     //                               child: Image.asset("assets/images/logo.png"),
// //     //                             );
// //     //                           },
// //     //                           imageUrl: sharedPreferences!.getString(
// //     //                               AllSharedPreferencesKey.userImage)!),
// //     //                     ),
// //     //                   ),
// //     //                 ),
// //     //                 Container(
// //     //                   margin: EdgeInsets.only(left: screenWidth * 0.05),
// //     //                   height: screenWidth >= 600
// //     //                       ? screenWidth * 0.18
// //     //                       : screenWidth > 450
// //     //                           ? screenWidth * 0.2
// //     //                           : screenWidth * 0.22,
// //     //                   child: Column(
// //     //                     mainAxisAlignment: MainAxisAlignment.center,
// //     //                     crossAxisAlignment: CrossAxisAlignment.start,
// //     //                     mainAxisSize: MainAxisSize.min,
// //     //                     children: [
// //     //                       headingText(
// //     //                           sharedPreferences!
// //     //                               .getString(AllSharedPreferencesKey.name)!,
// //     //                           color: AllColor.white),
// //     //                       midNormalText(
// //     //                           sharedPreferences!
// //     //                               .getString(AllSharedPreferencesKey.code)!,
// //     //                           color: AllColor.white),
// //     //                       midNormalText(
// //     //                           "Designation: ${sharedPreferences!.getString(AllSharedPreferencesKey.designation)!}",
// //     //                           color: AllColor.white),
// //     //                     ],
// //     //                   ),
// //     //                 )
// //     //               ],
// //     //             )),
// //     //             SizedBox(
// //     //               height: screenWidth * 0.02,
// //     //             ),
// //     //           ],
// //     //         ),
// //     //         // child: Column(
// //     //         //   mainAxisAlignment: MainAxisAlignment.center,
// //     //         //   crossAxisAlignment: CrossAxisAlignment.center,
// //     //         //   mainAxisSize: MainAxisSize.min,
// //     //         //   children: [
// //     //         //     Container(
// //     //         //         child: Row(
// //     //         //       mainAxisAlignment: MainAxisAlignment.start,
// //     //         //       crossAxisAlignment: CrossAxisAlignment.start,
// //     //         //       children: [
// //     //         //         Container(
// //     //         //           width: screenWidth >= 600
// //     //         //               ? screenWidth * 0.18
// //     //         //               : screenWidth > 450
// //     //         //                   ? screenWidth * 0.2
// //     //         //                   : screenWidth * 0.22,
// //     //         //           height: screenWidth >= 600
// //     //         //               ? screenWidth * 0.18
// //     //         //               : screenWidth > 450
// //     //         //                   ? screenWidth * 0.2
// //     //         //                   : screenWidth * 0.22,
// //     //         //           decoration: BoxDecoration(
// //     //         //               color: AllColor.white,
// //     //         //               borderRadius: BorderRadius.circular(1000),
// //     //         //               border: Border.all(width: 2, color: AllColor.black)),
// //     //         //           child: Center(
// //     //         //             child: ClipRRect(
// //     //         //               borderRadius: BorderRadius.circular(1000),
// //     //         //               child: CachedNetworkImage(
// //     //         //                   width: screenWidth >= 600
// //     //         //                       ? screenWidth * 0.16
// //     //         //                       : screenWidth > 450
// //     //         //                           ? screenWidth * 0.18
// //     //         //                           : screenWidth * 0.2,
// //     //         //                   height: screenWidth >= 600
// //     //         //                       ? screenWidth * 0.16
// //     //         //                       : screenWidth > 450
// //     //         //                           ? screenWidth * 0.18
// //     //         //                           : screenWidth * 0.2,
// //     //         //                   fit: BoxFit.cover,
// //     //         //                   placeholder: (_, __) {
// //     //         //                     return Center(
// //     //         //                       child: CircularProgressIndicator(),
// //     //         //                     );
// //     //         //                   },
// //     //         //                   errorWidget: (_, __, ___) {
// //     //         //                     return Center(
// //     //         //                       child: Image.asset("assets/images/logo.png"),
// //     //         //                     );
// //     //         //                   },
// //     //         //                   imageUrl: sharedPreferences!.getString(
// //     //         //                       AllSharedPreferencesKey.userImage)!),
// //     //         //             ),
// //     //         //           ),
// //     //         //         ),
// //     //         //         Container(
// //     //         //           margin: EdgeInsets.only(left: screenWidth * 0.05),
// //     //         //           height: screenWidth * 0.18,
// //     //         //           child: Column(
// //     //         //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //     //         //             crossAxisAlignment: CrossAxisAlignment.start,
// //     //         //             mainAxisSize: MainAxisSize.min,
// //     //         //             children: [
// //     //         //               headingText(
// //     //         //                   sharedPreferences!
// //     //         //                       .getString(AllSharedPreferencesKey.name)!,
// //     //         //                   color: AllColor.black),
// //     //         //               midNormalText(
// //     //         //                   sharedPreferences!
// //     //         //                       .getString(AllSharedPreferencesKey.code)!,
// //     //         //                   color: AllColor.black),
// //     //         //               midNormalText(
// //     //         //                   "Designation: ${sharedPreferences!.getString(AllSharedPreferencesKey.designation)!}",
// //     //         //                   color: AllColor.black),
// //     //         //             ],
// //     //         //           ),
// //     //         //         )
// //     //         //       ],
// //     //         //     )),
// //     //         //     SizedBox(
// //     //         //       height: screenWidth * 0.02,
// //     //         //     ),
// //     //         //     Container(
// //     //         //       width: screenWidth,
// //     //         //       margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
// //     //         //       child: Column(
// //     //         //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
// //     //         //         crossAxisAlignment: CrossAxisAlignment.start,
// //     //         //         children: [
// //     //         //           midNormalText(
// //     //         //               "Department:  ${sharedPreferences!.getString(AllSharedPreferencesKey.department)!}",
// //     //         //               color: AllColor.black),
// //     //         //           midNormalText(
// //     //         //               "Grade: ${sharedPreferences!.getString(AllSharedPreferencesKey.grade)!}",
// //     //         //               color: AllColor.black),
// //     //         //           midNormalText(
// //     //         //               "Date Of Joining: ${convertStringToDate(DateTime.now())}",
// //     //         //               color: AllColor.black),
// //     //         //         ],
// //     //         //       ),
// //     //         //     )
// //     //         //   ],
// //     //         // ),
// //     //       ),
// //     //     ),
// //     //   ),
// //     // );
// //   }
// // }

// // class CustomShape extends CustomClipper<Path> {
// //   @override
// //   getClip(Size size) {
// //     double height = size.height;
// //     double width = size.width;
// //     var path = Path();
// //     path.lineTo(0, height - 50);
// //     path.quadraticBezierTo(width / 2, height, width, height - 54);
// //     path.lineTo(width, 0);
// //     path.close();

// //     return path;
// //   }

// //   @override
// //   bool shouldReclip(CustomClipper oldClipper) {
// //     return true;
// //   }
// // }

// fetchAndSetAllIdSettingConfig(BuildContext context) async {
//   if (await internetCheck()) {
//     Map data = {
//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
//       "userId": loginUserId,
//       "individualId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
//     };
//     apiPostRequestWithHeader(data, AllUrls.userConfigData, context, loginToken)
//         .then((response) {
//       if (response == null) {
//         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//       } else {
//         Map<String, dynamic> jsonDataForDetails = json.decode(response);
//         log(":jsonDataForDetailsssss " + jsonDataForDetails.toString());
//         if (checkApiResponseSuccessOrNot(jsonDataForDetails)) {
//           if (jsonDataForDetails["data"].isEmpty) {
//             sharedPreferences!.setString(AllSharedPreferencesKey.checkInId, "");
//             sharedPreferences!
//                 .setString(AllSharedPreferencesKey.attendanceStatus, "");
//             sharedPreferences!.setString(AllSharedPreferencesKey.punchInId, "");
//             sharedPreferences!
//                 .setString(AllSharedPreferencesKey.breakPunchId, "");
//           } else {
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.checkInId,
//                 jsonDataForDetails["data"]["checkInId"].toString() == "0"
//                     ? ""
//                     : jsonDataForDetails["data"]["checkInId"].toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.attendanceStatus,
//                 jsonDataForDetails["data"]["attendanceStatus"].toString() == "0"
//                     ? ""
//                     : jsonDataForDetails["data"]["attendanceStatus"]
//                         .toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.punchInId,
//                 jsonDataForDetails["data"]["punchInId"].toString() == "0"
//                     ? ""
//                     : jsonDataForDetails["data"]["punchInId"].toString());
//             sharedPreferences!.setString(
//                 AllSharedPreferencesKey.breakPunchId,
//                 jsonDataForDetails["data"]["breakId"].toString() == "0"
//                     ? ""
//                     : jsonDataForDetails["data"]["breakId"].toString());
//           }

//           AppBuilder.of(context)!.rebuild();
//         } else {
//           commonAlertDialog(context, jsonDataForDetails["status"],
//               jsonDataForDetails["message"]);
//         }
//       }
//     });
//   } else {
//     showOfflineSnakbar(context);
//   }
// }
