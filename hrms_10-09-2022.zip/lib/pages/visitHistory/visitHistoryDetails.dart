import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/fromToDatePickerButton.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class VisitHistoryDetails extends StatefulWidget {
  final List orderList;
  final List paymentList;
  final List expenceDetails;
  final Map<String, dynamic> singleJsonData;
  const VisitHistoryDetails(
      {Key? key,
      required this.orderList,
      required this.expenceDetails,
      required this.paymentList,
      required this.singleJsonData})
      : super(key: key);
  @override
  _VisitHistoryDetailsState createState() => _VisitHistoryDetailsState();
}

class _VisitHistoryDetailsState extends State<VisitHistoryDetails> {
  bool loading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, AllString.visitDetails ),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                        decoration:customBackgroundGradient(),

            child: ListView(
              physics: BouncingScrollPhysics(),
              children: [
                Container(
                  decoration: BoxDecoration(
                      border:
                          Border(bottom: BorderSide(color: AllColor.black))),
                  padding: EdgeInsets.all(1),
                  margin: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.03,
                      vertical: screenWidth * 0.01),
                  child: Container(
                    decoration: BoxDecoration(
                        color: AllColor.white,
                        borderRadius: BorderRadius.circular(10)),
                    width: screenWidth,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Visitor Name",
                                value: widget.singleJsonData["visitTypeName"]
                                    .toString()),
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Visitor Type",
                                value: widget.singleJsonData["visitType"]
                                            .toString() ==
                                        "1"
                                    ? "Dealer"
                                    : widget.singleJsonData["visitType"]
                                                .toString() ==
                                            "2"
                                        ? "Office"
                                        : "Other"),
                          checkForExpenseAndVisitPurpose?  customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: AllString.purposeOfVisit,
                                value: showValidValue(widget.singleJsonData["visitingPurpose"]
                                            .toString()  )):Container(),
                            // customRowDetails(
                            //     width: screenWidth * 0.9,
                            //     widthTitle: screenWidth * 0.23,
                            //     title: "Remarks",
                            //     value: widget.remarks),
                            Container(
                              width: screenWidth - (screenWidth * 0.1),
                              alignment: Alignment.center,
                              child: Text(
                                "Visit In Details",
                                style: TextStyle(
                                    fontSize: screenWidth * 0.042,
                                    color: AllColor.greyColor,
                                    decoration: TextDecoration.underline,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Time",
                                value: checkApiValueValid(widget
                                        .singleJsonData["checkInTime"]
                                        .toString())
                                    ? AllString.na
                                    : fullTimeFormatter.format(DateTime.parse(
                                            widget.singleJsonData["checkInTime"]
                                                .toString())
                                        .toLocal())),
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Location",
                                value: widget.singleJsonData["checkInLocation"]
                                    .toString()),
                            Container(
                              width: screenWidth - (screenWidth * 0.1),
                              alignment: Alignment.center,
                              child: Text(
                                "Visit Out Details",
                                style: TextStyle(
                                    fontSize: screenWidth * 0.042,
                                    color: AllColor.greyColor,
                                    decoration: TextDecoration.underline,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Time",
                                value: checkApiValueValid(widget
                                        .singleJsonData["checkOutTime"]
                                        .toString())
                                    ? AllString.na
                                    : fullTimeFormatter.format(DateTime.parse(
                                            widget
                                                .singleJsonData["checkOutTime"]
                                                .toString())
                                        .toLocal())),
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Location",
                                value: widget.singleJsonData["checkOutLocation"]
                                    .toString()),
                            customRowDetails(
                                width: screenWidth * 0.9,
                                widthTitle: screenWidth * 0.28,
                                title: "Comment",
                                value: widget.singleJsonData["comment"]
                                    .toString()),
                            widget.paymentList.isEmpty
                                ? Container()
                                : Container(
                                    width: screenWidth - (screenWidth * 0.1),
                                    alignment: Alignment.center,
                                    child: Text(
                                      "Payment Details",
                                      style: TextStyle(
                                          fontSize: screenWidth * 0.042,
                                          color: AllColor.greyColor,
                                          decoration: TextDecoration.underline,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),

                            widget.paymentList.isEmpty
                                ? Container()
                                : customRowDetails(
                                    width: screenWidth * 0.9,
                                    widthTitle: screenWidth * 0.28,
                                    title: "Amount",
                                    value: widget.paymentList[0]
                                            ["paymentAmount"]
                                        .toString()),
                            widget.paymentList.isEmpty
                                ? Container()
                                : customRowDetails(
                                    width: screenWidth * 0.9,
                                    widthTitle: screenWidth * 0.28,
                                    title: "Remark",
                                    value: widget.paymentList[0]["remarks"]
                                        .toString()),
                            widget.paymentList.isEmpty
                                ? Container()
                                : widget.paymentList[0]["document"]
                                            .toString()
                                            .isEmpty ||
                                        widget.paymentList[0]["document"]
                                                .toString() ==
                                            "null"
                                    ? Container()
                                    : GestureDetector(
                                        onTap: () {
                                          Navigator.of(context).push(
                                              CupertinoPageRoute(
                                                  builder: (context) {
                                            return NetworkImageView(
                                              url: widget.paymentList[0]
                                                      ["document"]
                                                  .toString(),
                                            );
                                          }));
                                        },
                                        child: Center(
                                          child: Container(
                                            margin: customVertical(),
                                            width: screenWidth * 0.3,
                                            height: screenWidth * 0.3,
                                            decoration: BoxDecoration(
                                                color: AllColor.white,
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                border: Border.all(
                                                    width: 2,
                                                    color: AllColor.black)),
                                            child: Center(
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                child: CachedNetworkImage(
                                                    width: screenWidth * 0.3,
                                                    height: screenWidth * 0.3,
                                                    fit: BoxFit.cover,
                                                    placeholder: (_, __) {
                                                      return Center(
                                                        child:
                                                            CircularProgressIndicator(),
                                                      );
                                                    },
                                                    errorWidget:
                                                        (_, __, ___) {
                                                      return Center(
                                                        child: Image.asset(
                                                            "assets/images/appLogo.png"),
                                                      );
                                                    },
                                                imageUrl: widget
                                                    .paymentList[0]
                                                        ["document"]
                                                        .toString()),
                                                // child: Image.memory(
                                                //     Base64Decoder().convert(
                                                //         base64.normalize(widget
                                                //             .paymentList[0]
                                                //                 ["document"]
                                                //             .toString()))),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                            widget.expenceDetails.isEmpty
                                ? Container()
                                : Container(
                                    width: screenWidth - (screenWidth * 0.1),
                                    alignment: Alignment.center,
                                    child: Text(
                                      "Conveyance Details",
                                      style: TextStyle(
                                          fontSize: screenWidth * 0.042,
                                          color: AllColor.greyColor,
                                          decoration: TextDecoration.underline,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                            widget.expenceDetails.isEmpty
                                ? Container()
                                : customRowDetails(
                                    width: screenWidth * 0.9,
                                    widthTitle: screenWidth * 0.28,
                                    title: "Amount",
                                    value: widget.expenceDetails[0]
                                            ["claimAmount"]
                                        .toString()),
                            widget.expenceDetails.isEmpty
                                ? Container()
                                : customRowDetails(
                                    width: screenWidth * 0.9,
                                    widthTitle: screenWidth * 0.28,
                                    title: "Remark",
                                    value: widget.expenceDetails[0]
                                            ["claimComment"]
                                        .toString()),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  width: screenWidth / 2.5,
                                  child: widget.singleJsonData[
                                                  "supportingImage1"]
                                              .toString()
                                              .isEmpty ||
                                          widget.singleJsonData[
                                                      "supportingImage1"]
                                                  .toString() ==
                                              "null"
                                      ? Container()
                                      : GestureDetector(
                                          onTap: () {
                                            Navigator.of(context).push(
                                                CupertinoPageRoute(
                                                    builder: (context) {
                                              return NetworkImageView(
                                                url: widget.singleJsonData[
                                                        "supportingImage1"]
                                                    .toString(),
                                              );
                                            }));
                                          },
                                          child: Center(
                                            child: Container(
                                              margin: customVertical(),
                                              width: screenWidth * 0.3,
                                              height: screenWidth * 0.3,
                                              decoration: BoxDecoration(
                                                  color: AllColor.white,
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  border: Border.all(
                                                      width: 2,
                                                      color: AllColor.black)),
                                              child: Center(
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  child: CachedNetworkImage(
                                                      width: screenWidth * 0.3,
                                                      height: screenWidth * 0.3,
                                                      fit: BoxFit.cover,
                                                      placeholder: (_, __) {
                                                        return Center(
                                                          child:
                                                              CircularProgressIndicator(),
                                                        );
                                                      },
                                                      errorWidget:
                                                          (_, __, ___) {
                                                        return Center(
                                                          child: Image.asset(
                                                              "assets/images/appLogo.png"),
                                                        );
                                                      },
                                                  imageUrl: widget
                                                      .singleJsonData[
                                                          "supportingImage1"]
                                                      .toString()),
                                                  // child: Image.memory(
                                                  //     Base64Decoder().convert(
                                                  //         base64.normalize(widget
                                                  //             .singleJsonData[
                                                  //                 "supportingImage1"]
                                                  //             .toString()))),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                ),
                                Container(
                                  width: screenWidth / 2.5,
                                  child: widget.singleJsonData[
                                                  "supportingImage2"]
                                              .toString()
                                              .isEmpty ||
                                          widget.singleJsonData[
                                                      "supportingImage2"]
                                                  .toString() ==
                                              "null"
                                      ? Container()
                                      : GestureDetector(
                                          onTap: () {
                                            Navigator.of(context).push(
                                                CupertinoPageRoute(
                                                    builder: (context) {
                                              return NetworkImageView(
                                                url: widget.singleJsonData[
                                                        "supportingImage2"]
                                                    .toString(),
                                              );
                                            }));
                                          },
                                          child: Center(
                                            child: Container(
                                              margin: customVertical(),
                                              width: screenWidth * 0.3,
                                              height: screenWidth * 0.3,
                                              decoration: BoxDecoration(
                                                  color: AllColor.white,
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  border: Border.all(
                                                      width: 2,
                                                      color: AllColor.black)),
                                              child: Center(
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  child: CachedNetworkImage(
                                                      width: screenWidth * 0.3,
                                                      height: screenWidth * 0.3,
                                                      fit: BoxFit.cover,
                                                      placeholder: (_, __) {
                                                        return Center(
                                                          child:
                                                              CircularProgressIndicator(),
                                                        );
                                                      },
                                                      errorWidget:
                                                          (_, __, ___) {
                                                        return Center(
                                                          child: Image.asset(
                                                              "assets/images/appLogo.png"),
                                                        );
                                                      },
                                                      imageUrl: widget
                                                          .singleJsonData[
                                                              "supportingImage2"]
                                                          .toString()),
                                                  // child: Image.memory(
                                                  //   Base64Decoder().convert(
                                                  //       base64.normalize(widget
                                                  //           .singleJsonData[
                                                  //               "supportingImage2"]
                                                  //           .toString()
                                                  //           .trim())),
                                                  // ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  child: widget.orderList.isEmpty
                      ? commonNoDataFound()
                      : ListView.builder(
                          shrinkWrap: true,
                          padding: EdgeInsets.only(bottom: screenWidth * 0.08),
                          physics: BouncingScrollPhysics(),
                          itemCount: widget.orderList.length,
                          itemBuilder: (context, index) =>
                              customListItem(widget.orderList[index], index)),
                ),
              ],
            ),
          ),
        ));
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
        padding: customHorizontal(),
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                // customRowDetails(
                //     width: screenWidth * 0.8,
                //     widthTitle: screenWidth * 0.28,

                //     title: "Order Id",
                //     value: itemData["orderId"].toString()),
                customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.28,
                    title: "Pro. Category",
                    value: itemData["productCategoryName"].toString()),
                customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.28,
                    title: "Pro. Name",
                    value: itemData["modelNo"].toString()),
                customRowDetails(
                    width: screenWidth * 0.8,
                    widthTitle: screenWidth * 0.28,
                    title: "Quantity",
                    value: itemData["quantity"].toString()),
                // customRowDetails(
                //     width: screenWidth * 0.8,
                //     widthTitle: screenWidth * 0.28,
                //     title: "Remark",
                //     value: checkApiValueValid(itemData["remarks"].toString())
                //         ? AllString.na
                //         : itemData["remarks"].toString()),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
