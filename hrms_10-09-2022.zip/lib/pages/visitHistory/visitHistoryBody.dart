import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/order/applyOrder.dart';
import 'package:hr/pages/order/orderDetails.dart';
import 'package:hr/pages/visitHistory/visitHistoryDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/calendarCard.dart';
import 'package:hr/widget/customCatender.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/listDetailsClickedArrow.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class VisitHistoryBody extends StatefulWidget {
  @override
  _VisitHistoryBodyState createState() => _VisitHistoryBodyState();
}

class _VisitHistoryBodyState extends State<VisitHistoryBody> {
  bool loading = false;
  List _visitHistoryList = [];
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    fetchVisitHistory();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: customBackgroundGradient(),
        child: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(top: screenWidth * 0.13),
              child: _visitHistoryList.isEmpty
                  ? commonNoDataFound()
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                      physics: BouncingScrollPhysics(),
                      itemCount: _visitHistoryList.length,
                      itemBuilder: (context, index) =>
                          customListItem(_visitHistoryList[index], index)),
            ),
            Positioned(
                top: screenWidth * 0.01,
                right: screenWidth * 0.05,
                left: screenWidth * 0.05,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      child: normalText(AllString.selectDate + ": ",
                          color: AllColor.black),
                    ),
                    datePickerButton(
                        context, _selectedDate, Icons.calendar_today, () {
                      selectDate(context, _selectedDate).then((value) {
                        _selectedDate = value;
                        setState(() {});
                        log(_selectedDate.toString());
                        fetchVisitHistory();
                      });
                    }),
                  ],
                )),
          ],
        ),
      ),
    );
  }

  customListItem(Map<String, dynamic> itemData, int index) {
    List orderList = [];
    if (itemData["orderDetails"] == "") {
      orderList = [];
    } else {
      orderList = itemData["orderDetails"];
    }
    List paymentList = [];
    if (itemData["paymentDetails"] == "") {
      paymentList = [];
    } else {
      paymentList = itemData["paymentDetails"];
    }
    List expenceDetails = [];
    if (itemData["expenceDetails"] == "") {
      expenceDetails = [];
    } else {
      expenceDetails = itemData["expenceDetails"];
    }
    // String _orderId = "";
    // _productList.forEach((element) {
    //   _orderId += element["orderId"].toString();
    //   if (_productList.last["orderId"] != element["orderId"]) _orderId += " / ";
    // });
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => VisitHistoryDetails(
                  orderList: orderList,
                  paymentList: paymentList,
                  expenceDetails: expenceDetails,
                  singleJsonData: itemData,
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              calendarCard(
                  screenWidth * 0.23,
                  screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
                  screenWidth * 0.18,
                  DateTime.parse(itemData["createdDate"]).toLocal()),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // customRowDetails(
                  //     width: screenWidth * 0.65,
                  //     widthTitle: screenWidth * 0.23,
                  //     title: "OrderNo",
                  //     value: itemData["orderNo"]),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Visitor Name",
                      value: itemData["visitTypeName"].toString()),
                  customRowDetails(
                      width: screenWidth * 0.65,
                      widthTitle: screenWidth * 0.23,
                      title: "Visitor Type",
                      value: itemData["visitType"].toString() == "1"
                          ? "Dealer"
                          : itemData["visitType"].toString() == "2"
                              ? "Office"
                              : "Other"),
                  //          customRowDetails(
                  // width: screenWidth * 0.65,
                  // widthTitle: screenWidth * 0.23,
                  // title: "Comment",
                  // value: itemData["comment"].toString()),
                ],
              ),
              listDetailsClickedArrow()
            ],
          ),
        ),
      ),
    );
  }

  fetchVisitHistory() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "dealerId": "",
        "individualName": "",
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId)!,
        "fromDate": formatterForRequest.format(_selectedDate).toString(),
        "toDate": formatterForRequest.format(_selectedDate).toString(),
        "userId": loginUserId,
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
      };
      apiPostRequestWithHeader(
              data, AllUrls.getVisitDetails, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          if (checkApiResponseSuccessOrNot(jsonData)) {
            _visitHistoryList.clear();

            // List  _orderListTemp = jsonData["visitData"];
            //   _orderList =_orderListTemp.reversed.toList();
            if (jsonData["visitData"] == "") {
              _visitHistoryList = [];
            } else {
              _visitHistoryList = jsonData["visitData"];
            }
            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }
  }
}



























































// import 'dart:convert';
// import 'dart:developer';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/leaveBalance/applyLeave.dart';
// import 'package:hr/pages/leaveBalance/leave.dart';
// import 'package:hr/pages/myExpense/applyExpense.dart';
// import 'package:hr/pages/myExpense/myExpenseDetails.dart';
// import 'package:hr/pages/myLoan/applyLoan.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/widget/customCatender.dart';
// import 'package:hr/widget/customRowDetails.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/dashboard/dashboard.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allString.dart';

// class MyExpenseBody extends StatefulWidget {
//   @override
//   _MyExpenseBodyState createState() => _MyExpenseBodyState();
// }

// class _MyExpenseBodyState extends State<MyExpenseBody> {
//   bool loading = false;
//   List _myExpenseList = [];
//   @override
//   void initState() {
//     super.initState();
//     fetchExpense();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return LoadingOverlay(
//       isLoading: loading,
//       opacity: 0.1,
//       color: AllColor.primaryColor,
//       progressIndicator: loaderWaveOrange(),
//       child: Container(
//         width: screenWidth,
//         height: screenHeight,
//                                 decoration:customBackgroundGradient(),

//         child: Stack(
//           children: [
//             ListView.builder(
//                 padding: EdgeInsets.only(bottom: screenWidth * 0.03),
//                 physics: BouncingScrollPhysics(),
//                 itemCount: _myExpenseList.length,
//                 itemBuilder: (context, index) =>
//                     customMyLoanItem(_myExpenseList[index], index)),
//             Positioned(
//                 bottom: screenWidth * 0.05,
//                 right: screenWidth * 0.05,
//                 child: FloatingActionButton(
//                   onPressed: () {
//                     Navigator.of(context).push(CupertinoPageRoute(
//                         builder: (context) => ApplyExpense()));
//                   },
//                   child: normalIcon(Icons.add),
//                   backgroundColor: AllColor.primaryDeepColor,
//                 )),
//           ],
//         ),
//       ),
//     );
//   }

//   customMyLoanItem(Map<String, dynamic> itemData, int index) {
//     return GestureDetector(
//       onTap: () {
//         if (itemData["Status"] == "Reimbursment") {
//           Navigator.push(context,
//               CupertinoPageRoute(builder: (context) => MyExpenseDetails()));
//         }
//       },
//       child: Container(
//         padding: EdgeInsets.all(1),
//         decoration: customCardItemGradinet(),
//         height: screenWidth >= 600 ? screenWidth * 0.23 : screenWidth * 0.27,
//         margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
//         child: Container(
//           decoration: BoxDecoration(
//               color: AllColor.white, borderRadius: BorderRadius.circular(10)),
//           width: screenWidth,
//           child: Row(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               customCatender(
//                   screenWidth * 0.23,
//                   screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
//                   screenWidth * 0.18,
//                   index),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Amount",
//                       value: AllString.rs + " " + itemData["ExpenseAmount"]),
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Remark",
//                       value: itemData["ExpenseApplyRemarks"].toString()),
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Status",
//                       value: itemData["Status"]),
//                 ],
//               ),
//               itemData["Status"] == "Reimbursment"
//                   ? Container(
//                       margin: EdgeInsets.only(right: screenWidth * 0.02),
//                       child: normalIcon(Icons.arrow_forward_ios,
//                           color: AllColor.greyColor))
//                   : Container()
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   fetchExpense() async {
//     var jsonData = json.decode(
//         await rootBundle.loadString('assets/json/ExpenseListData.json'));
//     log(jsonData.toString());
//     _myExpenseList = jsonData["ExpenseListData"];
//     setState(() {});
//   }
// }
