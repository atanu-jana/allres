import 'dart:convert';
import 'dart:developer';
import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonAlertDialogWithYesNo.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/workPlan/daily/todaysPlan.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/tabbarWidget.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:loading_overlay/loading_overlay.dart';

BuildContext? dailyContext;
bool _dailyLoader = false;
List _dailyPlan = [];
DateTime _selectedDate = DateTime.now();
List _pendingList = [];

class Daily extends StatefulWidget {
  final Function() callBack;
  final Map meetingSingleData;
  final String teamMember;
  const Daily(
      {Key? key,
      required this.callBack,
      required this.meetingSingleData,
      required this.teamMember})
      : super(key: key);
  @override
  _DailyState createState() => _DailyState();
}

class _DailyState extends State<Daily> {
  String selectProject = AllString.select;
  String selectCollaboration = AllString.select;
  bool addTodaysPlan = false;

  bool showPendingList = false;
  TextEditingController timeStamptextEditingController =
      TextEditingController();
  TextEditingController planTextEditingController = TextEditingController();
  DateTime timeStamp = DateTime.now();
  List _currentWeekPlan = [];
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 300), () {
      _dailyPlan = [];
      _pendingList = [];
      _selectedDate = DateTime.now();
      fetchDailyPlan(
          context,
          widget.meetingSingleData["teamMeetingId"].toString(),
          _selectedDate,
          widget.teamMember);
    });

    fetchWeekPlan();
  }

  @override
  Widget build(BuildContext context) {
    dailyContext = context;
    return WillPopScope(
      onWillPop: () async {
        if (addTodaysPlan) {
          addTodaysPlan = false;
          timeStamp = DateTime.now();
          timeStamptextEditingController.text = convertStringToDate(timeStamp);
          planTextEditingController.clear();
          selectProject = AllString.select;
          setState(() {});
          return false;
        } else if (showPendingList) {
          showPendingList = false;
          setState(() {});
          return false;
        } else {
          Navigator.pop(context);
          return true;
        }
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(
            context,
            // widget.teamMember,
            // sharedPreferences!
            //                               .getString(AllSharedPreferencesKey
            //                                   .individualId)!,
            // (  (sharedPreferences!
            //                               .getString(AllSharedPreferencesKey
            //                                   .individualTypeId)
            //                               .toString() ==
            //                           "16" ||
            //                       sharedPreferences!
            //                               .getString(AllSharedPreferencesKey
            //                                   .individualTypeId)
            //                               .toString() ==
            //                           "17") &&
            //                   (widget.teamMember == "" ||
            //                       widget.teamMember == AllString.select ||
            //                       widget.teamMember
            //                               .split(AllString.splitText)
            //                               .last !=
            //                           sharedPreferences!.getString(
            //                               AllSharedPreferencesKey.individualId))).toString(),
            addTodaysPlan
                ? "Add Daily Plan"
                : showPendingList
                    ? "Pending Collaboration"
                    : "Operation", onBackPress: () {
          if (addTodaysPlan) {
            addTodaysPlan = false;
            timeStamp = DateTime.now();
            timeStamptextEditingController.text =
                convertStringToDate(timeStamp);
            planTextEditingController.clear();
            selectProject = AllString.select;
            setState(() {});
          } else if (showPendingList) {
            showPendingList = false;
            setState(() {});
          } else {
            Navigator.pop(context);
          }
        },
            actions: 
            // widget.teamMember.split(AllString.splitText).last ==
            //             sharedPreferences!
            //                 .getString(AllSharedPreferencesKey.individualId) ||
                    // sharedPreferences!.getString(
                    //         AllSharedPreferencesKey.individualTypeId) ==
                    //     "18"
                    ((sharedPreferences!
                                    .getString(AllSharedPreferencesKey
                                        .individualTypeId)
                                    .toString() ==
                                "16" ||
                            sharedPreferences!
                                    .getString(AllSharedPreferencesKey
                                        .individualTypeId)
                                    .toString() ==
                                "17") &&
                        (widget.teamMember == "" ||
                            widget.teamMember == AllString.select ||
                            widget.teamMember.split(AllString.splitText).last !=
                                sharedPreferences!.getString(
                                    AllSharedPreferencesKey.individualId)))
                ? []
                : [
                    Container(
                      margin: AllMargin.customHorizontalSmall(),
                      child: IconButton(
                          onPressed: () {
                            setState(() {
                              showPendingList = !showPendingList;
                              addTodaysPlan=false;
                            });
                          },
                          icon: Badge(
                              badgeColor: AllColor.deepYellow,
                              badgeContent:
                                  smallText(_pendingList.length.toString()),
                              child: Icon(
                                Icons.pending_rounded,
                              ))),
                    )
                  ]),
        body: LoadingOverlay(
          isLoading: _dailyLoader,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
                                      decoration:customBackgroundGradient(),

              child: Stack(
                children: [
                  showPendingList
                      ? showPendingListView()
                      : Container(
                          width: screenWidth,
                          height: screenHeight,
                          child: ListView(
                            children: [
                              Container(
                                height: screenHeight * 0.62,
                                child: addTodaysPlan
                                    ? addTodaysPlanView()
                                    : Column(
                                        children: [
                                          dateSelectDisplay(),
                                          Container(
                                            height: screenHeight * 0.53,
                                            margin: AllMargin
                                                .customMarginCardItemSameSmall(),
                                            padding: AllMargin
                                                .customMarginCardItemSameSmall(),
                                            decoration: BoxDecoration(
                                                color: AllColor.lightBlack,
                                                borderRadius: BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(10),
                                                    topRight:
                                                        Radius.circular(10),
                                                    bottomLeft:
                                                        Radius.circular(10),
                                                    bottomRight:
                                                        Radius.circular(10))),
                                            child: _dailyPlan.isEmpty
                                                ? commonNoDataFound()
                                                : ListView.builder(
                                                    padding: AllMargin
                                                        .customVertical(),
                                                    physics:
                                                        BouncingScrollPhysics(),
                                                    itemCount:
                                                        _dailyPlan.length,
                                                    itemBuilder: (context,
                                                            index) =>
                                                        DailyTaskView(
                                                          meetingSingleData: widget
                                                              .meetingSingleData,
                                                          index: index,
                                                          itemData:
                                                              _dailyPlan[index],
                                                          teamMember:
                                                              widget.teamMember,
                                                        )),
                                          ),
                                        ],
                                      ),
                              ),
                              // currentWeekDisplay(),
                              // Divider(),

                              // tabbarForStatusViewList(),
                              // tabbarViewBody(),
                              // todaysPlan(),

                              Container(
                                  margin: AllMargin.customVertical(),
                                  child: Divider()),
                              Container(
                                height: screenHeight * 0.21,
                                margin:
                                    AllMargin.customMarginCardItemSameSmall(),
                                padding:
                                    AllMargin.customMarginCardItemSameSmall(),
                                decoration: BoxDecoration(
                                    // color: AllColor.blue,
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(10),
                                        topRight: Radius.circular(10),
                                        bottomLeft: Radius.circular(10),
                                        bottomRight: Radius.circular(10))),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    // Container(
                                    //   width: screenWidth,
                                    //   margin: EdgeInsets.symmetric(
                                    //       horizontal: screenWidth * 0.02,
                                    //       vertical: screenHeight * 0),
                                    //   alignment: Alignment.center,
                                    //   height: screenWidth * 0.15,
                                    //   child: Column(
                                    //     mainAxisAlignment:
                                    //         MainAxisAlignment.center,
                                    //     crossAxisAlignment:
                                    //         CrossAxisAlignment.center,
                                    //     children: [
                                    //       headingText("Week 2",
                                    //           fontWeight: FontWeight.bold,
                                    //           center: true,
                                    //           color: AllColor.white),
                                    //       smallText(
                                    //           convertStringToDate(DateTime.now()),
                                    //           center: true,
                                    //           color: AllColor.greyColor),
                                    //     ],
                                    //   ),
                                    // ),
                                    Container(
                                      height: screenHeight * 0.19,
                                      child: _currentWeekPlan.isEmpty
                                          ? commonNoDataFound(
                                              color: AllColor.black)
                                          : Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  height: screenHeight * 0.02,
                                                  child: Center(
                                                    child: normalText(
                                                        showValidValue(
                                                            _currentWeekPlan
                                                                    .first[
                                                                "weekName"]),
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color: AllColor.black,
                                                        center: true),
                                                  ),
                                                ),
                                                Container(
                                                  height: screenHeight * 0.15,
                                                  child: ListView.builder(
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      padding: AllMargin
                                                          .customMarginCardItemSameSmall(),
                                                      physics:
                                                          BouncingScrollPhysics(),
                                                      itemCount:
                                                          _currentWeekPlan
                                                              .length,
                                                      itemBuilder:
                                                          (context, index) =>
                                                              itemView(
                                                                _currentWeekPlan[
                                                                    index],
                                                                index,
                                                              )),
                                                ),
                                              ],
                                            ),
                                    ),
                                    // Container(
                                    //   height: screenWidth * 1.3,
                                    //   child: ListView.builder(
                                    //       padding:
                                    //           AllMargin.customMarginCardItemSameSmall(),
                                    //       physics: BouncingScrollPhysics(),
                                    //       itemCount: 5,
                                    //       itemBuilder: (context, index) => itemView(
                                    //             {},
                                    //             index,
                                    //           )),
                                    // ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                  showPendingList
                      ? Container()
                      : ((sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "16" ||
                                  sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "17") &&
                              (widget.teamMember == "" ||
                                  widget.teamMember == AllString.select ||
                                  widget.teamMember
                                          .split(AllString.splitText)
                                          .last !=
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey.individualId))
                          // sharedPreferences!.getString(
                          //         AllSharedPreferencesKey
                          //             .individualTypeId) !=
                          //     "18"

                          )
                          ? Container()
                          : Positioned(
                              bottom: screenWidth * 0.05,
                              right: screenWidth * 0.05,
                              child: FloatingActionButton(
                                onPressed: () {
                                  if (addTodaysPlan) {
                                    addTodaysPlan = false;
                                     timeStamp = DateTime.now();
          timeStamptextEditingController.text = convertStringToDate(timeStamp);
          planTextEditingController.clear();
          selectProject = AllString.select;
                                    setState(() {});
                                  } else {
                                    addTodaysPlan = true;
                                     timeStamp = DateTime.now();
          timeStamptextEditingController.text = convertStringToDate(timeStamp);
          planTextEditingController.clear();
          selectProject = AllString.select;
          setState(() {});
                                  }
                                },
                                child: normalIcon(
                                    addTodaysPlan ? Icons.close : Icons.add),
                                backgroundColor: AllColor.primaryDeepColor,
                              )),
                ],
              )),
        ),
      ),
    );
  }

  showPendingListView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
      child: _pendingList.isEmpty
          ? commonNoDataFound()
          : ListView.builder(
              padding: AllMargin.customMarginCardItemSameSmall(),
              physics: BouncingScrollPhysics(),
              itemCount: _pendingList.length,
              itemBuilder: (context, index) =>
                  requestedListItem(_pendingList[index], index)),
    );
  }

  requestedListItem(Map<String, dynamic> itemData, int index) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: AllMargin.customMarginCardItem(),
          // child: Column(
          //   children: [
          //     Container(
          //       width: screenWidth * 0.85,
          //       child: Text(
          //         showValidValue(itemData["planTitle"]),
          //         textAlign: TextAlign.justify,
          //         style: normal2TextStyle(
          //           color: AllColor.black,
          //         ),
          //       ),
          //     ),
          //     Container(
          //       width: screenWidth * 0.85,
          //       child: Text(
          //         showValidValue(itemData["planDesc"]),
          //         textAlign: TextAlign.justify,
          //         style: normal2TextStyle(
          //           color: AllColor.black.withOpacity(0.5),
          //         ),
          //       ),
          //     ),
          //     Container(
          //       width: screenWidth * 0.85,
          //       child: Row(
          //         children: [
          //           Container(
          //             width: screenWidth * 0.28,
          //             child: Text(
          //               "Requested to: ",
          //               textAlign: TextAlign.justify,
          //               style: normal2TextStyle(
          //                 color: AllColor.greyColor,
          //               ),
          //             ),
          //           ),
          //           Container(
          //             width: screenWidth * 0.55,
          //             child: Text(
          //               showValidValue(itemData["collaboration"]),
          //               textAlign: TextAlign.justify,
          //               style: normal2TextStyle(
          //                   color: AllColor.black, fontWeight: FontWeight.bold),
          //             ),
          //           ),
          //         ],
          //       ),
          //     ),
          //     Divider(),
          //     Row(
          //       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          //       crossAxisAlignment: CrossAxisAlignment.center,
          //       children: [
          //         MaterialButton(
          //           height: screenWidth * 0.08,
          //           onPressed: () {
          //           },
          //           color: AllColor.red,
          //           child: normalText(
          //             AllString.delete,
          //             color: AllColor.white,
          //           ),
          //           splashColor: AllColor.red,
          //           shape: RoundedRectangleBorder(
          //               borderRadius: BorderRadius.circular(10000),
          //               side: BorderSide(color: AllColor.red)),
          //         ),
          //       ],
          //     )
          //   ],
          // )),

          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  Container(
                    width: screenWidth * 0.7,
                    child: Text(
                      showValidValue(itemData["planTitle"]),
                      textAlign: TextAlign.justify,
                      style: normal2TextStyle(
                        color: AllColor.black,
                      ),
                    ),
                  ),
                  Container(
                    width: screenWidth * 0.7,
                    child: Text(
                      showValidValue(itemData["planDesc"]),
                      textAlign: TextAlign.justify,
                      style: normal2TextStyle(
                        color: AllColor.black.withOpacity(0.5),
                      ),
                    ),
                  ),
                  Container(
                    width: screenWidth * 0.7,
                    child: Row(
                      children: [
                        Container(
                          width: screenWidth * 0.28,
                          child: Text(
                            "Requested to: ",
                            textAlign: TextAlign.justify,
                            style: normal2TextStyle(
                              color: AllColor.greyColor,
                            ),
                          ),
                        ),
                        Container(
                          width: screenWidth * 0.4,
                          child: Text(
                            showValidValue(itemData["collaboration"]),
                            textAlign: TextAlign.justify,
                            style: normal2TextStyle(
                                color: AllColor.black,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              IconButton(
                  onPressed: () {
                    deletePendingCollaboration(itemData);
                  },
                  icon: Icon(Icons.close, color: AllColor.red))
            ],
          )),
    );
  }

  deletePendingCollaboration(
    Map<String, dynamic> itemData,
  ) {
    setState(() {
      _dailyLoader = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "dailyPlanId": itemData["dailyPlanId"],
    };
    apiPostRequestWithHeader(
            data, AllUrls.deleteCollaboration, this.context, loginToken)
        .then((response) {
      if (response == null) {
        AppBuilder.of(context)!.rebuild();
        _dailyLoader = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]), function: () {
            Navigator.pop(context);
            fetchDailyPlan(
                context,
                widget.meetingSingleData["teamMeetingId"].toString(),
                _selectedDate,
                widget.teamMember);
          });
        } else {
          setState(() {
            _dailyLoader = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchWeekPlan() {
    setState(() {
      _dailyLoader = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.teamMember.split(AllString.splitText).last,
      "projectId": "",
      "createdDate": formatterForRequest.format(_selectedDate).toString(),
    };
    apiPostRequestWithHeader(
            data, AllUrls.getWeekPlanByDate, this.context, loginToken)
        .then((response) {
      if (response == null) {
        _dailyLoader = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _currentWeekPlan.clear();
          if (jsonData["data"].toString() == "") {
            _currentWeekPlan.clear();
          } else {
            _currentWeekPlan = jsonData["data"];
          }
          setState(() {
            _dailyLoader = false;
          });
        } else {
          setState(() {
            _dailyLoader = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  bool validateAndProceed() {
    if (planTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }

  addTodaysPlanView() {
    return ListView(
      physics: BouncingScrollPhysics(),
      children: [
        // textFieldHeader(AllString.dateSelect, fontWeight: FontWeight.bold),
        // Container(
        //     child: RoundedDateField(
        //   controller: timeStamptextEditingController,
        //   hintText: AllString.dateSelect,
        //   icon: Icons.date_range,
        //   onchangeFunction: (String val) {},
        //   suffixIcon: Icons.date_range,
        //   enable: false,
        //   suffixFunction: () {},
        // )),
        textFieldHeader(AllString.selectProject, fontWeight: FontWeight.bold),

        Container(
          child: DropdownButtonWithSearchProject(
            icon: LineIcons.sortAmountDown,
            selectedValue: selectProject,
            dropdownList: projectList,
            onChanged: onProjectChanged,
          ),
        ),
        textFieldHeader("Elaborate", fontWeight: FontWeight.bold),
        Container(
          margin: EdgeInsets.symmetric(
            vertical: screenWidth * 0.0,
            horizontal: screenWidth * 0.03,
          ),
          child: Center(
            child: textAreaField(
              context,
              AllString.typeHere,
              planTextEditingController,
              4,
              200,
              TextInputAction.newline,
              TextInputType.multiline,
            ),
          ),
        ),
        textFieldHeader(AllString.selectCollaborator,
            fontWeight: FontWeight.bold),

        Container(
          child: DropdownButtonWithSearch(
            icon: LineIcons.sortAmountDown,
            selectedValue: selectCollaboration,
            dropdownList: allTeamMemberList,
            onChanged: onCollaborationChanged,
          ),
        ),
        Container(
            margin: EdgeInsets.symmetric(
                vertical: screenWidth * 0.015, horizontal: screenWidth * 0.03),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                    child: button(context, function: () {
                  addTodaysPlan = false;
                  timeStamp = DateTime.now();
                  timeStamptextEditingController.text =
                      convertStringToDate(timeStamp);
                  planTextEditingController.clear();
                  setState(() {});
                },
                              color:AllColor.red,
 
                        textColor: AllColor.white,
                        text: AllString.reset,
                        width: screenWidth * 0.3)),
                Container(
                    child: button(context, function: () {
                  if (validateAndProceed()) {
                    addDailyPlan();
                  }
                },
                      color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                        textColor: AllColor.white,
                        text: AllString.add,
                        width: screenWidth * 0.3))
              ],
            )),
      ],
    );
  }

  addDailyPlan() {
    setState(() {
      _dailyLoader = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
      "projectId": selectProject.split(AllString.splitText).last,
      "collaborationId": selectCollaboration == AllString.select
          ? ""
          : selectCollaboration.split(AllString.splitText).last,
      "planTitle": selectProject.split(AllString.splitText).first,
      "planDesc": planTextEditingController.text,
      "createdDate": formatterForRequest.format(DateTime.now()),
    };
    apiPostRequestWithHeader(
            data, AllUrls.addDailyPlan, this.context, loginToken)
        .then((response) {
      if (response == null) {
        _dailyLoader = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]), function: () {
            // addTodaysPlan = false;
            timeStamp = DateTime.now();
            timeStamptextEditingController.text =
                convertStringToDate(timeStamp);
            planTextEditingController.clear();
            selectProject = AllString.select;
            selectCollaboration = AllString.select;
            setState(() {});
            Navigator.pop(context);
            fetchDailyPlan(
                context,
                widget.meetingSingleData["teamMeetingId"].toString(),
                _selectedDate,
                widget.teamMember);

            setState(() {
              _dailyLoader = false;
            });
          });
        } else {
          setState(() {
            _dailyLoader = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  onProjectChanged(String? value) {
    selectProject = value!;
    setState(() {});
  }

  onCollaborationChanged(String? value) {
    selectCollaboration = value!;
    setState(() {});
  }

  dateSelectDisplay() {
    return Container(
      width: screenWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child:
                normalText(AllString.selectDate + ": ", color: AllColor.black),
          ),
          datePickerButton(context, _selectedDate, Icons.calendar_today, () {
            selectDate(context, _selectedDate).then((value) {
              _selectedDate = value;
              setState(() {});

              fetchDailyPlan(
                  context,
                  widget.meetingSingleData["teamMeetingId"].toString(),
                  _selectedDate,
                  widget.teamMember);
            });
          }),
        ],
      ),
    );
  }

  itemView(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      child: Container(
        width: screenWidth * 0.85,
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: screenWidth * 0.8,
                child: Text(
                  showValidValue(itemData["goalTitle"]),
                  textAlign: TextAlign.justify,
                  style: normal2TextStyle(
                      color: AllColor.black, fontWeight: FontWeight.bold),
                ),
              ),
              Row(
                children: [
                  Container(
                    width: screenWidth * 0.7,
                    child: normal2Text(
                        showValidValue(itemData["goalDescription"]),
                        maxLines: 4,
                        color: AllColor.greyColor),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // tabbarForStatusViewList() {
  //   return Container(
  //     width: screenWidth,
  //     height: screenWidth * 0.15,
  //     margin: AllMargin.customMarginCardItem(),
  //     alignment: Alignment.center,
  //     decoration: BoxDecoration(
  //         color: AllColor.white,
  //         boxShadow: [
  //           BoxShadow(
  //             color: Colors.grey.withOpacity(0.5),
  //             spreadRadius: 5,
  //             blurRadius: 7,
  //             offset: Offset(0, 3), // changes position of shadow
  //           ),
  //         ],
  //         borderRadius: BorderRadius.circular(7)),
  //     child: Row(
  //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       children: [
  //         GestureDetector(
  //           onTap: () {
  //             setState(() {
  //               pendingList = true;
  //             });
  //           },
  //           child: tabbarView(
  //               "Pending", AllColor.deepYellow, pendingList ? true : false),
  //         ),
  //         GestureDetector(
  //           onTap: () {
  //             setState(() {
  //               pendingList = false;
  //             });
  //           },
  //           child: tabbarView(
  //               "Success", AllColor.deepGreen, !pendingList ? true : false),
  //         ),
  //       ],
  //     ),
  //   );
  // }

  // tabbarView(String title, Color color, bool enable) => Container(
  //       width: screenWidth / 2.7,
  //       height: screenWidth * 0.1,
  //       margin: AllMargin.customHorizontal(),
  //       alignment: Alignment.center,
  //       decoration: BoxDecoration(
  //           color: enable ? color : color.withOpacity(0.5),
  //           boxShadow: enable
  //               ? [
  //                   BoxShadow(
  //                     color: Colors.grey.withOpacity(0.5),
  //                     spreadRadius: 5,
  //                     blurRadius: 7,
  //                     offset: Offset(0, 3), // changes position of shadow
  //                   ),
  //                 ]
  //               : [],
  //           borderRadius: BorderRadius.circular(7)),
  //       child: headingText(title,
  //           color: AllColor.white, center: true, fontWeight: FontWeight.w400),
  //     );

  // statusHeader(String title, Color color) => Container(
  //       width: screenWidth  ,
  //       height: screenWidth * 0.1,
  //       margin: AllMargin.customMarginCardItem(),
  //       alignment: Alignment.center,
  //       decoration: BoxDecoration(
  //           color: AllColor.white,
  //           boxShadow: [
  //             BoxShadow(
  //               color: Colors.grey.withOpacity(0.5),
  //               spreadRadius: 5,
  //               blurRadius: 7,
  //               offset: Offset(0, 3), // changes position of shadow
  //             ),
  //           ],
  //           border: Border.all(width: 5, color: color),
  //           borderRadius: BorderRadius.circular(7)),
  //       child: headingText(title,
  //           color: color, center: true, fontWeight: FontWeight.bold),
  //     );
  currentWeekDisplay() {
    return Container(
      width: screenWidth,
      height: screenWidth * 0.2,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: screenWidth,
            height: 1,
            color: AllColor.greyColor,
          ),
          Container(
            width: screenWidth * 0.3,
            height: screenWidth * 0.15,
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: AllColor.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3), // changes position of shadow
                  ),
                ],
                border: Border.all(width: 5, color: AllColor.white),
                borderRadius: BorderRadius.circular(7)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                headingText("Week 1",
                    fontWeight: FontWeight.bold,
                    center: true,
                    color: AllColor.primaryColor),
                smallText(convertStringToDate(DateTime.now()),
                    center: true, color: AllColor.greyColor),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // todaysPlan() {
  //   return GestureDetector(
  //     onTap: () {
  //       Navigator.of(context)
  //           .push(CupertinoPageRoute(builder: (context) => TodaysPlan()));
  //     },
  //     child: Container(
  //       width: screenWidth,
  //       height: screenWidth * 0.1,
  //       margin: AllMargin.customMarginCardItem(),
  //       alignment: Alignment.center,
  //       decoration: BoxDecoration(
  //           color: AllColor.white,
  //           boxShadow: [
  //             BoxShadow(
  //               color: Colors.grey.withOpacity(0.5),
  //               spreadRadius: 5,
  //               blurRadius: 7,
  //               offset: Offset(0, 3), // changes position of shadow
  //             ),
  //           ],
  //           border: Border.all(width: 5, color: AllColor.white),
  //           borderRadius: BorderRadius.circular(7)),
  //       child: Row(
  //         crossAxisAlignment: CrossAxisAlignment.center,
  //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //         children: [
  //           Row(
  //             mainAxisAlignment: MainAxisAlignment.start,
  //             crossAxisAlignment: CrossAxisAlignment.center,
  //             children: [
  //               Container(
  //                 margin: AllMargin.customHorizontalSmall(),
  //                 child: normalIcon(Icons.today_outlined,
  //                     color: AllColor.primaryColor),
  //               ),
  //               Container(
  //                 margin: AllMargin.customHorizontal(),
  //                 child: headingText("Today's Plan",
  //                     color: AllColor.black,
  //                     center: true,
  //                     fontWeight: FontWeight.bold),
  //               ),
  //             ],
  //           ),
  //           Container(
  //             height: screenWidth * 0.1,
  //             width: screenWidth * 0.1,
  //             alignment: Alignment.center,
  //             margin: AllMargin.customHorizontalSmall(),
  //             child:
  //                 Icon(Icons.arrow_circle_right_outlined, color: AllColor.blue),
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }

  // tabbarViewBody() {
  //   return Container(
  //     margin: AllMargin.customMarginCardItem(),
  //     alignment: Alignment.center,
  //     decoration: BoxDecoration(
  //         color: AllColor.white,
  //         boxShadow: [
  //           BoxShadow(
  //             color: Colors.grey.withOpacity(0.5),
  //             spreadRadius: 5,
  //             blurRadius: 7,
  //             offset: Offset(0, 3), // changes position of shadow
  //           ),
  //         ],
  //         borderRadius: BorderRadius.circular(7)),
  //     child: pendingList
  //         ? ListView.builder(
  //             padding: AllMargin.customVertical(),
  //             physics: NeverScrollableScrollPhysics(),
  //             itemCount: 5,
  //             shrinkWrap: true,
  //             itemBuilder: (context, index) => itemView({}, index))
  //         : ListView.builder(
  //             padding: AllMargin.customVertical(),
  //             shrinkWrap: true,
  //             physics: NeverScrollableScrollPhysics(),
  //             itemCount: 5,
  //             itemBuilder: (context, index) => itemView({}, index)),
  //   );
  // }

}

class DailyTaskView extends StatefulWidget {
  final Map meetingSingleData;
  final String teamMember;
  final Map<String, dynamic> itemData;
  final int index;
  const DailyTaskView(
      {Key? key,
      required this.meetingSingleData,
      required this.teamMember,
      required this.index,
      required this.itemData})
      : super(key: key);

  @override
  State<DailyTaskView> createState() => _DailyTaskViewState();
}

class _DailyTaskViewState extends State<DailyTaskView> {
  String statusValue = AllString.select;
  String tempStatusValue = AllString.select;
  @override
  void initState() {
    tempStatusValue = validValue(widget.itemData["statusName"])
        ? widget.itemData["statusName"] +
            AllString.splitText +
            widget.itemData["statusId"].toString()
        : AllString.select;
    statusValue = validValue(widget.itemData["statusName"])
        ? widget.itemData["statusName"] +
            AllString.splitText +
            widget.itemData["statusId"].toString()
        : AllString.select;
    setState(() {});
    super.initState();
  }

  int config = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        padding: AllMargin.customMarginCardItem(),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Container(
                      width: screenWidth * 0.65,
                      child: Text(
                        showValidValue(widget.itemData["planTitle"]),
                        textAlign: TextAlign.justify,
                        style: normal2TextStyle(
                            color: AllColor.black,
                            fontWeight: FontWeight.bold,
                            lineThrough:
                                statusValue.split(AllString.splitText).first ==
                                        "Success"
                                    ? true
                                    : false),
                      ),
                    ),
                    Container(
                      width: screenWidth * 0.65,
                      child: Text(
                        showValidValue(widget.itemData["planDesc"]),
                        textAlign: TextAlign.justify,
                        style: normal2TextStyle(
                            color: AllColor.greyColor,
                            lineThrough:
                                statusValue.split(AllString.splitText).first ==
                                        "Success"
                                    ? true
                                    : false),
                      ),
                    ),
                  ],
                ),
                ((sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .individualTypeId)
                                        .toString() !=
                                    "16" &&
                                sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .individualTypeId)
                                        .toString() !=
                                    "17") ||
                            widget.teamMember.split(AllString.splitText).last ==
                                sharedPreferences!.getString(
                                    AllSharedPreferencesKey.individualId)!
                        // sharedPreferences!
                        //         .getString(AllSharedPreferencesKey
                        //             .individualTypeId)
                        //         .toString() ==
                        //     "18"
                        ) &&
                        formatter.format(_selectedDate) ==
                            formatter.format(DateTime.now())
                    ? Column(
                        children: [
                          // Container(
                          //     width: screenWidth * 0.15,
                          //     alignment: Alignment.center,
                          //     child: GestureDetector(
                          //         onTap: () {
                          //           if (config == 0) {
                          //             commonAlertDialogWithYesNo(
                          //                 context,
                          //                 AllString.areYouSure,
                          //                 "You want to start",
                          //                 yesColor: AllColor.green,
                          //                 noColor: AllColor.red,
                          //                 yesFunction: () {
                          //               config = 1;
                          //               setState(() {});
                          //               Navigator.pop(context);
                          //             });
                          //           } else {
                          //             commonAlertDialogWithYesNo(
                          //                 context,
                          //                 AllString.areYouSure,
                          //                 "You want to end",
                          //                 yesColor: AllColor.red,
                          //                 noColor: AllColor.green,
                          //                 yesFunction: () {
                          //               Navigator.pop(context);
                          //               TextEditingController
                          //                   endCommentTextEditingController =
                          //                   TextEditingController();
                          //               return commonAlertDialogWithCloseButtonWithWidget(
                          //                   context,
                          //                   AllColor.red,
                          //                   Column(
                          //                     children: [
                          //                       Column(
                          //                         children: [
                          //                           textFieldHeader("Comment",
                          //                               fontWeight:
                          //                                   FontWeight.bold),
                          //                           Container(
                          //                             margin:
                          //                                 EdgeInsets.symmetric(
                          //                               vertical:
                          //                                   screenWidth * 0.0,
                          //                               horizontal:
                          //                                   screenWidth * 0.03,
                          //                             ),
                          //                             child: Center(
                          //                               child: textAreaField(
                          //                                 context,
                          //                                 AllString.typeHere,
                          //                                 endCommentTextEditingController,
                          //                                 4,
                          //                                 200,
                          //                                 TextInputAction.done,
                          //                                 TextInputType.text,
                          //                               ),
                          //                             ),
                          //                           ),
                          //                         ],
                          //                       ),
                          //                       Container(
                          //                           margin:
                          //                               EdgeInsets.symmetric(
                          //                             vertical:
                          //                                 screenWidth * 0.015,
                          //                           ),
                          //                           child: Row(
                          //                             mainAxisAlignment:
                          //                                 MainAxisAlignment
                          //                                     .center,
                          //                             crossAxisAlignment:
                          //                                 CrossAxisAlignment
                          //                                     .center,
                          //                             children: [
                          //                               Container(
                          //                                   child: button(context,
                          //                                       function: () {
                          //                                 if (endCommentTextEditingController
                          //                                     .text
                          //                                     .isNotEmpty) {
                          //                                   config = 1;
                          //                                   setState(() {});
                          //                                   Navigator.pop(
                          //                                       context);
                          //                                 }
                          //                               },
                          //                                       color1:
                          //                                           Color.fromARGB(
                          //                                               255,
                          //                                               118,
                          //                                               83,
                          //                                               83),
                          //                                       color2: Color
                          //                                           .fromARGB(
                          //                                               255,
                          //                                               255,
                          //                                               0,
                          //                                               0),
                          //                                       textColor:
                          //                                           AllColor
                          //                                               .white,
                          //                                       text: AllString
                          //                                           .cancel,
                          //                                       width:
                          //                                           screenWidth *
                          //                                               0.25)),
                          //                               Container(
                          //                                   child: button(
                          //                                       context,
                          //                                       function: () {
                          //                                 config = 0;

                          //                                 setState(() {});
                          //                                 Navigator.pop(
                          //                                     context);
                          //                               },
                          //                                       color1: Color(
                          //                                           0xff536976),
                          //                                       color2: Color(
                          //                                           0xff292E49),
                          //                                       textColor:
                          //                                           AllColor
                          //                                               .white,
                          //                                       text: AllString
                          //                                           .add,
                          //                                       width:
                          //                                           screenWidth *
                          //                                               0.25))
                          //                             ],
                          //                           )),
                          //                     ],
                          //                   ), onCloseButtonPress: () {
                          //                 config = 1;
                          //                 setState(() {});
                          //                 Navigator.pop(context);
                          //               });
                          //             });
                          //           }
                          //           setState(() {});
                          //         },
                          //         child: Container(
                          //           width: screenWidth * 0.15,
                          //           decoration: BoxDecoration(
                          //               color: config == 0
                          //                   ? AllColor.white
                          //                   : AllColor.red,
                          //               borderRadius: BorderRadius.circular(10),
                          //               border: Border.all(
                          //                   color: config == 0
                          //                       ? AllColor.green
                          //                       : AllColor.red)),
                          //           padding: AllMargin.customVerticalSmall(),
                          //           child: Container(
                          //             child: smallText(
                          //               config == 0 ? "Start" : "End",
                          //               center: true,
                          //               fontWeight: FontWeight.bold,
                          //               color: config == 0
                          //                   ? AllColor.black
                          //                   : AllColor.white,
                          //             ),
                          //           ),
                          //         ))
                          //     // Container(
                          //     //   child: dropdownButton(status, onDropdownChange, "Success")),
                          //     ),

                          // Container(
                          //     margin: AllMargin.customVerticalSmall(),
                          //     width: screenWidth * 0.15,
                          //     height: 1,
                          //     color: AllColor.lightBlack),
                          Container(
                              width: screenWidth * 0.15,
                              alignment: Alignment.center,
                              child: GestureDetector(
                                  onTap: () {
                                    statusUpdateDialog();
                                  },
                                  child: Container(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Icon(Icons.update_rounded),
                                        Container(
                                          width: screenWidth * 0.15,
                                          alignment: Alignment.center,
                                          child: smallText(
                                              statusValue
                                                  .split(AllString.splitText)
                                                  .first,
                                              fontWeight: FontWeight.bold,
                                              center: true,
                                              color: statusColor(statusValue
                                                  .split(AllString.splitText)
                                                  .first)),
                                        )
                                      ],
                                    ),
                                  ))
                              // Container(
                              //   child: dropdownButton(status, onDropdownChange, "Success")),
                              ),
                        ],
                      )
                    : Container(
                        width: screenWidth * 0.15,
                        alignment: Alignment.center,
                        child: smallText(
                            statusValue.split(AllString.splitText).first,
                            fontWeight: FontWeight.bold,
                            center: true,
                            color: statusColor(
                                statusValue.split(AllString.splitText).first)),
                      ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  onDropdownChange(String? value) {
    statusValue = value!;
    setState(() {});
    AppBuilder.of(context)!.rebuild();
    Navigator.pop(context);
    statusUpdateDialog();
  }

  TextEditingController reasonTextEditingController = TextEditingController();
  statusUpdateDialog() {
    return commonAlertDialogWithCloseButtonWithWidget(
        context,
        AllColor.red,
        Column(
          children: [
            textFieldHeader(AllString.status, fontWeight: FontWeight.bold),
            dropdownButton(status, onDropdownChange, statusValue),
            // if (statusValue.split(AllString.splitText).first == "Failure")
            // Column(
            //   children: [
            //     textFieldHeader("Reason", fontWeight: FontWeight.bold),
            //     Container(
            //       margin: EdgeInsets.symmetric(
            //         vertical: screenWidth * 0.0,
            //         horizontal: screenWidth * 0.03,
            //       ),
            //       child: Center(
            //         child: textAreaField(
            //           context,
            //           AllString.typeHere,
            //           reasonTextEditingController,
            //           4,
            //           200,
            //           TextInputAction.done,
            //           TextInputType.text,
            //         ),
            //       ),
            //     ),
            //   ],
            // ),
            Container(
                margin: EdgeInsets.symmetric(
                  vertical: screenWidth * 0.015,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                        child: button(context, function: () {
                      statusValue = tempStatusValue;
                      AppBuilder.of(context)!.rebuild();
                      Navigator.pop(context);
                    },
                                                 color:AllColor.red,

                            textColor: AllColor.white,
                            text: AllString.cancel,
                            width: screenWidth * 0.25)),
                    Container(
                        child: button(context, function: () {
                      if (validateAndProceed()) {
                        Navigator.pop(context);
                        updateStatus();
                      }
                    },
                     color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                            textColor: AllColor.white,
                            text: AllString.add,
                            width: screenWidth * 0.25))
                  ],
                )),
          ],
        ), onCloseButtonPress: () {
      statusValue = tempStatusValue;
      AppBuilder.of(context)!.rebuild();
      Navigator.pop(context);
    });
  }

  bool validateAndProceed() {
    if (statusValue == AllString.select) {
      return false;
    }
    //  else if (statusValue.split(AllString.splitText).first == "Failure" &&
    //     reasonTextEditingController.text.isEmpty) {
    //   return false;
    // }

    else {
      return true;
    }
  }

  updateStatus() {
    setState(() {
      _dailyLoader = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.teamMember.split(AllString.splitText).last,
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
      "statusId": statusValue.split(AllString.splitText).last,
      "dailyPlanId": widget.itemData["dailyPlanId"],
    };
    apiPostRequestWithHeader(
            data, AllUrls.dailyPlanStatusUpdate, this.context, loginToken)
        .then((response) {
      if (response == null) {
        statusValue = tempStatusValue;
        AppBuilder.of(context)!.rebuild();
        _dailyLoader = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]));
          fetchDailyPlan(
              dailyContext!,
              widget.meetingSingleData["teamMeetingId"].toString(),
              _selectedDate,
              widget.teamMember);
          // setState(() {
          //   _dailyLoader = false;
          // });
        } else {
          statusValue = tempStatusValue;
          AppBuilder.of(context)!.rebuild();
          setState(() {
            _dailyLoader = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}

fetchDailyPlan(BuildContext context, String teamMeetingId,
    DateTime selectedDate, String teamMember) {
  _dailyLoader = true;
  AppBuilder.of(context)!.rebuild();
  Map data = {
    // "companyId": 4,
    // "individualId": 1,
    // "goalScheduleId": 6

    "companyId":
        sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
    "individualId":
        //  sharedPreferences!
        //             .getString(AllSharedPreferencesKey.individualTypeId)
        //             .toString() ==
        //         "18"
        sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualTypeId)
                        .toString() !=
                    "16" &&
                sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualTypeId)
                        .toString() !=
                    "17"
            ? sharedPreferences!.getString(AllSharedPreferencesKey.individualId)
            : teamMember.split(AllString.splitText).last,
    // sharedPreferences!.getString(AllSharedPreferencesKey.individualId),

    "teamMeetingId": teamMeetingId,
    "createdDate": formatterForRequest.format(selectedDate).toString(),
  };
  apiPostRequestWithHeader(data, AllUrls.dailyPlanList, context, loginToken)
      .then((response) {
    if (response == null) {
      _dailyLoader = false;
      AppBuilder.of(context)!.rebuild(); 

      commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    } else {
      Map<String, dynamic> jsonData = json.decode(response);
      if (checkApiResponseSuccessOrNot(jsonData)) {
        _dailyPlan.clear();
        AppBuilder.of(context)!.rebuild();
        if (jsonData["data"].toString() == "") {
          _dailyPlan.clear();
          fetchPendingList(context);
          AppBuilder.of(context)!.rebuild();
        } else {
          Future.delayed(Duration(milliseconds: 300), () {
            _dailyPlan = jsonData["data"];
            fetchPendingList(context);

            AppBuilder.of(context)!.rebuild();
          });
        }
        AppBuilder.of(context)!.rebuild();
      } else {
        _dailyLoader = false;
        AppBuilder.of(context)!.rebuild();

        commonAlertDialog(context, jsonData["status"], jsonData["message"]);
      }
    }
  });
}

fetchPendingList(BuildContext context) {
  _dailyLoader = true;
  AppBuilder.of(context)!.rebuild();
  Map data = {
    "companyId":
        sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
    "individualId":
        sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    "dailyStatus": "0",
    "createdDate": formatterForRequest.format(DateTime.now()).toString(),
  };
  apiPostRequestWithHeader(
          data, AllUrls.pendingCollaboration, context, loginToken)
      .then((response) {
    if (response == null) {
      _dailyLoader = false;
      AppBuilder.of(context)!.rebuild();
      commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    } else {
      Map<String, dynamic> jsonData = json.decode(response);
      if (checkApiResponseSuccessOrNot(jsonData)) {
        _pendingList.clear();
        if (jsonData["pendingCollaborationList"].toString() == "") {
          _pendingList.clear();
        } else {
          _pendingList = jsonData["pendingCollaborationList"];
        }
        Future.delayed(Duration(milliseconds: 300), () {
          _dailyLoader = false;
          AppBuilder.of(context)!.rebuild();
        });
      } else {
        _dailyLoader = false;
        AppBuilder.of(context)!.rebuild();

        commonAlertDialog(context, jsonData["status"], jsonData["message"]);
      }
    }
  });
}
