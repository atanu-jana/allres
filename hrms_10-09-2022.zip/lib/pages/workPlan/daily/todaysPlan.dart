// import 'dart:convert';
// import 'dart:developer';
// import 'dart:io';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:hr/api/apiPostRequestWithHeader.dart';
// import 'package:hr/api/imageToUrlApi.dart';
// import 'package:hr/common/commonAlertDialog.dart';
// import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/common/commonNoDataFound.dart';
// import 'package:hr/db/handler.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/order/order.dart';
// import 'package:hr/pages/workPlan/workPlanBody.dart';
// import 'package:hr/res/allSharePreferencesKey.dart';
// import 'package:hr/res/allUrls.dart';
// import 'package:hr/util/allFormatter.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/allMargin.dart';
// import 'package:hr/util/allText.dart';
// import 'package:hr/util/allTextStyle.dart';
// import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/util/customMarginCardItem.dart';
// import 'package:hr/util/internetCheck.dart';
// import 'package:hr/util/showOfflineSnakbar.dart';
// import 'package:hr/util/statusColor.dart';
// import 'package:hr/widget/button.dart';
// import 'package:hr/widget/customAppBar.dart';
// import 'package:hr/widget/customAppBarForBackHome.dart';
// import 'package:hr/widget/datePickerButton.dart';
// import 'package:hr/widget/dropdownButtonWithSearch.dart';
// import 'package:hr/widget/rounded_date_field.dart';
// import 'package:hr/widget/textFieldHeader.dart';
// import 'package:hr/widget/dropdownButton.dart';
// import 'package:hr/widget/rounded_input_field.dart';
// import 'package:hr/widget/textAreaField.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:ionicons/ionicons.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/dashboard/dashboard.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allString.dart';

// class TodaysPlan extends StatefulWidget {
//   const TodaysPlan({
//     Key? key,
//   }) : super(key: key);
//   @override
//   _TodaysPlanState createState() => _TodaysPlanState();
// }

// class _TodaysPlanState extends State<TodaysPlan> {
//   DateTime _selectedDate = DateTime.now();
//   bool loading = false;
//   bool addTodaysPlan = false;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AllColor.white,
//       appBar:
//           customAppBar(context, addTodaysPlan ? "Add Plan" : "Today's Plan"),
//       body: LoadingOverlay(
//         isLoading: loading,
//         opacity: 0.5,
//         color: AllColor.black,
//         progressIndicator: commonLoader(),
//         child: Container(
//             width: screenWidth,
//             height: screenHeight,
//                        decoration:customBackgroundGradient(),

//             child: addTodaysPlan
//                 ? addTodaysPlanView()
//                 : Stack(
//                     children: [
//                       ListView.builder(
//                           padding: EdgeInsets.only(
//                               top: screenWidth * 0.15,
//                               bottom: screenWidth * 0.03),
//                           physics: BouncingScrollPhysics(),
//                           itemCount: 5,
//                           itemBuilder: (context, index) =>
//                               ItemViewForDailyTodayStatus(
//                                 index: index,
//                                 itemData: {},
//                               )),
//                       Positioned(
//                           bottom: screenWidth * 0.05,
//                           right: screenWidth * 0.05,
//                           child: FloatingActionButton(
//                             onPressed: () {
//                               addTodaysPlan = true;
//                               planTextEditingController.clear();
//                               timeStamp = DateTime.now();
//                               timeStamptextEditingController.text =
//                                   convertStringToDate(timeStamp);
//                               setState(() {});
//                             },
//                             child: normalIcon(Icons.add),
//                             backgroundColor: AllColor.primaryDeepColor,
//                           )),
//                       Positioned(
//                         top: screenWidth * 0.0,
//                         child: dateSelectDisplay(),
//                       ),
//                     ],
//                   )),
//       ),
//     );
//   }

//   dateSelectDisplay() {
//     return Container(
//       width: screenWidth,
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: [
//           Container(
//             child:
//                 normalText(AllString.selectDate + ": ", color: AllColor.black),
//           ),
//           datePickerButton(context, _selectedDate, Icons.calendar_today, () {
//             selectDate(context, _selectedDate).then((value) {
//               _selectedDate = value;
//               setState(() {});
//             });
//           }),
//         ],
//       ),
//     );
//   }

//   TextEditingController timeStamptextEditingController =
//       TextEditingController();
//   TextEditingController planTextEditingController = TextEditingController();
//   DateTime timeStamp = DateTime.now();
//   bool validateAndProceed() {
//     if (planTextEditingController.text.isEmpty) {
//       return false;
//     } else {
//       return true;
//     }
//   }

//   addTodaysPlanView() {
//     return Container(
//       width: screenWidth,
//       height: screenHeight,
//       child: Stack(children: [
//         Column(
//           children: [
//             // textFieldHeader(AllString.dateSelect, fontWeight: FontWeight.bold),
//             // Container(
//             //     child: RoundedDateField(
//             //   controller: timeStamptextEditingController,
//             //   hintText: AllString.dateSelect,
//             //   icon: Icons.date_range,
//             //   onchangeFunction: (String val) {},
//             //   suffixIcon: Icons.date_range,
//             //   enable: false,
//             //   suffixFunction: () {},
//             // )),
//               textFieldHeader(AllString.selectProject,
//                       fontWeight: FontWeight.bold),
                 
//                   Container(
//                     child: DropdownButtonWithSearch(
//                       icon: LineIcons.sortAmountDown,
//                       selectedValue: selectProject,
//                       dropdownList: projectList,
//                       onChanged: onProjectChanged,
//                     ),
//                   ),
//             textFieldHeader("Elaborate", fontWeight: FontWeight.bold),
//             Container(
//               margin: EdgeInsets.symmetric(
//                 vertical: screenWidth * 0.0,
//                 horizontal: screenWidth * 0.03,
//               ),
//               child: Center(
//                 child: textAreaField(
//                   context,
//                   AllString.typeHere,
//                   planTextEditingController,
//                   4,
//                   200,
//                   TextInputAction.done,
//                   TextInputType.text,
//                 ),
//               ),
//             ),
//             Container(
//                 margin: EdgeInsets.symmetric(
//                     vertical: screenWidth * 0.015,
//                     horizontal: screenWidth * 0.03),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Container(
//                         child: button(context, function: () {
//                       addTodaysPlan = false;
//                       timeStamp = DateTime.now();
//                       timeStamptextEditingController.text =
//                           convertStringToDate(timeStamp);
//                       planTextEditingController.clear();
//                       setState(() {});
//                     },
//                             color1: Color.fromARGB(255, 118, 83, 83),
//                             color2: Color.fromARGB(255, 255, 0, 0),
//                             textColor: AllColor.white,
//                             text: AllString.reset,
//                             width: screenWidth * 0.3)),
//                     Container(
//                         child: button(context, function: () {
//                       if (validateAndProceed()) {}
//                     },
//                             color1: !validateAndProceed()
//                                 ? Colors.grey
//                                 : Color(0xff536976),
//                             color2: !validateAndProceed()
//                                 ? Colors.grey
//                                 : Color(0xff292E49),
//                             textColor: AllColor.white,
//                             text: AllString.add,
//                             width: screenWidth * 0.3))
//                   ],
//                 )),
//           ],
//         )
//       ]),
//     );
//   }
// }

// class ItemViewForDailyTodayStatus extends StatefulWidget {
//   final Map<String, dynamic> itemData;
//   final int index;
//   const ItemViewForDailyTodayStatus(
//       {Key? key, required this.index, required this.itemData})
//       : super(key: key);

//   @override
//   State<ItemViewForDailyTodayStatus> createState() =>
//       _ItemViewForDailyTodayStatusState();
// }

// class _ItemViewForDailyTodayStatusState
//     extends State<ItemViewForDailyTodayStatus> {
//   String statusValue = AllString.select;
//   @override
//   void initState() {
//     super.initState(); 
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.all(1),
//       decoration: customCardItemGradinet(),
//       margin: EdgeInsets.symmetric(
//           horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
//       child: Container(
//         decoration: BoxDecoration(
//             color: AllColor.white, borderRadius: BorderRadius.circular(10)),
//         width: screenWidth,
//         padding: AllMargin.customMarginCardItem(),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             Container(
//               width: screenWidth * 0.7,
//               child: Text(
//                 "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is " +
//                     random.nextInt(100).toString(),
//                 textAlign: TextAlign.justify,
//                 style: normal2TextStyle(
//                     color: AllColor.black,
//                     lineThrough: statusValue.split(AllString.splitText).first == "Success" ? true : false),
//               ),
//             ),
//             Container(
//                 width: screenWidth * 0.15,
//                 alignment: Alignment.center,
//                 child: GestureDetector(
//                     onTap: () {
//                       statusUpdateDialog();
//                     },
//                     child: Container(
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: [
//                           Icon(Icons.update_rounded),
//                           Container(
//                             child: smallText(statusValue,
//                                 fontWeight: FontWeight.bold,
//                                 color: statusColor(statusValue)),
//                           )
//                         ],
//                       ),
//                     ))
//                 // Container(
//                 //   child: dropdownButton(status, onDropdownChange, "Success")),
//                 ),
//           ],
//         ),
//       ),
//     );
//   }

//   onDropdownChange(String? value) {
//     statusValue = value!;
//     setState(() {});
//     AppBuilder.of(context)!.rebuild();
//     Navigator.pop(context);
//     statusUpdateDialog();
//   }

//   TextEditingController reasonTextEditingController = TextEditingController();
//   statusUpdateDialog() {
//     return commonAlertDialogWithCloseButtonWithWidget(
//         context,
//         AllColor.red,
//         Column(
//           children: [
//             textFieldHeader(AllString.status, fontWeight: FontWeight.bold),
//             dropdownButton(status, onDropdownChange, statusValue),
//             if (statusValue.split(AllString.splitText).first == "Failure")
//               Column(
//                 children: [
//                   textFieldHeader("Reason", fontWeight: FontWeight.bold),
//                   Container(
//                     margin: EdgeInsets.symmetric(
//                       vertical: screenWidth * 0.0,
//                       horizontal: screenWidth * 0.03,
//                     ),
//                     child: Center(
//                       child: textAreaField(
//                         context,
//                         AllString.typeHere,
//                         reasonTextEditingController,
//                         4,
//                         200,
//                         TextInputAction.done,
//                         TextInputType.text,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             Container(
//                 margin: EdgeInsets.symmetric(
//                   vertical: screenWidth * 0.015,
//                 ),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Container(
//                         child: button(context, function: () {
//                       Navigator.pop(context);
//                     },
//                             color1: Color.fromARGB(255, 118, 83, 83),
//                             color2: Color.fromARGB(255, 255, 0, 0),
//                             textColor: AllColor.white,
//                             text: AllString.cancel,
//                             width: screenWidth * 0.3)),
//                     Container(
//                         child: button(context, function: () {
//                       if (validateAndProceed()) {
//                         Navigator.pop(context);
//                       }
//                     },
//                             color1: !validateAndProceed()
//                                 ? Colors.grey
//                                 : Color(0xff536976),
//                             color2: !validateAndProceed()
//                                 ? Colors.grey
//                                 : Color(0xff292E49),
//                             textColor: AllColor.white,
//                             text: AllString.add,
//                             width: screenWidth * 0.3))
//                   ],
//                 )),
//           ],
//         ), onCloseButtonPress: () {
//       Navigator.pop(context);
//     });
//   }

//   bool validateAndProceed() {
//     if (statusValue == AllString.select) {
//       return false;
//     } else if (statusValue.split(AllString.splitText).first == "Failure" &&
//         reasonTextEditingController.text.isEmpty) {
//       return false;
//     } else {
//       return true;
//     }
//   }
// }
