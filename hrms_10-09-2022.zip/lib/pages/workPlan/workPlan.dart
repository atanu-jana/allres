import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpenseBody.dart';
import 'package:hr/pages/myLoan/myLoanBody.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class WorkPlan extends StatefulWidget {
  const WorkPlan({Key? key}) : super(key: key);
  @override
  _WorkPlanState createState() => _WorkPlanState();
}

class _WorkPlanState extends State<WorkPlan> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
              context, CupertinoPageRoute(builder: (context) => Home()));
          return true;
        },
        child: Scaffold(
            backgroundColor: AllColor.white,
            appBar: customAppBarForBackHome(context, AllString.workPlan),
            body: WorkPlanBody()));
  }
}
