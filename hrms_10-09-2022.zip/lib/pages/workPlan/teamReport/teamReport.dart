import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class TeamReport extends StatefulWidget {
  const TeamReport({
    Key? key,
  }) : super(key: key);
  @override
  _TeamReportState createState() => _TeamReportState();
}

class _TeamReportState extends State<TeamReport> {
  DateTime _selectedDate = DateTime.now();
  bool loading = false;
  String selectTeamMember = AllString.select;
  List _todaysReport = [];

  String selectedStatus = AllString.select;

  @override
  void initState() {
    super.initState();
    if (teamMemberList.length > 1) {
      selectTeamMember = teamMemberList[1];
      setState(() {});
    }
    fetchReport();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AllColor.white,
      appBar: customAppBar(context, "Today's Report"),
      body: LoadingOverlay(
        isLoading: loading,
        opacity: 0.5,
        color: AllColor.black,
        progressIndicator: commonLoader(),
        child: Container(
            width: screenWidth,
            height: screenHeight,
                        decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Container(
                  width: screenWidth,
                  height: screenHeight,
                  child: Column(
                    children: [
                      Container(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
// dateSelectDisplay(),
                            Column(
                              children: [
                                // sharedPreferences!
                                //             .getString(AllSharedPreferencesKey
                                //                 .individualTypeId)
                                //             .toString() ==
                                //         "18"
                                (sharedPreferences!
                                                .getString(
                                                    AllSharedPreferencesKey
                                                        .individualTypeId)
                                                .toString() !=
                                            "16" &&
                                        sharedPreferences!
                                                .getString(
                                                    AllSharedPreferencesKey
                                                        .individualTypeId)
                                                .toString() !=
                                            "17")
                                    ? Container()
                                    : Container(
                                        margin: AllMargin.customVertical(),
                                        child: Column(
                                          children: [
                                            textFieldHeader(
                                                AllString.selectMember,
                                                fontWeight: FontWeight.bold,
                                                center: true),
                                            Container(
                                              width: screenWidth,
                                              child: Container(
                                                child: DropdownButtonWithSearch(
                                                  icon:
                                                      LineIcons.sortAmountDown,
                                                  selectedValue:
                                                      selectTeamMember,
                                                  dropdownList: teamMemberList,
                                                  onChanged:
                                                      onTeamMemberChanged,
                                                ),
                                              ),
                                            )
                                            // child: dropdownButton(
                                            //     teamMemberList,
                                            //     onTeamMemberChanged,
                                            //     selectTeamMember)),
                                            // ),
                                          ],
                                        ),
                                      ),
                                Container(
                                  margin: AllMargin.customVertical(),
                                  child: Column(
                                    children: [
                                      textFieldHeader(AllString.status,
                                          fontWeight: FontWeight.bold,
                                          center: true),
                                      Container(
                                        width: screenWidth,
                                        child: Container(
                                            child: dropdownButton(
                                                status,
                                                onStatusChanged,
                                                selectedStatus)),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: screenHeight - (screenWidth * 0.75),
                        child: _todaysReport.isEmpty
                            ? commonNoDataFound()
                            : ListView.builder(
                                padding:
                                    EdgeInsets.only(bottom: screenWidth * 0.03),
                                physics: BouncingScrollPhysics(),
                                itemCount: _todaysReport.length,
                                itemBuilder: (context, index) =>
                                    TeamReportStatusView(
                                      index: index,
                                      itemData: _todaysReport[index],
                                    )),
                      )
                    ],
                  ),
                )
              ],
            )),
      ),
    );
  }

  onStatusChanged(String? value) {
    selectedStatus = value!;
    setState(() {});
    fetchReport();
  }

  onTeamMemberChanged(String? value) {
    selectTeamMember = value!;
    setState(() {});
    fetchReport();
  }

  dateSelectDisplay() {
    return Container(
      width: screenWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child:
                normalText(AllString.selectDate + ": ", color: AllColor.black),
          ),
          datePickerButton(context, _selectedDate, Icons.calendar_today, () {
            selectDate(context, _selectedDate).then((value) {
              _selectedDate = value;
              setState(() {});
            });
          }),
        ],
      ),
    );
  }

  fetchReport() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : selectTeamMember.split(AllString.splitText).last,
      "statusId": selectedStatus.split(AllString.splitText).last,
      "createdDate": formatterForRequest.format(DateTime.now()).toString(),
    };
    apiPostRequestWithHeader(
            data, AllUrls.todaysReports, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _todaysReport.clear();
          if (jsonData["todaysReportList"].toString() == "") {
            _todaysReport.clear();
          } else {
            _todaysReport = jsonData["todaysReportList"];
          }
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}

class TeamReportStatusView extends StatefulWidget {
  final Map<String, dynamic> itemData;
  final int index;
  const TeamReportStatusView(
      {Key? key, required this.index, required this.itemData})
      : super(key: key);

  @override
  State<TeamReportStatusView> createState() => _TeamReportStatusViewState();
}

class _TeamReportStatusViewState extends State<TeamReportStatusView> {
  // String statusValue = AllString.select;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        padding: AllMargin.customMarginCardItem(),
        child: ExpansionTile(
          title: Container(
            width: screenWidth * 0.85,
            child: Column(
              children: [
                Container(
                  width: screenWidth * 0.85,
                  child: Text(
                    showValidValue(widget.itemData["planTitle"]),
                    textAlign: TextAlign.justify,
                    style: normal2TextStyle(
                        color: AllColor.black,
                        fontWeight: FontWeight.bold,
                        lineThrough: false),
                  ),
                ),
                Container(
                  width: screenWidth * 0.85,
                  child: Text(
                    showValidValue(widget.itemData["planDesc"]),
                    textAlign: TextAlign.justify,
                    style: normal2TextStyle(
                        color: AllColor.greyColor, lineThrough: false),
                  ),
                ),
                // Divider(),
                // Container(
                //   width: screenWidth * 0.85,
                //   child: Row(
                //     children: [
                //       Container(
                //         width: screenWidth * 0.15,
                //         child: Text(
                //           AllString.status + " :",
                //           maxLines: 1,
                //           style: smallTextStyle(
                //               color: AllColor.black,
                //               fontWeight: FontWeight.bold),
                //         ),
                //       ),
                //       // Text(
                //       //   statusValue,
                //       //   style: normalTextStyle(
                //       //     color: statusColor(statusValue),
                //       //     fontWeight: FontWeight.bold,
                //       //   ),
                //       // ),
                //     ],
                //   ),
                // ),
              ],
            ),
          ),
          children: <Widget>[
            customRowDetails(
                width: screenWidth * 0.75,
                widthTitle: screenWidth * 0.23,
                title: "Time",
                value: showValidValue(widget.itemData["time"])),
            customRowDetails(
                width: screenWidth * 0.75,
                widthTitle: screenWidth * 0.23,
                title: "Collaboration",
                value: showValidValue(widget.itemData["collaboration"])),
          ],
        ),
      ),
    );
  }
}
