import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/workPlan/collaboration/collaboration.dart';
import 'package:hr/pages/workPlan/teamReport/teamReport.dart';
import 'package:hr/pages/workPlan/workPlanDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

List<String> status = [];
List<String> projectList = [];

class WorkPlanBody extends StatefulWidget {
  @override
  _WorkPlanBodyState createState() => _WorkPlanBodyState();
}

class _WorkPlanBodyState extends State<WorkPlanBody> {
  bool loading = false;
  @override
  void initState() {
    super.initState();
    fetchStatusList();
  }

  List<Color> workPlanColor = [
    Color(0xffffa726),
    Color(0xffff7043),
    Color(0xff66bb6a),
    Color(0xff26c6da),
    Color(0xffef5350),
    Color(0xffab47bc)
  ];
  List _meetingList = [];
  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                               decoration:customBackgroundGradient(),

        child: Stack(
          children: [
            Container(
              width: screenWidth,
              height: screenHeight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // height: screenWidth * 0.45,
                  header(),

                  Container(
                      height: screenWidth * 0.28,
                      child: Column(
                        children: [
                          todaysReport(),
                          // sharedPreferences!
                          //             .getString(AllSharedPreferencesKey
                          //                 .individualTypeId)
                          //             .toString() ==
                          //         "18"
                          //     ? Container()
                          //     :
                          todaysCollaboration(),
                        ],
                      )),
                  Container(
                    height:
                        screenHeight - (screenWidth * 0.5 + screenWidth * 0.55),
                    width: screenWidth,
                    child: Card(
                      color: AllColor.white,
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      margin: AllMargin.customMarginCardItem(),
                      child: _meetingList.isEmpty
                          ? commonNoDataFound()
                          : Container(
                              child: GridView.builder(
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 1,
                                    mainAxisSpacing: 1,
                                    childAspectRatio: 1,
                                  ),
                                  physics: BouncingScrollPhysics(),
                                  padding: EdgeInsets.zero,
                                  itemCount: _meetingList.length,
                                  itemBuilder: (context, index) =>
                                      itemView(_meetingList[index], index)),
                            ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  todaysReport() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => TeamReport()));
      },
      child: Container(
        width: screenWidth,
        height: screenWidth * 0.1,
        margin: AllMargin.customMarginCardItem(),
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: AllColor.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
            border: Border.all(width: 0, color: AllColor.white),
            borderRadius: BorderRadius.circular(7)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: screenWidth * 0.1,
                  width: screenWidth * 0.12,
                  decoration: BoxDecoration(
                      color: AllColor.accentColor,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(7),
                        bottomLeft: Radius.circular(7),
                      )),
                  padding: AllMargin.customHorizontalSmall(),
                  child: normalIcon(Icons.event_note_outlined,
                      color: AllColor.white),
                ),
                Container(
                  margin: AllMargin.customHorizontal(),
                  child: headingText("Today's Report",
                      color: AllColor.black,
                      center: true,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Container(
              height: screenWidth * 0.1,
              width: screenWidth * 0.1,
              alignment: Alignment.center,
              margin: AllMargin.customHorizontalSmall(),
              child:
                  Icon(Icons.arrow_circle_right_outlined, color: AllColor.blue),
            ),
          ],
        ),
      ),
    );
  }

  todaysCollaboration() {
    return GestureDetector(
      onTap: () {
        Navigator.of(context)
            .push(CupertinoPageRoute(builder: (context) => Collaboration()));
      },
      child: Container(
        width: screenWidth,
        height: screenWidth * 0.1,
        margin: AllMargin.customMarginCardItem(),
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: AllColor.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
            border: Border.all(width: 0, color: AllColor.white),
            borderRadius: BorderRadius.circular(7)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: screenWidth * 0.1,
                  width: screenWidth * 0.12,
                  decoration: BoxDecoration(
                      color: AllColor.accentColor,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(7),
                        bottomLeft: Radius.circular(7),
                      )),
                  padding: AllMargin.customHorizontalSmall(),
                  child:
                      normalIcon(Icons.webhook_rounded, color: AllColor.white),
                ),
                Container(
                  margin: AllMargin.customHorizontal(),
                  child: headingText("Today's Collaboration",
                      color: AllColor.black,
                      center: true,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Container(
              height: screenWidth * 0.1,
              width: screenWidth * 0.1,
              alignment: Alignment.center,
              margin: AllMargin.customHorizontalSmall(),
              child:
                  Icon(Icons.arrow_circle_right_outlined, color: AllColor.blue),
            ),
          ],
        ),
      ),
    );
  }

  itemView(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        if (selectTeamMember == AllString.select) {
          if (teamMemberList.length > 1) {
            selectTeamMember = teamMemberList[1];
            setState(() {});
          }
        } else {
          if (teamMemberList.length > 1) {
            selectTeamMember = teamMemberList[1];
            setState(() {});
          }
        }
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => WorkPlanDetails(
                  meetingSingleData: itemData,
                )));
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        // color: workPlanColor[random.nextInt(workPlanColor.length)],
        color: workPlanColor[index],
        elevation: 2,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.03),

        child: Container(
          decoration: BoxDecoration(
              color: AllColor.black.withOpacity(0.1),
              image: DecorationImage(
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                      AllColor.white.withOpacity(0.2), BlendMode.dstATop),
                  image: AssetImage("assets/images/workplanParent.png")),
              borderRadius: BorderRadius.circular(10)),
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                // padding: AllMargin.customMarginCardItemSameSmall(),
                // decoration: BoxDecoration(

                //   borderRadius: BorderRadius.circular(15),
                //   color: AllColor.black.withOpacity(0.3)
                // ),
                child: headingText(
                    validValue(itemData["startDate"])
                        ? convertStringToDate(
                            DateTime.parse(itemData["startDate"]))
                        : AllString.na,
                    center: true,
                    color: AllColor.white,
                    fontWeight: FontWeight.bold),
              ),
              Divider(
                color: AllColor.white,
              ),
              Container(
                // padding: AllMargin.customMarginCardItemSameSmall(),
                // decoration: BoxDecoration(

                //   borderRadius: BorderRadius.circular(15),
                //   color: AllColor.black.withOpacity(0.3)
                // ),
                child: headingText(
                    validValue(itemData["endDate"])
                        ? convertStringToDate(
                            DateTime.parse(itemData["endDate"]))
                        : AllString.na,
                    center: true,
                    color: AllColor.white,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }

  header() {
    return Container(
      width: screenWidth,
      height: screenWidth * 0.45,
      margin: AllMargin.customMarginCardItem(),
      child: Card(
        margin: EdgeInsets.zero,
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: screenWidth,
                height: screenWidth * 0.45,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AllColor.lightBlack,
                      AllColor.lightBlack,
                      AllColor.greyColor,
                      // Color(0xffeeeeee),
                      // Color(0xffb0bec5),
                      // Color(0xffb0bec5),
                      // Color(0xffeeeeee),
                      // AllColor.primaryColor,
                      // AllColor.accentColor,
                      // AllColor.primaryColor,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
              // Column(
              //   children: [
              //     Container(
              // width: screenWidth,
              // height: screenWidth * 0.45 / 2,
              //       color: AllColor.accentColor,
              //     ),
              //     Container(
              //       width: screenWidth,
              //       height: screenWidth * 0.45 / 2,
              //       color: AllColor.white,
              //     )
              //   ],
              // ),
              Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
                elevation: 5,
                child: Container(
                  width: screenWidth * 0.55,
                  height: screenWidth * 0.45 / 2,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      // gradient: LinearGradient(
                      //   colors: [
                      //     AllColor.lightBlack,
                      //     AllColor.white,
                      //     AllColor.white,
                      //     // Color(0xffeeeeee),
                      //     // Color(0xffb0bec5),
                      //     // Color(0xffb0bec5),
                      //     // Color(0xffeeeeee),
                      //     // AllColor.primaryColor,
                      //     // AllColor.accentColor,
                      //     // AllColor.primaryColor,
                      //   ],
                      //      begin: Alignment.topLeft,
                      // end: Alignment.bottomRight,
                      // ),
                      border: Border.all(color: AllColor.lightBlack, width: 5),
                      borderRadius: BorderRadius.circular(7)),
                  child: Container(
                    width: (screenWidth * 0.55) - 10,
                    height: (screenWidth * 0.45 / 2) - 10,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: AllColor.white,
                        borderRadius: BorderRadius.circular(7)),
                    child: headingText(

                        // "Work And Meeting Plan",
                        " Team Goal Tracking System ",
                        color: AllColor.black,
                        center: true,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              // Positioned(
              //   top: screenWidth * 0.01,
              //   right: screenWidth * 0.01,
              //   child: Icon(Icons.target , color: AllColor.red),
              // )
            ],
          ),
        ),
      ),
    );
  }

  fetchStatusList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(data, AllUrls.statusList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          status.clear();
          status.add(AllString.select);

          if (jsonData["data"].toString() == "") {
            status.clear();
          } else {
            List _tempList = jsonData["data"];
            _tempList.forEach((element) {
              status.add(element["statusName"].toString() +
                  AllString.splitText +
                  element["statusId"].toString());
            });
          }

          fetchMeetingList();
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchMeetingList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "individualTypeId": sharedPreferences!
          .getString(AllSharedPreferencesKey.individualTypeId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.allmeetingDate, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _meetingList.clear();
          if (jsonData["data"].toString() == "") {
            _meetingList.clear();
          } else {
            _meetingList = jsonData["data"];
          }

          fetchProjectList();
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
  fetchProjectList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId)
    };
    apiPostRequestWithHeader(
            data, AllUrls.projectList, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          projectList.clear();
          projectList.add(AllString.select);

          if (jsonData["data"].toString() == "") {
            projectList.clear();
          } else {
            List _tempList = jsonData["data"];
            _tempList.forEach((element) {
              projectList.add(element["projectTitle"].toString() +
                  AllString.splitText +
                  element["projectId"].toString());
            });
          }
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}

// import 'dart:convert';
// import 'dart:developer';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/leaveBalance/applyLeave.dart';
// import 'package:hr/pages/leaveBalance/leave.dart';
// import 'package:hr/pages/myExpense/applyExpense.dart';
// import 'package:hr/pages/myExpense/myExpenseDetails.dart';
// import 'package:hr/pages/myLoan/applyLoan.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/widget/customCatender.dart';
// import 'package:hr/widget/customRowDetails.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/dashboard/dashboard.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allString.dart';

// class MyExpenseBody extends StatefulWidget {
//   @override
//   _MyExpenseBodyState createState() => _MyExpenseBodyState();
// }

// class _MyExpenseBodyState extends State<MyExpenseBody> {
//   bool loading = false;
//   List _myExpenseList = [];
//   @override
//   void initState() {
//     super.initState();
//     fetchExpense();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return LoadingOverlay(
//       isLoading: loading,
//       opacity: 0.1,
//       color: AllColor.primaryColor,
//       progressIndicator: loaderWaveOrange(),
//       child: Container(
//         width: screenWidth,
//         height: screenHeight,
//                        decoration:customBackgroundGradient(),

//         child: Stack(
//           children: [
//             ListView.builder(
//                 padding: EdgeInsets.only(bottom: screenWidth * 0.03),
//                 physics: BouncingScrollPhysics(),
//                 itemCount: _myExpenseList.length,
//                 itemBuilder: (context, index) =>
//                     customMyLoanItem(_myExpenseList[index], index)),
//             Positioned(
//                 bottom: screenWidth * 0.05,
//                 right: screenWidth * 0.05,
//                 child: FloatingActionButton(
//                   onPressed: () {
//                     Navigator.of(context).push(CupertinoPageRoute(
//                         builder: (context) => ApplyExpense()));
//                   },
//                   child: normalIcon(Icons.add),
//                   backgroundColor: AllColor.primaryDeepColor,
//                 )),
//           ],
//         ),
//       ),
//     );
//   }

//   customMyLoanItem(Map<String, dynamic> itemData, int index) {
//     return GestureDetector(
//       onTap: () {
//         if (itemData["Status"] == "Reimbursment") {
//           Navigator.push(context,
//               CupertinoPageRoute(builder: (context) => MyExpenseDetails()));
//         }
//       },
//       child: Container(
//         padding: EdgeInsets.all(1),
//         decoration: customCardItemGradinet(),
//         height: screenWidth >= 600 ? screenWidth * 0.23 : screenWidth * 0.27,
//         margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
//         child: Container(
//           decoration: BoxDecoration(
//               color: AllColor.white, borderRadius: BorderRadius.circular(10)),
//           width: screenWidth,
//           child: Row(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               customCatender(
//                   screenWidth * 0.23,
//                   screenWidth >= 600 ? screenWidth * 0.18 : screenWidth * 0.27,
//                   screenWidth * 0.18,
//                   index),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Amount",
//                       value: AllString.rs + " " + itemData["ExpenseAmount"]),
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Remark",
//                       value: itemData["ExpenseApplyRemarks"].toString()),
//                   customRowDetails(
//                       width: screenWidth * 0.6,
//                       widthTitle: screenWidth * 0.15,
//                       title: "Status",
//                       value: itemData["Status"]),
//                 ],
//               ),
//               itemData["Status"] == "Reimbursment"
//                   ? Container(
//                       margin: EdgeInsets.only(right: screenWidth * 0.02),
//                       child: normalIcon(Icons.arrow_forward_ios,
//                           color: AllColor.greyColor))
//                   : Container()
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   fetchExpense() async {
//     var jsonData = json.decode(
//         await rootBundle.loadString('assets/json/ExpenseListData.json'));
//     log(jsonData.toString());
//     _myExpenseList = jsonData["ExpenseListData"];
//     setState(() {});
//   }
// }
