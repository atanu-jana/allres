import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/daily/daily.dart';
import 'package:hr/pages/workPlan/evaluation/evaluation.dart';
import 'package:hr/pages/workPlan/feedback/feedback.dart';
import 'package:hr/pages/workPlan/goal/goal.dart';
import 'package:hr/pages/workPlan/workPlan.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

String selectTeamMember = AllString.select;

class WorkPlanDetails extends StatefulWidget {
  final Map meetingSingleData;
  const WorkPlanDetails({
    Key? key,
    required this.meetingSingleData,
  }) : super(key: key);
  @override
  _WorkPlanDetailsState createState() => _WorkPlanDetailsState();
}

class _WorkPlanDetailsState extends State<WorkPlanDetails> {
  bool loading = false;

  @override
  void initState() {
    if (selectTeamMember == AllString.select) {
      if (teamMemberList.length > 1) {
        selectTeamMember = teamMemberList[1];
        setState(() {});
      }
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.push(
            context, CupertinoPageRoute(builder: (context) => WorkPlan()));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, getAppBarName(), smallTitle: true,
            onBackPress: () {
          Navigator.push(
              context, CupertinoPageRoute(builder: (context) => WorkPlan()));
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                   decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Container(
                  width: screenWidth,
                  height: screenHeight,
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // sharedPreferences!
                        //             .getString(
                        //                 AllSharedPreferencesKey.individualTypeId)
                        //             .toString() ==
                        //         "18"
                        (sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .individualTypeId)
                                        .toString() !=
                                    "16" &&
                                sharedPreferences!
                                        .getString(AllSharedPreferencesKey
                                            .individualTypeId)
                                        .toString() !=
                                    "17")
                            ? Container()
                            : Container(
                                margin: AllMargin.customVertical(),
                                child: Column(
                                  children: [
                                    textFieldHeader(AllString.selectMember,
                                        fontWeight: FontWeight.bold,
                                        center: true),
                                    Container(
                                      width: screenWidth,
                                      child: Container(
                                        child: DropdownButtonWithSearch(
                                          icon: LineIcons.sortAmountDown,
                                          selectedValue: selectTeamMember,
                                          dropdownList: teamMemberList,
                                          onChanged: onTeamMemberChanged,
                                        ),
                                        // child: dropdownButton(
                                        //     teamMemberList,
                                        //     onTeamMemberChanged,
                                        //     selectTeamMember)),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                        Divider(),
                        (sharedPreferences!
                                            .getString(AllSharedPreferencesKey
                                                .individualTypeId)
                                            .toString() ==
                                        "16" ||
                                    sharedPreferences!
                                            .getString(AllSharedPreferencesKey
                                                .individualTypeId)
                                            .toString() ==
                                        "17") &&
                                (teamMemberList.isEmpty ||
                                    selectTeamMember == AllString.select)
                            // sharedPreferences!
                            //         .getString(AllSharedPreferencesKey
                            //             .individualTypeId)
                            //         .toString() !=
                            //     "18"
                  
                            ? commonNoDataFound()
                            : Container(
                                height: screenHeight - (screenWidth * 0.3),
                                child: ListView(
                                  physics: BouncingScrollPhysics(),
                                  children: [
                                  
                                    customWorkPlanWidget(
                                        "Goal",
                                        "Goal setting involves the development of an action plan designed in order to motivate and guide a person or group toward a goal. ",
                                        "assets/images/goal.png", () {
                                      Navigator.of(context)
                                          .push(CupertinoPageRoute(
                                              builder: (context) => Goal(
                                                    teamMember: selectTeamMember,
                                                    meetingSingleData:
                                                        widget.meetingSingleData,
                                                  )));
                                    }, Color(0xfffff3e0)),
                                    customWorkPlanWidget(
                                        "Evaluation",
                                        "Evaluation is a systematic determination of a subject's merit, worth and significance, using criteria governed by a set of standards.",
                                        "assets/images/evaluation.png", () {
                                      Navigator.of(context)
                                          .push(CupertinoPageRoute(
                                              builder: (context) => Evaluation(
                                                    teamMember: selectTeamMember,
                                                    meetingSingleData:
                                                        widget.meetingSingleData,
                                                  )));
                                    }, Color(0xffe3f2fd)),
                                    customWorkPlanWidget(
                                        "Operation",
                                        "Learn how to use a Prioritized To-Do List to manage tasks effectively. Our free template will help you get everything done, in the right order.",
                                        "assets/images/daily.png", () {   Navigator.of(context).push(CupertinoPageRoute(
                                      builder: (context) => Daily(
                                            teamMember: selectTeamMember,
                                            meetingSingleData:
                                                widget.meetingSingleData,
                                            callBack: () {
                                              Navigator.push(
                                                  context,
                                                  CupertinoPageRoute(
                                                      builder: (context) =>
                                                          WorkPlanDetails(
                                                            meetingSingleData:
                                                                widget
                                                                    .meetingSingleData,
                                                          )));
                                            },
                                          ))); }, Color(0xffe8f5e9)),
                                    Divider(),
                                      Center(
                                      child: GestureDetector(
                                        onTap: () {
                                          
                                      Navigator.of(context)
                                          .push(CupertinoPageRoute(
                                              builder: (context) => Feedbackk(
                                                    teamMember: selectTeamMember,
                                                    meetingSingleData:
                                                        widget.meetingSingleData,
                                                    callBack: () {
                                                      Navigator.push(
                                                          context,
                                                          CupertinoPageRoute(
                                                              builder: (context) =>
                                                                  WorkPlanDetails(
                                                                    meetingSingleData:
                                                                        widget
                                                                            .meetingSingleData,
                                                                  )));
                                                    },
                                                  )));
                                   
                                        },
                                        child: Container(
                                          margin: AllMargin.customVertical(),
                                          padding:
                                              AllMargin.customMarginCardItem(),
                                          width: screenWidth * 0.8,
                                          height: screenWidth * 0.45,
                                          decoration: BoxDecoration(
                                            color: AllColor.white,
                                            // color: Color(0xffb4ffff),
                                            boxShadow: [
                                              BoxShadow(
                                                color:
                                                    Colors.grey.withOpacity(0.5),
                                                spreadRadius: 2,
                                                blurRadius: 7,
                                                offset: Offset(0,
                                                    3), // changes position of shadow
                                              ),
                                            ],
                  
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10)),
                                            border: Border.all(
                                                color: AllColor.black
                                                    .withOpacity(0.1)),
                                          ),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: AllColor.white,
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      "assets/images/feedback.png")),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  onTeamMemberChanged(String? value) {
    selectTeamMember = value!;
    setState(() {});
  }

  Widget customWorkPlanWidget(String title, String subTitle, String image,
          Function() onTap, Color color) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          margin: AllMargin.customMarginCardItemSame(),
          padding: AllMargin.customVertical(),
          width: screenWidth,
          decoration: BoxDecoration(boxShadow: [
            BoxShadow(
              color: AllColor.greyColor.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 5,
              offset: Offset(0, 2),
            ),
          ], color: color, borderRadius: BorderRadius.circular(15)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: screenWidth * 0.2,
                    width: screenWidth * 0.2,
                    margin: AllMargin.customMarginCardItemSameSmall(),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        border:
                            Border.all(width: 5, color: AllColor.lightBlack),
                        color: AllColor.white,
                        borderRadius: BorderRadius.circular(7)),
                    child: Image.asset(image),
                  ),
                  Container(
                    margin: AllMargin.customLeft(),
                    width: screenWidth - (screenWidth * 0.5),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          alignment: Alignment.centerLeft,
                          width: screenWidth - (screenWidth * 0.5),
                          child: headingText(title,
                              color: AllColor.primaryColor,
                              fontWeight: FontWeight.bold),
                        ),
                        Container(
                          margin: AllMargin.customVerticalSmall(),
                        ),
                        Container(
                          alignment: Alignment.centerLeft,
                          width: screenWidth - (screenWidth * 0.5),
                          child: smallText(subTitle,
                              color: AllColor.greyColor,
                              fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Container(
                height: screenWidth * 0.08,
                width: screenWidth * 0.08,
                margin: AllMargin.customMarginCardItemSameSmall(),
                child: normalIcon(Icons.arrow_forward_ios,
                    color: AllColor.greyColor),
              ),
            ],
          ),
        ),
      );

  String getAppBarName() {
    String a = validValue(widget.meetingSingleData["startDate"])
        ? convertStringToDate(
            DateTime.parse(widget.meetingSingleData["startDate"]))
        : AllString.na;
    String b = validValue(widget.meetingSingleData["endDate"])
        ? convertStringToDate(
            DateTime.parse(widget.meetingSingleData["endDate"]))
        : AllString.na;
    return a + " - " + b;
  }
}
