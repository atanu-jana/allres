import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class Collaboration extends StatefulWidget {
  const Collaboration({
    Key? key,
  }) : super(key: key);
  @override
  _CollaborationState createState() => _CollaborationState();
}

class _CollaborationState extends State<Collaboration> {
  DateTime _selectedDate = DateTime.now();
  bool loading = false;
  String selectTeamMember = AllString.select;
  List _collaborationList = [];
  List _requestedList = [];
  bool showRequestList = false;
  @override
  void initState() {
    super.initState();
    if (teamMemberList.length > 1) {
      selectTeamMember = teamMemberList[1];
      setState(() {});
    }
    fetchCollaboration();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (showRequestList) {
          showRequestList = false;
          setState(() {});
          return false;
        } else {
          Navigator.pop(context);
          return true;
        }
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context,
            showRequestList ? "Pending Collaboration" : "Today's Collaboration",
            onBackPress: () {
          if (showRequestList) {
            showRequestList = false;
            setState(() {});
          } else {
            Navigator.pop(context);
          }
        },
            actions: 
           (sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "16" ||
                                  sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "17") &&
                              (selectTeamMember == "" ||
                                  selectTeamMember == AllString.select ||
                                  selectTeamMember
                                          .split(AllString.splitText)
                                          .last !=
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey.individualId))
                // sharedPreferences!.getString(
                //         AllSharedPreferencesKey.individualTypeId) ==
                //     "18"

                ?[]:
                 [
                    Container(
                      margin: AllMargin.customHorizontalSmall(),
                      child: IconButton(
                          onPressed: () {
                            setState(() {
                              showRequestList = !showRequestList;
                            });
                          },
                          icon: Badge(
                              badgeColor: AllColor.deepYellow,
                              badgeContent:
                                  smallText(_requestedList.length.toString()),
                              child: Icon(
                                Icons.notifications,
                              ))),
                    )
                  ]
                ),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
                                     decoration:customBackgroundGradient(),

              child: Stack(
                children: [
                  showRequestList
                      ? showRequestedList()
                      : showCollaborationList()
                ],
              )),
        ),
      ),
    );
  }

  onTeamMemberChanged(String? value) {
    selectTeamMember = value!;
    setState(() {});
    fetchCollaboration();
  }

  dateSelectDisplay() {
    return Container(
      width: screenWidth,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child:
                normalText(AllString.selectDate + ": ", color: AllColor.black),
          ),
          datePickerButton(context, _selectedDate, Icons.calendar_today, () {
            selectDate(context, _selectedDate).then((value) {
              _selectedDate = value;
              setState(() {});
            });
          }),
        ],
      ),
    );
  }

  fetchCollaboration() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : selectTeamMember.split(AllString.splitText).last,
      "dailyStatus": "1",
      "createdDate": formatterForRequest.format(DateTime.now()).toString(),
    };
    apiPostRequestWithHeader(
            data, AllUrls.todaysCollaboration, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _collaborationList.clear();
          if (jsonData["todaysCollaborationList"].toString() == "") {
            _collaborationList.clear();
          } else {
            _collaborationList = jsonData["todaysCollaborationList"];
          }

          fetchPendingList();
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchPendingList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "dailyStatus": "0",
      "createdDate": formatterForRequest.format(DateTime.now()).toString(),
    };
    apiPostRequestWithHeader(
            data, AllUrls.todaysCollaborationStatus, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _requestedList.clear();
          if (jsonData["todaysCollaborationListStatus"].toString() == "") {
            _requestedList.clear();
          } else {
            _requestedList = jsonData["todaysCollaborationListStatus"];
          }
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  showRequestedList() {
    return Container(
      width: screenWidth,
      height: screenHeight,
      child: _requestedList.isEmpty
          ? commonNoDataFound()
          : ListView.builder(
              padding: AllMargin.customMarginCardItemSameSmall(),
              physics: BouncingScrollPhysics(),
              itemCount: _requestedList.length,
              itemBuilder: (context, index) =>
                  requestedListItem(_requestedList[index], index)),
    );
  }

  requestedListItem(Map<String, dynamic> itemData, int index) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            children: [
              Container(
                width: screenWidth * 0.85,
                child: Text(
                  showValidValue(itemData["planTitle"]),
                  textAlign: TextAlign.justify,
                  style: normal2TextStyle(
                    color: AllColor.black,
                  ),
                ),
              ),
              Container(
                width: screenWidth * 0.85,
                child: Text(
                  showValidValue(itemData["planDesc"]),
                  textAlign: TextAlign.justify,
                  style: normal2TextStyle(
                    color: AllColor.black.withOpacity(0.5),
                  ),
                ),
              ),
              Container(
                width: screenWidth * 0.85,
                child: Row(
                  children: [
                    Container(
                      width: screenWidth * 0.28,
                      child: Text(
                        "Requested by: ",
                        textAlign: TextAlign.justify,
                        style: normal2TextStyle(
                          color: AllColor.greyColor,
                        ),
                      ),
                    ),
                    Container(
                      width: screenWidth * 0.55,
                      child: Text(
                        showValidValue(itemData["collaboration"]),
                        textAlign: TextAlign.justify,
                        style: normal2TextStyle(
                            color: AllColor.black, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MaterialButton(
                    height: screenWidth * 0.08,
                    onPressed: () {
                      updateStatus(itemData, "", true);
                    },
                    color: AllColor.green,
                    child: normalText(
                      AllString.accept,
                      color: AllColor.white,
                    ),
                    splashColor: AllColor.green,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10000),
                        side: BorderSide(color: AllColor.green)),
                  ),
                  MaterialButton(
                    height: screenWidth * 0.08,
                    color: AllColor.red,
                    onPressed: () {
                      TextEditingController reasonTextEditingController =
                          TextEditingController();
                      return commonAlertDialogWithCloseButtonWithWidget(
                          context,
                          AllColor.red,
                          Column(
                            children: [
                              Column(
                                children: [
                                  textFieldHeader("Reason",
                                      fontWeight: FontWeight.bold),
                                  Container(
                                    margin: EdgeInsets.symmetric(
                                      vertical: screenWidth * 0.0,
                                      horizontal: screenWidth * 0.03,
                                    ),
                                    child: Center(
                                      child: textAreaField(
                                        context,
                                        AllString.typeHere,
                                        reasonTextEditingController,
                                        4,
                                        200,
                                        TextInputAction.done,
                                        TextInputType.text,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                  margin: EdgeInsets.symmetric(
                                    vertical: screenWidth * 0.015,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                          child: button(context, function: () {
                                        Navigator.pop(context);
                                      },

                              color:AllColor.red,

                                             
                                              textColor: AllColor.white,
                                              text: AllString.cancel,
                                              width: screenWidth * 0.25)),
                                      Container(
                                          child: button(context, function: () {
                                        if (reasonTextEditingController
                                            .text.isNotEmpty) {
                                          Navigator.pop(context);
                                          updateStatus(
                                              itemData,
                                              reasonTextEditingController.text,
                                              false);
                                        }
                                      },
                                             color:  AllColor.primaryColor,
                                              textColor: AllColor.white,
                                              text: AllString.add,
                                              width: screenWidth * 0.25))
                                    ],
                                  )),
                            ],
                          ), onCloseButtonPress: () {
                        AppBuilder.of(context)!.rebuild();
                        Navigator.pop(context);
                      });
                    },
                    child: normalText(
                      AllString.reject,
                      color: AllColor.white,
                    ),
                    splashColor: AllColor.red,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10000),
                        side: BorderSide(color: AllColor.red)),
                  ),
                ],
              )
            ],
          )),
    );
  }

  updateStatus(Map<String, dynamic> itemData, String comment, bool accept) {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "dailyPlanId": itemData["dailyPlanId"],
      "dailyStatus": accept ? "1" : "2",
      "rejectedComment": comment
    };
    apiPostRequestWithHeader(
            data, AllUrls.dailyCollaborationStaus, this.context, loginToken)
        .then((response) {
      if (response == null) {
        AppBuilder.of(context)!.rebuild();
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]), function: () {
            Navigator.pop(context);
            fetchCollaboration();
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  showCollaborationList() {
    return Container(
      width: screenWidth,
      height: screenHeight,
      child: Column(
        children: [
          // sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? Container()
              : Container(
                  height: screenWidth * 0.25,
                  child: Column(
                    children: [
                      // dateSelectDisplay(),
                      Container(
                        margin: AllMargin.customVertical(),
                        child: Column(
                          children: [
                            textFieldHeader(AllString.selectMember,
                                fontWeight: FontWeight.bold, center: true),
                            Container(
                              width: screenWidth,
                              child: Container(
                                child: DropdownButtonWithSearch(
                                  icon: LineIcons.sortAmountDown,
                                  selectedValue: selectTeamMember,
                                  dropdownList: teamMemberList,
                                  onChanged: onTeamMemberChanged,
                                ),
                              ),
                              // child: dropdownButton(teamMemberList,
                              //     onTeamMemberChanged, selectTeamMember)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
          Container(
            height:
                // sharedPreferences!
                //             .getString(AllSharedPreferencesKey.individualTypeId)
                //             .toString() ==
                //         "18"
                sharedPreferences!
                                .getString(
                                    AllSharedPreferencesKey.individualTypeId)
                                .toString() !=
                            "16" &&
                        sharedPreferences!
                                .getString(
                                    AllSharedPreferencesKey.individualTypeId)
                                .toString() !=
                            "17"
                    ? screenHeight - 100
                    : screenHeight - (screenWidth * 0.55),
            // margin: AllMargin.customMarginCardItemSameSmall(),
            // decoration: BoxDecoration(
            //     color: AllColor.primaryColor,
            //     borderRadius: BorderRadius.only(
            //         topLeft: Radius.circular(10),
            //         topRight: Radius.circular(10),
            //         bottomLeft: Radius.circular(10),
            //         bottomRight: Radius.circular(10))),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Container(
                //   width: screenWidth,
                //   margin: EdgeInsets.symmetric(
                //       horizontal: screenWidth * 0.02,
                //       vertical: screenHeight * 0),
                //   alignment: Alignment.center,
                //   height: screenWidth * 0.15,
                //   child: Column(
                //     mainAxisAlignment:
                //         MainAxisAlignment.center,
                //     crossAxisAlignment:
                //         CrossAxisAlignment.center,
                //     children: [
                //       headingText("Collaboration",
                //           fontWeight: FontWeight.bold,
                //           center: true,
                //           color: AllColor.white),
                //       smallText(
                //           convertStringToDate(DateTime.now()),
                //           center: true,
                //           color: AllColor.greyColor),
                //     ],
                //   ),
                // ),
                Container(
                  height:
                      // sharedPreferences!
                      //             .getString(
                      //                 AllSharedPreferencesKey.individualTypeId)
                      //             .toString() ==
                      //         "18"
                      sharedPreferences!
                                      .getString(AllSharedPreferencesKey
                                          .individualTypeId)
                                      .toString() !=
                                  "16" &&
                              sharedPreferences!
                                      .getString(AllSharedPreferencesKey
                                          .individualTypeId)
                                      .toString() !=
                                  "17"
                          ? screenHeight - 100
                          : screenHeight - (screenWidth * 0.55),

                  // height: screenWidth * 1.6,
                  child: _collaborationList.isEmpty
                      ? commonNoDataFound()
                      : ListView.builder(
                          padding: AllMargin.customMarginCardItemSameSmall(),
                          physics: BouncingScrollPhysics(),
                          itemCount: _collaborationList.length,
                          itemBuilder: (context, index) =>
                              TeamCollaborationView(
                                selectTeamMember: selectTeamMember,
                                index: index,
                                itemData: _collaborationList[index],
                              )),
                ),
              ],
            ),
          ),
          // Container(
          //       height: screenWidth * 0.82,
          //       margin: AllMargin.customMarginCardItemSameSmall(),
          //       decoration: BoxDecoration(
          //           color: AllColor.primaryColor,
          //           borderRadius: BorderRadius.only(
          //               topLeft: Radius.circular(10),
          //               topRight: Radius.circular(10),
          //               bottomLeft: Radius.circular(10),
          //               bottomRight: Radius.circular(10))),
          //       child: Column(
          //         mainAxisAlignment: MainAxisAlignment.center,
          //         crossAxisAlignment: CrossAxisAlignment.center,
          //         children: [
          //           Container(
          //             width: screenWidth,
          //             margin: EdgeInsets.symmetric(
          //                 horizontal: screenWidth * 0.02,
          //                 vertical: screenHeight * 0),
          //             alignment: Alignment.center,
          //             height: screenWidth * 0.15,
          //             child: Column(
          //               mainAxisAlignment:
          //                   MainAxisAlignment.center,
          //               crossAxisAlignment:
          //                   CrossAxisAlignment.center,
          //               children: [
          //                 headingText("Collaborator",
          //                     fontWeight: FontWeight.bold,
          //                     center: true,
          //                     color: AllColor.white),
          //                 smallText(
          //                     convertStringToDate(DateTime.now()),
          //                     center: true,
          //                     color: AllColor.greyColor),
          //               ],
          //             ),
          //           ),
          //           Container(
          //             height: screenWidth * 0.65,
          //             child: ListView.builder(
          //                 padding: AllMargin
          //                     .customMarginCardItemSameSmall(),
          //                 physics: BouncingScrollPhysics(),
          //                 itemCount: 5,
          //                 itemBuilder: (context, index) =>
          //                     TeamCollaborationView(
          //           index: index,
          //           itemData: {},
          //         )),
          //           ),

          //         ],
          //       ),
          //     ),
        ],
      ),
    );
  }
}

class TeamCollaborationView extends StatefulWidget {
  final Map<String, dynamic> itemData;
  final int index;
  final String selectTeamMember;
  const TeamCollaborationView(
      {Key? key,
      required this.index,
      required this.selectTeamMember,
      required this.itemData})
      : super(key: key);

  @override
  State<TeamCollaborationView> createState() => _TeamCollaborationViewState();
}

class _TeamCollaborationViewState extends State<TeamCollaborationView> {
  String statusValue = AllString.select;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
        decoration: BoxDecoration(
            color: showValidValue(widget.itemData["dailyStatus"]) == "2"
                ? Color(0xffffebee)
                : Color(0xffe8f5e9),
            borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        padding: AllMargin.customMarginCardItem(),
        child: ExpansionTile(
          title: Container(
            width: screenWidth * 0.85,
            child: Column(
              children: [
                Container(
                  width: screenWidth * 0.85,
                  child: Text(
                    showValidValue(widget.itemData["planTitle"]),
                    textAlign: TextAlign.justify,
                    style: normal2TextStyle(
                        color: AllColor.black,
                        fontWeight: FontWeight.bold,
                        lineThrough:
                            statusValue.split(AllString.splitText).first ==
                                    "Success"
                                ? true
                                : false),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: screenWidth * 0.25,
                      child: Text(
                        widget.selectTeamMember
                                    .split(AllString.splitText)
                                    .first ==
                                AllString.select
                            ? "You"
                            : widget.selectTeamMember
                                .split(AllString.splitText)
                                .first,
                        textAlign: TextAlign.justify,
                        style: normal2TextStyle(
                            color: AllColor.black,
                            lineThrough:
                                statusValue.split(AllString.splitText).first ==
                                        "Success"
                                    ? true
                                    : false),
                      ),
                    ),
                    Container(
                        width: screenWidth * 0.1,
                        child:
                            //  widget.index % 2 == 0
                            //     ? normalIcon(Icons.arrow_back,
                            //         color: AllColor.black)
                            //     :
                            normalIcon(Icons.arrow_forward,
                                color: AllColor.black)),
                    Container(
                      width: screenWidth * 0.25,
                      child: Text(
                        showValidValue(widget.itemData["collaboration"]),
                        textAlign: TextAlign.justify,
                        style: normal2TextStyle(
                            color: AllColor.black,
                            lineThrough:
                                statusValue.split(AllString.splitText).first ==
                                        "Success"
                                    ? true
                                    : false),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          children: <Widget>[
            Container(
              width: screenWidth * 0.85,
              child: Text(
                showValidValue(widget.itemData["planDesc"]),
                textAlign: TextAlign.justify,
                style: normal2TextStyle(
                    color: AllColor.greyColor,
                    lineThrough: statusValue.split(AllString.splitText).first ==
                            "Success"
                        ? true
                        : false),
              ),
            ),
            Container(
              width: screenWidth * 0.85,
              child: Center(
                child: Text(
                  "Reason",
                  textAlign: TextAlign.justify,
                  style: normal2TextStyle(
                      color: AllColor.black,
                      lineThrough:
                          statusValue.split(AllString.splitText).first ==
                                  "Success"
                              ? true
                              : false),
                ),
              ),
            ),
            Divider(),
            showValidValue(widget.itemData["dailyStatus"]) == "2"
                ? Container(
                    width: screenWidth * 0.85,
                    child: Text(
                      showValidValue(widget.itemData["rejectedComment"]),
                      textAlign: TextAlign.justify,
                      style: normal2TextStyle(
                          color: AllColor.red, fontWeight: FontWeight.bold),
                    ),
                  )
                : Container()
            // customRowDetails(
            //     width: screenWidth * 0.75,
            //     widthTitle: screenWidth * 0.23,
            //     title: "Time",
            //     value: "02:30".toString()),
            // customRowDetails(
            //     width: screenWidth * 0.75,
            //     widthTitle: screenWidth * 0.23,
            //     title: "Collaboration",
            //     value: "NA".toString()),
          ],
        ),
      ),
    );
  }
}
