import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/workPlan/evaluation/evaluationDetails.dart';
import 'package:hr/pages/workPlan/workPlan.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/pages/workPlan/workPlanDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class Evaluation extends StatefulWidget {
  final Map meetingSingleData;
  final String teamMember;
  const Evaluation(
      {Key? key, required this.meetingSingleData, required this.teamMember})
      : super(key: key);
  @override
  _EvaluationState createState() => _EvaluationState();
}

class _EvaluationState extends State<Evaluation> {
  @override
  void initState() {
    super.initState();
    fetchGoalList();
  }

  bool loading = false;
  List _evaluationList = [];
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.push(
            context,
            CupertinoPageRoute(
                builder: (context) => WorkPlanDetails(
                      meetingSingleData: widget.meetingSingleData,
                    )));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, "Evaluation", onBackPress: () {
          Navigator.push(
              context,
              CupertinoPageRoute(
                  builder: (context) => WorkPlanDetails(
                        meetingSingleData: widget.meetingSingleData,
                      )));
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                   decoration:customBackgroundGradient(),

            child: Container(
              margin: AllMargin.customMarginCardItem(),
              child: _evaluationList.isEmpty
                  ? commonNoDataFound()
                  : GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 1,
                        mainAxisSpacing: 1,
                        childAspectRatio: 1,
                      ),
                      physics: BouncingScrollPhysics(),
                      padding: EdgeInsets.zero,
                      itemCount: _evaluationList.length,
                      itemBuilder: (context, index) =>
                          itemView(_evaluationList[index], index)),
            ),
          ),
        ),
      ),
    );
  }

  itemView(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => EvaluationDetails(
                  meetingSingleData: widget.meetingSingleData,
                  teamMember: widget.teamMember,
                  evalutationData: itemData,
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Container(
              //   child: headingText("Week "+ (index + 1).toString(),
              //       color: AllColor.black, fontWeight: FontWeight.bold),
              // ),
              // Divider(),
              Container(
                alignment: Alignment.center,
                child: normal2Text(
                  showValidValue(itemData["goalEvaluationName"]),
                  center: true,
                  fontWeight: FontWeight.bold,
                  color: AllColor.black,
                ),
              ),
              Divider(),
              Container(
                alignment: Alignment.center,
                child: normalText(
                  validValue(itemData["evaluateDate"])
                      ? convertStringToDate(
                          DateTime.parse(itemData["evaluateDate"]))
                      : AllString.na,
                  center: true,
                  color: AllColor.greyColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  fetchGoalList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          (sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17")
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.teamMember.split(AllString.splitText).last,
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
    };
    apiPostRequestWithHeader(
            data, AllUrls.allEvaluations, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _evaluationList.clear();
          if (jsonData["data"].toString() == "") {
            _evaluationList.clear();
          } else {
            _evaluationList = jsonData["data"];
          }
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}
