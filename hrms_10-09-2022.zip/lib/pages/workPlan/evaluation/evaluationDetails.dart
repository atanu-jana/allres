import 'dart:convert';
import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/workPlan/evaluation/addEvaluation.dart';
import 'package:hr/pages/workPlan/evaluation/evaluation.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/tabbarWidget.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

bool _loadingEvaluation = false;
Map<String, dynamic> _currentPlanMap = {};
Map<String, dynamic> _upcomingPlanMap = {};

class EvaluationDetails extends StatefulWidget {
  final Map meetingSingleData;
  final Map evalutationData;
  final String teamMember;

  const EvaluationDetails(
      {Key? key,
      required this.meetingSingleData,
      required this.teamMember,
      required this.evalutationData})
      : super(key: key);
  @override
  _EvaluationDetailsState createState() => _EvaluationDetailsState();
}

class _EvaluationDetailsState extends State<EvaluationDetails>
    with TickerProviderStateMixin {
  TabController? _controller;
  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(milliseconds: 100), () {
      _currentPlanMap = {};
      _upcomingPlanMap = {};
      fetchEvaluationDetails(
        context,
        goalEvaluationId: widget.evalutationData["goalEvaluationId"].toString(),
        individualId: widget.teamMember.split(AllString.splitText).last,
        teamMeetingId: widget.meetingSingleData["teamMeetingId"].toString(),
      );
    });

    _controller = TabController(initialIndex: 0, length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => Evaluation(
                meetingSingleData: widget.meetingSingleData,
                teamMember: widget.teamMember)));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(
            context,
            showValidValue(widget.evalutationData["goalEvaluationName"]) , onBackPress: () {
          Navigator.of(context).push(CupertinoPageRoute(
              builder: (context) => Evaluation(
                  meetingSingleData: widget.meetingSingleData,
                  teamMember: widget.teamMember)));
        }),
        body: LoadingOverlay(
          isLoading: _loadingEvaluation,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
                        decoration:customBackgroundGradient(),

              child: Stack(
                children: [
                  // Container(
                  //   height: screenHeight,
                  //   child: Column(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     crossAxisAlignment: CrossAxisAlignment.center,
                  //     children: [
                  //       Container(
                  //         height: screenWidth * 0.45,
                  //         margin: AllMargin.customMarginCardItemSameSmall(),
                  //         padding: AllMargin.customMarginCardItemSameSmall(),
                  //         decoration: BoxDecoration(
                  //             color: AllColor.primaryColor,
                  //             borderRadius: BorderRadius.only(
                  //                 topLeft: Radius.circular(10),
                  //                 topRight: Radius.circular(10),
                  //                 bottomLeft: Radius.circular(10),
                  //                 bottomRight: Radius.circular(10))),
                  //         child: Column(
                  //           mainAxisAlignment: MainAxisAlignment.center,
                  //           crossAxisAlignment: CrossAxisAlignment.center,
                  //           children: [
                  //             Container(
                  //               width: screenWidth,
                  //               margin: EdgeInsets.symmetric(
                  //                   horizontal: screenWidth * 0.02,
                  //                   vertical: screenHeight * 0),
                  //               alignment: Alignment.center,
                  //               height: screenWidth * 0.1,
                  //               child: headingText("Week 1",
                  //               center: true,
                  //                   color: AllColor.greyColor),
                  //             ),
                  // Container(

                  //   height: screenWidth * 0.3,
                  //   child: ListView.builder(
                  //     scrollDirection: Axis.horizontal,
                  //       padding:
                  //           AllMargin.customMarginCardItemSameSmall(),
                  //       physics: BouncingScrollPhysics(),
                  //       itemCount: 5,
                  //       itemBuilder: (context, index) =>
                  //           EvolutionDetailsTile(
                  //             index: index,
                  //             itemData: {},
                  //           )),
                  // ),
                  //           ],
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  _currentPlanMap.isEmpty ||
                          _upcomingPlanMap.isEmpty ||
                          _currentPlanMap["data"].isEmpty ||
                          _upcomingPlanMap["data"].isEmpty
                      ? commonNoDataFound()
                      : planTabView(),
                  _currentPlanMap.isEmpty ||
                          _upcomingPlanMap.isEmpty ||
                          _currentPlanMap["data"].isEmpty ||
                          _upcomingPlanMap["data"].isEmpty
                      ? Container()
                      :   !(checkAddButton())
                          ? Container()
                          : Positioned(
                              bottom: screenWidth * 0.05,
                              right: screenWidth * 0.05,
                              child: FloatingActionButton(
                                onPressed: () {
                                  Navigator.of(context).push(CupertinoPageRoute(
                                      builder: (context) => AddEvaluation(
                                            onBackPress: () {
                                              Navigator.push(
                                                  context,
                                                  CupertinoPageRoute(
                                                      builder: (context) =>
                                                          EvaluationDetails(
                                                              meetingSingleData:
                                                                  widget
                                                                      .meetingSingleData,
                                                              teamMember: widget
                                                                  .teamMember,
                                                              evalutationData:
                                                                  widget
                                                                      .evalutationData)));
                                            },
                                            evalutationData:
                                                widget.evalutationData,
                                            meetingSingleData:
                                                widget.meetingSingleData,
                                            weekId: _controller!.index == 0
                                                ? _currentPlanMap["weekId"]
                                                    .toString()
                                                : _upcomingPlanMap["weekId"]
                                                    .toString(),
                                            weekName: _controller!.index == 0
                                                ? _currentPlanMap["weekName"]
                                                    .toString()
                                                : _upcomingPlanMap["weekName"]
                                                    .toString(),
                                          )));
                                  // planAddOptionAlert();
                                },
                                child: normalIcon(Icons.add),
                                backgroundColor: AllColor.primaryDeepColor,
                              )),
                ],
              )),
        ),
      ),
    );
  }

  bool checkAddButton() {
    if(_controller!.index == 0){
 
    if ((((widget.teamMember.split(AllString.splitText).last ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)!) ||
            // sharedPreferences!
            //         .getString(AllSharedPreferencesKey.individualTypeId) ==
            //     "18"
                  sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "16"&&sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "17"
                ) &&
        ((DateTime.now().isAfter(convertDateTimeToString(_currentPlanMap["startDate"])) &&
                DateTime.now().isBefore(convertDateTimeToString(
                    _currentPlanMap["endDate"]))) ||
            ((formatter.format(DateTime.now()) ==
                formatter.format(convertDateTimeToString(
                    _currentPlanMap["startDate"])))) ||
            (formatter.format(DateTime.now()) ==
                formatter.format(convertDateTimeToString(
                    _currentPlanMap["endDate"])))))) {
      return true;
    } else {
      return false;
    }
    }else{
      if ((((widget.teamMember.split(AllString.splitText).last ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)!) ||
            // sharedPreferences!
            //         .getString(AllSharedPreferencesKey.individualTypeId) ==
            //     "18"
                sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "16"&&sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "17"
                ) &&
        ((DateTime.now().isAfter(convertDateTimeToString(_upcomingPlanMap["startDate"])) &&
                DateTime.now().isBefore(convertDateTimeToString(
                    _upcomingPlanMap["endDate"]))) ||
            ((formatter.format(DateTime.now()) ==
                formatter.format(convertDateTimeToString(
                    _upcomingPlanMap["startDate"])))) ||
            (formatter.format(DateTime.now()) ==
                formatter.format(convertDateTimeToString(
                    _upcomingPlanMap["endDate"])))))) {
      return true;
    } else {
      return false;
    }
    }



  
    // // if (_controller!.index == 0) {
    // if (index == 0) {
    //   if
    //       // (((widget.teamMember.split(AllString.splitText).last ==
    //       //             sharedPreferences!
    //       //                 .getString(AllSharedPreferencesKey.individualId)!) ||
    //       //         sharedPreferences!
    //       //                 .getString(AllSharedPreferencesKey.individualTypeId) ==
    //       //             "18") &&
    //       //     DateTime.now()
    //       //         .isAfter(convertDateTimeToString(_currentPlanMap["startDate"])) &&
    //       //     DateTime.now()
    //       //         .isBefore(convertDateTimeToString(_currentPlanMap["endDate"])))

    //       (((widget.teamMember.split(AllString.splitText).last ==
    //                   sharedPreferences!
    //                       .getString(AllSharedPreferencesKey.individualId)!) ||
    //               sharedPreferences!.getString(AllSharedPreferencesKey.individualTypeId) ==
    //                   "18") &&
    //           ((DateTime.now().isAfter(convertDateTimeToString(
    //                       _currentPlanMap["startDate"])) &&
    //                   DateTime.now().isBefore(convertDateTimeToString(
    //                       _currentPlanMap["endDate"]))) ||
    //               ((formatter.format(DateTime.now()) ==
    //                   formatter.format(convertDateTimeToString(
    //                       _currentPlanMap["startDate"])))) ||
    //               (formatter.format(DateTime.now()) ==
    //                   formatter.format(
    //                       convertDateTimeToString(_currentPlanMap["endDate"]))))) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // } else if (index == 1) {
    //   if
    //       // (((widget.teamMember.split(AllString.splitText).last ==
    //       //             sharedPreferences!
    //       //                 .getString(AllSharedPreferencesKey.individualId)!) ||
    //       //         sharedPreferences!
    //       //                 .getString(AllSharedPreferencesKey.individualTypeId) ==
    //       //             "18") &&
    //       //     DateTime.now().isAfter(
    //       //         convertDateTimeToString(_upcomingPlanMap["startDate"])) &&
    //       //     DateTime.now()
    //       //         .isBefore(convertDateTimeToString(_upcomingPlanMap["endDate"])))
    //       (((widget.teamMember.split(AllString.splitText).last ==
    //                   sharedPreferences!
    //                       .getString(AllSharedPreferencesKey.individualId)!) ||
    //               sharedPreferences!.getString(AllSharedPreferencesKey.individualTypeId) ==
    //                   "18") &&
    //           ((DateTime.now().isAfter(convertDateTimeToString(
    //                       _upcomingPlanMap["startDate"])) &&
    //                   DateTime.now().isBefore(convertDateTimeToString(
    //                       _upcomingPlanMap["endDate"]))) ||
    //               ((formatter.format(DateTime.now()) ==
    //                   formatter.format(convertDateTimeToString(
    //                       _upcomingPlanMap["startDate"])))) ||
    //               (formatter.format(DateTime.now()) ==
    //                   formatter.format(
    //                       convertDateTimeToString(_upcomingPlanMap["endDate"]))))) {
    //     return true;
    //   } else {
    //     return false;
    //   }
    // } else {
    //   return false;
    // }
  }

  planTabView() {
    return Container(
      margin: AllMargin.customMarginCardItem(),
      decoration: BoxDecoration(
          color:
          _controller!.index == 0
                  ?  Color(0xffe1f5fe)
                  : Color(0xfffbe9e7),
              // _controller!.index == 0 ? AllColor.primaryColor : AllColor.indigo,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(35),
              topRight: Radius.circular(35),
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10))),
      child: ClipRRect(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(35),
            topRight: Radius.circular(35),
            bottomLeft: Radius.circular(10),
            bottomRight: Radius.circular(10)),
        child: ListView(
          shrinkWrap: true,
          children: [
            MyTabBar(
              controller: _controller!,
              labels: [
                showValidValue(_currentPlanMap["weekName"]),
                showValidValue(_upcomingPlanMap["weekName"])
              ],
              backgroundColor: AllColor.white,
              foregroundColor: _controller!.index == 0
                  ?  Color(0xffe1f5fe)
                  : Color(0xfffbe9e7),
              activeBackgroundColor: _controller!.index == 0
                  ? Color(0xffe1f5fe)
                  : Color(0xfffbe9e7),
              activeForegroundColor: AllColor.white,
              fontSize: screenWidth * 0.04,
            ),
            Container(
              color: _controller!.index == 0
                  ?  Color(0xffe1f5fe)
                  : Color(0xfffbe9e7),
              height: screenWidth * 1.65,
              margin: AllMargin.customBottomSmall(),
              child: TabBarView(
                physics: NeverScrollableScrollPhysics(),
                controller: _controller,
                children: [
                  ListView.builder(
                      padding: AllMargin.customVertical(),
                      physics: BouncingScrollPhysics(),
                      itemCount: _currentPlanMap["data"].length,
                      itemBuilder: (context, index) => EvolutionDetailsTile(
                            teamMember: widget.teamMember,
                            parentItemData: _currentPlanMap,
                            index: index,
                            itemData: _currentPlanMap["data"][index],
                            evalutationData: widget.evalutationData,
                            meetingSingleData: widget.meetingSingleData,
                          )),
                  ListView.builder(
                      padding: AllMargin.customVertical(),
                      physics: BouncingScrollPhysics(),
                      itemCount: _upcomingPlanMap["data"].length,
                      itemBuilder: (context, index) => EvolutionDetailsTile(
                            teamMember: widget.teamMember,
                            evalutationData: widget.evalutationData,
                            meetingSingleData: widget.meetingSingleData,
                            parentItemData: _upcomingPlanMap,
                            index: index,
                            itemData: _upcomingPlanMap["data"][index],
                          ))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  itemView(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            children: [
              Container(
                width: screenWidth * 0.8,
                child: Text(
                  showValidValue(itemData["goalTitle"]),
                  textAlign: TextAlign.justify,
                  style: normal2TextStyle(
                      color: AllColor.black, fontWeight: FontWeight.bold),
                ),
              ),
              Row(
                children: [
                  Container(
                    width: screenWidth * 0.8,
                    child: normal2Text(
                        showValidValue(itemData["goalDescription"]),
                        color: AllColor.greyColor),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // planAddOptionAlert() {
  //   return commonAlertDialogWithCloseButtonWithWidget(
  //       context,
  //       AllColor.red,
  //       Column(
  //         children: [
  //           ListTile(
  //             onTap: () {
  //               Navigator.pop(context);
  //               Navigator.of(context).push(CupertinoPageRoute(
  //                   builder: (context) => AddEvaluation(newPlan: true)));
  //             },
  //             contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //             leading: normalIcon(Icons.fiber_new_outlined,
  //                 color: AllColor.primaryColor),
  //             title: normalText(AllString.neww, color: AllColor.black),
  //           ),
  //           Divider(),
  //           ListTile(
  //             onTap: () {
  //               Navigator.pop(context);

  //               Navigator.of(context).push(CupertinoPageRoute(
  //                   builder: (context) => AddEvaluation(newPlan: false)));
  //             },
  //             contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //             leading: normalIcon(Icons.e_mobiledata_outlined,
  //                 color: AllColor.primaryColor),
  //             title: normalText(AllString.existing, color: AllColor.black),
  //           ),
  //         ],
  //       ), onCloseButtonPress: () {
  //     Navigator.pop(context);
  //   });
  // }

}

class EvolutionDetailsTile extends StatefulWidget {
  final Map<String, dynamic> parentItemData;
  final Map<String, dynamic> itemData;
  final String teamMember;
  final Map meetingSingleData;
  final Map evalutationData;
  final int index;
  const EvolutionDetailsTile(
      {Key? key,
      required this.index,
      required this.teamMember,
      required this.parentItemData,
      required this.meetingSingleData,
      required this.evalutationData,
      required this.itemData})
      : super(key: key);

  @override
  State<EvolutionDetailsTile> createState() => _EvolutionDetailsTileState();
}

class _EvolutionDetailsTileState extends State<EvolutionDetailsTile> {
  String tempStatusValue = AllString.select;
  String statusValue = AllString.select;
  bool displayFailure = false;
  @override
  void initState() {
    tempStatusValue = validValue(widget.itemData["statusName"])
        ? widget.itemData["statusName"] +
            AllString.splitText +
            widget.itemData["statusId"].toString()
        : AllString.select;
    statusValue = validValue(widget.itemData["statusName"])
        ? widget.itemData["statusName"] +
            AllString.splitText +
            widget.itemData["statusId"].toString()
        : AllString.select;
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: screenWidth,
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            children: [
              Container(
                width: screenWidth * 0.8,
                child: Text(
//                   widget.parentItemData["startDate"] +
//                       " " +
//                       widget.parentItemData["endDate"] +
//                       " " +
//                       "isAfter: " +
//  DateTime.now()
//                           .isAfter(convertDateTimeToString(
//                               widget.parentItemData["startDate"]))
//                           .toString() +
//                       " isBefore " +
//                      DateTime.now()
//                           .isBefore(convertDateTimeToString(
//                               widget.parentItemData["endDate"]))
//                           .toString(),
                  showValidValue(widget.itemData["goalTitle"]),
                  textAlign: TextAlign.justify,
                  style: normal2TextStyle(
                      color: AllColor.black, fontWeight: FontWeight.bold),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: screenWidth * 0.65,
                    child: Text(
                      showValidValue(widget.itemData["goalDescription"]),
                      textAlign: TextAlign.justify,
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                      style: normal2TextStyle(
                          color: AllColor.greyColor,
                          lineThrough:
                              statusValue.split(AllString.splitText).first ==
                                      "Success"
                                  ? true
                                  : false),
                    ),
                  ),
                  // convertDateTimeToString(widget.parentItemData["startDate"])
                  // .difference(convertDateTimeToString(
                  //     widget.parentItemData["endDate"]))
                  //             .inDays >=
                  //         0
                  // if ((widget.teamMember.split(AllString.splitText).last ==
                  //         sharedPreferences!.getString(
                  //             AllSharedPreferencesKey.individualId)! )&&
                  //     (DateTime.now().isAfter(convertDateTimeToString(
                  //             widget.parentItemData["startDate"])) &&
                  //         DateTime.now().isBefore(convertDateTimeToString(
                  //             widget.parentItemData["endDate"]))))
                  if (statusVisible())
                    // if (!convertDateTimeToString(
                    //         widget.parentItemData["endDate"])
                    //     .isBefore(DateTime.now()))
                    Container(
                        width: screenWidth * 0.15,
                        alignment: Alignment.center,
                        child: GestureDetector(
                            onTap: () {
                              if (statusValue
                                      .split(AllString.splitText)
                                      .first
                                      .toLowerCase() ==
                                  "failure") {
                                fetchFailureData(false);
                                Future.delayed(Duration(milliseconds: 600), () {
                                  statusUpdateDialog();
                                });
                              } else {
                                statusUpdateDialog();
                              }
                            },
                            child: Container(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Icon(Icons.update_rounded),
                                  Container(
                                    width: screenWidth * 0.15,
                                    alignment: Alignment.center,
                                    child: smallText(
                                        statusValue
                                            .split(AllString.splitText)
                                            .first,
                                        center: true,
                                        fontWeight: FontWeight.bold,
                                        color: statusColor(statusValue
                                            .split(AllString.splitText)
                                            .first)),
                                  )
                                ],
                              ),
                            ))
                        // Container(
                        //   child: dropdownButton(status, onDropdownChange, "Success")),
                        )
                  else
                    GestureDetector(
                      onTap: () {
                        if (statusValue
                                .split(AllString.splitText)
                                .first
                                .toLowerCase() ==
                            "failure") {
                          if (!displayFailure) {
                            fetchFailureData(true);
                          } else {
                            displayFailure = false;
                            setState(() {});
                          }
                        }
                      },
                      child: Container(
                        width: screenWidth * 0.15,
                        alignment: Alignment.center,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: screenWidth * 0.15,
                              alignment: Alignment.center,
                              child: smallText(
                                  statusValue.split(AllString.splitText).first,
                                  fontWeight: FontWeight.bold,
                                  center: true,
                                  color: statusColor(statusValue
                                      .split(AllString.splitText)
                                      .first)),
                            ),
                            statusValue
                                        .split(AllString.splitText)
                                        .first
                                        .toLowerCase() ==
                                    "failure"
                                ? Container(
                                    width: screenWidth * 0.15,
                                    alignment: Alignment.center,
                                    child: normalIcon(Icons.expand_more_rounded,
                                        color: AllColor.greyColor))
                                : Container(),
                          ],
                        ),
                      ),
                    )
                ],
              ),
              !displayFailure
                  ? Container()
                  : Column(
                      children: [
                        Divider(),
                        Container(
                          padding: AllMargin.customMarginCardItemSameSmall(),
                          margin: AllMargin.customVerticalSmall(),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: AllColor.lightBlack),
                          child: Column(
                            children: [
                              questionAnd("What was missing from your end?",
                                  reason1TextEditingController.text),
                              questionAnd("What did you learn?",
                                  reason2TextEditingController.text),
                              questionAnd("What will you do differently?",
                                  reason3TextEditingController.text),
                              questionAnd("What will you get done and by when?",
                                  reason4TextEditingController.text)
                            ],
                          ),
                        ),
                      ],
                    )
            ],
          ),
        ),
      ),
    );
  }

  Widget questionAnd(String question, String answer) {
    return Container(
      width: screenWidth,
      padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: screenWidth * 0.8,
            child: normal2Text(question,
                fontWeight: FontWeight.bold, color: AllColor.black),
          ),
          Container(
            width: screenWidth * 0.8,
            child: normalText(answer,
                fontWeight: FontWeight.w400, color: AllColor.greyColor),
          ),
        ],
      ),
    );
  }

  onDropdownChange(String? value) {
    statusValue = value!;
    setState(() {});
    AppBuilder.of(context)!.rebuild();
    Navigator.pop(context);
    statusUpdateDialog();
  }

  TextEditingController reason1TextEditingController = TextEditingController();
  TextEditingController reason2TextEditingController = TextEditingController();
  TextEditingController reason3TextEditingController = TextEditingController();
  TextEditingController reason4TextEditingController = TextEditingController();

  statusUpdateDialog() {
    return commonAlertDialogWithCloseButtonWithWidget(
        context,
        AllColor.red,
        Container(
          child: ListView(
            shrinkWrap: true,
            children: [
              textFieldHeader(AllString.status, fontWeight: FontWeight.bold),
              dropdownButton(status, onDropdownChange, statusValue),
              if (statusValue.split(AllString.splitText).first == "Failure")
                Container(
                  height: screenWidth * 0.8,
                  child: ListView(
                    shrinkWrap: true,
                    physics: BouncingScrollPhysics(),
                    children: [
                      textFieldHeader("What was missing from your end?",
                          fontWeight: FontWeight.bold),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.typeHere,
                            reason1TextEditingController,
                            4,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                      textFieldHeader("What did you learn?",
                          fontWeight: FontWeight.bold),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.typeHere,
                            reason2TextEditingController,
                            4,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                      textFieldHeader("What will you do differently?",
                          fontWeight: FontWeight.bold),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.typeHere,
                            reason3TextEditingController,
                            4,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                      textFieldHeader("What will you get done and by when?",
                          fontWeight: FontWeight.bold),
                      Container(
                        margin: EdgeInsets.symmetric(
                          vertical: screenWidth * 0.0,
                          horizontal: screenWidth * 0.03,
                        ),
                        child: Center(
                          child: textAreaField(
                            context,
                            AllString.typeHere,
                            reason4TextEditingController,
                            4,
                            200,
                            TextInputAction.done,
                            TextInputType.text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              Container(
                  margin: EdgeInsets.symmetric(
                    vertical: screenWidth * 0.015,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                          child: button(context, function: () {
                        statusValue = tempStatusValue;
                        AppBuilder.of(context)!.rebuild();
                        Navigator.pop(context);
                      },
                              color:AllColor.red,

                              textColor: AllColor.white,
                              text: AllString.cancel,
                              width: screenWidth * 0.25)),
                      Container(
                          child: button(context, function: () {
                        if (validateAndProceed()) {
                          Navigator.pop(context);
                          updateStatus();
                        }
                      },
                           color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                              textColor: AllColor.white,
                              text: AllString.add,
                              width: screenWidth * 0.25))
                    ],
                  )),
            ],
          ),
        ), onCloseButtonPress: () {
      statusValue = tempStatusValue;
      AppBuilder.of(context)!.rebuild();
      Navigator.pop(context);
    });
  }

  bool validateAndProceed() {
    if (statusValue == AllString.select) {
      return false;
    } else if (statusValue.split(AllString.splitText).first == "Failure") {
      if (reason1TextEditingController.text.isNotEmpty ||
          reason2TextEditingController.text.isNotEmpty ||
          reason3TextEditingController.text.isNotEmpty ||
          reason4TextEditingController.text.isNotEmpty) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  updateStatus() {
    // log("evalutationData: " + widget.evalutationData.toString());
    // log("parentItemData: " + widget.  parentItemData .toString());
    // log("itemData: " + widget.itemData.toString());
    setState(() {
      _loadingEvaluation = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
      "statusId": statusValue.split(AllString.splitText).last,
      "goalScheduleId": widget.itemData["goalScheduleId"],
      "goalEvaluationId": widget.evalutationData["goalEvaluationId"],
      "goalId": widget.itemData["goalId"],
      "missing": reason1TextEditingController.text,
      "learn": reason2TextEditingController.text,
      "differently": reason3TextEditingController.text,
      "done": reason4TextEditingController.text,
    };

    apiPostRequestWithHeader(
            data, AllUrls.updateWeekStatus, this.context, loginToken)
        .then((response) {
      if (response == null) {
        statusValue = tempStatusValue;
        AppBuilder.of(context)!.rebuild();
        _loadingEvaluation = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]));
          fetchEvaluationDetails(
            context,
            goalEvaluationId:
                widget.evalutationData["goalEvaluationId"].toString(),
            individualId: widget.teamMember.split(AllString.splitText).last,
            teamMeetingId: widget.meetingSingleData["teamMeetingId"].toString(),
          );
          setState(() {
            _loadingEvaluation = false;
          });
        } else {
          statusValue = tempStatusValue;
          AppBuilder.of(context)!.rebuild();
          setState(() {
            _loadingEvaluation = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchFailureData(bool open) {
    setState(() {
      _loadingEvaluation = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
      //  sharedPreferences!
      //             .getString(AllSharedPreferencesKey.individualTypeId)
      //             .toString() ==
      //         "18"
        sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "16"&&sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "17"
          ? sharedPreferences!.getString(AllSharedPreferencesKey.individualId)
          : widget.teamMember.split(AllString.splitText).last,
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
      "goalScheduleId": widget.itemData["goalScheduleId"],
      "goalEvaluationId": widget.evalutationData["goalEvaluationId"],
      "goalId": widget.itemData["goalId"],
    };

    apiPostRequestWithHeader(
            data, AllUrls.getFailureStatus, this.context, loginToken)
        .then((response) {
      if (response == null) {
        statusValue = tempStatusValue;
        AppBuilder.of(context)!.rebuild();
        _loadingEvaluation = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          reason1TextEditingController.text =
              showValidValue(jsonData["failureStatus"][0]["missing"]);
          reason2TextEditingController.text =
              showValidValue(jsonData["failureStatus"][0]["learn"]);
          reason3TextEditingController.text =
              showValidValue(jsonData["failureStatus"][0]["different"]);
          reason4TextEditingController.text =
              showValidValue(jsonData["failureStatus"][0]["done"]);
          if (open) {
            displayFailure = true;
            setState(() {});
          } else {
            displayFailure = false;
            setState(() {});
          }
          setState(() {
            _loadingEvaluation = false;
          });
        } else {
          statusValue = tempStatusValue;
          AppBuilder.of(context)!.rebuild();
          setState(() {
            _loadingEvaluation = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  bool statusVisible() {
    if ((((widget.teamMember.split(AllString.splitText).last ==
                sharedPreferences!
                    .getString(AllSharedPreferencesKey.individualId)!) ||
            // sharedPreferences!
            //         .getString(AllSharedPreferencesKey.individualTypeId) ==
            //     "18"
                  sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "16"&&sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "17"
                ) &&
        ((DateTime.now().isAfter(convertDateTimeToString(widget.parentItemData["startDate"])) &&
                DateTime.now().isBefore(convertDateTimeToString(
                    widget.parentItemData["endDate"]))) ||
            ((formatter.format(DateTime.now()) ==
                formatter.format(convertDateTimeToString(
                    widget.parentItemData["startDate"])))) ||
            (formatter.format(DateTime.now()) ==
                formatter.format(convertDateTimeToString(
                    widget.parentItemData["endDate"])))))) {
      return true;
    } else {
      return false;
    }
  }
}

fetchEvaluationDetails(BuildContext context,
    {required String goalEvaluationId,
    required String teamMeetingId,
    required String individualId}) {
  _loadingEvaluation = true;
  AppBuilder.of(context)!.rebuild();

  Map data = {
    "companyId":
        sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
    "individualId": 
    // sharedPreferences!
    //             .getString(AllSharedPreferencesKey.individualTypeId)
    //             .toString() ==
    //         "18"
      sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "16"&&sharedPreferences!
                                  .getString(
                                      AllSharedPreferencesKey.individualTypeId)
                                  .toString() !=
                              "17"
        ? sharedPreferences!.getString(AllSharedPreferencesKey.individualId)
        : individualId,
    "goalEvaluationId": goalEvaluationId,
    "teamMeetingId": teamMeetingId,
  };
  apiPostRequestWithHeader(
          data, AllUrls.evaluationPlanLists, context, loginToken)
      .then((response) {
    if (response == null) {
      _loadingEvaluation = false;
      AppBuilder.of(context)!.rebuild();

      commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
    } else {
      Map<String, dynamic> jsonData = json.decode(response);
      if (checkApiResponseSuccessOrNot(jsonData)) {
        AppBuilder.of(context)!.rebuild();
        _currentPlanMap.clear();
        _upcomingPlanMap.clear();
        if (jsonData["evolutionData"].toString() == "") {
          _currentPlanMap.clear();
          _upcomingPlanMap.clear();
        } else if (jsonData["evolutionData"]["currentWeek"].toString() == "") {
          _currentPlanMap.clear();
        } else if (jsonData["evolutionData"]["upcomingWeek"].toString() == "") {
          _upcomingPlanMap.clear();
        } else {
          _currentPlanMap = jsonData["evolutionData"]["currentWeek"];
          _upcomingPlanMap = jsonData["evolutionData"]["upcomingWeek"];
          AppBuilder.of(context)!.rebuild();
          _loadingEvaluation = false;
        }

        AppBuilder.of(context)!.rebuild();
      } else {
        _loadingEvaluation = false;
        AppBuilder.of(context)!.rebuild();

        commonAlertDialog(context, jsonData["status"], jsonData["message"]);
      }
    }
  });
}
