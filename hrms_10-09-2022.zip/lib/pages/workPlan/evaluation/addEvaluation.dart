import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class AddEvaluation extends StatefulWidget {
  final String weekId;
  final Map evalutationData;
  final Map meetingSingleData;
  final String weekName;
  final Function() onBackPress;
  const AddEvaluation({
    Key? key,
    required this.weekId,
    required this.evalutationData,
    required this.weekName,
    required this.meetingSingleData,
    required this.onBackPress,
  }) : super(key: key);
  @override
  _AddEvaluationState createState() => _AddEvaluationState();
}

class _AddEvaluationState extends State<AddEvaluation> {
  bool loading = false;
  String selectProject = AllString.select;
  TextEditingController planTextEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Future.delayed(Duration(milliseconds: 200), () {
          widget.onBackPress();
        });
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, "Add New Goal", onBackPress: () {
          widget.onBackPress();
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                   decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Container(
                  width: screenWidth,
                  height: screenHeight,
                  child: Stack(children: [
                    Column(
                      children: [
                        textFieldHeader(AllString.selectProject,
                            fontWeight: FontWeight.bold),
                        Container(
                          child: DropdownButtonWithSearch(
                            icon: LineIcons.sortAmountDown,
                            selectedValue: selectProject,
                            dropdownList: projectList,
                            onChanged: onProjectChanged,
                          ),
                        ),
                        textFieldHeader("Elaborate",
                            fontWeight: FontWeight.bold),
                        Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.typeHere,
                              planTextEditingController,
                              4,
                              200,
                                 TextInputAction.newline,

                              TextInputType.multiline,
                            ),
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.015,
                                horizontal: screenWidth * 0.03),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                    child: button(context, function: () {
                                  resetField();
                                },
                                                                    color:AllColor.red,

                                        textColor: AllColor.white,
                                        text: AllString.reset,
                                        width: screenWidth * 0.3)),
                                Container(
                                    child: button(context, function: () {
                                  if (validateAndProceed()) {
                                    addGoal();
                                  }
                                },
                                  color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                                        textColor: AllColor.white,
                                        text: AllString.add,
                                        width: screenWidth * 0.3))
                              ],
                            )),
                      ],
                    )
                  ]),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool validateAndProceed() {
    if (selectProject == AllString.select ||
        planTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }

  addGoal() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
      "goalScheduleId": widget.weekId,
      "projectId": selectProject.split(AllString.splitText).last,
      "goalTitle": selectProject.split(AllString.splitText).first,
      "goalDescription": planTextEditingController.text,
      "date": formatterForRequest.format(DateTime.now()),
      "goalEvaluationId": widget.evalutationData.isEmpty
          ? ""
          : widget.evalutationData["goalEvaluationId"]
    };
    apiPostRequestWithHeader(
            data, AllUrls.addGoalPlan, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]));
          selectProject = AllString.select;
          planTextEditingController.clear();
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  resetField() {
    planTextEditingController.clear();
    setState(() {});
  }

  onProjectChanged(String? value) {
    selectProject = value!;
    setState(() {});
  }
}
