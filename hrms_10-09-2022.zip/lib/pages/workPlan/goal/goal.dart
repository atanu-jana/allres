import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/workPlan/goal/addGoal.dart';
import 'package:hr/pages/workPlan/goal/goalDetails.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/pages/workPlan/workPlanDetails.dart';

import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class Goal extends StatefulWidget {
  final Map meetingSingleData;
  final String teamMember;

  const Goal(
      {Key? key, required this.meetingSingleData, required this.teamMember})
      : super(key: key);
  @override
  _GoalState createState() => _GoalState();
}

class _GoalState extends State<Goal> {
  @override
  void initState() {
    super.initState();
    fetchGoalList();
  }

  bool loading = false;
  List _goalList = [];
  bool enableAddButton = false;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.push(
            context,
            CupertinoPageRoute(
                builder: (context) => WorkPlanDetails(
                      meetingSingleData: widget.meetingSingleData,
                    )));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, "Goal", onBackPress: () {
          Navigator.push(
              context,
              CupertinoPageRoute(
                  builder: (context) => WorkPlanDetails(
                        meetingSingleData: widget.meetingSingleData,
                      )));
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
                        decoration:customBackgroundGradient(),

              child: Stack(
                children: [
                  Container(
                    width: screenWidth,
                    height: screenHeight,
                                            decoration:customBackgroundGradient(),

                    child: Container(
                      margin: AllMargin.customMarginCardItem(),
                      child: _goalList.isEmpty
                          ? commonNoDataFound()
                          : GridView.builder(
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 1,
                                mainAxisSpacing: 1,
                                childAspectRatio: 1,
                              ),
                              physics: BouncingScrollPhysics(),
                              padding: EdgeInsets.zero,
                              itemCount: _goalList.length,
                              itemBuilder: (context, index) =>
                                  itemView(_goalList[index], index)),
                    ),
                  ),
                  // ListView.builder(
                  //     padding: EdgeInsets.only(bottom: screenWidth * 0.03),
                  //     physics: BouncingScrollPhysics(),
                  //     itemCount: 30,
                  //     itemBuilder: (context, index) => itemView({}, index)),
                  enableAddButton
                      ? ((widget.teamMember == "" ||
                                  widget.teamMember == AllString.select ||
                                  widget.teamMember
                                          .split(AllString.splitText)
                                          .last !=
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey
                                              .individualId)) &&
                              //  sharedPreferences!.getString(
                              // AllSharedPreferencesKey.individualTypeId) !="18"
                              (sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "16" &&
                                  sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "17"))
                          ? Container()
                          : Positioned(
                              bottom: screenWidth * 0.05,
                              right: screenWidth * 0.05,
                              child: FloatingActionButton(
                                onPressed: () {
                                  List<String> goalList = [];
                                  goalList.clear();
                                  goalList.add(AllString.select);
                                  if (_goalList.isNotEmpty) {
                                    _goalList.forEach((element) {
                                      goalList.add(element["goalTitle"]
                                              .toString() +
                                          AllString.splitText +
                                          element["goalScheduleId"].toString());
                                    });
                                  }
                                  Navigator.of(context).push(CupertinoPageRoute(
                                      builder: (context) => AddGoal(
                                            selectedGoal: "",
                                            goalList: goalList,
                                            meetingSingleData:
                                                widget.meetingSingleData,
                                            teamMember: widget.teamMember,
                                          )));
                                  // planAddOptionAlert();
                                },
                                child: normalIcon(Icons.add),
                                backgroundColor: AllColor.primaryDeepColor,
                              ))
                      : Container(),
                ],
              )),
        ),
      ),
    );
  }

  // planAddOptionAlert() {
  //   return commonAlertDialogWithCloseButtonWithWidget(
  //       context,
  //       AllColor.red,
  //       Column(
  //         children: [
  //           ListTile(
  //             onTap: () {
  //               List<String> goalList=[];
  //               if (_goalList.isNotEmpty) {
  //         status.clear();
  //         status.add(AllString.select);

  //           _goalList.forEach((element) {
  //             goalList.add(element["goalTitle"].toString() +
  //                 AllString.splitText +
  //                 element["goalScheduleId"].toString());
  //           });

  //       }
  //               Navigator.pop(context);
  //               Navigator.of(context).push(CupertinoPageRoute(
  //                   builder: (context) => AddGoal(newGoal: true,goalList: goalList,)));
  //             },
  //             contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //             leading: normalIcon(Icons.fiber_new_outlined,
  //                 color: AllColor.primaryColor),
  //             title: normalText(AllString.neww, color: AllColor.black),
  //           ),
  //           Divider(),
  //           ListTile(
  //             onTap: () {
  //               Navigator.pop(context);

  //               Navigator.of(context).push(CupertinoPageRoute(
  //                   builder: (context) => AddGoal(newGoal: false,goalList: goalList)));
  //             },
  //             contentPadding: EdgeInsets.only(left: screenWidth * 0.05),
  //             leading: normalIcon(Icons.e_mobiledata_outlined,
  //                 color: AllColor.primaryColor),
  //             title: normalText(AllString.existing, color: AllColor.black),
  //           ),
  //         ],
  //       ), onCloseButtonPress: () {
  //     Navigator.pop(context);
  //   });
  // }

  // itemView(Map<String, dynamic> itemData, int index) {
  //   String statusValue = status[random.nextInt(status.length)];
  //   return GestureDetector(
  //     child: Container(
  //       padding: EdgeInsets.all(1),
  //       decoration: customCardItemGradinet(),
  //       margin: EdgeInsets.symmetric(
  //           horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
  //       child: Container(
  //         decoration: BoxDecoration(
  //             color: AllColor.white, borderRadius: BorderRadius.circular(10)),
  //         width: screenWidth,
  //         padding: AllMargin.customMarginCardItem(),
  //         child: Row(

  //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //         crossAxisAlignment: CrossAxisAlignment.center,
  //           children: [
  //             Container(
  //               width: screenWidth * 0.7,

  //               child: Text(
  //                   "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is " +
  //                       random.nextInt(100).toString(),
  //                       textAlign: TextAlign.justify,
  //                   style: normal2TextStyle(
  //                   color: AllColor.black,
  //                    lineThrough: statusValue == "Success" ? true : false
  //                   ),
  //             ),
  //             ),

  //           Container(
  //               width: screenWidth * 0.15,
  //               alignment: Alignment.center,
  //               child:  Container(

  //                     child: Column(
  //                       mainAxisAlignment: MainAxisAlignment.center,
  //                       crossAxisAlignment: CrossAxisAlignment.center,
  //                       children: [
  //                        normalText(weeks[random.nextInt(weeks.length)],
  //                   color: AllColor.greyColor),
  //                    smallText(statusValue,
  //                           fontWeight: FontWeight.bold,

  //                     color: statusColor(statusValue))
  //                       ],
  //                     ),
  //                   ))
  //               // Container(
  //               //   child: dropdownButton(status, onDropdownChange, "Success")),
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }

  itemView(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => GoalDetails(
                  enableAddButton: enableAddButton,
                  meetingSingleData: widget.meetingSingleData,
                  teamMember: widget.teamMember,
                  goalData: itemData,
                )));
      },
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: AllColor.white, borderRadius: BorderRadius.circular(10)),
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                child: headingText(showValidValue(itemData["goalTitle"]),
                  center: true,

                    color: AllColor.black, fontWeight: FontWeight.bold),
              ),
              Divider(),
              Container(
                alignment: Alignment.center,
                child: normal2Text(
                  validValue(itemData["goalDate"])
                      ? convertStringToDate(
                          DateTime.parse(itemData["goalDate"]))
                      : AllString.na,
                  center: true,

                  color: AllColor.black,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  fetchGoalList() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          (sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17")
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.teamMember.split(AllString.splitText).last,
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
    };
    apiPostRequestWithHeader(data, AllUrls.allGoals, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _goalList.clear();
          if (jsonData["allGoalLists"].toString() == "") {
            _goalList.clear();
          } else {
            if (jsonData["allGoalLists"]["goalList"].toString() == "") {
              _goalList = [];
            } else {
              _goalList = jsonData["allGoalLists"]["goalList"];
            }
            setState(() {});
          }
          enableAddButton = jsonData["allGoalLists"]["flag"];
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}
