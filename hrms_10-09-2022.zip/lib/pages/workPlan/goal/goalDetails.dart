import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/myExpense/myExpense.dart';
import 'package:hr/pages/workPlan/evaluation/addEvaluation.dart';
import 'package:hr/pages/workPlan/goal/goal.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/checkForApproveAndReject.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/networkImageView.dart';
import 'package:hr/widget/tabbarWidget.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class GoalDetails extends StatefulWidget {
  final Map meetingSingleData;
  final Map goalData;
  final String teamMember;
  final bool enableAddButton;

  const GoalDetails(
      {Key? key,
      required this.meetingSingleData,
      required this.teamMember,
      required this.enableAddButton,
      required this.goalData})
      : super(key: key);
  @override
  _GoalDetailsState createState() => _GoalDetailsState();
}

class _GoalDetailsState extends State<GoalDetails> {
  bool loading = false;
  List _goalList = [];
  @override
  void initState() {
    super.initState();
    fetchGoalDetails();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => Goal(
                meetingSingleData: widget.meetingSingleData,
                teamMember: widget.teamMember)));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context,
            "Goal" + " : " + showValidValue(widget.goalData["goalTitle"]),
            onBackPress: () {
          Navigator.of(context).push(CupertinoPageRoute(
              builder: (context) => Goal(
                  meetingSingleData: widget.meetingSingleData,
                  teamMember: widget.teamMember)));
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
                                     decoration:customBackgroundGradient(),

              child: Stack(
                children: [
                  Column(
                    children: [
                      Container(
                        height: screenWidth * 0.1,
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(color: AllColor.lightBlack))),
                        margin: AllMargin.customBottomSmall(),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            details(
                              Color(0xffffffff),
                              "Initial Goal",
                            ),
                            details(
                              Color(0xffb3e5fc),
                              "Modified Goal",
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: screenHeight - (screenWidth * 0.4),
                        margin: AllMargin.customBottomSmall(),
                        child: _goalList.isEmpty
                            ? commonNoDataFound(color: AllColor.black)
                            : ListView.builder(
                                padding: AllMargin.customVertical(),
                                physics: BouncingScrollPhysics(),
                                itemCount: _goalList.length,
                                itemBuilder: (context, index) =>
                                    itemView(_goalList[index], index)),
                      ),
                    ],
                  ),
                  widget.enableAddButton
                      ? (sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "16" ||
                                  sharedPreferences!
                                          .getString(AllSharedPreferencesKey
                                              .individualTypeId)
                                          .toString() ==
                                      "17") &&
                              (widget.teamMember == "" ||
                                  widget.teamMember == AllString.select ||
                                  widget.teamMember
                                          .split(AllString.splitText)
                                          .last !=
                                      sharedPreferences!.getString(
                                          AllSharedPreferencesKey.individualId))
                          // sharedPreferences!.getString(
                          //         AllSharedPreferencesKey.individualTypeId) !=
                          //     "18"

                          ? Container()
                          : Positioned(
                              bottom: screenWidth * 0.05,
                              right: screenWidth * 0.05,
                              child: FloatingActionButton(
                                onPressed: () {
                                  Navigator.of(context).push(CupertinoPageRoute(
                                      builder: (context) => AddEvaluation(
                                            onBackPress: () {
                                              Navigator.push(
                                                  context,
                                                  CupertinoPageRoute(
                                                      builder: (context) =>
                                                          GoalDetails(
                                                            enableAddButton: widget
                                                                .enableAddButton,
                                                            meetingSingleData:
                                                                widget
                                                                    .meetingSingleData,
                                                            teamMember: widget
                                                                .teamMember,
                                                            goalData:
                                                                widget.goalData,
                                                          )));
                                            },
                                            evalutationData: {},
                                            meetingSingleData:
                                                widget.meetingSingleData,
                                            weekId: widget
                                                .goalData["goalScheduleId"]
                                                .toString(),
                                            weekName: widget
                                                .goalData["goalTitle"]
                                                .toString(),
                                          )));
                                },
                                child: normalIcon(Icons.add),
                                backgroundColor: AllColor.primaryDeepColor,
                              ))
                      : Container(),
                ],
              )),
        ),
      ),
    );
  }

  details(Color color, String text) {
    return Container(
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
                border: Border.all(color: AllColor.greyColor),
                color: color,
                borderRadius: BorderRadius.circular(100)),
            width: screenWidth * 0.03,
            height: screenWidth * 0.03,
            margin: AllMargin.customRightSmall(),
          ),
          smallText(text, color: AllColor.black.withOpacity(0.6))
        ],
      ),
    );
  }

  itemView(Map<String, dynamic> itemData, int index) {
    return GestureDetector(
      child: Container(
        padding: EdgeInsets.all(1),
        decoration: customCardItemGradinet(),
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
        child: Container(
          decoration: BoxDecoration(
              color: itemData["goalConfig"].toString() == "0"
                  ? AllColor.white
                  : Color(0xffb3e5fc),
              borderRadius: BorderRadius.circular(10)),
          width: screenWidth,
          padding: AllMargin.customMarginCardItem(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: screenWidth * 0.8,
                child: Text(
                  showValidValue(itemData["goalTitle"]),
                  textAlign: TextAlign.start,
                  style: normal2TextStyle(
                      color: AllColor.black, fontWeight: FontWeight.bold),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: screenWidth * 0.8,
                    child: Text(
                      showValidValue(itemData["goalDescription"]),
                      textAlign: TextAlign.justify,
                      style: normal2TextStyle(
                        color: AllColor.greyColor,
                        //  lineThrough: statusValue == "Success" ? true : false
                      ),
                    ),
                  ),

                  // Container(
                  //     width: screenWidth * 0.15,
                  //     alignment: Alignment.center,
                  //     child:  Container(

                  //           child: Column(
                  //             mainAxisAlignment: MainAxisAlignment.center,
                  //             crossAxisAlignment: CrossAxisAlignment.center,
                  //             children: [
                  //              normalText(weeks[random.nextInt(weeks.length)],
                  //         color: AllColor.greyColor),
                  //          smallText(statusValue,
                  //                 fontWeight: FontWeight.bold,

                  //           color: statusColor(statusValue))
                  //             ],
                  //           ),
                  //         ))
                  // Container(
                  //   child: dropdownButton(status, onDropdownChange, "Success")),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  fetchGoalDetails() {
    setState(() {
      loading = true;
    });
    Map data = {
      // "companyId": 4,
      // "individualId": 1,
      // "goalScheduleId": 6

      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          // sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.teamMember.split(AllString.splitText).last,
      "goalScheduleId": widget.goalData["goalScheduleId"],
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
    };
    apiPostRequestWithHeader(
            data, AllUrls.goalPlanLists, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _goalList.clear();
          if (jsonData["goalData"].toString() == "") {
            _goalList.clear();
          } else {
            _goalList = jsonData["goalData"];
          }
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }
}

// import 'dart:convert';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:hr/api/apiPostRequestWithHeader.dart';
// import 'package:hr/common/commonAlertDialog.dart';
// import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/common/commonNoDataFound.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/myExpense/myExpense.dart';
// import 'package:hr/pages/workPlan/evaluation/addEvaluation.dart';
// import 'package:hr/pages/workPlan/workPlanBody.dart';
// import 'package:hr/res/allSharePreferencesKey.dart';
// import 'package:hr/res/allUrls.dart';
// import 'package:hr/util/allFormatter.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/allMargin.dart';
// import 'package:hr/util/allText.dart';
// import 'package:hr/util/allTextStyle.dart';
// import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
// import 'package:hr/util/checkApiValueValid.dart';
// import 'package:hr/util/checkForApproveAndReject.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/util/customMarginCardItem.dart';
// import 'package:hr/util/internetCheck.dart';
// import 'package:hr/util/showOfflineSnakbar.dart';
// import 'package:hr/util/statusColor.dart';
// import 'package:hr/widget/button.dart';
// import 'package:hr/widget/customAppBar.dart';
// import 'package:hr/widget/customAppBarForBackHome.dart';
// import 'package:hr/widget/customRowDetails.dart';
// import 'package:hr/widget/networkImageView.dart';
// import 'package:hr/widget/tabbarWidget.dart';
// import 'package:hr/widget/textAreaField.dart';
// import 'package:hr/widget/textFieldHeader.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/dashboard/dashboard.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allString.dart';

// class GoalDetails extends StatefulWidget {
//   final Map meetingSingleData;
//   final Map goalData;
//   final String teamMember;
//   const GoalDetails(
//       {Key? key,
//       required this.meetingSingleData,
//       required this.teamMember,
//       required this.goalData})
//       : super(key: key);
//   @override
//   _GoalDetailsState createState() => _GoalDetailsState();
// }

// class _GoalDetailsState extends State<GoalDetails>
//     with TickerProviderStateMixin {
//   bool loading = false;
//   List _oldPlan = [];
//   List _modifiedPlan = [];
//   TabController? _controller;
//   @override
//   void initState() {
//     super.initState();
//     fetchGoalDetails();

//     _controller = TabController(initialIndex: 0, length: 2, vsync: this);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AllColor.white,
//       appBar:
//           customAppBar(context, showValidValue(widget.goalData["goalTitle"])),
//       body: LoadingOverlay(
//         isLoading: loading,
//         opacity: 0.5,
//         color: AllColor.black,
//         progressIndicator: commonLoader(),
//         child: Container(
//             width: screenWidth,
//             height: screenHeight,
//                        decoration:customBackgroundGradient(),

//             child: Stack(
//               children: [
//                 planTabView(),
//                 // _controller!.index == 1
//                 //     ? Positioned(
//                 //         bottom: screenWidth * 0.05,
//                 //         right: screenWidth * 0.05,
//                 //         child: FloatingActionButton(
//                 //           onPressed: () {
//                 //             Navigator.of(context).push(CupertinoPageRoute(
//                 //                 builder: (context) =>
//                 //                     AddEvaluation(newPlan: true)));
//                 //           },
//                 //           child: normalIcon(Icons.add),
//                 //           backgroundColor: AllColor.primaryDeepColor,
//                 //         ))
//                 //     : Container(),
//                 // ListView.builder(
//                 //     padding: EdgeInsets.only(bottom: screenWidth * 0.03),
//                 //     physics: BouncingScrollPhysics(),
//                 //     itemCount: 30,
//                 //     itemBuilder: (context, index) => itemView({}, index)),
//               ],
//             )),
//       ),
//     );
//   }

//   planTabView() {
//     return _oldPlan.isEmpty
//         ? Container(
//             margin: AllMargin.customMarginCardItem(),
//             decoration: BoxDecoration(
//                 color: AllColor.blue,
//                 borderRadius: BorderRadius.only(
//                     topLeft: Radius.circular(35),
//                     topRight: Radius.circular(35),
//                     bottomLeft: Radius.circular(10),
//                     bottomRight: Radius.circular(10))),
//             child: ClipRRect(
//               borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(35),
//                   topRight: Radius.circular(35),
//                   bottomLeft: Radius.circular(10),
//                   bottomRight: Radius.circular(10)),
//               child: ListView(
//                 shrinkWrap: true,
//                 children: [
//                   AspectRatio(
//                     aspectRatio: 100 / 18,
//                     child: ColoredBox(
//                       color: AllColor.white,
//                       child: Stack(fit: StackFit.expand, children: [
//                         Stack(
//                           children: [
//                             Align(
//                               alignment: Alignment.center,
//                               child: FractionallySizedBox(
//                                 widthFactor: .5,
//                                 heightFactor: 1,
//                                 child: TextButton(
//                                   onPressed: null,
//                                   child: Text(
//                                     "Modified Plan",
//                                     style: TextStyle(
//                                         color: AllColor.black,
//                                         fontSize: screenWidth * 0.04),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ],
//                         )
//                       ]),
//                     ),
//                   ),
//                   Container(
//                     color: _controller!.index == 0
//                         ? AllColor.blue
//                         : AllColor.greyColor,
//                     height: screenWidth * 1.65,
//                     margin: AllMargin.customBottomSmall(),
//                     child: _modifiedPlan.isEmpty
//                         ? commonNoDataFound(color: AllColor.white)
//                         : ListView.builder(
//                             padding: AllMargin.customVertical(),
//                             physics: BouncingScrollPhysics(),
//                             itemCount: _modifiedPlan.length,
//                             itemBuilder: (context, index) =>
//                                 itemView(_modifiedPlan[index], index)),
//                   ),
//                 ],
//               ),
//             ),
//           )
//         : Container(
//             margin: AllMargin.customMarginCardItem(),
//             decoration: BoxDecoration(
//                 color: _controller!.index == 0
//                     ? AllColor.blue
//                     : AllColor.greyColor,
//                 borderRadius: BorderRadius.only(
//                     topLeft: Radius.circular(35),
//                     topRight: Radius.circular(35),
//                     bottomLeft: Radius.circular(10),
//                     bottomRight: Radius.circular(10))),
//             child: ClipRRect(
//               borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(35),
//                   topRight: Radius.circular(35),
//                   bottomLeft: Radius.circular(10),
//                   bottomRight: Radius.circular(10)),
//               child: ListView(
//                 shrinkWrap: true,
//                 children: [
//                   MyTabBar(
//                     controller: _controller!,
//                     labels: ["Modified Plan", "Old Plan"],
//                     backgroundColor: AllColor.white,
//                     foregroundColor: _controller!.index == 0
//                         ? AllColor.blue
//                         : AllColor.greyColor,
//                     activeBackgroundColor: _controller!.index == 0
//                         ? AllColor.blue
//                         : AllColor.greyColor,
//                     activeForegroundColor: AllColor.white,
//                     fontSize: screenWidth * 0.04,
//                   ),
//                   Container(
//                     color: _controller!.index == 0
//                         ? AllColor.blue
//                         : AllColor.greyColor,
//                     height: screenWidth * 1.65,
//                     margin: AllMargin.customBottomSmall(),
//                     child: TabBarView(
//                       controller: _controller,
//                       children: [
//                         _modifiedPlan.isEmpty
//                             ? commonNoDataFound(color: AllColor.white)
//                             : ListView.builder(
//                                 padding: AllMargin.customVertical(),
//                                 physics: BouncingScrollPhysics(),
//                                 itemCount: _modifiedPlan.length,
//                                 itemBuilder: (context, index) =>
//                                     itemView(_modifiedPlan[index], index)),
//                         _oldPlan.isEmpty
//                             ? commonNoDataFound(color: AllColor.white)
//                             : ListView.builder(
//                                 padding: AllMargin.customVertical(),
//                                 physics: BouncingScrollPhysics(),
//                                 itemCount: _oldPlan.length,
//                                 itemBuilder: (context, index) =>
//                                     itemView(_oldPlan[index], index))
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           );
//   }

//   itemView(Map<String, dynamic> itemData, int index) {
//     return GestureDetector(
//       child: Container(
//         padding: EdgeInsets.all(1),
//         decoration: customCardItemGradinet(),
//         margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
//         child: Container(
//           decoration: BoxDecoration(
//               color: AllColor.white, borderRadius: BorderRadius.circular(10)),
//           width: screenWidth,
//           padding: AllMargin.customMarginCardItem(),
//           child: Column(
//             children: [
//               Container(
//                 width: screenWidth * 0.8,
//                 child: Text(
//                   showValidValue(itemData["goalTitle"]),
//                   textAlign: TextAlign.justify,
//                   style: normal2TextStyle(
//                       color: AllColor.black, fontWeight: FontWeight.bold),
//                 ),
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   Container(
//                     width: screenWidth * 0.8,
//                     child: Text(
//                       showValidValue(itemData["goalDescription"]),
//                       textAlign: TextAlign.justify,
//                       style: normal2TextStyle(
//                         color: AllColor.greyColor,
//                         //  lineThrough: statusValue == "Success" ? true : false
//                       ),
//                     ),
//                   ),

//                   // Container(
//                   //     width: screenWidth * 0.15,
//                   //     alignment: Alignment.center,
//                   //     child:  Container(

//                   //           child: Column(
//                   //             mainAxisAlignment: MainAxisAlignment.center,
//                   //             crossAxisAlignment: CrossAxisAlignment.center,
//                   //             children: [
//                   //              normalText(weeks[random.nextInt(weeks.length)],
//                   //         color: AllColor.greyColor),
//                   //          smallText(statusValue,
//                   //                 fontWeight: FontWeight.bold,

//                   //           color: statusColor(statusValue))
//                   //             ],
//                   //           ),
//                   //         ))
//                   // Container(
//                   //   child: dropdownButton(status, onDropdownChange, "Success")),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   fetchGoalDetails() {
//     setState(() {
//       loading = true;
//     });
//     Map data = {
//       // "companyId": 4,
//       // "individualId": 1,
//       // "goalScheduleId": 6

//       "companyId":
//           sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
//       "individualId": sharedPreferences!
//                   .getString(AllSharedPreferencesKey.individualTypeId)
//                   .toString() ==
//               "18"
//           ? sharedPreferences!.getString(AllSharedPreferencesKey.individualId)
//           : widget.teamMember.split(AllString.splitText).last,
//       "goalScheduleId": widget.goalData["goalScheduleId"],
//       "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
//     };
//     apiPostRequestWithHeader(
//             data, AllUrls.goalPlanLists, this.context, loginToken)
//         .then((response) {
//       if (response == null) {
//         loading = false;
//         setState(() {});
//         commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
//       } else {
//         Map<String, dynamic> jsonData = json.decode(response);
//         if (checkApiResponseSuccessOrNot(jsonData)) {
//           _oldPlan.clear();
//           _modifiedPlan.clear();
//           if (jsonData["goalData"].toString() == "") {
//             _oldPlan.clear();
//             _modifiedPlan.clear();
//           } else if (jsonData["goalData"]["oldPlan"].toString() == "") {
//             _oldPlan.clear();
//           } else if (jsonData["goalData"]["modifiedPlan"].toString() == "") {
//             _modifiedPlan.clear();
//           } else {
//             _modifiedPlan = jsonData["goalData"]["modifiedPlan"];
//             _oldPlan = jsonData["goalData"]["oldPlan"];
//           }
//           setState(() {
//             loading = false;
//           });
//         } else {
//           setState(() {
//             loading = false;
//           });
//           commonAlertDialog(context, jsonData["status"], jsonData["message"]);
//         }
//       }
//     });
//   }
// }
