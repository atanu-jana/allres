import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/goal/goal.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class AddGoal extends StatefulWidget {
  final String selectedGoal;
  final Map meetingSingleData;
  final String teamMember;
  final List<String> goalList;
  const AddGoal({
    Key? key,
    required this.meetingSingleData,
    required this.selectedGoal,
    required this.teamMember,
    required this.goalList,
  }) : super(key: key);
  @override
  _AddGoalState createState() => _AddGoalState();
}

class _AddGoalState extends State<AddGoal> {
  bool loading = false;
  String selectProject = AllString.select;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (context) => Goal(
                meetingSingleData: widget.meetingSingleData,
                teamMember: widget.teamMember)));
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, "Add New Goal", onBackPress: () {
          Navigator.of(context).push(CupertinoPageRoute(
              builder: (context) => Goal(
                  meetingSingleData: widget.meetingSingleData,
                  teamMember: widget.teamMember)));
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
            width: screenWidth,
            height: screenHeight,
                                    decoration:customBackgroundGradient(),

            child: Stack(
              children: [
                Container(
                  width: screenWidth,
                  height: screenHeight,
                  child: Stack(children: [
                    Column(
                      children: [
                        textFieldHeader(AllString.selectProject,
                            fontWeight: FontWeight.bold),
                        Container(
                          child: DropdownButtonWithSearch(
                            icon: LineIcons.sortAmountDown,
                            selectedValue: selectProject,
                            dropdownList: projectList,
                            onChanged: onProjectChanged,
                          ),
                        ),
                        textFieldHeader("Elaborate",
                            fontWeight: FontWeight.bold),
                        Container(
                          margin: EdgeInsets.symmetric(
                            vertical: screenWidth * 0.0,
                            horizontal: screenWidth * 0.03,
                          ),
                          child: Center(
                            child: textAreaField(
                              context,
                              AllString.typeHere,
                              planTextEditingController,
                              4,
                              200,
                              // TextInputAction.next,
                                
                                 TextInputAction.newline,

                              TextInputType.multiline,
                            ),
                          ),
                        ),
                        textFieldHeader(AllString.week,
                            fontWeight: FontWeight.bold),
                        Container(
                          width: screenWidth,
                          child: Container(
                              child: dropdownButton(
                                  widget.goalList, onGoalSelect, selectedGoal)),
                        ),
                        Container(
                            margin: EdgeInsets.symmetric(
                                vertical: screenWidth * 0.015,
                                horizontal: screenWidth * 0.03),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                    child: button(context, function: () {
                                  resetField();
                                },
                                                                      color:AllColor.red,

                                        textColor: AllColor.white,
                                        text: AllString.reset,
                                        width: screenWidth * 0.3)),
                                Container(
                                    child: button(context, function: () {
                                  if (validateAndProceed()) {
                                    addGoal();
                                  }
                                },
                                        color: !validateAndProceed()
                            ? Colors.grey
                            :AllColor.primaryColor,
                                        textColor: AllColor.white,
                                        text: AllString.add,
                                        width: screenWidth * 0.3))
                              ],
                            )),
                      ],
                    )
                  ]),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  TextEditingController timeStamptextEditingController =
      TextEditingController();
  TextEditingController planTextEditingController = TextEditingController();
  DateTime timeStamp = DateTime.now();
  bool validateAndProceed() {
    if (planTextEditingController.text.isEmpty) {
      return false;
    } else if (selectedGoal == AllString.select && widget.selectedGoal == '') {
      return false;
    } else {
      return true;
    }
  }

  addGoal() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
      "teamMeetingId": widget.meetingSingleData["teamMeetingId"],
      "goalScheduleId": selectedGoal.split(AllString.splitText).last,
      "projectId": selectProject.split(AllString.splitText).last,
      "goalTitle": selectProject.split(AllString.splitText).first,
      "goalDescription": planTextEditingController.text,
      "date": formatterForRequest.format(DateTime.now()),
      "goalEvaluationId": ""
    };
    apiPostRequestWithHeader(
            data, AllUrls.addGoalPlan, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]));

              selectProject = AllString.select;
          planTextEditingController.clear();
          selectedGoal=AllString.select;
          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  resetField() {
    planTextEditingController.clear();
    setState(() {});
  }

  onProjectChanged(String? value) {
    selectProject = value!;
    setState(() {});
  }

  List<String> selectedPlanForAdd = [];
  String selectedGoal = AllString.select;

  bool existingPlanValidateAndProceed() {
    if (selectedPlanForAdd.isEmpty) {
      return false;
    } else if (selectedGoal == AllString.select) {
      return false;
    } else {
      return true;
    }
  }

  onGoalSelect(String? value) {
    selectedGoal = value!;
    setState(() {});
  }
}

// import 'dart:convert';
// import 'dart:developer';
// import 'dart:io';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:hr/api/apiPostRequestWithHeader.dart';
// import 'package:hr/api/imageToUrlApi.dart';
// import 'package:hr/common/commonAlertDialog.dart';
// import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
// import 'package:hr/common/commonLoader.dart';
// import 'package:hr/common/commonNoDataFound.dart';
// import 'package:hr/db/handler.dart';
// import 'package:hr/pages/home/home.dart';
// import 'package:hr/pages/order/order.dart';
// import 'package:hr/pages/workPlan/goal/goal.dart';
// import 'package:hr/pages/workPlan/workPlanBody.dart';
// import 'package:hr/res/allSharePreferencesKey.dart';
// import 'package:hr/res/allUrls.dart';
// import 'package:hr/util/allFormatter.dart';
// import 'package:hr/util/allIcon.dart';
// import 'package:hr/util/allMargin.dart';
// import 'package:hr/util/allText.dart';
// import 'package:hr/util/allTextStyle.dart';
// import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
// import 'package:hr/util/customCardItemGradinet.dart';
// import 'package:hr/util/customMarginCardItem.dart';
// import 'package:hr/util/internetCheck.dart';
// import 'package:hr/util/showOfflineSnakbar.dart';
// import 'package:hr/widget/button.dart';
// import 'package:hr/widget/customAppBar.dart';
// import 'package:hr/widget/customAppBarForBackHome.dart';
// import 'package:hr/widget/dropdownButtonWithSearch.dart';
// import 'package:hr/widget/rounded_date_field.dart';
// import 'package:hr/widget/textFieldHeader.dart';
// import 'package:hr/widget/dropdownButton.dart';
// import 'package:hr/widget/rounded_input_field.dart';
// import 'package:hr/widget/textAreaField.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:ionicons/ionicons.dart';
// import 'package:line_icons/line_icons.dart';
// import 'package:loading_overlay/loading_overlay.dart';
// import 'package:hr/main.dart';
// import 'package:hr/pages/dashboard/dashboard.dart';
// import 'package:hr/res/allColors.dart';
// import 'package:hr/res/allString.dart';

// class AddGoal extends StatefulWidget {
//   final bool newGoal;
//   final List<String> goalList;
//   const AddGoal({
//     Key? key,
//     required this.newGoal, 
//     required this.goalList, 
//   }) : super(key: key);
//   @override
//   _AddGoalState createState() => _AddGoalState();
// }

// class _AddGoalState extends State<AddGoal> {
//   bool loading = false;
//   bool existingPlanSelected = false;
//   List<String> existingPlenList = [];
//   String selectProject = AllString.select;

//   @override
//   void initState() {
//     for (var i = 0; i < 30; i++) {
//       existingPlenList.add("It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is " + random.nextInt(100).toString());
//     }
//     timeStamp = DateTime.now();
//     timeStamptextEditingController.text = convertStringToDate(timeStamp);
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AllColor.white,
//       appBar: customAppBar(
//           context, widget.newGoal ? "Add New Plan" : "Add Existing Plan"),
//       body: LoadingOverlay(
//         isLoading: loading,
//         opacity: 0.5,
//         color: AllColor.black,
//         progressIndicator: commonLoader(),
//         child: Container(
//           width: screenWidth,
//           height: screenHeight,
//                        decoration:customBackgroundGradient(),

//           child: Stack(
//             children: [if (widget.newGoal) newPlanAdd() else existingPlanAdd()],
//           ),
//         ),
//       ),
//     );
//   }

//   TextEditingController timeStamptextEditingController =
//       TextEditingController();
//   TextEditingController planTextEditingController = TextEditingController();
//   DateTime timeStamp = DateTime.now();
//   bool validateAndProceed() {
     
//     if (planTextEditingController.text.isEmpty) {
//       return false;
//     } else  if (selectedGoal == AllString.select) {
//       return false;
//     } else {
//       return true;
//     }
//   }

//   resetField() {
//     planTextEditingController.clear();
//     setState(() {});
//   }

//   newPlanAdd() {
//     return Container(
//       width: screenWidth,
//       height: screenHeight,
//       child: Stack(children: [
//         Column(
//           children: [
//             // textFieldHeader(AllString.dateSelect, fontWeight: FontWeight.bold),
//             // Container(
//             //     child: RoundedDateField(
//             //   controller: timeStamptextEditingController,
//             //   hintText: AllString.dateSelect,
//             //   icon: Icons.date_range,
//             //   onchangeFunction: (String val) {},
//             //   suffixIcon: Icons.date_range,
//             //   enable: false,
//             //   suffixFunction: () {},
//             // )),
//               textFieldHeader(AllString.selectProject,
//                       fontWeight: FontWeight.bold),
                 
//                   Container(
//                     child: DropdownButtonWithSearch(
//                       icon: LineIcons.sortAmountDown,
//                       selectedValue: selectProject,
//                       dropdownList: projectList,
//                       onChanged: onProjectChanged,
//                     ),
//                   ),
//             textFieldHeader("Elaborate", fontWeight: FontWeight.bold),
//             Container(
//               margin: EdgeInsets.symmetric(
//                 vertical: screenWidth * 0.0,
//                 horizontal: screenWidth * 0.03,
//               ),
//               child: Center(
//                 child: textAreaField(
//                   context,
//                   AllString.typeHere,
//                   planTextEditingController,
//                   4,
//                   200,
//                   TextInputAction.done,
//                   TextInputType.text,
//                 ),
//               ),
//             ),
//               textFieldHeader(AllString.week, fontWeight: FontWeight.bold),
//                 Container(
//                   width: screenWidth,
//                   child: Container(
//                       child: dropdownButton(widget.goalList,
//                           onGoalSelect, selectedGoal)),
//                 ),
//             Container(
//                 margin: EdgeInsets.symmetric(
//                     vertical: screenWidth * 0.015,
//                     horizontal: screenWidth * 0.03),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Container(
//                         child: button(context, function: () {
//                       resetField();
//                     },
//                             color1: Color.fromARGB(255, 118, 83, 83),
//                             color2: Color.fromARGB(255, 255, 0, 0),
//                             textColor: AllColor.white,
//                             text: AllString.reset,
//                             width: screenWidth * 0.3)),
//                     Container(
//                         child: button(context, function: () {
//                       if (validateAndProceed()) {}
//                     },
//                             color1: !validateAndProceed()
//                                 ? Colors.grey
//                                 : Color(0xff536976),
//                             color2: !validateAndProceed()
//                                 ? Colors.grey
//                                 : Color(0xff292E49),
//                             textColor: AllColor.white,
//                             text: AllString.add,
//                             width: screenWidth * 0.3))
//                   ],
//                 )),
//           ],
//         )
//       ]),
//     );
//   }
//   onProjectChanged(String? value) {
//     selectProject = value!;
//     setState(() {});
//   }
//   List<String> selectedPlanForAdd = [];
//   String selectedGoal = AllString.select;
  
//     bool existingPlanValidateAndProceed() {
//     if (selectedPlanForAdd.isEmpty) {
//       return false;
//     } else  if (selectedGoal == AllString.select) {
//       return false;
//     }else {
//       return true;
//     }
//   }
//   existingPlanAdd() {
//     return Container(
//       width: screenWidth,
//       height: screenHeight,
//       child: existingPlanSelected
//           ? Stack(
//               children: [
//              Column(
//                children: [
//                 //     textFieldHeader(AllString.dateSelect,
//                 //     fontWeight: FontWeight.bold),
//                 // Container(
//                 //     child: RoundedDateField(
//                 //   controller: timeStamptextEditingController,
//                 //   hintText: AllString.dateSelect,
//                 //   icon: Icons.date_range,
//                 //   onchangeFunction: (String val) {},
//                 //   suffixIcon: Icons.date_range,
//                 //   enable: false,
//                 //   suffixFunction: () {},
//                 // )),
//                 textFieldHeader(AllString.week, fontWeight: FontWeight.bold),
//                 Container(
//                   width: screenWidth,
//                   child: Container(
//                       child: dropdownButton(widget.goalList,
//                           onGoalSelect, selectedGoal)),
//                 ),
//                 Container(
//                     margin: EdgeInsets.symmetric(
//                         vertical: screenWidth * 0.015,
//                         horizontal: screenWidth * 0.03),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         Container(
//                             child: button(context, function: () {
//                           existingPlanSelected = false;
//                           selectedPlanForAdd = [];
//                           setState(() {});
//                         },
//                                 color1: Color.fromARGB(255, 118, 83, 83),
//                                 color2: Color.fromARGB(255, 255, 0, 0),
//                                 textColor: AllColor.white,
//                                 text: AllString.cancel,
//                                 width: screenWidth * 0.3)),
//                         Container(
//                             child: button(context, function: () {
//                           if (existingPlanValidateAndProceed()) {}
//                         },
//                                 color1: !existingPlanValidateAndProceed()
//                                     ? Colors.grey
//                                     : Color(0xff536976),
//                                 color2: !existingPlanValidateAndProceed()
//                                     ? Colors.grey
//                                     : Color(0xff292E49),
//                                 textColor: AllColor.white,
//                                 text: AllString.add,
//                                 width: screenWidth * 0.3))
//                       ],
//                     )),
//                ],
//              )
//               ],
//             )
//           : Stack(
//               children: [
//                 Container(
//                   child: existingPlenList.isEmpty
//                       ? commonNoDataFound()
//                       : ListView.builder(
//                           padding: EdgeInsets.only(bottom: screenWidth * 0.03),
//                           physics: BouncingScrollPhysics(),
//                           itemCount: existingPlenList.length,
//                           itemBuilder: (context, index) => itemView({}, index)),
//                 ),
//                 if (selectedPlanForAdd.isNotEmpty)
//                   Positioned(
//                       bottom: screenWidth * 0.05,
//                       right: screenWidth * 0.05,
//                       child: FloatingActionButton(
//                         onPressed: () {
//                           existingPlanSelected = true;
//                           setState(() {});
//                         },
//                         child: normalIcon(Icons.add),
//                         backgroundColor: AllColor.primaryDeepColor,
//                       )),
//               ],
//             ),
//     );
//   }

//   onGoalSelect(String? value) {
//     selectedGoal = value!;
//     setState(() {});
//   }

//   itemView(Map<String, dynamic> itemData, int index) {
//     return GestureDetector(
//       onTap: () {
//         if (selectedPlanForAdd.contains(existingPlenList[index])) {
//           selectedPlanForAdd.remove(existingPlenList[index]);
//           AppBuilder.of(context)!.rebuild();
//         } else {
//           selectedPlanForAdd.add(existingPlenList[index]);
//           setState(() {});
//           AppBuilder.of(context)!.rebuild();
//         }
//       },
//       child: Container(
//         padding: EdgeInsets.all(1),
//         decoration: customCardItemGradinet(),
//         margin: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
//         child: Container(
//           decoration: BoxDecoration(
//               color: AllColor.white, borderRadius: BorderRadius.circular(10)),
//           width: screenWidth,
//           padding: AllMargin.customMarginCardItem(),
//           child: Row(
//             crossAxisAlignment: CrossAxisAlignment.center,
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               Container(
//                 width: screenWidth * 0.1,
//                 child: Checkbox(
//                   onChanged: (_) {},
//                   checkColor: AllColor.white,
//                   activeColor: AllColor.primaryColor,
//                   value: selectedPlanForAdd.contains(existingPlenList[index])
//                       ? true
//                       : false,
//                 ),
//               ),
//               Container(
//                 width: screenWidth * 0.75,
//                 child: normal2Text(existingPlenList[index],
//                     color: AllColor.black, fontWeight: FontWeight.bold),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
