import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:math' as math;
import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/feedback/myFeedbackDetails.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class FeedbackDetails extends StatefulWidget {
  final Function() parentCallBack;
  final Map parentMeetingSingleData;
  final String parentTeamMember;
  final String teamMember;
  const FeedbackDetails({
    Key? key,
    required this.parentCallBack,
    required this.parentMeetingSingleData,
    required this.teamMember,
    required this.parentTeamMember,
  }) : super(key: key);
  @override
  _FeedbackDetailsState createState() => _FeedbackDetailsState();
}

class _FeedbackDetailsState extends State<FeedbackDetails> {
  bool loading = false;
  List _feedbackList = [];
  List<String> _forList = [];
  bool addFeedback = false;
  String selectFor = AllString.select;
  TextEditingController planTextEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // fetchForQ();
    fetchFeedback();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (addFeedback) {
          addFeedback = false;
          planTextEditingController.clear();
          selectFor = AllString.select;
          setState(() {});
          return false;
        } else {
          Navigator.pop(context);
          return true;
        }
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar:
            customAppBar(context, titleString(), smallTitle: true, actions: [
          ((sharedPreferences!
                              .getString(
                                  AllSharedPreferencesKey.individualTypeId)
                              .toString() ==
                          "16" ||
                      sharedPreferences!
                              .getString(
                                  AllSharedPreferencesKey.individualTypeId)
                              .toString() ==
                          "17") &&
                  (widget.parentTeamMember == "" ||
                      widget.parentTeamMember == AllString.select ||
                      widget.parentTeamMember.split(AllString.splitText).last !=
                          sharedPreferences!
                              .getString(AllSharedPreferencesKey.individualId)))
              ? Container()
              : Container(
                  margin: AllMargin.customMarginCardItemSameSmall(),
                  child: TextButton.icon(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all(AllColor.lightBlack),
                          shape: MaterialStateProperty.all(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(7)))),
                      onPressed: () {
                        Navigator.of(context).push(CupertinoPageRoute(
                            builder: (context) => MyFeedbackDetails(
                                  teamMember: widget.teamMember,
                                  parentTeamMember: widget.parentTeamMember,
                                  parentMeetingSingleData:
                                      widget.parentMeetingSingleData,
                                  parentCallBack: () {
                                    Navigator.pop(context);
                                  },
                                )));
                      },
                      icon: Icon(Icons.visibility, color: AllColor.greyColor),
                      label:
                          normalText("Given feedback", color: AllColor.black)),
                )
        ], onBackPress: () {
          if (addFeedback) {
            addFeedback = false;
            planTextEditingController.clear();
            selectFor = AllString.select;
            setState(() {});
            return false;
          } else {
            Navigator.pop(context);
            return true;
          }
        }),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
              decoration: customBackgroundGradient(),
              child: Stack(
                children: [
                  addFeedback
                      ? addFeedbackView()
                      : Container(
                          width: screenWidth,
                          height: screenHeight,
                          child: _feedbackList.isEmpty
                              ? commonNoDataFound()
                              : ListView.builder(
                                  padding: EdgeInsets.only(
                                      bottom: screenWidth * 0.03),
                                  physics: BouncingScrollPhysics(),
                                  itemCount: _feedbackList.length,
                                  itemBuilder: (context, index) => feedbackItem(
                                      _feedbackList[index], index)),
                        ),
                  // addFeedback
                  //     ? Container()
                  //     : ((sharedPreferences!
                  //                         .getString(AllSharedPreferencesKey
                  //                             .individualTypeId)
                  //                         .toString() ==
                  //                     "16" ||
                  //                 sharedPreferences!
                  //                         .getString(AllSharedPreferencesKey
                  //                             .individualTypeId)
                  //                         .toString() ==
                  //                     "17") &&
                  //             (widget.parentTeamMember == "" ||
                  //                 widget.parentTeamMember == AllString.select ||
                  //                 widget.parentTeamMember
                  //                         .split(AllString.splitText)
                  //                         .last !=
                  //                     sharedPreferences!.getString(
                  //                         AllSharedPreferencesKey
                  //                             .individualId)))
                  //         ? Container()
                  //         : Positioned(
                  //             bottom: screenWidth * 0.05,
                  //             right: screenWidth * 0.05,
                  //             child: FloatingActionButton(
                  //               onPressed: () {
                  //                 if (addFeedback) {
                  //                   addFeedback = false;
                  //                   selectFor = AllString.select;

                  //                   planTextEditingController.clear();
                  //                   setState(() {});
                  //                 } else {
                  //                   addFeedback = true;
                  //                   selectFor = AllString.select;

                  //                   planTextEditingController.clear();
                  //                   setState(() {});
                  //                 }
                  //               },
                  //               child: normalIcon(Icons.add),
                  //               backgroundColor: AllColor.primaryDeepColor,
                  //             )),
                ],
              )),
        ),
      ),
    );
  }

  addFeedbackView() {
    return Container(
      width: screenWidth,
      height: screenHeight,
      child: ListView(
        physics: BouncingScrollPhysics(),
        children: [
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.03,
              vertical: screenWidth * 0.03,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
                  child: Column(
                    children: [
                      Container(
                          alignment: Alignment.center,
                          padding: AllMargin.customMarginCardItem(),
                          child: normalText("*" + AllString.alreadyPunchAlert,
                              color: AllColor.blue,
                              fontWeight: FontWeight.bold,
                              center: true)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Divider(),
          textFieldHeader(AllString.select, fontWeight: FontWeight.bold),
          Container(
            child: dropdownButton(_forList, onFeedbackChanged, selectFor),
          ),
          textFieldHeader("Type Here", fontWeight: FontWeight.bold),
          Container(
            margin: EdgeInsets.symmetric(
              vertical: screenWidth * 0.0,
              horizontal: screenWidth * 0.03,
            ),
            child: Center(
              child: textAreaField(
                context,
                AllString.typeHere,
                planTextEditingController,
                4,
                255,
                TextInputAction.newline,
                TextInputType.multiline,
              ),
            ),
          ),
          Container(
              margin: EdgeInsets.symmetric(
                  vertical: screenWidth * 0.015,
                  horizontal: screenWidth * 0.03),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      child: button(context, function: () {
                    addFeedback = false;
                    selectFor = AllString.select;

                    planTextEditingController.clear();
                    setState(() {});
                  },
                          color: AllColor.red,
                          textColor: AllColor.white,
                          text: AllString.reset,
                          width: screenWidth * 0.3)),
                  Container(
                      child: button(context, function: () {
                    if (validateAndProceed()) {
                      addFeedbackk();
                    }
                  },
                          color: !validateAndProceed()
                              ? Colors.grey
                              : AllColor.primaryColor,
                          textColor: AllColor.white,
                          text: AllString.add,
                          width: screenWidth * 0.3))
                ],
              )),
        ],
      ),
    );
  }

  addFeedbackk() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.parentTeamMember.split(AllString.splitText).last,
      "messageId": selectFor.split(AllString.splitText).last,
      "teamMeetingId":
          widget.parentMeetingSingleData["teamMeetingId"].toString(),
      "feedBackToId": widget.teamMember.split(AllString.splitText).last,
      "comment": planTextEditingController.text
    };
    apiPostRequestWithHeader(
            data, AllUrls.addEmployeeFeedback, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          commonAlertDialog(context, showValidValue(jsonData["status"]),
              showValidValue(jsonData["message"]), function: () {
            addFeedback = false;
            planTextEditingController.clear();
            selectFor = AllString.select;
            setState(() {});
            Navigator.pop(context);
            fetchFeedback();

            setState(() {
              loading = false;
            });
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  bool validateAndProceed() {
    if (selectFor == AllString.select) {
      return false;
    } else if (planTextEditingController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }

  onFeedbackChanged(String? value) {
    selectFor = value!;
    setState(() {});
  }

  String titleString() {
    // return ((sharedPreferences!
    //                     .getString(AllSharedPreferencesKey.individualTypeId)
    //                     .toString() ==
    //                 "16" ||
    //             sharedPreferences!
    //                     .getString(AllSharedPreferencesKey.individualTypeId)
    //                     .toString() ==
    //                 "17") &&
    //         (widget.teamMember == "" ||
    //             widget.teamMember == AllString.select ||
    //             widget.teamMember.split(AllString.splitText).last !=
    //                 sharedPreferences!
    //                     .getString(AllSharedPreferencesKey.individualId)))
    //     ? widget.parentTeamMember.split(AllString.splitText).first +
    //         " - " +
    //         widget.teamMember.split(AllString.splitText).first
    //     : sharedPreferences!.getString(AllSharedPreferencesKey.firstName)! +
    //         " - " +
    //         widget.teamMember.split(AllString.splitText).first;
    return ((sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualTypeId)
                        .toString() ==
                    "16" ||
                sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualTypeId)
                        .toString() ==
                    "17") &&
            (widget.teamMember == "" ||
                widget.teamMember == AllString.select ||
                widget.teamMember.split(AllString.splitText).last !=
                    sharedPreferences!
                        .getString(AllSharedPreferencesKey.individualId)))
        ? widget.parentTeamMember.split(AllString.splitText).first.isEmpty ||
                widget.parentTeamMember.split(AllString.splitText).first ==
                    AllString.select ||
                widget.parentTeamMember
                        .split(AllString.splitText)
                        .first
                        .toLowerCase() ==
                    "you"
            ? widget.teamMember.split(AllString.splitText).first +
                " \n " +
                "Feedback for me"
            : widget.teamMember.split(AllString.splitText).first +
                " - " +
                "Feedback for " +
                widget.parentTeamMember.split(AllString.splitText).first
        : widget.teamMember.split(AllString.splitText).first +
            " \n " +
            "Feedback for me";

    // widget.parentTeamMember.split(AllString.splitText).first.isEmpty ||
    // widget.parentTeamMember.split(AllString.splitText).first==AllString.select ||
    // widget.parentTeamMember.split(AllString.splitText).first.toLowerCase()=="you"
    //     ?sharedPreferences!.getString(AllSharedPreferencesKey.firstName)! +
    //         " - " +
    //         widget.teamMember.split(AllString.splitText).first
    //     :  widget.parentTeamMember.split(AllString.splitText).first +
    //         " - " +
    //         widget.teamMember.split(AllString.splitText).first;
  }

  fetchForQ() {
    setState(() {
      loading = true;
    });
    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          sharedPreferences!.getString(AllSharedPreferencesKey.individualId),
    };
    apiPostRequestWithHeader(
            data, AllUrls.feedbackMessages, this.context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});
        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _forList.clear();
          _forList.add(AllString.select);

          if (jsonData["feedbackMessageList"].toString() == "") {
            status.clear();
          } else {
            List _tempList = jsonData["feedbackMessageList"];
            _tempList.forEach((element) {
              _forList.add(element["messageName"].toString() +
                  AllString.splitText +
                  element["messageId"].toString());
            });
          }

          setState(() {
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  fetchFeedback() {
    loading = true;
    setState(() {});

    Map data = {
      "companyId":
          sharedPreferences!.getString(AllSharedPreferencesKey.companyId),
      "individualId":
          //  sharedPreferences!
          //             .getString(AllSharedPreferencesKey.individualTypeId)
          //             .toString() ==
          //         "18"
          sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "16" &&
                  sharedPreferences!
                          .getString(AllSharedPreferencesKey.individualTypeId)
                          .toString() !=
                      "17"
              ? sharedPreferences!
                  .getString(AllSharedPreferencesKey.individualId)
              : widget.parentTeamMember.split(AllString.splitText).last,
      "teamMeetingId":
          widget.parentMeetingSingleData["teamMeetingId"].toString(),
      "feedBackFromId": widget.teamMember.split(AllString.splitText).last,
    };
    apiPostRequestWithHeader(
            data, AllUrls.otherEmloyeesFeedbackList, context, loginToken)
        .then((response) {
      if (response == null) {
        loading = false;
        setState(() {});

        commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
      } else {
        Map<String, dynamic> jsonData = json.decode(response);
        if (checkApiResponseSuccessOrNot(jsonData)) {
          _feedbackList.clear();
          setState(() {});

          if (jsonData["feedbackList"].toString() == "") {
            _feedbackList.clear();
            setState(() {});
          } else {
            _feedbackList = jsonData["feedbackList"];

            setState(() {});
          }

          loading = false;
          setState(() {});
        } else {
          loading = false;
          setState(() {});

          commonAlertDialog(context, jsonData["status"], jsonData["message"]);
        }
      }
    });
  }

  feedbackItem(Map<String, dynamic> itemData, int index) {
    return Container(
      padding: EdgeInsets.all(1),
      decoration: customCardItemGradinet(),
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      child: Container(
        decoration: BoxDecoration(
            color: AllColor.white, borderRadius: BorderRadius.circular(10)),
        width: screenWidth,
        padding: AllMargin.customMarginCardItem(),
        child: ExpansionTile(
          title: Container(
            width: screenWidth * 0.85,
            child: Column(
              children: [
                Container(
                  width: screenWidth * 0.85,
                  child: Text(
                    showValidValue(itemData["messageName"]),
                    textAlign: TextAlign.justify,
                    style: normal2TextStyle(
                      color: AllColor.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          children: <Widget>[
            Container(
              width: screenWidth * 0.85,
              child: Text(
                showValidValue(itemData["comment"]),
                textAlign: TextAlign.justify,
                style: normal2TextStyle(
                  color: AllColor.greyColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
