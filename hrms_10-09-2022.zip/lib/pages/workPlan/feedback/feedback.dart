import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:math' as math;
import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/api/imageToUrlApi.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonAlertDialogWithCloseButtonWithWidget.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/db/handler.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/order/order.dart';
import 'package:hr/pages/workPlan/feedback/feedbackDetails.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/pages/workPlan/workPlanDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/checkApiValueValid.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/util/statusColor.dart';
import 'package:hr/widget/button.dart';
import 'package:hr/widget/customAppBar.dart';
import 'package:hr/widget/customAppBarForBackHome.dart';
import 'package:hr/widget/customRowDetails.dart';
import 'package:hr/widget/datePickerButton.dart';
import 'package:hr/widget/dropdownButtonWithSearch.dart';
import 'package:hr/widget/rounded_date_field.dart';
import 'package:hr/widget/textFieldHeader.dart';
import 'package:hr/widget/dropdownButton.dart';
import 'package:hr/widget/rounded_input_field.dart';
import 'package:hr/widget/textAreaField.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ionicons/ionicons.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class Feedbackk extends StatefulWidget {
  final Function() callBack;
  final Map meetingSingleData;
  final String teamMember;
  const Feedbackk(
      {Key? key,
      required this.callBack,
      required this.meetingSingleData,
      required this.teamMember})
      : super(key: key);
  @override
  _FeedbackkState createState() => _FeedbackkState();
}

class _FeedbackkState extends State<Feedbackk> {
  bool loading = false;
  List _searchResult = [];

  TextEditingController _searchTextEditingController = TextEditingController();
  FocusNode _focusNode = FocusNode();
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context);
        return true;
      },
      child: Scaffold(
        backgroundColor: AllColor.white,
        appBar: customAppBar(context, "Feedback"),
        body: LoadingOverlay(
          isLoading: loading,
          opacity: 0.5,
          color: AllColor.black,
          progressIndicator: commonLoader(),
          child: Container(
              width: screenWidth,
              height: screenHeight,
              decoration: customBackgroundGradient(),
              child: Stack(
                children: [
                  Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        width: screenWidth,
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03,
                            vertical: screenWidth * 0.015),
                        decoration: BoxDecoration(
                            color: AllColor.lightGrey,
                            borderRadius: BorderRadius.circular(10)),
                        height: screenWidth * 0.1,
                        child: Center(
                          child: TextField(
                            focusNode: _focusNode,
                            controller: _searchTextEditingController,
                            onChanged: onSearchTextChanged,
                            decoration: InputDecoration(
                                suffixIcon: _searchTextEditingController
                                        .text.isEmpty
                                    ? Container(
                                        width: screenWidth * 0,
                                      )
                                    : GestureDetector(
                                        onTap: () {
                                          _searchTextEditingController.clear();
                                          _focusNode.unfocus();
                                          onSearchTextChanged('');
                                        },
                                        child: Icon(Icons.close,
                                            color: AllColor.black),
                                      ),
                                prefixIcon: Icon(
                                  Icons.search,
                                  color: AllColor.black,
                                ),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: screenWidth * 0.03,
                                    vertical: screenWidth * 0.03),
                                isDense: true,
                                hintStyle:
                                    normalTextStyle(color: AllColor.black),
                                hintText: "Search here"),
                          ),
                        ),
                      )),
                  Container(
                    margin: EdgeInsets.only(
                      top: screenWidth * 0.14,
                    ),
                    child: Container(
                      child: _searchResult.length != 0 ||
                              _searchTextEditingController.text.isNotEmpty
                          ? ListView.builder(
                              shrinkWrap: true,
                              physics: BouncingScrollPhysics(),
                              itemCount: _searchResult.length,
                              itemBuilder: (context, index) =>
                                  teamMemberItem(_searchResult[index]))
                          : allTeamMemberList.isEmpty
                              ? commonNoDataFound()
                              : ListView.builder(
                                  padding: EdgeInsets.only(
                                      bottom: screenWidth * 0.03),
                                  physics: BouncingScrollPhysics(),
                                  itemCount: allTeamMemberList.length,
                                  itemBuilder: (context, index) =>
                                      teamMemberItem(allTeamMemberList[index])),
                    ),
                  ),
                ],
              )),
        ),
      ),
    );
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    allTeamMemberList.forEach((searchDetails) {
      if (searchDetails.toString().toLowerCase().contains(text))
        _searchResult.add(searchDetails);
      setState(() {});
    });
    setState(() {});
  }

  teamMemberItem(String singleMember) {
    return singleMember == AllString.select
        ? Container()
        : GestureDetector(
            onTap: () {
              Navigator.of(context).push(CupertinoPageRoute(
                  builder: (context) => FeedbackDetails(
                        teamMember: singleMember,
                        parentTeamMember: widget.teamMember,
                        parentMeetingSingleData: widget.meetingSingleData,
                        parentCallBack: widget.callBack,
                      )));
            },
            child: Container(
              width: screenWidth,
              height: screenWidth * 0.1,
              margin: AllMargin.customMarginCardItem(),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: AllColor.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 5,
                      blurRadius: 7,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                  border: Border.all(width: 0, color: AllColor.white),
                  borderRadius: BorderRadius.circular(10000)),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        height: screenWidth * 0.1,
                        width: screenWidth * 0.1,
                        decoration: BoxDecoration(
                            // color: AllColor.primaryDeepColor,
                            color: Colors.primaries[
                                math.Random().nextInt(Colors.primaries.length)],
                            // color: Color((math.Random().nextDouble() * 0xFFFFFF).toInt()).withOpacity(1),
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10000),
                              bottomLeft: Radius.circular(10000),
                            )),
                        padding: AllMargin.customHorizontalSmall(),
                        child: normalIcon(FontAwesomeIcons.userAlt,
                            color: AllColor.white),
                      ),
                      Container(
                        margin: AllMargin.customHorizontal(),
                        child: headingText(
                            singleMember.split(AllString.splitText).first,
                            color: AllColor.black,
                            center: true,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Container(
                    height: screenWidth * 0.1,
                    width: screenWidth * 0.1,
                    alignment: Alignment.center,
                    margin: AllMargin.customHorizontalSmall(),
                    child: Icon(Icons.arrow_circle_right_outlined,
                        color: AllColor.blue),
                  ),
                ],
              ),
            ),
          );
  }
}
