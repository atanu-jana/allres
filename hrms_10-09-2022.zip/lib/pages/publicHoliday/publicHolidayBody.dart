import 'dart:convert';
import 'dart:developer' as dev;
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_calendar_carousel/classes/event.dart';
import 'package:flutter_calendar_carousel/classes/multiple_marked_dates.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:hr/pages/myReimbursment/myReimbursmentDetails.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:hr/widget/smallButton.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';

class PublicHolidayBody extends StatefulWidget {
  @override
  _PublicHolidayBodyState createState() => _PublicHolidayBodyState();
}

class _PublicHolidayBodyState extends State<PublicHolidayBody> {
  bool loading = false;
  DateTime? eventSelectedDate;
  String? eventSelectedDateTitle;
  List _publicHolidaysList = [];
  List<Event> _publicHolidaysListList = [];
  DateTime _currentDate = DateTime.now();
  DateTime _currentDate2 = DateTime.now();
  String _currentMonth = DateFormat.yMMM().format(DateTime.now());
  DateTime _targetDateTime = DateTime.now();
  Event? selectedEvent;
  List<Color> color = [
    Color(0xffcfd8dc),
    Color(0xffd7ccc8),
    Color(0xffffccbc),
    Color(0xffffecb3),
    Color(0xffc8e6c9),
    Color(0xffb2ebf2),
    Color(0xffbbdefb),
    Color(0xffc5cae9),
    Color(0xffd1c4e9),
    Color(0xffe1bee7),
    Color(0xfff8bbd0),
    Color(0xffffcdd2),
  ];
  Random random = new Random();
  late CalendarCarousel _calendarCarouselNoHeader;

  static Widget _eventIcon = new Container(
    decoration: new BoxDecoration(
        color: AllColor.primaryDeepColor,
        borderRadius: BorderRadius.all(Radius.circular(1000)),
        border: Border.all(color: AllColor.primaryDeepColor, width: 2.0)),
    child: Icon(
      Icons.circle,
      size: 5,
      color: AllColor.primaryDeepColor,
    ),
  );

  EventList<Event> _markedDateMap = new EventList<Event>(
    events: {
      new DateTime(2021, 1, 1): [
        new Event(
          date: new DateTime(2021, 1, 1),
          title: 'Happy New Year',
          icon: _eventIcon,
        ),
      ],
    },
  );

  @override
  void initState() {
    super.initState();
    fetchHolidays();
  }

  @override
  Widget build(BuildContext context) {
    _calendarCarouselNoHeader = CalendarCarousel<Event>(
      todayBorderColor: AllColor.primaryDeepColor,
      onDayPressed: (DateTime date, List<Event> events) {
        // _publicHolidaysListList = [];
        selectedEvent = null;

        setState(() {});
        this.setState(() => _currentDate2 = date);
        // _publicHolidaysListList = [];
        setState(() {});
        events.forEach((event) {
          if (event.date == date) {
            selectedEvent = event;
            // print(event.title);
            // _publicHolidaysListList.add(event
            //     // eventSelectedDate = event.date;
            //     );
            setState(() {});
          } else {
            selectedEvent = null;
            setState(() {});
          }
          // }
        });
      },
      daysHaveCircularBorder: true,
      showOnlyCurrentMonthDate: false,
      weekendTextStyle: normalTextStyle(color: AllColor.red),
      thisMonthDayBorderColor: Colors.grey,
      weekFormat: false,

// !! ----------- icon Display total
      markedDatesMap: _markedDateMap,
      markedDateIconMargin: 0,
      markedDateShowIcon: true,

      markedDateIconMaxShown: 1,
      markedDateIconBuilder: (event) {
        return event.icon;
      },
      markedDateCustomShapeBorder:
          CircleBorder(side: BorderSide(color: AllColor.primaryDeepColor)),
      markedDateCustomTextStyle: normalTextStyle(color: AllColor.black),

      markedDateWidget: _eventIcon,

      height: screenWidth * 1.2,
      selectedDateTime: _currentDate2,
      targetDateTime: _targetDateTime,
      customGridViewPhysics: NeverScrollableScrollPhysics(),
      showHeader: true,
      // headerText: _publicHolidaysListList.length.toString(),
      headerText: _currentMonth,
      headerTextStyle:
          headingTextStyle(fontWeight: FontWeight.bold, color: AllColor.black),
      pageSnapping: true,
      pageScrollPhysics: BouncingScrollPhysics(),
      todayTextStyle: normalTextStyle(color: AllColor.white),
      todayButtonColor: AllColor.deepGreen,
      selectedDayButtonColor: AllColor.primaryColor,
      selectedDayBorderColor: AllColor.white,
      selectedDayTextStyle: normalTextStyle(color: AllColor.white),
      minSelectedDate: _currentDate.subtract(Duration(days: 360)),
      maxSelectedDate: _currentDate.add(Duration(days: 360)),
      prevDaysTextStyle: normalTextStyle(
        color: AllColor.greyColor,
      ),
      leftButtonIcon: IconButton(
        icon: Icon(Icons.arrow_back_ios_outlined, color: Color(0xffe91e63)),
        onPressed: () {
          selectedEvent = null;
          setState(() {});
          setState(() {
            _targetDateTime =
                DateTime(_targetDateTime.year, _targetDateTime.month - 1);
            _currentMonth = DateFormat.yMMM().format(_targetDateTime);
          });
        },
      ),
      rightButtonIcon: IconButton(
        icon: Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff009688)),
        onPressed: () {
          selectedEvent = null;
          setState(() {});
          setState(() {
            _targetDateTime =
                DateTime(_targetDateTime.year, _targetDateTime.month + 1);
            _currentMonth = DateFormat.yMMM().format(_targetDateTime);
          });
        },
      ),
      onCalendarChanged: (DateTime date) {
        selectedEvent = null;
        setState(() {});
        this.setState(() {
          _targetDateTime = date;
          _currentMonth = DateFormat.yMMM().format(_targetDateTime);
        });

        setCurrentMonthEvents(date);
      },
      onDayLongPressed: (DateTime date) {
        // log('long pressed date $date');
      },
    );

    return Container(
      width: screenWidth,
      height: screenHeight,
                             decoration:customBackgroundGradient(),

      child: ListView(
        shrinkWrap: true,
        children: <Widget>[
          //custom icon

          // Container(
          //   margin: EdgeInsets.symmetric(
          //       horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
          //   child: new Row(
          //     children: <Widget>[
          //       Expanded(
          //           child: headingText(
          //               // selectedEvent!.date.toString(),
          //               _currentMonth,
          //               fontWeight: FontWeight.bold,
          //               color: AllColor.black)),
          //       Container(
          //     child: smallButton(
          //   context,
          //   color: Color(0xffe91e63),
          //   textColor: AllColor.white,
          //   text: "PREV",
          //   width: screenWidth * 0.2,
          //   function: () {
          //     selectedEvent = null;
          //     setState(() {});
          //     setState(() {
          //       _targetDateTime = DateTime(
          //           _targetDateTime.year, _targetDateTime.month - 1);
          //       _currentMonth = DateFormat.yMMM().format(_targetDateTime);
          //     });
          //   },
          // )),
          //       Container(
          //         width: screenWidth * 0.03,
          //       ),
          //       Container(
          //     child: smallButton(
          //   context,
          //   color: Color(0xff009688),
          //   textColor: AllColor.white,
          //   text: "NEXT",
          //   width: screenWidth * 0.2,
          //   function: () {
          //     selectedEvent = null;
          //     setState(() {});
          //     setState(() {
          //       _targetDateTime = DateTime(
          //           _targetDateTime.year, _targetDateTime.month + 1);
          //       _currentMonth = DateFormat.yMMM().format(_targetDateTime);
          //     });
          //   },
          // )),
          //     ],
          //   ),
          // ),

          Container(
            margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
            child: _calendarCarouselNoHeader,
          ), //
          Divider(),
          loading
              ? commonLoader()
              : _publicHolidaysListList.isEmpty
                  ? Container(
                      height: screenWidth * 0.1,
                      alignment: Alignment.center,
                      width: screenWidth,
                      margin:
                          EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                      child:
                          normalText(AllString.noEvents, color: AllColor.black),
                    )
                  : Container(
                      margin:
                          EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                      width: screenWidth,
                      height: screenWidth * 0.5,
                      child: ListView.builder(
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: _publicHolidaysListList.length,
                          itemBuilder: (context, index) {
                            return customPublicHolidayItem(
                                _publicHolidaysListList[index]);
                          }))
        ],
      ),
    );
  }

  customPublicHolidayItem(Event event) {
    return Container(
      height: screenWidth * 0.15,
      margin: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
      decoration: BoxDecoration(
          color: AllColor.lightBlueGrey,
          border: (selectedEvent != null &&
                  formatter.format(event.date) ==
                      formatter.format(selectedEvent!.date))
              ? Border.all(color: AllColor.green, width: 2)
              : Border.all(width: 0),
          borderRadius: BorderRadius.circular(10)),
      width: screenWidth,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: EdgeInsets.only(
                top: screenWidth * 0.002,
                bottom: screenWidth * 0.002,
                left: screenWidth * 0.002),
            decoration: BoxDecoration(
              color: AllColor.lightBlueGrey,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(10),
                bottomLeft: Radius.circular(10),
              ),
            ),
            child: Container(
              width: screenWidth * 0.22,
              height: screenWidth * 0.15,
              decoration: BoxDecoration(
                  color: AllColor.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    bottomLeft: Radius.circular(10),
                  )),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    event.date.weekday == 7
                        ? weekDay[0].toString()
                        : weekDay[event.date.weekday].toString(),
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      fontSize: screenWidth * 0.028,
                      fontWeight: FontWeight.w300,
                      color: AllColor.green,
                    ),
                  ),
                  Text(
                    event.date.day.toString(),
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      fontSize: screenWidth * 0.028,
                      fontWeight: FontWeight.w600,
                      color: AllColor.black,
                    ),
                  ),
                  Text(
                    month[event.date.month - 1].toString() +
                        ", " +
                        event.date.year.toString(),
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      fontSize: screenWidth * 0.025,
                      fontWeight: FontWeight.w900,
                      color: AllColor.greyColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: screenWidth * 0.02,
          ),
          Container(
            width: screenWidth * 0.68,
            child: Text(event.title!,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: normalTextStyle(
                  color: AllColor.black,
                )),
          ),
        ],
      ),
    );
  }

  fetchHolidays() async {
    // var jsonData = json.decode(
    //     await rootBundle.loadString('assets/json/HolidayListData.json'));
    // // log(jsonData.toString());

    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
      };

      apiPostRequestWithHeader(
              data, AllUrls.getHolidaynList, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          commonAlertDialog(context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          dev.log(jsonData.toString());
          if (checkApiResponseSuccessOrNot(jsonData)) {
            if (jsonData["holidayData"] == "") {
              _publicHolidaysList = [];
            } else {
              _publicHolidaysList = jsonData["holidayData"];
              dev.log("_publicHolidaysList: " +
                  _publicHolidaysList.length.toString());
              setState(() {});
              _publicHolidaysList.forEach((element) {
                dev.log("element" + element.toString());
                // _markedDateMap.add(
                //     DateTime.parse(element["holidayDate"]),
                //     Event(

                //         date: DateTime.parse(element["holidayDate"]),
                //         title: element["holidayDescription"],
                //         icon: Container(
                //             width: screenWidth * 0.15,
                //             height: screenWidth * 0.15,
                //             alignment: Alignment.center,
                //             decoration: BoxDecoration(
                //               color: Color(0xffef6c00),
                //               borderRadius:
                //                   BorderRadius.all(Radius.circular(100000)),
                //             ),
                //             child: normalText(
                //                 convertStringToDate(
                //                   DateTime.parse(element["holidayDate"]),
                //                 ),
                //                 color: AllColor.white,
                //                 fontWeight: FontWeight.w500))));
                String dateString = formatter
                    .format(DateTime.parse(element["holidayDate"].toString()).toLocal());
                dev.log(dateString);
                _markedDateMap.add(
                    DateTime(
                        int.parse(dateString.split("-").last),
                        int.parse(dateString.split("-")[1]),
                        int.parse(dateString.split("-").first)),
                    Event(
                        date: DateTime(
                            int.parse(dateString.split("-").last),
                            int.parse(dateString.split("-")[1]),
                            int.parse(dateString.split("-").first)),
                        title: element["holidayDescription"],
                        icon: Container(
                            width: screenWidth * 0.15,
                            height: screenWidth * 0.15,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: Color(0xffef6c00),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(100000)),
                            ),
                            child: normalText(
                                DateTime(
                                        int.parse(dateString.split("-").last),
                                        int.parse(dateString.split("-")[1]),
                                        int.parse(dateString.split("-").first))
                                    .day
                                    .toString(),
                                color: AllColor.white,
                                fontWeight: FontWeight.w500))));
              });
              Future.delayed(Duration(milliseconds: 300), () {
                setCurrentMonthEvents(_targetDateTime);
              });

              AppBuilder.of(context)!.rebuild();
            }
            setCurrentMonthEvents(_targetDateTime);

            setState(() {
              loading = false;
            });
          } else {
            setState(() {
              loading = false;
            });
            commonAlertDialog(context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      showOfflineSnakbar(context);
    }

    // _publicHolidaysList = jsonData["HolidayListData"];
    // _markedDateMap.add(
    //     DateTime(
    //         int.parse(element["Holiday_Date"].toString().split("/").last),
    //         int.parse(element["Holiday_Date"].toString().split("/")[1]),
    //         int.parse(element["Holiday_Date"].toString().split("/").first)),
    //     Event(
    //         date: DateTime(
    //             int.parse(element["Holiday_Date"].toString().split("/").last),
    //             int.parse(element["Holiday_Date"].toString().split("/")[1]),
    //             int.parse(
    //                 element["Holiday_Date"].toString().split("/").first)),
    //         title: element["HolidayDescription"],
    //         icon: Container(
    //             width: screenWidth * 0.15,
    //             height: screenWidth * 0.15,
    //             alignment: Alignment.center,
    //             decoration: BoxDecoration(
    //               color: Color(0xffef6c00),
    //               borderRadius: BorderRadius.all(Radius.circular(100000)),
    //             ),
    //             child: normalText(
    //                 DateTime(
    //                         int.parse(element["Holiday_Date"]
    //                             .toString()
    //                             .split("/")
    //                             .last),
    //                         int.parse(element["Holiday_Date"]
    //                             .toString()
    //                             .split("/")[1]),
    //                         int.parse(element["Holiday_Date"]
    //                             .toString()
    //                             .split("/")
    //                             .first))
    //                     .day
    //                     .toString(),
    //                 color: AllColor.white,
    //                 fontWeight: FontWeight.w500))));
  }

  setCurrentMonthEvents(DateTime date) {
    _publicHolidaysListList = [];
    setState(() {});

    _publicHolidaysList.forEach((event) {
      dev.log(event.toString());
      String dateString =
          formatter.format(DateTime.parse(event["holidayDate"].toString()).toLocal());
      if ((DateTime.parse(event["holidayDate"]).month == date.month) &&
          (DateTime.parse(event["holidayDate"]).year == date.year)) {
        _publicHolidaysListList.add(Event(
                date: DateTime(
                    int.parse(dateString.split("-").last),
                    int.parse(dateString.split("-")[1]),
                    int.parse(dateString.split("-").first)),
                title: event["holidayDescription"],
                icon: Container(
                    width: screenWidth * 0.15,
                    height: screenWidth * 0.15,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Color(0xffef6c00),
                      borderRadius: BorderRadius.all(Radius.circular(100000)),
                    ),
                    child: normalText(
                        DateTime(
                                int.parse(dateString.split("-").last),
                                int.parse(dateString.split("-")[1]),
                                int.parse(dateString.split("-").first))
                            .day
                            .toString(),
                        color: AllColor.white,
                        fontWeight: FontWeight.w500)))

            // eventSelectedDate = event.date;
            );
        setState(() {});
      }
      _publicHolidaysList
          .sort((a, b) => a['holidayDate'].compareTo(b['holidayDate']));
      AppBuilder.of(context)!.rebuild();
    });
  }

  // fetchHolidays() async {
  //   var jsonData = json.decode(
  //       await rootBundle.loadString('assets/json/HolidayListData.json'));
  //   // log(jsonData.toString());
  //   _publicHolidaysList = jsonData["HolidayListData"];
  //   setState(() {});
  //   _publicHolidaysList.forEach((element) {
  //     _markedDateMap.add(
  //         DateTime(
  //             int.parse(element["Holiday_Date"].toString().split("/").last),
  //             int.parse(element["Holiday_Date"].toString().split("/")[1]),
  //             int.parse(element["Holiday_Date"].toString().split("/").first)),
  //         Event(
  //             date: DateTime(
  //                 int.parse(element["Holiday_Date"].toString().split("/").last),
  //                 int.parse(element["Holiday_Date"].toString().split("/")[1]),
  //                 int.parse(
  //                     element["Holiday_Date"].toString().split("/").first)),
  //             title: element["HolidayDescription"],
  //             icon: Container(
  //                 width: screenWidth * 0.15,
  //                 height: screenWidth * 0.15,
  //                 alignment: Alignment.center,
  //                 decoration: BoxDecoration(
  //                   color: Color(0xffef6c00),
  //                   borderRadius: BorderRadius.all(Radius.circular(100000)),
  //                 ),
  //                 child: normalText(
  //                     DateTime(
  //                             int.parse(element["Holiday_Date"]
  //                                 .toString()
  //                                 .split("/")
  //                                 .last),
  //                             int.parse(element["Holiday_Date"]
  //                                 .toString()
  //                                 .split("/")[1]),
  //                             int.parse(element["Holiday_Date"]
  //                                 .toString()
  //                                 .split("/")
  //                                 .first))
  //                         .day
  //                         .toString(),
  //                     color: AllColor.white,
  //                     fontWeight: FontWeight.w500))));
  //   });
  // }

}
