import 'dart:developer';
import 'dart:convert';
import 'dart:io';
import 'package:hr/api/apiPostRequestWithHeader.dart';
import 'package:hr/common/commonAlertDialog.dart';
import 'package:hr/common/commonFluttertoast.dart';
import 'package:hr/common/commonLoader.dart';
import 'package:hr/common/commonNoDataFound.dart';
import 'package:hr/pages/fileView/pdfView.dart';
import 'package:hr/res/allSharePreferencesKey.dart';
import 'package:hr/res/allUrls.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allMargin.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiResponseSuccessOrNot.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:hr/util/customMarginCardItem.dart';
import 'package:hr/util/internetCheck.dart';
import 'package:hr/util/otherUtils.dart';
import 'package:hr/util/requestPermission.dart';
import 'package:hr/util/showOfflineSnakbar.dart';
import 'package:open_file/open_file.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/pages/leaveBalance/applyLeave.dart';
import 'package:hr/pages/leaveBalance/leave.dart';
import 'package:hr/pages/myExpense/applyExpense.dart';
import 'package:hr/pages/myExpense/myExpenseDetails.dart';
import 'package:hr/pages/myLoan/applyLoan.dart';
import 'package:line_icons/line_icons.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/dashboard/dashboard.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:permission_handler/permission_handler.dart';

class PayslipBody extends StatefulWidget {
  @override
  _PayslipBodyState createState() => _PayslipBodyState();
}

class _PayslipBodyState extends State<PayslipBody> {
  bool loading = false;
  int topMonth = DateTime.now().month - 1;
  int topYear = DateTime.now().year;
  String paySlip = "";
  @override
  void initState() {
    super.initState();
    fetchAttendance();
  }

  @override
  Widget build(BuildContext context) {
    return LoadingOverlay(
      isLoading: loading,
      opacity: 0.5,
      color: AllColor.black,
      progressIndicator: commonLoader(),
      child: Container(
        width: screenWidth,
        height: screenHeight,
                               decoration:customBackgroundGradient(),

        child: ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          title: Container(
            height: screenWidth * 0.1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  onPressed: () {
                    if (month[topMonth] != month[0]) {
                      topMonth = topMonth - 1;
                      topYear = topYear;
                      setState(() {});
                    } else {
                      topMonth = 11;

                      topYear = topYear - 1;
                      setState(() {});
                    }
                    fetchAttendance();
                  },
                  icon: Container(
                      color: AllColor.transparentColor,
                      margin: EdgeInsets.only(left: screenWidth * 0.03),
                      child: smallIcon(Icons.arrow_back_ios_outlined,
                          color: AllColor.primaryColor)),
                ),
                Container(
                  child: Row(
                    children: [
                      normalText(month[topMonth],
                          color: AllColor.black, letterSpacing: 1.5),
                      Container(
                        width: screenWidth * 0.03,
                      ),
                      normalText(topYear.toString(), color: AllColor.black),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () {
                    if (topYear != DateTime.now().year ||
                        (month[topMonth] != month[DateTime.now().month - 1])) {
                      if (month[topMonth] != month[11]) {
                        topMonth = topMonth + 1;
                        topYear = topYear;
                        setState(() {});
                      } else {
                        topMonth = 0;

                        topYear = topYear + 1;
                        setState(() {});
                      }
                    }
                    fetchAttendance();

                    // if ((month[(.month + 1) - 1] !=
                    //     month[(.month) - 1])) if (month[
                    //         (.month - 1) - 1] !=
                    //     month[0]) {
                    //   topMonth = month[(.month - 1) - 1];
                    //   topYear = (.year).toString();
                    //   setState(() {});
                    // } else {
                    //   topMonth = month[(.month - 1) - 1];
                    //   topYear = (.year - 1).toString();
                    //   setState(() {});
                    // }
                  },
                  icon: Container(
                      color: AllColor.transparentColor,
                      margin: EdgeInsets.only(right: screenWidth * 0.03),
                      child: smallIcon(Icons.arrow_forward_ios_outlined,
                          color: month[topMonth] ==
                                      month[DateTime.now().month - 1] &&
                                  topYear == DateTime.now().year
                              ? AllColor.greyColor
                              : AllColor.primaryColor)),
                ),
              ],
            ),
          ),
          subtitle: Container(
            height: screenHeight - 100,
            child: Column(
              children: [
                // topMonth == 2 || topMonth == 3
                //     ? Container(
                //         margin: AllMargin.customMarginCardItem(),
                //         child: Container(
                //           height: screenWidth * 0.15,
                //           padding: EdgeInsets.all(1),
                //           decoration: customCardItemGradinet(),
                //           margin: customMarginCardItem(),
                //           child: Container(
                //             padding: EdgeInsets.symmetric(
                //               horizontal: screenWidth * 0.03,
                //               vertical: screenWidth * 0.03,
                //             ),
                //             decoration: BoxDecoration(
                //                 color: AllColor.lightBlueGrey,
                //                 borderRadius: BorderRadius.circular(7)),
                //             width: screenWidth,
                //             alignment: Alignment.centerLeft,
                //             child: Row(
                //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //               crossAxisAlignment: CrossAxisAlignment.start,
                //               children: [
                //                 Container(
                //                   child: normalText(
                //                       "payslip-" +
                //                           month[topMonth]
                //                               .toString()
                //                               .toLowerCase() +
                //                           "-" +
                //                           topYear.toString() +
                //                           ".pdf",
                //                       color: AllColor.greyColor),
                //                 ),
                //                 GestureDetector(
                //                   onTap: () {
                //                     if (topMonth == 2 &&
                //                         topYear == DateTime.now().year) {
                //                       downloadControl(
                //                           "http://13.233.6.10/easeurbiz/hrmsapi/notificationPdf/PAY_SLIP_SAMPLE_2.pdf");
                //                     } else if (topMonth == 3 &&
                //                         topYear == DateTime.now().year) {
                //                       downloadControl(
                //                           "http://13.233.6.10/easeurbiz/hrmsapi/notificationPdf/PAY_SLIP_SAMPLE_3.pdf");
                //                     }
                //                   },
                //                   child: Container(
                //                       child: Container(
                //                     width: screenWidth * 0.18,
                //                     decoration: BoxDecoration(
                //                         color: AllColor.blue,
                //                         borderRadius: BorderRadius.circular(10),
                //                         border:
                //                             Border.all(color: AllColor.blue)),
                //                     padding: AllMargin.customVerticalSmall(),
                //                     child: Container(
                //                       child: smallText(
                //                         "Download",
                //                         center: true,
                //                         fontWeight: FontWeight.bold,
                //                         color: AllColor.white,
                //                       ),
                //                     ),
                //                   )),
                //                 ),
                //               ],
                //             ),
                //           ),
                //         ),
                //       )
                //     : commonNoDataFound(),
                paySlip.isNotEmpty
                    ? Container(
                        margin: AllMargin.customMarginCardItem(),
                        child: Container(
                          height: screenWidth * 0.15,
                          padding: EdgeInsets.all(1.5),
                          decoration: customCardItemGradinet(),
                          margin: customMarginCardItem(),
                          child: Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.03,
                              vertical: screenWidth * 0.03,
                            ),
                            decoration: BoxDecoration(
                                color: AllColor.lightBlueGrey,
                                borderRadius: BorderRadius.circular(7)),
                            width: screenWidth,
                            alignment: Alignment.centerLeft,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  child: normalText(
                                      "payslip-" +
                                          month[topMonth]
                                              .toString()
                                              .toLowerCase() +
                                          "-" +
                                          topYear.toString() +
                                          ".pdf",
                                      color: AllColor.greyColor),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    // if (topMonth == 2 &&
                                    //     topYear == DateTime.now().year) {
                                    downloadControl(paySlip);
                                    // } else if (topMonth == 3 &&
                                    //     topYear == DateTime.now().year) {
                                    //   downloadControl(
                                    //       "http://13.233.6.10/easeurbiz/hrmsapi/notificationPdf/PAY_SLIP_SAMPLE_3.pdf");
                                    // }
                                  },
                                  child: Container(
                                      child: Container(
                                    width: screenWidth * 0.18,
                                    decoration: BoxDecoration(
                                        color: AllColor.blue,
                                        borderRadius: BorderRadius.circular(10),
                                        border:
                                            Border.all(color: AllColor.blue)),
                                    padding: AllMargin.customVerticalSmall(),
                                    child: Container(
                                      child: smallText(
                                        "Download",
                                        center: true,
                                        fontWeight: FontWeight.bold,
                                        color: AllColor.white,
                                      ),
                                    ),
                                  )),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    : commonNoDataFound(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  downloadControl(String url) async {
    try {
      if (Platform.isAndroid) {
        try {
          if (await requestPermission(Permission.storage, this.context) &&await requestPermission(Permission.manageExternalStorage, this.context) ) {
            try {
              commonFluttertoast(msg: "Download Starting...");

              final http.Response downloadData = await http.get(Uri.parse(url));
              Directory directory;

              directory = (await getExternalStorageDirectory())!;
              String newPath = "";
              List<String> folders = directory.path.split("/");
              for (int x = 1; x < folders.length; x++) {
                String folder = folders[x];
                if (folder != "Android") {
                  newPath += "/" + folder;
                } else {
                  break;
                }
              }

              newPath = newPath + "/HRMS/PaySlip";
              directory = Directory(newPath);
              if (!await directory.exists()) {
                await directory.create(recursive: true);
              }
              if (await directory.exists()) {
                String fileName = 
                sharedPreferences!.getString(AllSharedPreferencesKey.firstName)!+
                "-Payslip-" +
                    
                    month[topMonth].toString().toLowerCase() +
                    "-" +
                    topYear.toString() +
                    ".pdf";
                File filge = new File(join('${directory.path}/$fileName'));
                var bodyBytfes = downloadData.bodyBytes;
                commonFluttertoast(
                    msg:
                        "Download File into: " + '${directory.path}/$fileName');
                filge.writeAsBytesSync(bodyBytfes);
                // ignore: unnecessary_cast
                Uint8List bytes = filge.readAsBytesSync() as Uint8List;
                ByteData.view(bytes.buffer);
                OpenFile.open(filge.path);
              }
            } catch (e) {}
          } else {
            commonFluttertoast(msg: "Need storage permission");
          }
        } catch (e) {}
      } else {
        // Not IOS
      }
    } catch (e) {}
  }

  fetchAttendance() async {
    if (await internetCheck()) {
      setState(() {
        loading = true;
      });
      Map data = {
        "individualName": "",
        "companyId":
            sharedPreferences!.getString(AllSharedPreferencesKey.companyId)!,
        "individualId":
            sharedPreferences!.getString(AllSharedPreferencesKey.individualId)!,
        "userId": loginUserId,
        // "fromdate": DateTime(topYear, topMonth + 1, 01).toString(),
        // "todate": DateTime(topYear, topMonth + 1, monthLastDate[topMonth])
        // "todate": DateTime(topYear, topMonth + 1, (topMonth + 1) == 1 ? 28 : 30)
        // .toString()
        "month": topMonth + 1,
        "year": topYear
      };

      apiPostRequestWithHeader(
              data, AllUrls.getEmployeePayslip, this.context, loginToken)
          .then((response) {
        if (response == null) {
          loading = false;
          setState(() {});
          paySlip = "";
          setState(() {});
          commonAlertDialog(
              this.context, AllString.warning ,AllString.connectionFailure);
        } else {
          Map<String, dynamic> jsonData = json.decode(response);
          log(jsonData.toString());
          paySlip = "";
          setState(() {});
          if (checkApiResponseSuccessOrNot(jsonData)) {
            // if (jsonData["attendanceData"] == "") {
            //   _attendanceList = [];
            // } else {
            //   _attendanceList = jsonData["attendanceData"];
            // }
            if (jsonData["paySlipDetails"] == null ||
                jsonData["paySlipDetails"].isEmpty ||
                jsonData["paySlipDetails"].toString() == "") {
              paySlip = "";
              setState(() {});
            } else if (jsonData["paySlipDetails"][0]["payslip"] == null ||
                jsonData["paySlipDetails"][0]["payslip"].isEmpty) {
              paySlip = "";
              setState(() {});
            } else {
              paySlip = jsonData["paySlipDetails"][0]["payslip"];
              setState(() {});
            }
            setState(() {
              loading = false;
            });
          } else {
            paySlip = "";
            setState(() {});
            setState(() {
              loading = false;
            });
            commonAlertDialog(
                this.context, jsonData["status"], jsonData["message"]);
          }
        }
      });
    } else {
      paySlip = "";
      setState(() {});
      showOfflineSnakbar(this.context);
    }
  }
}
