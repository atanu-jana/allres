import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/otherUtils.dart';

customDevelopedByButton(BuildContext context) => GestureDetector(
      onTap: () => launchURL("http://infymax.com/"),
      child: Container(
        width: screenWidth,
        height: screenWidth * 0.2,
        alignment: Alignment.center,
        child: Column(
          children: [
            Text(
              "Developed by",
              style: TextStyle(
                  color: AllColor.greyColor, fontSize: screenWidth * 0.022),
              textAlign: TextAlign.center,
            ),
            Image.asset(
              "assets/images/logo.png",
              height: screenHeight * 0.05,
            ),
            Text(
              "Infymax Solutions Pvt Ltd.",
              style: TextStyle(
                color: AllColor.primaryColor,
                fontSize: screenWidth * 0.03,
                decoration: TextDecoration.underline,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
