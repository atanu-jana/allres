import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/workPlan/workPlanBody.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/customCardItemGradinet.dart';
import 'package:line_icons/line_icons.dart';

List<String> dropdownListForDelegate = [AllString.select];
List<String> dropdownListForDelegateForLocalCategory = [AllString.select];
String previousValue = AllString.select;

class DropdownButtonWithSearch extends StatefulWidget {
  List<String> dropdownList;
  Function(String?) onChanged;
  String selectedValue;
  IconData icon;
  bool whiteTheme;

  DropdownButtonWithSearch({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
    this.whiteTheme = false,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchState createState() =>
      _DropdownButtonWithSearchState();
}

class _DropdownButtonWithSearchState extends State<DropdownButtonWithSearch> {
  @override
  void initState() {
    super.initState();
    dropdownListForDelegate = widget.dropdownList;
    setState(() {});

    previousValue = widget.selectedValue;

    dropdownListForDelegate = widget.dropdownList;
    // widget.controller.text = widget.dripdownList.first.toString();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegate(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                    color:
                        widget.whiteTheme ? AllColor.white : AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: widget.whiteTheme
                              ? AllColor.white
                              : AllColor.primaryDeepColor,
                        )),
                    Container(
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            color: widget.whiteTheme
                                ? AllColor.white
                                : AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color:
                          widget.whiteTheme ? AllColor.white : AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegate<T> extends SearchDelegate<T> {
  List<String> data = dropdownListForDelegate;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}


class DropdownButtonWithSearchProject extends StatefulWidget {
  final List<String> dropdownList;
  final Function(String?) onChanged;
  final String selectedValue;
  final IconData icon;
  const DropdownButtonWithSearchProject({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchProjectState createState() =>
      _DropdownButtonWithSearchProjectState();
}

class _DropdownButtonWithSearchProjectState
    extends State<DropdownButtonWithSearchProject> {
  @override
  void initState() {
    super.initState();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegateProject(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: AllColor.primaryDeepColor,
                        )),
                    Container(
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            color: AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color: AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegateProject<T> extends SearchDelegate<T> {
  List<String> data = projectList;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}

class DropdownButtonWithSearchForDealerList extends StatefulWidget {
  final List<String> dropdownList;
  final Function(String?) onChanged;
  final String selectedValue;
  final IconData icon;
  const DropdownButtonWithSearchForDealerList({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchForDealerListState createState() =>
      _DropdownButtonWithSearchForDealerListState();
}

class _DropdownButtonWithSearchForDealerListState
    extends State<DropdownButtonWithSearchForDealerList> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegateForDealerList(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: AllColor.primaryDeepColor,
                        )),
                    Container(
                        width: screenWidth * 0.6,
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            overflow: true,
                            color: AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color: AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegateForDealerList<T> extends SearchDelegate<T> {
  List<String> data = dealerList;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}

class DropdownButtonWithSearchForCategoryList extends StatefulWidget {
  final List<String> dropdownList;
  final Function(String?) onChanged;
  final String selectedValue;
  final IconData icon;
  const DropdownButtonWithSearchForCategoryList({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchForCategoryListState createState() =>
      _DropdownButtonWithSearchForCategoryListState();
}

class _DropdownButtonWithSearchForCategoryListState
    extends State<DropdownButtonWithSearchForCategoryList> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegateForCategoryist(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: AllColor.primaryDeepColor,
                        )),
                    Container(
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            color: AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color: AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegateForCategoryist<T> extends SearchDelegate<T> {
  List<String> data = categoryList;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}

class DropdownButtonWithSearchForBrandList extends StatefulWidget {
  final List<String> dropdownList;
  final Function(String?) onChanged;
  final String selectedValue;
  final IconData icon;
  const DropdownButtonWithSearchForBrandList({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchForBrandListState createState() =>
      _DropdownButtonWithSearchForBrandListState();
}

class _DropdownButtonWithSearchForBrandListState
    extends State<DropdownButtonWithSearchForBrandList> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegateForBrandList(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: AllColor.primaryDeepColor,
                        )),
                    Container(
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            color: AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color: AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegateForBrandList<T> extends SearchDelegate<T> {
  List<String> data = brandList;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}

class DropdownButtonWithSearchForSuggetionType extends StatefulWidget {
  final List<String> dropdownList;
  final Function(String?) onChanged;
  final String selectedValue;
  final IconData icon;
  const DropdownButtonWithSearchForSuggetionType({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchForSuggetionTypeState createState() =>
      _DropdownButtonWithSearchForSuggetionTypeState();
}

class _DropdownButtonWithSearchForSuggetionTypeState
    extends State<DropdownButtonWithSearchForSuggetionType> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegateForSuggetionType(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: AllColor.primaryDeepColor,
                        )),
                    Container(
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            color: AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color: AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegateForSuggetionType<T> extends SearchDelegate<T> {
  List<String> data = suggestionTypeDetails;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}






































 

class DropdownButtonWithSearchForLocalCategory extends StatefulWidget {
  List<String> dropdownList;
  Function(String?) onChanged;
  String selectedValue;
  IconData icon;
  bool whiteTheme;

  DropdownButtonWithSearchForLocalCategory({
    Key? key,
    required this.dropdownList,
    required this.onChanged,
    required this.selectedValue,
    required this.icon,
    this.whiteTheme = false,
  }) : super(key: key);

  @override
  _DropdownButtonWithSearchForLocalCategoryState createState() =>
      _DropdownButtonWithSearchForLocalCategoryState();
}

class _DropdownButtonWithSearchForLocalCategoryState extends State<DropdownButtonWithSearchForLocalCategory> {
  @override
  void initState() {
    super.initState();
    dropdownListForDelegateForLocalCategory = widget.dropdownList;
    setState(() {});

    previousValue = widget.selectedValue;

    dropdownListForDelegateForLocalCategory = widget.dropdownList;
    // widget.controller.text = widget.dripdownList.first.toString();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
          onTap: () async {
            // focusNode!.unfocus();
            var result = await showSearch<String>(
              context: context,
              delegate: CustomDelegateForLocalCategory(),
            );
            widget.onChanged(
                result == null || result == "" ? AllString.select : result);
            // setState(() => widget.controller.text = result!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(
              vertical: screenWidth * 0.03,
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                    color:
                        widget.whiteTheme ? AllColor.white : AllColor.black)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.03),
                        child: normalIcon(
                          widget.icon,
                          color: widget.whiteTheme
                              ? AllColor.white
                              : AllColor.primaryDeepColor,
                        )),
                    Container(
                        child: normalText(
                            widget.selectedValue
                                .split(AllString.splitText)
                                .first,
                            color: widget.whiteTheme
                                ? AllColor.white
                                : AllColor.black)),
                  ],
                ),
                Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
                    child: normalIcon(
                      Icons.expand_more_rounded,
                      color:
                          widget.whiteTheme ? AllColor.white : AllColor.black,
                    )),
              ],
            ),
          )),
    );
  }
}

class CustomDelegateForLocalCategory<T> extends SearchDelegate<T> {
  List<String> data = dropdownListForDelegateForLocalCategory;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) ||
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: normalText(listToShow[i].split(AllString.splitText).first,
              color: AllColor.black),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}