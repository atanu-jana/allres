import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allText.dart';

customAppBar(BuildContext context, String title,
        {Color? color,
        Function()? onBackPress,
        List<Widget>? actions,
        bool smallTitle = false}) =>
    AppBar(
        actions: actions == null ? [] : actions,
        // brightness: Brightness.dark,
        elevation: 0,
        // backgroundColor: color ?? AllColor.primaryDeepColor,
        backgroundColor: color ?? AllColor.white,
        iconTheme: IconThemeData(color: AllColor.black),
        centerTitle: true,
        title: smallTitle
            ? smallText(
                title,
                color: AllColor.black,
                center: true,
              )
            : headingText(
                title,
                color: AllColor.black,
                center: true,
              ),
        leading: IconButton(
            // child: Center(
            //   child: SvgPicture.asset(
            //     "assets/icons/back.svg",
            //     width: screenWidth * 0.06,
            //     height: screenWidth * 0.06,
            //   ),
            // ),
            icon: Center(
              child: Icon(
                Icons.arrow_back,
                color: AllColor.black,
              ),
            ),
            onPressed: onBackPress == null
                ? () => Navigator.pop(context)
                : onBackPress));
