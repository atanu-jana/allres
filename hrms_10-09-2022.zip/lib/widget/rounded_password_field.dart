import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:simple_tooltip/simple_tooltip.dart';

class RoundedPasswordField extends StatefulWidget {
  final String hintText;
  final FocusNode focusNode;
  final IconData iconData;
  final bool showToolTip;
  final String? errorText;

  final Function(String val)? onchangeFunction;
  final TextInputAction textInputAction;
  final TextEditingController controller;

  const RoundedPasswordField(
      {Key? key,
      required this.hintText,
      required this.showToolTip,
      required this.errorText,
      required this.onchangeFunction,
      required this.iconData,
      required this.textInputAction,
      required this.focusNode,
      required this.controller})
      : super(key: key);
  @override
  _RoundedPasswordFieldState createState() => _RoundedPasswordFieldState();
}

class _RoundedPasswordFieldState extends State<RoundedPasswordField> {
  bool obscureText = true;

  @override
  Widget build(BuildContext context) {
    return SimpleTooltip(
      tooltipTap: () {},
      animationDuration: Duration(seconds: 1),
      show: widget.showToolTip,
      tooltipDirection: TooltipDirection.up,
      ballonPadding: EdgeInsets.zero,
      minimumOutSidePadding: 0,
      arrowBaseWidth: 8,
      arrowLength: 10,
      arrowTipDistance: 0,
      backgroundColor: AllColor.primaryColor,
      borderWidth: 0,
      content: Container(
        child: Text(
          widget.errorText!,
          style: TextStyle(
            color: AllColor.white,
            fontSize: screenWidth * 0.025,
            decoration: TextDecoration.none,
          ),
        ),
      ),
      hideOnTooltipTap: true,
      child: Container(
                     height:screenWidth * 0.13,

        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.02, vertical: screenWidth * 0.008),
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7.0),
            border: Border.all(color: AllColor.primaryDeepColor, width: 1.5)),
        child: TextField(
          keyboardType: TextInputType.visiblePassword,
          textInputAction: widget.textInputAction,
          focusNode: widget.focusNode,
          controller: widget.controller,
          obscureText: this.obscureText,
          cursorColor: AllColor.primaryDeepColor,
          textAlignVertical: TextAlignVertical.center,
          
          onChanged: widget.onchangeFunction,
          decoration: InputDecoration(
            focusedBorder: InputBorder.none,
            prefixIcon: mediumIcon(
              widget.iconData,
              color: AllColor.primaryDeepColor,
            ),
            isDense: true,
            contentPadding: EdgeInsets.zero,
            focusedErrorBorder: InputBorder.none,
            suffixIcon: GestureDetector(
                child: Icon(
                  obscureText ? Icons.visibility : Icons.visibility_off,
                  color: AllColor.primaryDeepColor,
                ),
                onTap: () {
                  obscureText = !obscureText;
                  setState(() {});
                }),
            errorBorder: InputBorder.none,
            border: InputBorder.none,
            hintText: widget.hintText,
            labelStyle: normalTextStyle(color: AllColor.primaryColor),
          ),
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:smartcheck/common/common.dart';
// import 'package:smartcheck/main.dart';
// import 'package:smartcheck/res/allColors.dart';

// class RoundedPasswordField extends StatefulWidget {
//   final String hintText;
//   final FocusNode focusNode;
//   final IconData iconData;
//   final TextInputAction textInputAction;
//   final TextEditingController controller;

//   const RoundedPasswordField(
//       {Key? key,
//       required this.iconData,
//       required this.hintText,
//       required this.textInputAction,
//       required this.focusNode,
//       required this.controller})
//       : super(key: key);
//   @override
//   _RoundedPasswordFieldState createState() => _RoundedPasswordFieldState();
// }

// class _RoundedPasswordFieldState extends State<RoundedPasswordField> {
//   bool obscureText = true;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       // height: screenWidth * 0.13,
//       margin: EdgeInsets.symmetric(
//           horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
//       child: TextField(
//         keyboardType: TextInputType.visiblePassword,
//         textInputAction: widget.textInputAction,
//         focusNode: widget.focusNode,
//         controller: widget.controller,
//         obscureText: this.obscureText,
//         obscuringCharacter: "*",
        
//         cursorColor: AllColor.primaryDeepColor,
//         decoration: InputDecoration(
//           enabledBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           disabledBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           focusedBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.primaryDeepColor),
//           ),
//           focusedErrorBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           errorBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           prefixIcon: Icon(
//             widget.iconData,
//             color: AllColor.primaryDeepColor,
//           ),
//           isDense: true,
//           contentPadding: EdgeInsets.zero,
//           suffixIcon: GestureDetector(
//               child: Icon(
//                 obscureText ? Icons.visibility : Icons.visibility_off,
//                 size: screenWidth * 0.04,
//                 color: AllColor.primaryDeepColor,
//               ),
//               onTap: () {
//                 obscureText = !obscureText;
//                 setState(() {});
//               }),
//                 errorText: "",
//           errorStyle: extraSmallTextStyle(color: AllColor.red),
//           labelText: widget.hintText,
//           labelStyle: smallTextStyle(color: AllColor.greyColor),
//         ),
//       ),
//     );
//   }
// }
