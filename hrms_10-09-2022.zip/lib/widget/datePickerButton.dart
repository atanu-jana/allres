import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:intl/intl.dart';

datePickerButton(
    BuildContext context, DateTime date, IconData icon, Function() onPicked,
    {bool enable = true,bool dense=false}) {
  return Container(
    margin:dense?EdgeInsets.zero: EdgeInsets.symmetric(
        horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
    child: GestureDetector(
      onTap:onPicked,
      child: Container(
        padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.02, vertical: screenHeight * 0.01),
        // decoration: BoxDecoration(
        //     gradient: LinearGradient(
        //         begin: Alignment(-5, 1),
        //         end: Alignment(0, 0),
        //         colors: [
        //           AllColor.primaryColor.withOpacity(0.5),
        //           AllColor.primaryDeepColor
        //         ]),
        //     borderRadius: BorderRadius.circular(5)),
        child: Row(
          children: [
         
            Text(convertStringToDate(date),
                textAlign: TextAlign.center,
                style: normalTextStyle(color: AllColor.primaryDeepColor)),
                   Container(
              margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
              child: normalIcon(icon,color: AllColor.primaryDeepColor),
            ),
          ],
        ),
      ),
    ),
  );
}

Future<DateTime> selectDate(
  BuildContext context,
  DateTime initialDate,
) async {
  DateTime? newSelectedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: ColorScheme.dark(
              primary: Colors.blue,
              onPrimary: Colors.white,
              surface: Colors.blue,
              onSurface: Colors.black,
            ),
            dialogBackgroundColor: Colors.white,
          ),
          child: child!,
        );
      });
return newSelectedDate??initialDate;
}
Future<DateTime> selectDateWithFromAndToDate(
  BuildContext context,
  DateTime initialDate,
  DateTime firstDatee,
  DateTime lastDatee,
) async {
  DateTime? newSelectedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate:firstDatee,
      lastDate: lastDatee,
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: ColorScheme.dark(
              primary: Colors.blue,
              onPrimary: Colors.white,
              surface: Colors.blue,
              onSurface: Colors.black,
            ),
            dialogBackgroundColor: Colors.white,
          ),
          child: child!,
        );
      });
return newSelectedDate??initialDate;
}
