import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:photo_view/photo_view.dart';

class NetworkImageView extends StatefulWidget {
  final String url;
  NetworkImageView({Key? key, required this.url}) : super(key: key);

  @override 
  _NetworkImageViewState createState() => _NetworkImageViewState();
}

class _NetworkImageViewState extends State<NetworkImageView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            child: InkWell(
                child: Container(
                    width: screenWidth,
                    height: screenHeight,
                    // decoration: BoxDecoration(
                    //     image: DecorationImage(
                    //         fit: BoxFit.cover, image: NetworkImage(imageUrl))),
                    child: PhotoView(
                      filterQuality: FilterQuality.high,
                      gaplessPlayback: false,
                      customSize: MediaQuery.of(context).size,
                      minScale: PhotoViewComputedScale.contained * 0.8,
                      maxScale: PhotoViewComputedScale.covered * 1.8,
                      initialScale: PhotoViewComputedScale.contained,
                      enableRotation: true,
                      backgroundDecoration:
                          BoxDecoration(color: AllColor.white),
                      errorBuilder: (_, __, ___) {
                        return Container(
                          width: screenWidth,
                          height: screenHeight,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image:
                                      AssetImage("assets/images/appLogo.png"))),
                        );
                      },
                      // imageProvider: MemoryImage(
                      //   Base64Decoder().convert(
                      //       base64.normalize(widget.url.toString().trim())),
                      // ),
                      imageProvider: NetworkImage( widget.url.toString(),
                      ),
                      loadingBuilder: (context, event) {
                        if (event == null) {
                          return Scaffold(
                            backgroundColor: AllColor.white,
                            body: Center(
                              child: Text("Loading"),
                            ),
                          );
                        }

                        final value = event.cumulativeBytesLoaded /
                            (event.expectedTotalBytes ??
                                event.cumulativeBytesLoaded);

                        final percentage = (100 * value).floor();
                        return Scaffold(
                          backgroundColor: AllColor.white,
                          body: Center(
                            child: Text("$percentage%"),
                          ),
                        );
                      },
                    )))));
  }
}
