import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';

listDetailsClickedArrow() {
  return Container(
    width: screenWidth * 0.05,
    height: screenWidth * 0.05,
    child:
        normalIcon(Icons.arrow_forward_ios_rounded, color: AllColor.greyColor),
  );
}
