import 'package:hr/main.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

customDrawerTile(BuildContext context, IconData icon, String title,
        bool enableBottomBorder, Function() onTap) =>
    GestureDetector(
      onTap: onTap,
      child: Container(
        // color:
        //     AllString.selectedPage == title ? AllColor.lightGrey : AllColor.white,
        width: screenWidth,
        height: screenWidth * 0.13,
        decoration: BoxDecoration(
            color: AllColor.white,
            // border: Border(
            //     bottom: BorderSide(
            //         color: enableBottomBorder
            //             ? AllColor.primaryDeepColor
            //             : AllColor.white,
            //         width: 1))
                    
                    ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: screenWidth * 0.03,
            ),
            Container(
              width: screenWidth * 0.08,
              height: screenWidth * 0.08,
              child: Icon(
                icon,
                color: AllColor.black,
                // width: AllString.selectedPage == title
                //     ? screenWidth * 0.055
                //     : screenWidth * 0.045,
                // height: AllString.selectedPage == title
                //     ? screenWidth * 0.055
                //     : screenWidth * 0.045,
              ),
            ),
            Container(
              width: screenWidth * 0.04,
            ),
            Text(
              title,
              style: TextStyle(
                  color: AllColor.black,
                  //  AllString.selectedPage == title
                  // ? AllColor.primaryDeepColor
                  //     :
                  //  AllColor.black.withOpacity(0.7),
                  fontWeight: 
                  // currentScreenName == title
                  //     ?
                       FontWeight.bold
                      // : FontWeight.normal
                      ),
            ),
          ],
        ),
      ),
    );
