 
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';

class RoundedDateField extends StatelessWidget {
  final String? hintText;
  final IconData? icon;
  final IconData? suffixIcon;
  final TextEditingController? controller;
  final bool? enable;
  final Function(String val)? onchangeFunction;
  Function()? suffixFunction;
  RoundedDateField({
    Key? key,
    required this.hintText,
    required this.controller,
    this.enable = true,
    this.icon = Icons.person,
    this.suffixIcon = Icons.circle,
    required this.onchangeFunction,
    this.suffixFunction,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(

        // height: screenWidth * 0.13,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
        // margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
        // height: screenWidth * 0.16,
        padding: EdgeInsets.all(2),
        decoration: BoxDecoration(
            color:  Color(0xFFeeeeee),
            borderRadius: BorderRadius.circular(7.0),
            border: Border.all(color: AllColor.primaryColor, width: 1.5)),
        child: GestureDetector(
          onTap: suffixFunction,
          child: TextField(
            enabled: false,
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.start,
            controller: controller,
            cursorColor: AllColor.primaryColor,
            minLines: 1,
            style: normal2TextStyle(
                color:  AllColor.black),
            onChanged: onchangeFunction,
            decoration: InputDecoration(
              suffixIcon: GestureDetector(
                  child: mediumIcon(
                    suffixIcon!,
                    color: AllColor.primaryColor,
                  ),
                  onTap: suffixFunction),
              isDense: true,
              contentPadding: EdgeInsets.zero,
              errorBorder: InputBorder.none,
              focusedErrorBorder: InputBorder.none,
              errorStyle: extraSmallTextStyle(color: AllColor.red),
              counterText: "",
              prefixIcon: mediumIcon(
                icon!,
                color: AllColor.primaryColor,
              ),
              focusedBorder: InputBorder.none,
              border: InputBorder.none,
              hintText: hintText,

              // labelText: hintText,
              hintStyle: normal2TextStyle(color: AllColor.greyColor),
              labelStyle: normal2TextStyle(color: AllColor.primaryColor),
            ),
          ),
        ));
  }
}
