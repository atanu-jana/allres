import 'package:animated_button/animated_button.dart';
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/textCapitalized.dart';

alertButton(BuildContext context,
    {required Function() function,
    required Color color,
    double elevation = 1,
    Color textColor = Colors.white,
    String? text}) {
  return Container(
    padding: EdgeInsets.symmetric(
        vertical: screenWidth * 0.01, horizontal: screenWidth * 0.05),
    child:  AnimatedButton(
      width: screenWidth*0.25,
        child: Text(
          text!.capitalize(),
          style: normalTextStyle(color: AllColor.white),
        ),
        onPressed: function,
        duration: 70,
        height: screenWidth * 0.1,
        shadowDegree: ShadowDegree.dark,
        color: color,
      ),
  );
  // return GestureDetector(
  //   onTap: function,
  //   child: Container(
  // width: screenWidth * 0.26,
  // height: screenWidth * 0.1,
  //     decoration: BoxDecoration(
  //         color: AllColor.white,
  //         borderRadius: BorderRadius.circular(7),
  //         border: Border.all(color: color, width: 2)),
  //     alignment: Alignment.center,
  //     child: normalText(text!, color: textColor),
  //   ),
  // );
}
