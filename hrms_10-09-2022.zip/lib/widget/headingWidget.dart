import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allText.dart';

headingWidget(String headingTextString, Color color) => Container(
      width: screenWidth,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0),
      alignment: Alignment.centerLeft,
      height: screenWidth * 0.1,
      decoration: BoxDecoration(color: AllColor.white),
      child: headingText(headingTextString, color: color),
    );
