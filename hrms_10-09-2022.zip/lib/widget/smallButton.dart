
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/util/allTextStyle.dart';

smallButton(BuildContext context,
    {@required Function()? function,
    Color color = Colors.white,
    double elevation = 1,
    Color textColor = Colors.white,
    String? text,
    double? width}) {
  return Container(
    height: screenWidth * 0.06,
    margin: EdgeInsets.symmetric(vertical: screenWidth * 0.015),
    width: width,
    child: MaterialButton(
      elevation: elevation,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10000)),
      color: color,
      onPressed: function,
      child: Text(
        text!.toUpperCase(),
        style: smallTextStyle(color: textColor),
      ),
    ),
  );
}
