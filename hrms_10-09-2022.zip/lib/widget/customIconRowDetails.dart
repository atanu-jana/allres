import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';

customIconRowDetails(
    {required double width,
    required IconData icon,
    required String value,
    bool displayFullValue = false}) {
  return Container(
    width: width,
    padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: screenWidth * 0.06,
          height: screenWidth * 0.06,
          child: normalIcon(icon, color: AllColor.primaryDeepColor),
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
        ),
        Container(
          width: (width - screenWidth * 0.1) - 10,
          child: displayFullValue
              ? Text(value,
                  style: normalTextStyle(
                    color: AllColor.black,
                  ))
              : Text(value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: normalTextStyle(
                    color: AllColor.black,
                  )),
        ),
      ],
    ),
  );
}
