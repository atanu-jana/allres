import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';

class RoundedDropDownButton extends StatefulWidget {
  final TextEditingController controller;
  final List dripdownList;
  final String hintText;
  final IconData icon;
  final Function(String? value) onChange;
  const RoundedDropDownButton({
    Key? key,
    required this.controller,
    required this.hintText,
    required this.onChange,
    required this.icon,
    required this.dripdownList,
  }) : super(key: key);

  @override
  _RoundedDropDownButtonState createState() => _RoundedDropDownButtonState();
}

class _RoundedDropDownButtonState extends State<RoundedDropDownButton> {
  @override
  void initState() {
    super.initState();
    widget.controller.text = widget.dripdownList.first.toString();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        alignment: Alignment.center,
        margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
        child: DropdownButtonFormField(
          items: widget.dripdownList.map((value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Container(
                width: screenWidth * 0.2,
                child: Text(
                  value,
                  overflow: TextOverflow.ellipsis,
                  style: smallTextStyle(color: AllColor.black),
                ),
              ),
            );
          }).toList(),
          onChanged: widget.onChange,
          value: widget.controller.text,
          decoration: InputDecoration(
            isDense: true,
            contentPadding: EdgeInsets.zero,
            errorText: "",
            errorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AllColor.primaryColor),
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                )),
            focusedErrorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AllColor.red),
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                )),
            errorStyle: extraSmallTextStyle(color: AllColor.red),
            counterText: "",
            prefixIcon: normalIcon(widget.icon,
                color: "".isEmpty ? AllColor.primaryColor : AllColor.red),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(5.0)),
                borderSide: BorderSide(color: AllColor.primaryColor)),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                ),
                borderSide: BorderSide(color: AllColor.primaryColor)),
            hintText: widget.hintText,
            labelStyle: smallTextStyle(color: AllColor.greyColor),
          ),
        ));
  }
}
