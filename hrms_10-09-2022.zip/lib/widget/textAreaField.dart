import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allTextStyle.dart';

textAreaField(
  BuildContext context,
  String title,
  TextEditingController controller,
  int maxLines,
  int maxLength,
  TextInputAction textInputAction,
  TextInputType textInputType,
) {
  return Container(
    padding: EdgeInsets.all(2),
    decoration: BoxDecoration(
        color: AllColor.white,
        borderRadius: BorderRadius.circular(7.0),
        border: Border.all(color: AllColor.primaryDeepColor, width: 1.5)),
    margin: EdgeInsets.symmetric(vertical: screenHeight * 0.008),
    child: TextFormField(
      textAlignVertical: TextAlignVertical.bottom,
      textAlign: TextAlign.start,
      maxLines: maxLines,
      maxLength: maxLength,
      controller: controller,
      keyboardType: textInputType,
      textInputAction: textInputAction,
      onChanged: (_) {
        AppBuilder.of(context)!.rebuild();
      },
      decoration: InputDecoration(
        isDense: true,
        // prefixIcon:
        //     Icon(icon, size: screenWidth * 0.05, color: AllColor.primaryColor),
        border: InputBorder.none,
        filled: true,
        fillColor: AllColor.white,
        labelStyle: normalTextStyle(color: AllColor.primaryColor),
        contentPadding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.03, vertical: screenWidth * 0.0),
        hintText: title,
        focusedBorder: InputBorder.none,
      ),
    ),
  );
}
