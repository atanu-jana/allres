import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:simple_tooltip/simple_tooltip.dart';

class RoundedInputField extends StatelessWidget {
  final String? hintText;
  final int? maxLength;
  final IconData? icon;
  final TextEditingController? controller;
  final TextInputType? textInputType;
  final TextInputAction? textInputAction;
  final FocusNode? focusNode;
  final String? errorText;
  final bool? enable;
  final bool showToolTip;
  final Function(String val)? onchangeFunction;
  RoundedInputField({
    Key? key,
    required this.hintText,
    required this.controller,
    this.enable = true,
    required this.showToolTip,
    this.maxLength = 50,
    this.icon = Icons.person,
    required this.textInputType,
    required this.focusNode,
    required this.textInputAction,
    required this.errorText,
    required this.onchangeFunction,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SimpleTooltip(
        tooltipTap: () {},
        animationDuration: Duration(seconds: 3),
        show: showToolTip,
        tooltipDirection: TooltipDirection.up,
        ballonPadding: EdgeInsets.zero,
        minimumOutSidePadding: 0,
        arrowBaseWidth: 8,
        arrowLength: 10,
        arrowTipDistance: 0,
        backgroundColor: AllColor.primaryColor,
        borderWidth: 0,
        content: Container(
          child: Text(
            errorText!,
            style: TextStyle(
              color: AllColor.white,
              fontSize: screenWidth * 0.0,
              decoration: TextDecoration.none,
            ),
          ),
        ),
        hideOnTooltipTap: true,
        child: Container(
               height:screenWidth * 0.13,
        margin: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.02, vertical: screenWidth * 0.008),
            padding: EdgeInsets.all(5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7.0),
            border: Border.all(color: AllColor.primaryDeepColor, width: 1.5)),
        child: TextField(
              enabled: enable,
              textAlignVertical: TextAlignVertical.center,
              textAlign: TextAlign.start,
              focusNode: this.focusNode,
              maxLength: maxLength,
              keyboardType: textInputType,
              textInputAction: textInputAction,
              controller: controller,
         
              cursorColor: AllColor.primaryDeepColor,
              minLines: 1,
              onChanged: onchangeFunction,
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.zero,
                errorBorder: InputBorder.none,
                focusedErrorBorder: InputBorder.none,
                errorStyle: extraSmallTextStyle(color: AllColor.red),
                counterText: "",
                prefixIcon: mediumIcon(
                  icon!,
                  color: AllColor.primaryDeepColor,
                ),
                focusedBorder: InputBorder.none,
                border: InputBorder.none,
                hintText: hintText,
                labelStyle: normalTextStyle(
                    color: AllColor.primaryColor),
              ),
            )));
  }
}

// import 'package:smartcheck/common/common.dart';
// import 'package:smartcheck/main.dart';
// import 'package:smartcheck/res/allColors.dart';
// import 'package:flutter/material.dart';

// class RoundedInputField extends StatelessWidget {
//   final String? hintText;
//   final int? maxLength;
//   final IconData? icon;
//   final TextEditingController? controller;
//   final TextInputType? textInputType;
//   final TextInputAction? textInputAction;
//   final FocusNode? focusNode;
//   final String? errorText;
//   final bool? enable;
//   final bool? requiredField;
//   final Function(String val)? onchangeFunction;
//   const RoundedInputField({
//     Key? key,
//     required this.hintText,
//     required this.controller,
//     this.requiredField = false,
//     this.enable = true,
//     this.maxLength = 50,
//     this.icon = Icons.person,
//     required this.textInputType,
//     required this.focusNode,
//     required this.textInputAction,
//     required this.errorText,
//     required this.onchangeFunction,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       // height: screenWidth * 0.13,
//       margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
//       // height: screenWidth * 0.16,
//       child: TextField(

//         enabled: enable,
//         textAlignVertical: TextAlignVertical.center,
//         textAlign: TextAlign.start,
//         focusNode: this.focusNode,
//         maxLength: maxLength,
//         keyboardType: textInputType,
//         textInputAction: textInputAction,
//         controller: controller,
//         cursorColor: AllColor.primaryDeepColor,
//         minLines: 1,

//         style: midNormalTextStyle(color: AllColor.black),
//         onChanged: onchangeFunction,
//         decoration: InputDecoration(

//           enabledBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           disabledBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           focusedBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.primaryColor),
//           ),
//           focusedErrorBorder: UnderlineInputBorder(
//             borderSide: BorderSide(
//                 color: errorText!.isEmpty ? AllColor.primaryColor : AllColor.red),
//           ),
//           errorBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: errorText!.isEmpty ? AllColor.white : AllColor.red),
//           ),
//           border: UnderlineInputBorder(
//             borderSide: BorderSide(color: AllColor.white),
//           ),
//           isDense: true,
//           contentPadding: EdgeInsets.zero,
//           errorText: errorText,
//           errorStyle: extraSmallTextStyle(color: AllColor.red),
//           counterText: "",
//           prefixIcon: Icon(icon!,
//               color: errorText!.isEmpty ? AllColor.primaryColor : AllColor.red),
//           labelText: hintText,
//           labelStyle: smallTextStyle(color: AllColor.greyColor),
//         ),
//       ),
//     );
//   }
// }
class TooltipShapeBorder extends ShapeBorder {
  final double arrowWidth;
  final double arrowHeight;
  final double arrowArc;
  final double radius;

  TooltipShapeBorder({
    this.radius = 5.0,
    this.arrowWidth = 20.0,
    this.arrowHeight = 10.0,
    this.arrowArc = 0.0,
  }) : assert(arrowArc <= 1.0 && arrowArc >= 0.0);

  @override
  EdgeInsetsGeometry get dimensions => EdgeInsets.only(bottom: arrowHeight);

  // @override
  // Path getInnerPath(Rect rect, {TextDirection textDirection}) => null;

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) {
    rect = Rect.fromPoints(
        rect.topLeft, rect.bottomRight - Offset(0, arrowHeight));
    double x = arrowWidth, y = arrowHeight, r = 1 - arrowArc;
    return Path()
      ..addRRect(RRect.fromRectAndRadius(rect, Radius.circular(radius)))
      ..moveTo(rect.bottomCenter.dx + x / 2, rect.bottomCenter.dy)
      ..relativeLineTo(-x / 2 * r, y * r)
      ..relativeQuadraticBezierTo(
          -x / 2 * (1 - r), y * (1 - r), -x * (1 - r), 0)
      ..relativeLineTo(-x / 2 * r, -y * r);
  }

  @override
  void paint(Canvas canvas, Rect rect, {TextDirection? textDirection}) {}

  @override
  ShapeBorder scale(double t) => this;

  @override
  Path getInnerPath(Rect rect, {TextDirection? textDirection}) {
    // TODO: implement getInnerPath
    throw UnimplementedError();
  }
}
