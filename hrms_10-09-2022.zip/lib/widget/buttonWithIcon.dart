import 'package:animated_button/animated_button.dart';
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/textCapitalized.dart';

buttonWithIcon(BuildContext context,
    {required Function()? function,
    required Color color1,
    required Color color2,
    required IconData icon,
    bool enable = true,
    double elevation = 1,
    Color textColor = Colors.white,
    String? text,
    double? width}) {
      return   Container(
    width: width ?? screenWidth,
    alignment: Alignment.center,
    padding: EdgeInsets.symmetric(
        vertical: screenWidth * 0.01, horizontal: screenWidth * 0.05),
    child: Center(
      child: AnimatedButton(
        child:  Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(right: screenWidth * 0.02),
              child: normalIcon(icon),
            ),
            Text(
              // text!.toUpperCase(),
              text!.capitalize(),
              style: normalTextStyle(color: textColor),
            ),
          ],
        ),
        onPressed: enable ? function! : () {},
        duration: 70,
        height: screenWidth * 0.1,
        enabled: enable,
        shadowDegree: ShadowDegree.dark,
        color: color2,
      ),
    ),
  );
  // return GestureDetector(
  //   onTap: enable ? function : () {},
  //   child: Container(
  //     width: width ?? screenWidth,
  //     alignment: Alignment.center,
  //     child: Container(
  //       height: screenWidth * 0.08,
  //       margin: EdgeInsets.symmetric(vertical: screenWidth * 0.015),
  //         decoration: enable
  //           ? BoxDecoration(
  //               border: Border.all(color: color1, width: 2.0),
  //               borderRadius: BorderRadius.circular(1000),
  //               gradient: RadialGradient(
  //                 center: Alignment(0.55, 0.55),
  //                 focalRadius: 64,
  //                 colors: [color1.withOpacity(0.5), color2],
  //               ),
  //               boxShadow: [
  //                 BoxShadow(
  //                   color: AllColor.greyColor.withOpacity(0.5),
  //                   spreadRadius: 5,
  //                   blurRadius: 7,
  //                   offset: Offset(0, 3), // changes position of shadow
  //                 ),
  //               ],
  //               // gradient: LinearGradient(
  //               //     begin: Alignment(-5, 1),
  //               //     end: Alignment(0, 0),
  //               //     colors: [color1.withOpacity(0.5), color2]),
  //               // borderRadius: BorderRadius.circular(5)
  //             )
  //           : BoxDecoration(
  //               border: Border.all(
  //                   color: AllColor.black.withOpacity(0.2), width: 2.0),
  //               borderRadius: BorderRadius.circular(1000),
  //               gradient: RadialGradient(
  //                   center: Alignment(0.55, 0.55),
  //                   focalRadius: 64,
  //                   colors: [AllColor.greyColor, AllColor.greyColor]),
  //               boxShadow: [
  //                 BoxShadow(
  //                   color: AllColor.greyColor.withOpacity(0.2),
  //                   spreadRadius: 2,
  //                   blurRadius: 3,
  //                   offset: Offset(0, 2), // changes position of shadow
  //                 ),
  //               ],
  //               // gradient: LinearGradient(
  //               //     begin: Alignment(-5, 1),
  //               //     end: Alignment(0, 0),
  //               //     colors: [AllColor.greyColor, AllColor.greyColor]),
  //               // borderRadius: BorderRadius.circular(5)
  //             ),
  //       // decoration: enable
  //       //     ? BoxDecoration(
  //       //         gradient: LinearGradient(
  //       //             begin: Alignment(-5, 1),
  //       //             end: Alignment(0, 0),
  //       //             colors: [color1.withOpacity(0.5), color2]),
  //       //         borderRadius: BorderRadius.circular(5))
  //       //     : BoxDecoration(
  //       //         gradient: LinearGradient(
  //       //             begin: Alignment(-5, 1),
  //       //             end: Alignment(0, 0),
  //       //             colors: [AllColor.greyColor, AllColor.greyColor]),
  //       //         borderRadius: BorderRadius.circular(5)),
  //  padding: EdgeInsets.symmetric(
  //           vertical: screenWidth * 0.01, horizontal: screenWidth * 0.05),
        // child: Row(
        //   mainAxisSize: MainAxisSize.min,
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   crossAxisAlignment: CrossAxisAlignment.center,
        //   children: [
        //     Container(
        //       margin: EdgeInsets.only(right: screenWidth * 0.02),
        //       child: normalIcon(icon),
        //     ),
        //     Text(
        //       // text!.toUpperCase(),
        //       text!.capitalize(),
        //       style: normalTextStyle(color: textColor),
        //     ),
        //   ],
        // ),
  //     ),
  //   ),
  // );
}
