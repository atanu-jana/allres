import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allTextStyle.dart';

customCatender(double width, double height, double widthHeight, int index) {
  // DateTime date
  return Container(
    height: height,
    width: width,
    margin: EdgeInsets.only(right: screenWidth * 0.03),
    child: Center(
      child: Container(
        width: widthHeight,
        height: widthHeight,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: AllColor.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 5,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: screenWidth * 0.2,
              height: screenWidth * 0.08,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: AllColor.blueGrey,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                  )),
              child: Text(
                month[DateTime.now().month - 1].toString().substring(0, 3),
                textAlign: TextAlign.start,
                style: normalTextStyle(color: AllColor.white),
              ),
            ),
            Container(
              height: screenWidth * 0.1,
              alignment: Alignment.center,
              child: Text(((DateTime.now().day - 5) + index).toString(),
                  textAlign: TextAlign.start,
                  style: headingTextStyle(color: AllColor.black)),
            ),
          ],
        ),
      ),
    ),
  );
}
