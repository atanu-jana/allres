import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/util/allTextStyle.dart';
customButtonWithPNGIcon(BuildContext context,
    {required Function()? function,
    required String? icon,
    Color color = Colors.white,
    Color textColor = Colors.white,
    String? text,
    double? width}) {
  var function2 = function;
  return Container(
    height: screenWidth * 0.1,
    margin: EdgeInsets.symmetric(vertical: screenWidth * 0.03),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(8),
      color: color,
    ),
    width: width,
    child: GestureDetector(
      onTap: function2,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: screenWidth * 0.05,
            height: screenWidth * 0.05,
            margin: EdgeInsets.only(right: screenWidth * 0.02),
            child: Image.asset(icon!),
          ),
          Container(
            width: screenWidth * 0.15,
            child: Text(
              text!.toUpperCase(),
              textAlign: TextAlign.center,
              maxLines: 2,
              style: extraSmallTextStyle(color: textColor),
            ),
          ),
        ],
      ),
    ),
  );
}