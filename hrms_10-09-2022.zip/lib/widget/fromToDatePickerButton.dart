import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:intl/intl.dart';

fromToDatePickerButton(
    BuildContext context,
    double width,
    DateTime fromDate,
    DateTime toDate,
    IconData icon,
    Function() fromDateChnaged,
    Function() toDateChnaged,
    {bool enable = true}) {
  return Container(
    width: width,
    margin: EdgeInsets.symmetric(
        horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: fromDateChnaged,
          child: Container(
            padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.02, vertical: screenHeight * 0.01),
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment(-5, 1),
                    end: Alignment(0, 0),
                    colors: [
                      AllColor.primaryColor.withOpacity(0.5),
                      AllColor.primaryDeepColor
                    ]),
                borderRadius: BorderRadius.circular(5)),
            child: Column(
              children: [
                Text(
                  AllString.fromDate,
                  style: smallTextStyle(color: AllColor.greyColor),
                ),
                Row(
                  children: [
                    Container(
                      margin:
                          EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
                      child: normalIcon(icon),
                    ),
                    Text(convertStringToDate(fromDate),
                        textAlign: TextAlign.center,
                        style: normalTextStyle(color: AllColor.white)),
                  ],
                ),
              ],
            ),
          ),
        ),
        GestureDetector(
          onTap: toDateChnaged,
          child: Container(
            padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.02, vertical: screenHeight * 0.01),
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment(-5, 1),
                    end: Alignment(0, 0),
                    colors: [
                      AllColor.primaryColor.withOpacity(0.5),
                      AllColor.primaryDeepColor
                    ]),
                borderRadius: BorderRadius.circular(5)),
            child: Column(
              children: [
                Text(
                  AllString.toDate,
                  style: smallTextStyle(color: AllColor.greyColor),
                ),
                Row(
                  children: [
                    Container(
                      margin:
                          EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
                      child: normalIcon(icon),
                    ),
                    Text(convertStringToDate(toDate),
                        textAlign: TextAlign.center,
                        style: normalTextStyle(color: AllColor.white)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

Future<DateTime> selectDateForFromAndTO(
  BuildContext context,
  DateTime initialDate,
  bool toDate
) async {
  DateTime? newSelectedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate:DateTime.now(),
      // lastDate:toDate? DateTime(2050):DateTime.now(),
      lastDate: DateTime(2050),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: ColorScheme.dark(
              primary: Colors.blue,
              onPrimary: Colors.white,
              surface: Colors.blue,
              onSurface: Colors.black,
            ),
            dialogBackgroundColor: Colors.white,
          ),
          child: child!,
        );
      });
return newSelectedDate??initialDate;
}
