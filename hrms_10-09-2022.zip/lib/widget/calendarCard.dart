import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allFormatter.dart';
import 'package:hr/util/allTextStyle.dart';

calendarCard(double width, double height, double widthHeight, DateTime date) {
  // DateTime date
  return Card(
    margin: EdgeInsets.only(
      right: screenWidth * 0.03,
      left: screenWidth * 0.02,
      top: screenWidth * 0.02,
      bottom: screenWidth * 0.02,
    ),
    child: Container(
      width: screenWidth * 0.18,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: AllColor.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 5,
              offset: Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: AllColor.blueGrey,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                  )),
              child: Text(
                month[date.month - 1].toString().substring(0, 3),
                textAlign: TextAlign.start,
                style: normalTextStyle(color: AllColor.white),
              ),
            ),
            Container(
              alignment: Alignment.center,
              child: Text(
                  ((date.day)).toString().length == 1
                      ? "0" + ((date.day)).toString()
                      : ((date.day)).toString(),
                  textAlign: TextAlign.start,
                  style: headingTextStyle(color: AllColor.black)),
            ),
            Container(
              alignment: Alignment.center,
              child: Text(((date.year)).toString(),
                  textAlign: TextAlign.start,
                  style: smallTextStyle(color: AllColor.greyColor)),
            ),
          ],
        ),
      ),
    ),
  );
}
