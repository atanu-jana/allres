import 'package:animated_button/animated_button.dart';
import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/textCapitalized.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';

button(BuildContext context,
    {required Function()? function,
    required Color color,
    bool enable = true,
    Color textColor = Colors.white,
    String? text,
    double? width,
    RoundedLoadingButtonController? btnController}) {
  return Container(
    // width: width ?? screenWidth,
    alignment: Alignment.center,
    padding: EdgeInsets.symmetric(
        vertical: screenWidth * 0.01, horizontal: screenWidth * 0.05),
    child: Center(
      child: AnimatedButton(
        width: width ?? screenWidth - 150,
        child: Text(
          text!.capitalize(),
          style: normalTextStyle(color: textColor),
        ),
        onPressed: enable ? function! : () {},
        duration: 70,
        height: screenWidth * 0.1,
        enabled: enable,
        shadowDegree: ShadowDegree.dark,
        color: color,
      ),
    ),
  );
//       return Container(
//             width: width ?? screenWidth,
//     alignment: Alignment.center,
//     padding: EdgeInsets.symmetric(
//         vertical: screenWidth * 0.01, horizontal: screenWidth * 0.05),
//         child: RoundedLoadingButton(
//           color: color2,
//     child: Text(
//           text!.capitalize(),
//           style: normalTextStyle(color: textColor),
//         ),
//     controller: btnController!,
//     onPressed: enable ? function! : () {},
// ),
//       );
  // return GestureDetector(
  //   onTap: enable ? function : () {},
  //   child: Container(
  //     width: width ?? screenWidth,
  //     alignment: Alignment.center,
  //     child: Container(
  //       // height: screenWidth * 0.08,
  //       margin: EdgeInsets.symmetric(vertical: screenWidth * 0.015),
  //       decoration: enable
  //           ? BoxDecoration(
  //               border: Border.all(color: color1, width: 2.0),
  //               borderRadius: BorderRadius.circular(1000),
  //               gradient: RadialGradient(
  //                 center: Alignment(0.55, 0.55),
  //                 focalRadius: 64,
  //                 colors: [color1.withOpacity(0.5), color2],
  //               ),
  //               boxShadow: [
  //                 BoxShadow(
  //                   color: AllColor.greyColor.withOpacity(0.5),
  //                   spreadRadius: 5,
  //                   blurRadius: 7,
  //                   offset: Offset(0, 3), // changes position of shadow
  //                 ),
  //               ],
  //               // gradient: LinearGradient(
  //               //     begin: Alignment(-5, 1),
  //               //     end: Alignment(0, 0),
  //               //     colors: [color1.withOpacity(0.5), color2]),
  //               // borderRadius: BorderRadius.circular(5)
  //             )
  //           : BoxDecoration(
  //               border: Border.all(
  //                   color: AllColor.black.withOpacity(0.2), width: 2.0),
  //               borderRadius: BorderRadius.circular(1000),
  //               gradient: RadialGradient(
  //                   center: Alignment(0.55, 0.55),
  //                   focalRadius: 64,
  //                   colors: [AllColor.greyColor, AllColor.greyColor]),
  //               boxShadow: [
  //                 BoxShadow(
  //                   color: AllColor.greyColor.withOpacity(0.2),
  //                   spreadRadius: 2,
  //                   blurRadius: 3,
  //                   offset: Offset(0, 2), // changes position of shadow
  //                 ),
  //               ],
  //               // gradient: LinearGradient(
  //               //     begin: Alignment(-5, 1),
  //               //     end: Alignment(0, 0),
  //               //     colors: [AllColor.greyColor, AllColor.greyColor]),
  //               // borderRadius: BorderRadius.circular(5)
  //             ),
  // padding: EdgeInsets.symmetric(
  //     vertical: screenWidth * 0.01, horizontal: screenWidth * 0.05),
  //       child: Row(
  //         mainAxisSize: MainAxisSize.min,
  //         mainAxisAlignment: MainAxisAlignment.center,
  //         crossAxisAlignment: CrossAxisAlignment.center,
  //         children: [
  //           Text(
  //             // text!.toUpperCase(),
  //             text!.capitalize(),
  //             style: normalTextStyle(color: textColor),
  //           ),
  //         ],
  //       ),
  //     ),
  //   ),
  // );
}
