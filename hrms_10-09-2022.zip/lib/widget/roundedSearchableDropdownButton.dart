import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allIcon.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/otherUtils.dart';

class RoundedSearchableDropDownButton extends StatefulWidget {
  final TextEditingController controller;
  final List dripdownList;
  final String hintText;
  final IconData icon;
  const RoundedSearchableDropDownButton({
    Key? key,
    required this.controller,
    required this.hintText,
    required this.icon,
    required this.dripdownList,
  }) : super(key: key);

  @override
  _RoundedSearchableDropDownButtonState createState() =>
      _RoundedSearchableDropDownButtonState();
}

class _RoundedSearchableDropDownButtonState
    extends State<RoundedSearchableDropDownButton> {
  @override
  void initState() {
    super.initState();
    widget.controller.text = widget.dripdownList.first.toString();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: screenWidth * 0.13,
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.02, vertical: screenHeight * 0.008),
      child: GestureDetector(
        onTap: () async {
          // focusNode!.unfocus();
          var result = await showSearch<String>(
            context: context,
            delegate: CustomDelegate(),
          );
          setState(() => widget.controller.text = result!);
        },
        child: TextField(
          controller: widget.controller,
          cursorColor: AllColor.primaryColor,
          minLines: 1,
          style: midNormalTextStyle(color: AllColor.black),
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AllColor.primaryColor),
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                )),
            disabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AllColor.primaryColor),
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                )),
            isDense: true,
            enabled: false,
            errorText: " ",
            contentPadding: EdgeInsets.zero,
            errorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AllColor.primaryColor),
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                )),
            focusedErrorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AllColor.primaryColor),
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                )),
            errorStyle: extraSmallTextStyle(color: AllColor.red),
            counterText: "",
            prefixIcon: normalIcon(widget.icon, color: AllColor.primaryColor),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(5.0)),
                borderSide: BorderSide(color: AllColor.primaryColor)),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(5.0),
                ),
                borderSide: BorderSide(color: AllColor.primaryColor)),
            hintText: widget.hintText,
            labelStyle: smallTextStyle(color: AllColor.greyColor),
          ),
        ),
      ),
    );
  }
}

class CustomDelegate<T> extends SearchDelegate<T> {
  List<String> data = stateList;

  @override
  List<Widget> buildActions(BuildContext context) =>
      [IconButton(icon: Icon(Icons.clear), onPressed: () => query = '')];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
      icon: Icon(Icons.chevron_left), onPressed: () => close(context, '' as T));

  @override
  Widget buildResults(BuildContext context) => Container();

  @override
  Widget buildSuggestions(BuildContext context) {
    List listToShow;
    if (query.isNotEmpty)
      listToShow = data
          .where((e) =>
              e.toString().toLowerCase().contains(query) &&
              e.toString().toLowerCase().startsWith(query))
          .toList();
    else
      listToShow = data;

    return ListView.builder(
      itemCount: listToShow.length,
      itemBuilder: (_, i) {
        return ListTile(
          title: Text(listToShow[i]),
          onTap: () => close(context, listToShow[i]),
        );
      },
    );
  }
}
