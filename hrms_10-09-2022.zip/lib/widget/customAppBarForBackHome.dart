import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/pages/home/home.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/res/allString.dart';
import 'package:flutter/cupertino.dart';

customAppBarForBackHome(BuildContext context, String title, {Color? color}) =>
    AppBar(
      iconTheme: IconThemeData(color: AllColor.black),
      elevation: 0,
      // backgroundColor: color ?? AllColor.primaryColor,
      backgroundColor: color ?? AllColor.white,
      // shadowColor: AllColor.primaryColor,
      // flexibleSpace: Container(
      //     decoration: BoxDecoration(
      //   gradient: LinearGradient(
      //       begin: Alignment(-5, 1),
      //       end: Alignment(0, 0),
      //       colors: [
      //         // Color(0xff005C97),
      //         // Color(0xff363795)
      //         Color(0xff536976),
      //         Color(0xff292E49)
      //         // Color.fromRGBO(2, 0, 36, 0.8)
      //         // Color.fromRGBO(2, 0, 36, 1),
      //         // Color.fromRGBO(9, 9, 121, 1),
      //         // Color.fromRGBO(9, 9, 121, 1),
      //         // Color.fromRGBO(0, 212, 255, 1)
      //       ]),
      // )),
      leading: GestureDetector(
        // child: Center(
        //   child: SvgPicture.asset(
        //     "assets/icons/back.svg",
        //     width: screenWidth * 0.06,
        //     height: screenWidth * 0.06,
        //   ),
        // ),
        child: Center(
          child: IconButton(
            onPressed: () => Navigator.push(
                context, CupertinoPageRoute(builder: (context) => Home())),
            icon: Icon(
              Icons.arrow_back,
              color: AllColor.black,
            ),
          ),
        ),
      ),
      title: headingText(title, color: AllColor.black),
      centerTitle: true,
      // brightness: Brightness.dark,
      actions: currentScreenName == AllString.dashboard
          ? [
              // GestureDetector(
              //   onTap: () {
              //     AllString.selectedPage = AllString.dashboard;
              //     AllString.currentPage = AllString.cart;

              //     AppBuilder.of(context).rebuild();
              //     Navigator.of(context).pushReplacement(
              //         CupertinoPageRoute(builder: (context) => CartPage()));
              //   },
              //   child: Container(
              //       margin: EdgeInsets.symmetric(
              //         horizontal: screenWidth >= 600
              //             ? screenWidth * 0.02
              //             : screenWidth * 0.0,
              //       ),
              //       child: CircleAvatar(
              //         backgroundColor: AllColor.primaryColor,
              //         child: SvgPicture.asset(
              //           "assets/icons/cart.svg",
              //           width: screenWidth * 0.06,
              //           height: screenWidth * 0.06,
              //         ),
              //       )),
              // ),
              // GestureDetector(
              //   onTap: () {
              //     AllString.selectedPage = AllString.dashboard;
              //     AllString.currentPage = AllString.dashboard;

              //     AppBuilder.of(context)!.rebuild();
              //     Navigator.of(context).push(CupertinoPageRoute(
              //         builder: (context) => NotificationPage()));
              //   },
              //   child: Container(
              //       margin: EdgeInsets.symmetric(
              //         horizontal: screenWidth >= 600
              //             ? screenWidth * 0.02
              //             : screenWidth * 0.0,
              //       ),
              //       child: CircleAvatar(
              //         backgroundColor: AllColor.primaryColor,
              //         child: SvgPicture.asset(
              //           "assets/icons/bell.svg",
              //           width: screenWidth * 0.06,
              //           height: screenWidth * 0.06,
              //         ),
              //       )),
              // ),
            ]
          : [],
    );
