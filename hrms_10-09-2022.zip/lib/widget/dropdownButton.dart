import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:line_icons/line_icons.dart';

dropdownButton(List<String> dropdownList, Function(String?) onChanged,
        String selectedValue) =>
    Container(
      margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.03),
      child: FormField<String>(builder: (FormFieldState<String> state) {
        return InputDecorator(
            decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.03,
                  vertical: screenWidth * 0.02,
                ),
                labelStyle: smallTextStyle(color: AllColor.greyColor),
                errorStyle: TextStyle(color: Colors.redAccent, fontSize: 16.0),
                prefixIcon: Icon(
                  LineIcons.sortAmountDown,
                  color: AllColor.black,
                ),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5.0))),
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    value: selectedValue,
                    isDense: true,
                    onChanged: onChanged,
                    items: dropdownList.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Container(
                          width: screenWidth * 0.5,
                          child: smallText(
                              value.split(AllString.splitText).first,
                              color: AllColor.black),
                        ),
                      );
                    }).toList())));
      }),
    );
