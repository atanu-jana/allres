import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allText.dart';
import 'package:hr/util/allTextStyle.dart';
import 'package:hr/util/checkApiValueValid.dart';

customRowDetails(
    {required double width,
    required double widthTitle,
    required String title,
    required String value}) {
  return Container(
    width: width,
    padding: EdgeInsets.symmetric(vertical: screenWidth * 0.01),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: widthTitle,
          child: Text(
            title + " :",
            maxLines: 1,
            style: smallTextStyle(
                color: AllColor.black, fontWeight: FontWeight.bold),
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.01),
        ),
        Container(
          width: (width - widthTitle) - 15,
          child: Text(checkApiValueValid(value)?AllString.na:value,
              maxLines: 5,
              overflow: TextOverflow.ellipsis,
              style: normalTextStyle(
                color: value.contains("Approved") || value == AllString.continuee
                    ? AllColor.deepGreen
                    : value == "Reimbursment"
                        ? AllColor.indigo
                        : value.contains("Rejected")
                            ? AllColor.red
                            : value.contains("Pending") 
                                ? AllColor.deepYellow
                                : AllColor.black,
              )),
        ),
      ],
    ),
  );
}
