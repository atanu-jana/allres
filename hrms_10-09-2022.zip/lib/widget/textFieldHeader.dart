import 'package:flutter/material.dart';
import 'package:hr/main.dart';
import 'package:hr/res/allColors.dart';
import 'package:hr/res/allString.dart';
import 'package:hr/util/allText.dart';

textFieldHeader(String title,{FontWeight fontWeight=FontWeight.normal,bool center=false}) => Container(
      margin: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.03, vertical: screenWidth * 0.01),
      alignment: center? Alignment.center:Alignment.centerLeft,
      child: normalText(title+ ": ",
      fontWeight:fontWeight,
          color: AllColor.black),
    );
