import 'package:flutter/material.dart';

class AllColor {
  static Color appBackground = Color(0xFFE9E9E9);
  static Color tableBackground = Color(0xff276678);

  static Color white = Color(0xffffffff);
  static Color lightYellow = Color(0xFFFFEE50);
  static Color yellow = Color(0xFFD3BE06);
  static Color deepYellow = Color(0xFFffa000);
  static Color lightBlack = Color(0xfff2f2f4);
  static Color deepGrey = Color(0xff757575);
  static Color green = Color(0xFF1faa00);
  static Color indigo = Colors.indigo;
  static Color blue = Colors.blue;
  static Color blueGrey = Colors.blueGrey;
  static Color lightBlueGrey = Color(0xffeceff1);
  static Color red = Color(0xFFFF0000);
  static Color orange = Color(0xFFff5722);
  static Color pink = Color(0xFFa00037);
  static Color amber = Color(0xFFac1900);
  static Color purple = Color(0xFF38006b);
  static Color black = Color(0xFF000000);
  static Color deepGreen = Color.fromARGB(255, 0, 105, 25);
  static Color lightGrey = Color(0xFFe0e0e0);
  static Color textColor = Color(0xFF010101);
  static Color transparentColor = Colors.transparent;
  static Color greyColor = Colors.grey;
  static Color workPlanParent = Color(0xffffa726);
 
 
  static Color primaryColor = Color(0xff25388E); // Primary
  static Color primaryDeepColor = Color(0xff25388E); // Primary Dark * Appbar/Button *
  static Color accentColor = Color.fromRGBO(0, 212, 255, 1); // Accent
  // static Color primaryColor = Color(0xFF2979ff); // Primary
  // static Color primaryDeepColor = Color(0xFF0086c3); // Primary Dark * Appbar/Button *
  // static Color accentColor = Color(0xFF5d4bf7); // Accent
}



/*
--header-bgcolor: #fff;
    --header-textcolor:#000;
    --sub-header-bgcolor:#fff;
    --sub-header-textcolor:#000;
    --page-bgcolor:#e4e5e6;
    --main-container-bgcolor:#eceff1;
    --footer-bgcolor:#eeea092;
    --footer-textcolor:#fff;
    --hyperlink-color:#636f7f;
    --sidenav-bg-color:#636f7f;
    --sidenav-nav-link-textcolor:#fff;
    --sidenav-active-nav-link-bgcolor:#20a8d8;
    --sidenav-active-nav-link-textcolor:#fff;
    --sidenav-open-close-icon-color:#20a8d8;
    --sidenav-sandwich-menu-color:#20a8d8;
    --sidebar-nav-link-nav-icon-color:red;
    --group-box-border-color:#ccc;
    --group-box-bgcolor:#fff;
    --group-box-header-text-color:#000;
    --component-border-color:#ccc;
    --component-text-color:#ccc;
    --component-selected-border-color:#768197;
    --component-selected-text-color:#768197;
    --table-header-bgcolor:#768197;
    --table-header-textcolor:#fff;
    --table-body-textcolor:#000;
    --table-header-sorting-color:#fff;
    --table-header-sorting-active-color:#000;
    --alternating-table-even-color:rgba(0, 0, 0, 0.025);
    --alternating-table-odd-color:#fff;
    /* for dashboard */
    --dashboard-box1-image-bgcolor:#7ebb42;
  --dashboard-box1-bordercolor:#6a9e30;
  --dashboard-box2-image-bgcolor:#3e82d7;
  --dashboard-box2-bordercolor:#1e68c7;
  --dashboard-box3-image-bgcolor:#768197;
  --dashboard-box3-bordercolor:#5b6984;
  --dashboard-box4-image-bgcolor:#8841a7;
  --dashboard-box4-bordercolor:#6c3684;
  --dashboard-box5-image-bgcolor:#384e65;
  --dashboard-box5-bordercolor:#2b3c4c;
  --dashboard-box6-image-bgcolor:#18bb9c;
  --dashboard-box6-bordercolor:#169a82;
  --dashboard-box7-image-bgcolor:#f3a038;
  --dashboard-box7-bordercolor:#e8960f;
  --dashboard-box8-image-bgcolor:#c54e36;
  --dashboard-box8-bordercolor:#b93727;
  /* buttons */
  --buttons-text-color:#fff;
  --add-button:#14afa1;
  --listing-button:#14afa1;
  --save-button:#7ebb42;
  --cancel-button:#b93727;
  --download-button:#768197;
  --status-active:#7ebb42;
  --status-inactive:#b93727;
  /* icons */
  --complete-icon:#7ebb42;
  --incomplete-icon:#b93727;
  --logout-icon:#14afa1;
  --search-icon:#14afa1;
  --refresh-icon:#14afa1;
  --edit-icon:#7ebb42;
  --delete-icon:#b93727;
  --visibile-icon:#14afa1;
  --locator-icon:#14afa1;
  --upload-icon:#14afa1;
  --countbgcolor:#768197;
  /* tab */
  --tab-bg-color:#768197;
  --tab-text-color:#fff;
  --tab-active-bg-color:#fff;
  --tab-active-text-color:#768197;
  --navigate-light-color:#ccc;
  --navigate-dark-color:#000;
*/
