class AllUrls {
  static String productionUrl = "http://hrmsapi.easeurbiz.com:3013/";
  static String localUrl = "http://192.168.1.250:3013/";
  static String staggingUrl = "http://13.233.206.61:3017/";

  static String baseUrl = productionUrl;

  static String hrmsLoginPost = baseUrl + "hrmsLogin";
  static String addEmployeeAttendance = baseUrl + "addEmployeeAttendance";
  static String getEmployeeProfileDetails =
      baseUrl + "getEmployeeProfileDetails";
  // baseUrl + "getEmployeeProfileInformation";
  static String breakStartEnd = baseUrl + "breakStartEnd";
  static String pendingCollaboration = baseUrl + "pendingCollaboration";
  static String updateAppVersion = baseUrl + "updateAppVersion";
  static String companyPayment = baseUrl + "companyPayment";
  static String getCommonData = baseUrl + "getCommonData";
  static String getModelByDivision = baseUrl + "getModelByDivision";
  static String getEmployeeDealer = baseUrl + "getEmployeeDealer";
  static String addEmployeeKpiTemplate = baseUrl + "addEmployeeKpiTemplate";
  static String addOrder = baseUrl + "addOrder";
  static String getOrderList = baseUrl + "getOrderList";
  static String getVisitDetails = baseUrl + "getVisitDetails";
  static String getExpencelist = baseUrl + "getExpencelist";
  static String getPaymentlist = baseUrl + "getPaymentlist";
  static String addEmployeeExpence = baseUrl + "addEmployeeExpence";
  static String getAttendenceList = baseUrl + "getAttendenceList";
  static String getEmployeePayslip = baseUrl + "getEmployeePayslip";
  static String getEmployeeBreakList = baseUrl + "getEmployeeBreakList";
  static String employeeVisitOut = baseUrl + "employeeVisitOut";
  static String employeeVisitIn = baseUrl + "employeeVisitIn";
  static String getLocationTrakingDetails =
      baseUrl + "getLocationTrakingDetails";
  static String addEmployeePosition = baseUrl + "addEmployeePosition";
  static String getEmployeeDetailsById = baseUrl + "getEmployeeDetailsById";
  static String getVisitOutField = baseUrl + "getVisitOutField";
  static String uploadImage = baseUrl + "uploadImage";
  static String uploadEmployeeVisitImage = baseUrl + "uploadEmployeeVisitImage";
  static String uploadVideo = baseUrl + "uploadVideo";
  static String expanseReview = baseUrl + "expanseReview";
  static String deleteCollaboration = baseUrl + "deleteCollaboration";

  static String reimbursementMasterDataPost =
      baseUrl + "reimbursementMasterData";
  // static String uploadDocumentPost = baseUrl + "uploadDocument";
  // static String dealerListPost = baseUrl + "dealerList";
  static String categoryListPost = baseUrl + "categoryList";
  // static String allProductListPost = baseUrl + "allProductList";
  // static String productListPost = baseUrl2 + "productList";
  // static String productDivisionListPost = baseUrl2 + "productDivisionList";
  static String productDivisionListPost = baseUrl + "categoryList";
  // static String productListPost = baseUrl + "productList";
  // static String addDealerOrderPost = baseUrl + "addDealerOrder";
  static String addPaymentPost = baseUrl + "addPayment";
  static String addConveyancePost = baseUrl + "addConveyance";
  static String addKraTemplateForCompany = baseUrl + "addKraTemplateForCompany";
  static String addEmployeeKraTemplate    = baseUrl + "addEmployeeKraTemplate";
  static String conveyanceListByIdPost = baseUrl + "conveyanceListById";
  static String reviewConveyancePost = baseUrl + "reviewConveyance";

  static String getLeaveList = baseUrl + "getLeaveList";
  static String getEmployeeLeaveBalance = baseUrl + "getEmployeeLeaveBalance";
  static String leaveApproval = baseUrl + "leaveApproval";
  static String applyLeave = baseUrl + "applyLeave";

  static String applyLoan = baseUrl + "applyLoan";
  static String addCompanyTemplate = baseUrl + "addCompanyTemplate";
  static String reviewEmployeeKpi = baseUrl + "reviewEmployeeKpi";
  static String getCompanyKpiTemplate = baseUrl + "getCompanyKpiTemplate";
  static String getLoanList = baseUrl + "getLoanList";
  static String approveLoan = baseUrl + "approveLoan";

  static String addSuggestion = baseUrl + "addSuggestion";
  static String getSuggestionList = baseUrl + "getSuggestionList";

  static String getHolidaynList = baseUrl + "getHolidaynList";

  static String getKRATemplateList = baseUrl + "getEmployeeKraTemplate";

  static String getKRATaskList = baseUrl + "getKraTask";
  static String getCompanyKraTemplate = baseUrl + "getCompanyKraTemplate";

  static String getKRAGraphList = baseUrl + "getKragraph";

  static String getKRApercentageList = baseUrl + "getKraPercentage";

  static String getKRApercentageDetailsList =
      baseUrl + "getKraPercentageDetails";

  static String getAcceptReviewRating = baseUrl + "acceptKpiReviewRating";

  static String getTeamKPIList = baseUrl + "getKpiByKra";

  static String getEmployeeKpiReview = baseUrl + "employeeKpiReview";

  static String getConfigData = baseUrl + "getConfigData";
  static String hrmsMenuAccess = baseUrl + "hrmsMenuAccess";

  static String getServiceList = baseUrl + "getServiceList";
  static String userConfigData = baseUrl + "userConfigData";

  // *** TGTS ---------------------------------------------------
  static String statusList = baseUrl + "statusList";
  static String feedbackMessages = baseUrl + "feedbackMessages";
  static String requestStatus = baseUrl + "requestStatus";
  static String visitingPurpose = baseUrl + "visitingPurpose";
  static String allmeetingDate = baseUrl + "allmeetingDate";
  static String memberList = baseUrl + "memberList";
  static String allGoals = baseUrl + "allGoals";
  static String todaysCollaboration = baseUrl + "todaysCollaboration";
  static String todaysCollaborationStatus =
      baseUrl + "todaysCollaborationStatus";
  static String todaysReports = baseUrl + "todaysReports";
  static String goalPlanLists = baseUrl + "goalPlanLists";
  static String viewEmployeeFeedbackList = baseUrl + "viewEmployeeFeedbackList";
  static String allEvaluations = baseUrl + "allEvaluations";
  static String evaluationPlanLists = baseUrl + "evaluationPlanLists";
  static String dailyPlanList = baseUrl + "dailyPlanList";
  static String otherEmloyeesFeedbackList =
      baseUrl + "otherEmloyeesFeedbackList";
  static String projectList = baseUrl + "projectList";
  static String addGoalPlan = baseUrl + "addGoalPlan";
  static String dailyPlanStatusUpdate = baseUrl + "dailyPlanStatusUpdate";
  static String dailyCollaborationStaus = baseUrl + "dailyCollaborationStaus";
  static String addDailyPlan = baseUrl + "addDailyPlan";
  static String addEmployeeFeedback = baseUrl + "addEmployeeFeedback";
  static String editEmployeeFeedback = baseUrl + "editEmployeeFeedback";
  static String updateWeekStatus = baseUrl + "updateWeekStatus";
  static String getFailureStatus = baseUrl + "getFailureStatus";
  static String getWeekPlanByDate = baseUrl + "getWeekPlanByDate";
  static String requestTypeList = baseUrl + "requestTypeList";
  static String taskTypeList = baseUrl + "taskTypeList";
  static String departmentList = baseUrl + "departmentList";
  static String departmentWiseEmployee = baseUrl + "departmentWiseEmployee";
  static String addEmployeeRequest = baseUrl + "addEmployeeRequest";
  static String addEmployeeTask = baseUrl + "addEmployeeTask";
  static String reassignEmployeeTask = baseUrl + "reassignEmployeeTask";
  static String taskApproval = baseUrl + "taskApproval";
  static String pendingTaskApproval = baseUrl + "pendingTaskApproval";
  static String closedTask = baseUrl + "closedTask";
  static String employeeRequestList = baseUrl + "employeeRequestList";
  static String viewEmployeeTask = baseUrl + "viewEmployeeTask";
  static String employeePendingRequest = baseUrl + "employeePendingRequest";
  static String updateEmployeeRequest = baseUrl + "updateEmployeeRequest";
  static String updateTaskStatus = baseUrl + "updateTaskStatus";
  static String getKraSchedule = baseUrl + "getKraSchedule";
}

// class AllUrls {
//   static String baseUrl =
//       "http://192.168.1.250:3005/";
//   static String baseUrl2 =
//       "http://smartcareapi.easeurbiz.com:3007/";

//   static String easeUrBizUserLoginPost = baseUrl + "easeUrBizUserLogin";
//   static String attendancePunchInOutPost = baseUrl + "attendancePunchInOut";
//   static String startEndBreakPost = baseUrl + "startEndBreak";
//   static String reimbursementMasterDataPost = baseUrl + "reimbursementMasterData";
//   static String applyReimbursementPost = baseUrl + "applyReimbursement";
//   static String uploadDocumentPost = baseUrl + "uploadDocument";
//   static String reimbursementByIdPost = baseUrl + "reimbursementById";
//   static String dealerOrderListByIdPost = baseUrl + "dealerOrderListById";
//   // static String dealerOrderListPost = baseUrl + "dealerOrderList";
//   static String paymentListByIdPost = baseUrl + "paymentListById";
//   static String getAttendanceByIdPost = baseUrl + "getAttendanceById";
//   static String dealerListPost = baseUrl + "dealerList";
//   static String categoryListPost = baseUrl + "categoryList";
//   // static String allProductListPost = baseUrl + "allProductList";
//   // static String productListPost = baseUrl2 + "productList";
//   static String productListPost = baseUrl + "allProductList";
//   // static String productDivisionListPost = baseUrl2 + "productDivisionList";
//   static String productDivisionListPost = baseUrl + "categoryList";
//   // static String productListPost = baseUrl + "productList";
//   static String addDealerOrderPost = baseUrl + "addDealerOrder";
//   static String employeeVisitCheckOutPost = baseUrl + "employeeVisitCheckOut";
//   static String employeeVisitCheckInPost = baseUrl + "employeeVisitCheckIn";
//   static String addPaymentPost = baseUrl + "addPayment";
//   static String addConveyancePost = baseUrl + "addConveyance";
//   static String conveyanceListByIdPost = baseUrl + "conveyanceListById";
//   static String positionConfigPost = baseUrl + "positionConfig";
//   static String addEmployeePositionPost = baseUrl + "addEmployeePosition";
//   static String employeeBreakListPost = baseUrl + "employeeBreakList";
//   static String getEmployeeDetailsPost = baseUrl + "getEmployeeDetails";
//   static String reimbursementReviewPost = baseUrl + "reimbursementReview";
//   static String reviewConveyancePost = baseUrl + "reviewConveyance";

// }
