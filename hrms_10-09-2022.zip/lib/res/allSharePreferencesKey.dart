class AllSharedPreferencesKey {
  static String companyLogo = "companyLogo";
  static String userTypeId = "userTypeId";
  static String positionForSend = "positionForSend";
  static String companyId = "companyId";
  static String officeType = "officeType";
  static String companyName = "companyName";
  static String companyContactNo = "companyContactNo";
  static String userRoleName = "userRoleName";
  static String designation = "designation";
  static String companyEmailId = "companyEmailId";
  static String individualId = "individualId";
  static String companyAddress = "companyAddress";
  static String district = "district";
  static String companyPincode = "companyPincode";
  static String userId = "userId";
  static String firstName = "firstName";
  static String branchName = "branchName";
  static String branchId = "branchId";
  static String individualTypeId = "individualTypeId";
  static String image = "image";
  static String userType = "userType";
  static String token = "token";
  static String address = "address";
  static String location = "location";
  static String latitude = "latitude";
  static String sendLatitude = "latitude";
  static String longitude = "longitude";
  static String sendLongitude = "longitude";

  static String userConfigSetting = "userConfigSetting";
  static String productList = "productList";
  static String contact1 = "contact1";
  static String contact2 = "contact2";
  static String dob = "dob";
  static String email = "email";
  static String checkInOption = "checkInOption";
  static String checkInOptionName = "checkInOptionName";
  static String reportingManager = "reportingManager";
  static String checkInOptionNameWithId = "checkInOptionNameWithId";
  static String allowance = "allowance";
  static String timeinterval = "timeinterval";
 



  static String allDealerJson = "allDealerJson";
  static String allCheckOutFields = "allCheckOutFields";
  static String allCommonDataJson = "allCommonDataJson";


  

// ! *** Colors preference  
  static String colorPrimary = "colorPrimary";
  static String colorPrimaryDark = "colorPrimaryDark";
  static String colorAccent = "colorAccent";



  
  static String checkInId = "checkInId";
  static String attendanceStatus = "attendanceStatus";
  static String punchInId = "punchInId";
  static String breakPunchId = "breakPunchId";
}
